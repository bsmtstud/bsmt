import React, { useState, useCallback } from 'react';

// ============================================================================
// THE BASEMENT - AI-Powered Video Production Platform
// ============================================================================

// Icons as simple SVG components
const Icons = {
  Home: () => (
    <svg width="20" height="20" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2">
      <path d="M3 9l9-7 9 7v11a2 2 0 0 1-2 2H5a2 2 0 0 1-2-2z"/>
      <polyline points="9,22 9,12 15,12 15,22"/>
    </svg>
  ),
  Folder: () => (
    <svg width="20" height="20" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2">
      <path d="M22 19a2 2 0 0 1-2 2H4a2 2 0 0 1-2-2V5a2 2 0 0 1 2-2h5l2 3h9a2 2 0 0 1 2 2z"/>
    </svg>
  ),
  Film: () => (
    <svg width="20" height="20" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2">
      <rect x="2" y="2" width="20" height="20" rx="2.18" ry="2.18"/>
      <line x1="7" y1="2" x2="7" y2="22"/><line x1="17" y1="2" x2="17" y2="22"/>
      <line x1="2" y1="12" x2="22" y2="12"/><line x1="2" y1="7" x2="7" y2="7"/>
      <line x1="2" y1="17" x2="7" y2="17"/><line x1="17" y1="17" x2="22" y2="17"/>
      <line x1="17" y1="7" x2="22" y2="7"/>
    </svg>
  ),
  Layout: () => (
    <svg width="20" height="20" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2">
      <rect x="3" y="3" width="18" height="18" rx="2" ry="2"/>
      <line x1="3" y1="9" x2="21" y2="9"/><line x1="9" y1="21" x2="9" y2="9"/>
    </svg>
  ),
  Scissors: () => (
    <svg width="20" height="20" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2">
      <circle cx="6" cy="6" r="3"/><circle cx="6" cy="18" r="3"/>
      <line x1="20" y1="4" x2="8.12" y2="15.88"/><line x1="14.47" y1="14.48" x2="20" y2="20"/>
      <line x1="8.12" y1="8.12" x2="12" y2="12"/>
    </svg>
  ),
  Users: () => (
    <svg width="20" height="20" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2">
      <path d="M17 21v-2a4 4 0 0 0-4-4H5a4 4 0 0 0-4 4v2"/>
      <circle cx="9" cy="7" r="4"/>
      <path d="M23 21v-2a4 4 0 0 0-3-3.87"/><path d="M16 3.13a4 4 0 0 1 0 7.75"/>
    </svg>
  ),
  Settings: () => (
    <svg width="20" height="20" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2">
      <circle cx="12" cy="12" r="3"/>
      <path d="M19.4 15a1.65 1.65 0 0 0 .33 1.82l.06.06a2 2 0 0 1 0 2.83 2 2 0 0 1-2.83 0l-.06-.06a1.65 1.65 0 0 0-1.82-.33 1.65 1.65 0 0 0-1 1.51V21a2 2 0 0 1-2 2 2 2 0 0 1-2-2v-.09A1.65 1.65 0 0 0 9 19.4a1.65 1.65 0 0 0-1.82.33l-.06.06a2 2 0 0 1-2.83 0 2 2 0 0 1 0-2.83l.06-.06a1.65 1.65 0 0 0 .33-1.82 1.65 1.65 0 0 0-1.51-1H3a2 2 0 0 1-2-2 2 2 0 0 1 2-2h.09A1.65 1.65 0 0 0 4.6 9a1.65 1.65 0 0 0-.33-1.82l-.06-.06a2 2 0 0 1 0-2.83 2 2 0 0 1 2.83 0l.06.06a1.65 1.65 0 0 0 1.82.33H9a1.65 1.65 0 0 0 1-1.51V3a2 2 0 0 1 2-2 2 2 0 0 1 2 2v.09a1.65 1.65 0 0 0 1 1.51 1.65 1.65 0 0 0 1.82-.33l.06-.06a2 2 0 0 1 2.83 0 2 2 0 0 1 0 2.83l-.06.06a1.65 1.65 0 0 0-.33 1.82V9a1.65 1.65 0 0 0 1.51 1H21a2 2 0 0 1 2 2 2 2 0 0 1-2 2h-.09a1.65 1.65 0 0 0-1.51 1z"/>
    </svg>
  ),
  Plus: () => (
    <svg width="20" height="20" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2">
      <line x1="12" y1="5" x2="12" y2="19"/><line x1="5" y1="12" x2="19" y2="12"/>
    </svg>
  ),
  ChevronRight: () => (
    <svg width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2">
      <polyline points="9,18 15,12 9,6"/>
    </svg>
  ),
  ChevronDown: () => (
    <svg width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2">
      <polyline points="6,9 12,15 18,9"/>
    </svg>
  ),
  Upload: () => (
    <svg width="20" height="20" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2">
      <path d="M21 15v4a2 2 0 0 1-2 2H5a2 2 0 0 1-2-2v-4"/>
      <polyline points="17,8 12,3 7,8"/><line x1="12" y1="3" x2="12" y2="15"/>
    </svg>
  ),
  Image: () => (
    <svg width="20" height="20" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2">
      <rect x="3" y="3" width="18" height="18" rx="2" ry="2"/>
      <circle cx="8.5" cy="8.5" r="1.5"/><polyline points="21,15 16,10 5,21"/>
    </svg>
  ),
  Sparkles: () => (
    <svg width="20" height="20" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2">
      <path d="M12 3l1.5 4.5L18 9l-4.5 1.5L12 15l-1.5-4.5L6 9l4.5-1.5L12 3z"/>
      <path d="M5 19l1 3 1-3 3-1-3-1-1-3-1 3-3 1 3 1z"/>
      <path d="M19 12l1 2 1-2 2-1-2-1-1-2-1 2-2 1 2 1z"/>
    </svg>
  ),
  Edit: () => (
    <svg width="20" height="20" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2">
      <path d="M11 4H4a2 2 0 0 0-2 2v14a2 2 0 0 0 2 2h14a2 2 0 0 0 2-2v-7"/>
      <path d="M18.5 2.5a2.121 2.121 0 0 1 3 3L12 15l-4 1 1-4 9.5-9.5z"/>
    </svg>
  ),
  Camera: () => (
    <svg width="20" height="20" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2">
      <path d="M23 19a2 2 0 0 1-2 2H3a2 2 0 0 1-2-2V8a2 2 0 0 1 2-2h4l2-3h6l2 3h4a2 2 0 0 1 2 2z"/>
      <circle cx="12" cy="13" r="4"/>
    </svg>
  ),
  Play: () => (
    <svg width="20" height="20" viewBox="0 0 24 24" fill="currentColor">
      <polygon points="5,3 19,12 5,21"/>
    </svg>
  ),
  Share: () => (
    <svg width="20" height="20" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2">
      <circle cx="18" cy="5" r="3"/><circle cx="6" cy="12" r="3"/><circle cx="18" cy="19" r="3"/>
      <line x1="8.59" y1="13.51" x2="15.42" y2="17.49"/><line x1="15.41" y1="6.51" x2="8.59" y2="10.49"/>
    </svg>
  ),
  MessageCircle: () => (
    <svg width="20" height="20" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2">
      <path d="M21 11.5a8.38 8.38 0 0 1-.9 3.8 8.5 8.5 0 0 1-7.6 4.7 8.38 8.38 0 0 1-3.8-.9L3 21l1.9-5.7a8.38 8.38 0 0 1-.9-3.8 8.5 8.5 0 0 1 4.7-7.6 8.38 8.38 0 0 1 3.8-.9h.5a8.48 8.48 0 0 1 8 8v.5z"/>
    </svg>
  ),
  History: () => (
    <svg width="20" height="20" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2">
      <path d="M3 3v5h5"/><path d="M3.05 13A9 9 0 1 0 6 5.3L3 8"/>
      <path d="M12 7v5l4 2"/>
    </svg>
  ),
  Check: () => (
    <svg width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="3">
      <polyline points="20,6 9,17 4,12"/>
    </svg>
  ),
  X: () => (
    <svg width="20" height="20" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2">
      <line x1="18" y1="6" x2="6" y2="18"/><line x1="6" y1="6" x2="18" y2="18"/>
    </svg>
  ),
  ArrowLeft: () => (
    <svg width="20" height="20" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2">
      <line x1="19" y1="12" x2="5" y2="12"/><polyline points="12,19 5,12 12,5"/>
    </svg>
  ),
  Tv: () => (
    <svg width="20" height="20" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2">
      <rect x="2" y="7" width="20" height="15" rx="2" ry="2"/>
      <polyline points="17,2 12,7 7,2"/>
    </svg>
  ),
  Layers: () => (
    <svg width="20" height="20" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2">
      <polygon points="12,2 2,7 12,12 22,7 12,2"/>
      <polyline points="2,17 12,22 22,17"/><polyline points="2,12 12,17 22,12"/>
    </svg>
  ),
  Menu: () => (
    <svg width="20" height="20" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2">
      <line x1="3" y1="6" x2="21" y2="6"/><line x1="3" y1="12" x2="21" y2="12"/><line x1="3" y1="18" x2="21" y2="18"/>
    </svg>
  ),
  FileText: () => (
    <svg width="20" height="20" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2">
      <path d="M14 2H6a2 2 0 0 0-2 2v16a2 2 0 0 0 2 2h12a2 2 0 0 0 2-2V8z"/>
      <polyline points="14,2 14,8 20,8"/><line x1="16" y1="13" x2="8" y2="13"/>
      <line x1="16" y1="17" x2="8" y2="17"/><polyline points="10,9 9,9 8,9"/>
    </svg>
  ),
  Palette: () => (
    <svg width="20" height="20" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2">
      <circle cx="13.5" cy="6.5" r="0.5" fill="currentColor"/>
      <circle cx="17.5" cy="10.5" r="0.5" fill="currentColor"/>
      <circle cx="8.5" cy="7.5" r="0.5" fill="currentColor"/>
      <circle cx="6.5" cy="12.5" r="0.5" fill="currentColor"/>
      <path d="M12 2C6.5 2 2 6.5 2 12s4.5 10 10 10c.926 0 1.648-.746 1.648-1.688 0-.437-.18-.835-.437-1.125-.29-.289-.438-.652-.438-1.125a1.64 1.64 0 0 1 1.668-1.668h1.996c3.051 0 5.555-2.503 5.555-5.555C21.965 6.012 17.461 2 12 2z"/>
    </svg>
  ),
  Sliders: () => (
    <svg width="20" height="20" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2">
      <line x1="4" y1="21" x2="4" y2="14"/><line x1="4" y1="10" x2="4" y2="3"/>
      <line x1="12" y1="21" x2="12" y2="12"/><line x1="12" y1="8" x2="12" y2="3"/>
      <line x1="20" y1="21" x2="20" y2="16"/><line x1="20" y1="12" x2="20" y2="3"/>
      <line x1="1" y1="14" x2="7" y2="14"/><line x1="9" y1="8" x2="15" y2="8"/>
      <line x1="17" y1="16" x2="23" y2="16"/>
    </svg>
  ),
  Mic: () => (
    <svg width="20" height="20" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2">
      <path d="M12 1a3 3 0 0 0-3 3v8a3 3 0 0 0 6 0V4a3 3 0 0 0-3-3z"/>
      <path d="M19 10v2a7 7 0 0 1-14 0v-2"/><line x1="12" y1="19" x2="12" y2="23"/>
      <line x1="8" y1="23" x2="16" y2="23"/>
    </svg>
  ),
  Wand: () => (
    <svg width="20" height="20" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2">
      <path d="M15 4V2"/><path d="M15 16v-2"/><path d="M8 9h2"/><path d="M20 9h2"/>
      <path d="M17.8 11.8L19 13"/><path d="M15 9h0"/><path d="M17.8 6.2L19 5"/>
      <path d="m3 21 9-9"/><path d="M12.2 6.2L11 5"/>
    </svg>
  ),
  Zap: () => (
    <svg width="20" height="20" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2">
      <polygon points="13,2 3,14 12,14 11,22 21,10 12,10 13,2"/>
    </svg>
  ),
  Volume: () => (
    <svg width="20" height="20" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2">
      <polygon points="11,5 6,9 2,9 2,15 6,15 11,19 11,5"/>
      <path d="M19.07 4.93a10 10 0 0 1 0 14.14"/>
      <path d="M15.54 8.46a5 5 0 0 1 0 7.07"/>
    </svg>
  ),
  Gauge: () => (
    <svg width="20" height="20" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2">
      <path d="M12 2a10 10 0 1 0 10 10"/><path d="M12 12l5-5"/>
      <path d="M12 6v2"/><path d="M6 12h2"/><path d="M7.8 7.8l1.4 1.4"/>
    </svg>
  ),
  TrendingUp: () => (
    <svg width="20" height="20" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2">
      <polyline points="23,6 13.5,15.5 8.5,10.5 1,18"/>
      <polyline points="17,6 23,6 23,12"/>
    </svg>
  ),
  Hash: () => (
    <svg width="20" height="20" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2">
      <line x1="4" y1="9" x2="20" y2="9"/><line x1="4" y1="15" x2="20" y2="15"/>
      <line x1="10" y1="3" x2="8" y2="21"/><line x1="16" y1="3" x2="14" y2="21"/>
    </svg>
  ),
  Eye: () => (
    <svg width="20" height="20" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2">
      <path d="M1 12s4-8 11-8 11 8 11 8-4 8-11 8-11-8-11-8z"/>
      <circle cx="12" cy="12" r="3"/>
    </svg>
  ),
  MapPin: () => (
    <svg width="20" height="20" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2">
      <path d="M21 10c0 7-9 13-9 13s-9-6-9-13a9 9 0 0 1 18 0z"/>
      <circle cx="12" cy="10" r="3"/>
    </svg>
  ),
  Box: () => (
    <svg width="20" height="20" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2">
      <path d="M21 16V8a2 2 0 0 0-1-1.73l-7-4a2 2 0 0 0-2 0l-7 4A2 2 0 0 0 3 8v8a2 2 0 0 0 1 1.73l7 4a2 2 0 0 0 2 0l7-4A2 2 0 0 0 21 16z"/>
      <polyline points="3.27,6.96 12,12.01 20.73,6.96"/><line x1="12" y1="22.08" x2="12" y2="12"/>
    </svg>
  ),
  Shirt: () => (
    <svg width="20" height="20" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2">
      <path d="M20.38 3.46L16 2a4 4 0 0 1-8 0L3.62 3.46a2 2 0 0 0-1.34 2.23l.58 3.47a1 1 0 0 0 .99.84H6v10c0 1.1.9 2 2 2h8a2 2 0 0 0 2-2V10h2.15a1 1 0 0 0 .99-.84l.58-3.47a2 2 0 0 0-1.34-2.23z"/>
    </svg>
  ),
  Car: () => (
    <svg width="20" height="20" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2">
      <path d="M14 16H9m10 0h3v-3.15a1 1 0 0 0-.84-.99L16 11l-2.7-3.6a1 1 0 0 0-.8-.4H5.24a2 2 0 0 0-1.8 1.1l-.8 1.63A6 6 0 0 0 2 12.42V16h2"/>
      <circle cx="6.5" cy="16.5" r="2.5"/><circle cx="16.5" cy="16.5" r="2.5"/>
    </svg>
  ),
  AlertCircle: () => (
    <svg width="20" height="20" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2">
      <circle cx="12" cy="12" r="10"/><line x1="12" y1="8" x2="12" y2="12"/>
      <line x1="12" y1="16" x2="12.01" y2="16"/>
    </svg>
  ),
  ChevronLeft: () => (
    <svg width="20" height="20" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2">
      <polyline points="15,18 9,12 15,6"/>
    </svg>
  ),
  Download: () => (
    <svg width="20" height="20" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2">
      <path d="M21 15v4a2 2 0 0 1-2 2H5a2 2 0 0 1-2-2v-4"/>
      <polyline points="7,10 12,15 17,10"/><line x1="12" y1="15" x2="12" y2="3"/>
    </svg>
  ),
  RefreshCw: () => (
    <svg width="20" height="20" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2">
      <polyline points="23,4 23,10 17,10"/><polyline points="1,20 1,14 7,14"/>
      <path d="M3.51 9a9 9 0 0 1 14.85-3.36L23 10M1 14l4.64 4.36A9 9 0 0 0 20.49 15"/>
    </svg>
  ),
  MousePointer: () => (
    <svg width="20" height="20" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2">
      <path d="M3 3l7.07 16.97 2.51-7.39 7.39-2.51L3 3z"/>
      <path d="M13 13l6 6"/>
    </svg>
  ),
  Type: () => (
    <svg width="20" height="20" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2">
      <polyline points="4,7 4,4 20,4 20,7"/>
      <line x1="9" y1="20" x2="15" y2="20"/>
      <line x1="12" y1="4" x2="12" y2="20"/>
    </svg>
  ),
  SkipBack: () => (
    <svg width="20" height="20" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2">
      <polygon points="19,20 9,12 19,4 19,20"/>
      <line x1="5" y1="19" x2="5" y2="5"/>
    </svg>
  ),
  SkipForward: () => (
    <svg width="20" height="20" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2">
      <polygon points="5,4 15,12 5,20 5,4"/>
      <line x1="19" y1="5" x2="19" y2="19"/>
    </svg>
  ),
  Search: () => (
    <svg width="20" height="20" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2">
      <circle cx="11" cy="11" r="8"/><line x1="21" y1="21" x2="16.65" y2="16.65"/>
    </svg>
  ),
  Save: () => (
    <svg width="20" height="20" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2">
      <path d="M19 21H5a2 2 0 01-2-2V5a2 2 0 012-2h11l5 5v11a2 2 0 01-2 2z"/>
      <polyline points="17,21 17,13 7,13 7,21"/><polyline points="7,3 7,8 15,8"/>
    </svg>
  ),
  User: () => (
    <svg width="20" height="20" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2">
      <path d="M20 21v-2a4 4 0 00-4-4H8a4 4 0 00-4 4v2"/><circle cx="12" cy="7" r="4"/>
    </svg>
  ),
};

// ============================================================================
// STYLE CONSTANTS
// ============================================================================
const colors = {
  bg: {
    primary: '#0a0a0b',
    secondary: '#111113',
    tertiary: '#1a1a1d',
    elevated: '#222225',
    hover: '#2a2a2e',
  },
  accent: {
    primary: '#6366f1',
    primaryHover: '#818cf8',
    secondary: '#3b82f6',
    success: '#22c55e',
    warning: '#f59e0b',
    error: '#ef4444',
  },
  text: {
    primary: '#fafafa',
    secondary: '#a1a1aa',
    tertiary: '#71717a',
    inverse: '#0a0a0b',
  },
  border: {
    subtle: '#27272a',
    default: '#3f3f46',
    focus: '#6366f1',
  }
};

// ============================================================================
// GLOBAL STYLES
// ============================================================================
const globalStyles = `
  @import url('https://fonts.googleapis.com/css2?family=Space+Grotesk:wght@300;400;500;600;700&family=JetBrains+Mono:wght@400;500&display=swap');
  
  * {
    margin: 0;
    padding: 0;
    box-sizing: border-box;
  }
  
  body {
    font-family: 'Space Grotesk', -apple-system, BlinkMacSystemFont, sans-serif;
    background: ${colors.bg.primary};
    color: ${colors.text.primary};
    line-height: 1.6;
    overflow: hidden;
  }
  
  ::-webkit-scrollbar {
    width: 8px;
    height: 8px;
  }
  
  ::-webkit-scrollbar-track {
    background: ${colors.bg.secondary};
  }
  
  ::-webkit-scrollbar-thumb {
    background: ${colors.border.default};
    border-radius: 4px;
  }
  
  ::-webkit-scrollbar-thumb:hover {
    background: ${colors.text.tertiary};
  }
  
  input, textarea, select, button {
    font-family: inherit;
  }
  
  ::selection {
    background: ${colors.accent.primary};
    color: white;
  }

  @keyframes fadeIn {
    from { opacity: 0; }
    to { opacity: 1; }
  }
  
  @keyframes slideUp {
    from { opacity: 0; transform: translateY(20px); }
    to { opacity: 1; transform: translateY(0); }
  }
  
  @keyframes slideIn {
    from { opacity: 0; transform: translateX(-20px); }
    to { opacity: 1; transform: translateX(0); }
  }
  
  @keyframes pulse {
    0%, 100% { opacity: 1; }
    50% { opacity: 0.5; }
  }
  
  @keyframes shimmer {
    0% { background-position: -200% 0; }
    100% { background-position: 200% 0; }
  }
`;

// ============================================================================
// DATA CONSTANTS
// ============================================================================
const FILM_STYLES = [
  { id: 'live-action', name: 'Live Action', icon: '🎬' },
  { id: 'anime', name: 'Anime', icon: '🎌' },
  { id: 'animated-2d', name: '2D Animated', icon: '✏️' },
  { id: 'animated-3d', name: '3D Animated', icon: '🎮' },
  { id: 'stop-motion', name: 'Stop Motion', icon: '🎭' },
  { id: 'documentary', name: 'Documentary', icon: '📹' },
  { id: 'mixed-media', name: 'Mixed Media', icon: '🎨' },
];

const GENRES = [
  { id: 'drama', name: 'Drama', subgenres: ['Crime Drama', 'Legal Drama', 'Medical Drama', 'Family Drama', 'Period Drama'] },
  { id: 'comedy', name: 'Comedy', subgenres: ['Sitcom', 'Dark Comedy', 'Romantic Comedy', 'Sketch Comedy', 'Satire'] },
  { id: 'thriller', name: 'Thriller', subgenres: ['Psychological', 'Crime', 'Political', 'Conspiracy', 'Supernatural'] },
  { id: 'scifi', name: 'Sci-Fi', subgenres: ['Space Opera', 'Cyberpunk', 'Post-Apocalyptic', 'Time Travel', 'Hard Sci-Fi'] },
  { id: 'fantasy', name: 'Fantasy', subgenres: ['High Fantasy', 'Urban Fantasy', 'Dark Fantasy', 'Fairy Tale', 'Mythological'] },
  { id: 'horror', name: 'Horror', subgenres: ['Supernatural', 'Slasher', 'Psychological', 'Body Horror', 'Folk Horror'] },
  { id: 'action', name: 'Action', subgenres: ['Martial Arts', 'Spy', 'Heist', 'Military', 'Superhero'] },
  { id: 'romance', name: 'Romance', subgenres: ['Contemporary', 'Historical', 'Paranormal', 'Comedy', 'Drama'] },
  { id: 'mystery', name: 'Mystery', subgenres: ['Detective', 'Cozy', 'Noir', 'Police Procedural', 'Whodunit'] },
  { id: 'documentary', name: 'Documentary', subgenres: ['True Crime', 'Nature', 'Historical', 'Biographical', 'Social'] },
];

const TONES = [
  { id: 'dramatic', name: 'Dramatic', color: '#8b5cf6' },
  { id: 'suspenseful', name: 'Suspenseful', color: '#ef4444' },
  { id: 'humorous', name: 'Humorous', color: '#f59e0b' },
  { id: 'dark', name: 'Dark', color: '#374151' },
  { id: 'lighthearted', name: 'Light-hearted', color: '#10b981' },
  { id: 'emotional', name: 'Emotional', color: '#ec4899' },
  { id: 'satirical', name: 'Satirical', color: '#6366f1' },
  { id: 'serious', name: 'Serious', color: '#64748b' },
  { id: 'whimsical', name: 'Whimsical', color: '#14b8a6' },
  { id: 'gritty', name: 'Gritty', color: '#78716c' },
];

const VIDEO_STYLES = [
  { id: 'cinematic', name: 'Cinematic', preview: 'linear-gradient(135deg, #1a1a2e 0%, #16213e 100%)' },
  { id: 'vintage', name: 'Vintage', preview: 'linear-gradient(135deg, #8b7355 0%, #5c4033 100%)' },
  { id: 'noir', name: 'Film Noir', preview: 'linear-gradient(135deg, #1a1a1a 0%, #333333 100%)' },
  { id: 'neon', name: 'Neon', preview: 'linear-gradient(135deg, #ff006e 0%, #8338ec 50%, #3a86ff 100%)' },
  { id: 'pastel', name: 'Pastel', preview: 'linear-gradient(135deg, #ffecd2 0%, #fcb69f 100%)' },
  { id: 'anime', name: 'Anime', preview: 'linear-gradient(135deg, #667eea 0%, #764ba2 100%)' },
  { id: 'watercolor', name: 'Watercolor', preview: 'linear-gradient(135deg, #a8edea 0%, #fed6e3 100%)' },
  { id: 'comic', name: 'Comic Book', preview: 'linear-gradient(135deg, #f093fb 0%, #f5576c 100%)' },
  { id: 'documentary', name: 'Documentary', preview: 'linear-gradient(135deg, #4a5568 0%, #2d3748 100%)' },
  { id: 'dreamy', name: 'Dreamy', preview: 'linear-gradient(135deg, #e0c3fc 0%, #8ec5fc 100%)' },
  { id: 'grunge', name: 'Grunge', preview: 'linear-gradient(135deg, #434343 0%, #000000 100%)' },
  { id: 'pop', name: 'Pop Art', preview: 'linear-gradient(135deg, #ff5f6d 0%, #ffc371 100%)' },
];

// ============================================================================
// REUSABLE COMPONENTS
// ============================================================================

const Button = ({ children, variant = 'default', size = 'md', icon, onClick, disabled, style, ...props }) => {
  const baseStyles = {
    display: 'inline-flex',
    alignItems: 'center',
    justifyContent: 'center',
    gap: '8px',
    borderRadius: '8px',
    fontWeight: '500',
    cursor: disabled ? 'not-allowed' : 'pointer',
    transition: 'all 0.2s ease',
    border: 'none',
    opacity: disabled ? 0.5 : 1,
  };
  
  const variants = {
    default: {
      background: colors.bg.tertiary,
      color: colors.text.primary,
      border: `1px solid ${colors.border.subtle}`,
    },
    primary: {
      background: colors.accent.primary,
      color: 'white',
    },
    ghost: {
      background: 'transparent',
      color: colors.text.secondary,
    },
    outline: {
      background: 'transparent',
      color: colors.text.primary,
      border: `1px solid ${colors.border.default}`,
    },
  };
  
  const sizes = {
    sm: { padding: '6px 12px', fontSize: '13px' },
    md: { padding: '10px 16px', fontSize: '14px' },
    lg: { padding: '14px 24px', fontSize: '16px' },
  };
  
  return (
    <button
      onClick={onClick}
      disabled={disabled}
      style={{ ...baseStyles, ...variants[variant], ...sizes[size], ...style }}
      {...props}
    >
      {icon && <span style={{ display: 'flex' }}>{icon}</span>}
      {children}
    </button>
  );
};

const Input = ({ label, placeholder, value, onChange, type = 'text', multiline, rows = 3, style, ...props }) => {
  const inputStyles = {
    width: '100%',
    padding: '12px 16px',
    background: colors.bg.secondary,
    border: `1px solid ${colors.border.subtle}`,
    borderRadius: '8px',
    color: colors.text.primary,
    fontSize: '14px',
    outline: 'none',
    transition: 'border-color 0.2s ease, box-shadow 0.2s ease',
    resize: multiline ? 'vertical' : 'none',
  };
  
  const Component = multiline ? 'textarea' : 'input';
  
  return (
    <div style={{ marginBottom: '16px', ...style }}>
      {label && (
        <label style={{
          display: 'block',
          marginBottom: '8px',
          fontSize: '13px',
          fontWeight: '500',
          color: colors.text.secondary,
          textTransform: 'uppercase',
          letterSpacing: '0.5px',
        }}>
          {label}
        </label>
      )}
      <Component
        type={type}
        placeholder={placeholder}
        value={value}
        onChange={(e) => onChange(e.target.value)}
        rows={multiline ? rows : undefined}
        style={inputStyles}
        onFocus={(e) => {
          e.target.style.borderColor = colors.accent.primary;
          e.target.style.boxShadow = `0 0 0 3px ${colors.accent.primary}20`;
        }}
        onBlur={(e) => {
          e.target.style.borderColor = colors.border.subtle;
          e.target.style.boxShadow = 'none';
        }}
        {...props}
      />
    </div>
  );
};

const Select = ({ label, value, onChange, options, placeholder }) => {
  return (
    <div style={{ marginBottom: '16px' }}>
      {label && (
        <label style={{
          display: 'block',
          marginBottom: '8px',
          fontSize: '13px',
          fontWeight: '500',
          color: colors.text.secondary,
          textTransform: 'uppercase',
          letterSpacing: '0.5px',
        }}>
          {label}
        </label>
      )}
      <select
        value={value}
        onChange={(e) => onChange(e.target.value)}
        style={{
          width: '100%',
          padding: '12px 16px',
          background: colors.bg.secondary,
          border: `1px solid ${colors.border.subtle}`,
          borderRadius: '8px',
          color: value ? colors.text.primary : colors.text.tertiary,
          fontSize: '14px',
          outline: 'none',
          cursor: 'pointer',
        }}
      >
        <option value="" disabled>{placeholder}</option>
        {options.map((opt) => (
          <option key={opt.id || opt} value={opt.id || opt}>
            {opt.name || opt}
          </option>
        ))}
      </select>
    </div>
  );
};

const Chip = ({ label, selected, onClick, color }) => (
  <button
    onClick={onClick}
    style={{
      padding: '8px 16px',
      borderRadius: '20px',
      border: `1px solid ${selected ? (color || colors.accent.primary) : colors.border.subtle}`,
      background: selected ? `${color || colors.accent.primary}20` : 'transparent',
      color: selected ? (color || colors.accent.primary) : colors.text.secondary,
      fontSize: '13px',
      fontWeight: '500',
      cursor: 'pointer',
      transition: 'all 0.2s ease',
    }}
  >
    {label}
  </button>
);

const Card = ({ children, style, onClick, hoverable }) => (
  <div
    onClick={onClick}
    style={{
      background: colors.bg.secondary,
      border: `1px solid ${colors.border.subtle}`,
      borderRadius: '12px',
      padding: '20px',
      cursor: onClick ? 'pointer' : 'default',
      transition: 'all 0.2s ease',
      ...(hoverable && { ':hover': { borderColor: colors.accent.primary } }),
      ...style,
    }}
  >
    {children}
  </div>
);

const ProgressSteps = ({ steps, currentStep }) => (
  <div style={{
    display: 'flex',
    alignItems: 'center',
    justifyContent: 'center',
    gap: '8px',
    marginBottom: '32px',
  }}>
    {steps.map((step, index) => (
      <React.Fragment key={step}>
        <div style={{
          display: 'flex',
          alignItems: 'center',
          gap: '8px',
        }}>
          <div style={{
            width: '32px',
            height: '32px',
            borderRadius: '50%',
            display: 'flex',
            alignItems: 'center',
            justifyContent: 'center',
            fontSize: '14px',
            fontWeight: '600',
            background: index <= currentStep ? colors.accent.primary : colors.bg.tertiary,
            color: index <= currentStep ? 'white' : colors.text.tertiary,
            border: `2px solid ${index <= currentStep ? colors.accent.primary : colors.border.subtle}`,
          }}>
            {index < currentStep ? <Icons.Check /> : index + 1}
          </div>
          <span style={{
            fontSize: '14px',
            fontWeight: index === currentStep ? '600' : '400',
            color: index <= currentStep ? colors.text.primary : colors.text.tertiary,
          }}>
            {step}
          </span>
        </div>
        {index < steps.length - 1 && (
          <div style={{
            width: '40px',
            height: '2px',
            background: index < currentStep ? colors.accent.primary : colors.border.subtle,
            borderRadius: '1px',
          }} />
        )}
      </React.Fragment>
    ))}
  </div>
);

const ReferenceUpload = ({ label, description, images, onUpload, onRemove }) => (
  <div style={{ marginBottom: '24px' }}>
    <label style={{
      display: 'block',
      marginBottom: '8px',
      fontSize: '13px',
      fontWeight: '500',
      color: colors.text.secondary,
      textTransform: 'uppercase',
      letterSpacing: '0.5px',
    }}>
      {label}
    </label>
    {description && (
      <p style={{ fontSize: '13px', color: colors.text.tertiary, marginBottom: '12px' }}>
        {description}
      </p>
    )}
    <div style={{ display: 'flex', gap: '12px', flexWrap: 'wrap' }}>
      {images.map((img, idx) => (
        <div key={idx} style={{
          width: '100px',
          height: '100px',
          borderRadius: '8px',
          background: `url(${img}) center/cover`,
          position: 'relative',
        }}>
          <button
            onClick={() => onRemove(idx)}
            style={{
              position: 'absolute',
              top: '-8px',
              right: '-8px',
              width: '24px',
              height: '24px',
              borderRadius: '50%',
              background: colors.accent.error,
              border: 'none',
              color: 'white',
              cursor: 'pointer',
              display: 'flex',
              alignItems: 'center',
              justifyContent: 'center',
            }}
          >
            <Icons.X />
          </button>
        </div>
      ))}
      <button
        onClick={onUpload}
        style={{
          width: '100px',
          height: '100px',
          borderRadius: '8px',
          border: `2px dashed ${colors.border.default}`,
          background: 'transparent',
          color: colors.text.tertiary,
          cursor: 'pointer',
          display: 'flex',
          flexDirection: 'column',
          alignItems: 'center',
          justifyContent: 'center',
          gap: '8px',
          fontSize: '12px',
          transition: 'all 0.2s ease',
        }}
      >
        <Icons.Upload />
        Upload
      </button>
    </div>
  </div>
);

// ============================================================================
// LANDING PAGE - "THE BASEMENT"
// ============================================================================
const LandingPage = ({ onEnter }) => {
  const [isHovered, setIsHovered] = useState(false);
  const [scrollY, setScrollY] = useState(0);
  
  // Handle scroll for parallax effect
  React.useEffect(() => {
    const handleScroll = () => setScrollY(window.scrollY);
    window.addEventListener('scroll', handleScroll);
    return () => window.removeEventListener('scroll', handleScroll);
  }, []);
  
  const features = [
    {
      icon: '🎬',
      title: 'Script to Screen',
      description: 'Transform your scripts into visual storyboards with AI-powered scene breakdowns and shot composition.',
    },
    {
      icon: '🎨',
      title: 'AI Generation',
      description: 'Generate stunning images and videos with state-of-the-art AI models. Full control over every visual detail.',
    },
    {
      icon: '👥',
      title: 'Character Consistency',
      description: 'Maintain visual consistency across scenes with our Elements system. Your characters stay recognizable.',
    },
    {
      icon: '🎞️',
      title: 'Timeline Editor',
      description: 'Professional editing tools with multi-track audio, transitions, and real-time preview.',
    },
    {
      icon: '📦',
      title: 'Asset Management',
      description: 'Organize all your generated content in one place. Search, filter, and reuse across projects.',
    },
    {
      icon: '🚀',
      title: 'Export Anywhere',
      description: 'Export in multiple formats optimized for social media, streaming platforms, or professional delivery.',
    },
  ];
  
  const stats = [
    { value: '4K', label: 'Resolution' },
    { value: '60fps', label: 'Frame Rate' },
    { value: '10s', label: 'Video Length' },
    { value: '∞', label: 'Creativity' },
  ];
  
  return (
    <div style={{
      minHeight: '100vh',
      background: '#000000',
      color: '#ffffff',
      overflow: 'auto',
    }}>
      {/* Video Background Hero */}
      <div style={{
        position: 'relative',
        height: '100vh',
        display: 'flex',
        flexDirection: 'column',
        justifyContent: 'center',
        alignItems: 'center',
        overflow: 'hidden',
      }}>
        {/* Video Background Placeholder (gradient animation) */}
        <div style={{
          position: 'absolute',
          top: 0,
          left: 0,
          right: 0,
          bottom: 0,
          background: `
            radial-gradient(ellipse at 20% 80%, rgba(30, 30, 50, 0.8) 0%, transparent 50%),
            radial-gradient(ellipse at 80% 20%, rgba(40, 20, 40, 0.8) 0%, transparent 50%),
            radial-gradient(ellipse at 50% 50%, rgba(20, 20, 30, 0.9) 0%, transparent 70%),
            linear-gradient(180deg, #0a0a0a 0%, #111111 50%, #0a0a0a 100%)
          `,
          transform: `translateY(${scrollY * 0.3}px)`,
        }}>
          {/* Animated grain overlay */}
          <div style={{
            position: 'absolute',
            top: 0,
            left: 0,
            right: 0,
            bottom: 0,
            opacity: 0.03,
            background: `url("data:image/svg+xml,%3Csvg viewBox='0 0 256 256' xmlns='http://www.w3.org/2000/svg'%3E%3Cfilter id='noiseFilter'%3E%3CfeTurbulence type='fractalNoise' baseFrequency='0.9' numOctaves='4' stitchTiles='stitch'/%3E%3C/filter%3E%3Crect width='100%25' height='100%25' filter='url(%23noiseFilter)'/%3E%3C/svg%3E")`,
          }} />
          
          {/* Floating particles */}
          {[...Array(20)].map((_, i) => (
            <div
              key={i}
              style={{
                position: 'absolute',
                width: `${Math.random() * 4 + 2}px`,
                height: `${Math.random() * 4 + 2}px`,
                background: 'rgba(255,255,255,0.1)',
                borderRadius: '50%',
                left: `${Math.random() * 100}%`,
                top: `${Math.random() * 100}%`,
                animation: `float ${Math.random() * 10 + 10}s ease-in-out infinite`,
                animationDelay: `${Math.random() * 5}s`,
              }}
            />
          ))}
        </div>
        
        {/* Top Navigation */}
        <nav style={{
          position: 'absolute',
          top: 0,
          left: 0,
          right: 0,
          padding: '24px 48px',
          display: 'flex',
          justifyContent: 'space-between',
          alignItems: 'center',
          zIndex: 10,
        }}>
          <div style={{
            fontSize: '24px',
            fontWeight: '700',
            letterSpacing: '-0.5px',
            display: 'flex',
            alignItems: 'center',
            gap: '12px',
          }}>
            The Basement
          </div>
          
          <div style={{ display: 'flex', gap: '32px', alignItems: 'center' }}>
            <a href="#features" style={{ color: 'rgba(255,255,255,0.7)', textDecoration: 'none', fontSize: '14px', fontWeight: '500', transition: 'color 0.2s' }}>Features</a>
            <a href="#workflow" style={{ color: 'rgba(255,255,255,0.7)', textDecoration: 'none', fontSize: '14px', fontWeight: '500', transition: 'color 0.2s' }}>Workflow</a>
            <a href="#pricing" style={{ color: 'rgba(255,255,255,0.7)', textDecoration: 'none', fontSize: '14px', fontWeight: '500', transition: 'color 0.2s' }}>Pricing</a>
          </div>
        </nav>
        
        {/* Hero Content */}
        <div style={{
          position: 'relative',
          zIndex: 5,
          textAlign: 'center',
          maxWidth: '900px',
          padding: '0 24px',
        }}>
          {/* Badge */}
          <div style={{
            display: 'inline-flex',
            alignItems: 'center',
            gap: '8px',
            padding: '8px 16px',
            background: 'rgba(255,255,255,0.05)',
            border: '1px solid rgba(255,255,255,0.1)',
            borderRadius: '100px',
            marginBottom: '32px',
            fontSize: '13px',
            color: 'rgba(255,255,255,0.7)',
          }}>
            <span style={{ 
              width: '6px', 
              height: '6px', 
              background: '#10b981', 
              borderRadius: '50%',
              animation: 'pulse 2s ease-in-out infinite',
            }} />
            Now in Public Beta
          </div>
          
          {/* Main Headline */}
          <h1 style={{
            fontSize: 'clamp(48px, 8vw, 80px)',
            fontWeight: '700',
            lineHeight: '1.05',
            marginBottom: '24px',
            letterSpacing: '-2px',
          }}>
            Where Stories
            <br />
            <span style={{
              background: 'linear-gradient(135deg, #ffffff 0%, rgba(255,255,255,0.6) 100%)',
              WebkitBackgroundClip: 'text',
              WebkitTextFillColor: 'transparent',
            }}>
              Come to Life
            </span>
          </h1>
          
          {/* Subheadline */}
          <p style={{
            fontSize: '18px',
            lineHeight: '1.6',
            color: 'rgba(255,255,255,0.6)',
            maxWidth: '600px',
            margin: '0 auto 40px',
          }}>
            The all-in-one AI platform for episodic content creation.
            From script to screen in minutes, not months.
          </p>
          
          {/* CTA Buttons */}
          <div style={{ display: 'flex', gap: '16px', justifyContent: 'center', flexWrap: 'wrap' }}>
            <button
              onClick={onEnter}
              onMouseEnter={() => setIsHovered(true)}
              onMouseLeave={() => setIsHovered(false)}
              style={{
                padding: '16px 40px',
                fontSize: '16px',
                fontWeight: '600',
                background: isHovered ? '#ffffff' : 'rgba(255,255,255,0.95)',
                color: '#000000',
                border: 'none',
                borderRadius: '8px',
                cursor: 'pointer',
                transition: 'all 0.3s ease',
                transform: isHovered ? 'translateY(-2px)' : 'none',
                boxShadow: isHovered 
                  ? '0 20px 40px rgba(255,255,255,0.15)' 
                  : '0 10px 30px rgba(255,255,255,0.1)',
              }}
            >
              Start Creating — It's Free
            </button>
            
            <button
              style={{
                padding: '16px 32px',
                fontSize: '16px',
                fontWeight: '500',
                background: 'transparent',
                color: '#ffffff',
                border: '1px solid rgba(255,255,255,0.2)',
                borderRadius: '8px',
                cursor: 'pointer',
                transition: 'all 0.2s ease',
                display: 'flex',
                alignItems: 'center',
                gap: '8px',
              }}
            >
              <span style={{ fontSize: '18px' }}>▶</span>
              Watch Demo
            </button>
          </div>
        </div>
        
        {/* Scroll Indicator */}
        <div style={{
          position: 'absolute',
          bottom: '40px',
          left: '50%',
          transform: 'translateX(-50%)',
          display: 'flex',
          flexDirection: 'column',
          alignItems: 'center',
          gap: '8px',
          color: 'rgba(255,255,255,0.4)',
          fontSize: '12px',
          animation: 'bounce 2s ease-in-out infinite',
        }}>
          <span>Scroll to explore</span>
          <Icons.ChevronDown style={{ width: 20, height: 20 }} />
        </div>
      </div>
      
      {/* Stats Bar */}
      <div style={{
        background: 'rgba(255,255,255,0.02)',
        borderTop: '1px solid rgba(255,255,255,0.05)',
        borderBottom: '1px solid rgba(255,255,255,0.05)',
        padding: '48px 0',
      }}>
        <div style={{
          maxWidth: '1200px',
          margin: '0 auto',
          display: 'flex',
          justifyContent: 'space-around',
          flexWrap: 'wrap',
          gap: '32px',
          padding: '0 24px',
        }}>
          {stats.map((stat, i) => (
            <div key={i} style={{ textAlign: 'center' }}>
              <div style={{ 
                fontSize: '48px', 
                fontWeight: '700', 
                marginBottom: '8px',
                letterSpacing: '-2px',
              }}>
                {stat.value}
              </div>
              <div style={{ 
                fontSize: '14px', 
                color: 'rgba(255,255,255,0.5)',
                textTransform: 'uppercase',
                letterSpacing: '2px',
              }}>
                {stat.label}
              </div>
            </div>
          ))}
        </div>
      </div>
      
      {/* Features Section */}
      <div id="features" style={{
        padding: '120px 24px',
        maxWidth: '1200px',
        margin: '0 auto',
      }}>
        <div style={{ textAlign: 'center', marginBottom: '80px' }}>
          <h2 style={{
            fontSize: '48px',
            fontWeight: '700',
            marginBottom: '16px',
            letterSpacing: '-1px',
          }}>
            Everything You Need
          </h2>
          <p style={{
            fontSize: '18px',
            color: 'rgba(255,255,255,0.5)',
            maxWidth: '500px',
            margin: '0 auto',
          }}>
            Professional-grade tools for every stage of production
          </p>
        </div>
        
        <div style={{
          display: 'grid',
          gridTemplateColumns: 'repeat(auto-fit, minmax(320px, 1fr))',
          gap: '24px',
        }}>
          {features.map((feature, i) => (
            <div
              key={i}
              style={{
                padding: '32px',
                background: 'rgba(255,255,255,0.02)',
                border: '1px solid rgba(255,255,255,0.05)',
                borderRadius: '16px',
                transition: 'all 0.3s ease',
              }}
              onMouseEnter={(e) => {
                e.currentTarget.style.background = 'rgba(255,255,255,0.04)';
                e.currentTarget.style.borderColor = 'rgba(255,255,255,0.1)';
                e.currentTarget.style.transform = 'translateY(-4px)';
              }}
              onMouseLeave={(e) => {
                e.currentTarget.style.background = 'rgba(255,255,255,0.02)';
                e.currentTarget.style.borderColor = 'rgba(255,255,255,0.05)';
                e.currentTarget.style.transform = 'translateY(0)';
              }}
            >
              <div style={{ fontSize: '40px', marginBottom: '20px' }}>
                {feature.icon}
              </div>
              <h3 style={{
                fontSize: '20px',
                fontWeight: '600',
                marginBottom: '12px',
              }}>
                {feature.title}
              </h3>
              <p style={{
                fontSize: '15px',
                lineHeight: '1.6',
                color: 'rgba(255,255,255,0.5)',
              }}>
                {feature.description}
              </p>
            </div>
          ))}
        </div>
      </div>
      
      {/* Workflow Section */}
      <div id="workflow" style={{
        padding: '120px 24px',
        background: 'rgba(255,255,255,0.02)',
      }}>
        <div style={{ maxWidth: '1200px', margin: '0 auto' }}>
          <div style={{ textAlign: 'center', marginBottom: '80px' }}>
            <h2 style={{
              fontSize: '48px',
              fontWeight: '700',
              marginBottom: '16px',
              letterSpacing: '-1px',
            }}>
              Your Creative Workflow
            </h2>
            <p style={{
              fontSize: '18px',
              color: 'rgba(255,255,255,0.5)',
              maxWidth: '500px',
              margin: '0 auto',
            }}>
              From concept to final cut in four simple steps
            </p>
          </div>
          
          <div style={{
            display: 'flex',
            justifyContent: 'space-between',
            alignItems: 'flex-start',
            gap: '24px',
            flexWrap: 'wrap',
          }}>
            {[
              { step: '01', title: 'Write', desc: 'Start with your script or let AI help you develop your story concept.' },
              { step: '02', title: 'Visualize', desc: 'Generate storyboards, design characters, and build your visual world.' },
              { step: '03', title: 'Generate', desc: 'Create stunning AI images and videos with full creative control.' },
              { step: '04', title: 'Edit & Export', desc: 'Fine-tune in the timeline and export for any platform.' },
            ].map((item, i) => (
              <div key={i} style={{ flex: '1', minWidth: '220px', textAlign: 'center' }}>
                <div style={{
                  width: '80px',
                  height: '80px',
                  borderRadius: '50%',
                  background: 'rgba(255,255,255,0.05)',
                  border: '1px solid rgba(255,255,255,0.1)',
                  display: 'flex',
                  alignItems: 'center',
                  justifyContent: 'center',
                  margin: '0 auto 24px',
                  fontSize: '24px',
                  fontWeight: '700',
                  color: 'rgba(255,255,255,0.8)',
                }}>
                  {item.step}
                </div>
                <h3 style={{ fontSize: '24px', fontWeight: '600', marginBottom: '12px' }}>
                  {item.title}
                </h3>
                <p style={{ fontSize: '14px', color: 'rgba(255,255,255,0.5)', lineHeight: '1.6' }}>
                  {item.desc}
                </p>
              </div>
            ))}
          </div>
        </div>
      </div>
      
      {/* CTA Section */}
      <div style={{
        padding: '120px 24px',
        textAlign: 'center',
      }}>
        <h2 style={{
          fontSize: '56px',
          fontWeight: '700',
          marginBottom: '24px',
          letterSpacing: '-1px',
        }}>
          Ready to Create?
        </h2>
        <p style={{
          fontSize: '18px',
          color: 'rgba(255,255,255,0.5)',
          marginBottom: '40px',
        }}>
          Join creators already building in The Basement
        </p>
        <button
          onClick={onEnter}
          style={{
            padding: '20px 48px',
            fontSize: '18px',
            fontWeight: '600',
            background: '#ffffff',
            color: '#000000',
            border: 'none',
            borderRadius: '8px',
            cursor: 'pointer',
            transition: 'all 0.3s ease',
          }}
          onMouseEnter={(e) => {
            e.currentTarget.style.transform = 'translateY(-2px)';
            e.currentTarget.style.boxShadow = '0 20px 40px rgba(255,255,255,0.15)';
          }}
          onMouseLeave={(e) => {
            e.currentTarget.style.transform = 'translateY(0)';
            e.currentTarget.style.boxShadow = 'none';
          }}
        >
          Enter The Basement
        </button>
      </div>
      
      {/* Footer */}
      <footer style={{
        borderTop: '1px solid rgba(255,255,255,0.05)',
        padding: '48px 24px',
      }}>
        <div style={{
          maxWidth: '1200px',
          margin: '0 auto',
          display: 'flex',
          justifyContent: 'space-between',
          alignItems: 'center',
          flexWrap: 'wrap',
          gap: '24px',
        }}>
          <div style={{
            fontSize: '18px',
            fontWeight: '600',
            display: 'flex',
            alignItems: 'center',
            gap: '8px',
          }}>
            The Basement
          </div>
          <div style={{
            display: 'flex',
            gap: '32px',
            fontSize: '14px',
            color: 'rgba(255,255,255,0.5)',
          }}>
            <span>© 2025 The Basement</span>
            <a href="#" style={{ color: 'rgba(255,255,255,0.5)', textDecoration: 'none' }}>Privacy</a>
            <a href="#" style={{ color: 'rgba(255,255,255,0.5)', textDecoration: 'none' }}>Terms</a>
          </div>
        </div>
      </footer>
      
      {/* Keyframes for animations */}
      <style>{`
        @keyframes float {
          0%, 100% { transform: translateY(0px); opacity: 0.3; }
          50% { transform: translateY(-20px); opacity: 0.6; }
        }
        @keyframes bounce {
          0%, 100% { transform: translateX(-50%) translateY(0); }
          50% { transform: translateX(-50%) translateY(10px); }
        }
        @keyframes pulse {
          0%, 100% { opacity: 1; }
          50% { opacity: 0.5; }
        }
      `}</style>
    </div>
  );
};

// ============================================================================
// SIDEBAR COMPONENT
// ============================================================================
const Sidebar = ({ currentView, setCurrentView, currentProject }) => {
  const [isCollapsed, setIsCollapsed] = useState(true); // Start collapsed
  
  const navItems = [
    { id: 'home', label: 'Home', icon: <Icons.Home /> },
    { id: 'projects', label: 'Projects', icon: <Icons.Film /> },
    { id: 'templates', label: 'Templates', icon: <Icons.Layout /> },
    { id: 'gen-space', label: 'Gen Space', icon: <Icons.Camera /> },
    { id: 'elements', label: 'Elements', icon: <Icons.Layers /> },
    { id: 'assets', label: 'My Assets', icon: <Icons.Image /> },
    { id: 'promo-studio', label: 'Promo Studio', icon: <Icons.Sparkles /> },
    { id: 'settings', label: 'Settings', icon: <Icons.Settings /> },
  ];
  
  return (
    <div style={{
      width: isCollapsed ? '72px' : '240px',
      height: '100vh',
      background: colors.bg.secondary,
      borderRight: `1px solid ${colors.border.subtle}`,
      display: 'flex',
      flexDirection: 'column',
      flexShrink: 0,
      transition: 'width 0.2s ease',
    }}>
      {/* Logo & Collapse Toggle */}
      <div style={{
        padding: isCollapsed ? '20px 12px' : '20px 16px',
        borderBottom: `1px solid ${colors.border.subtle}`,
        display: 'flex',
        alignItems: 'center',
        justifyContent: isCollapsed ? 'center' : 'space-between',
      }}>
        {isCollapsed ? (
          <button
            onClick={() => setIsCollapsed(false)}
            style={{
              background: 'none',
              border: 'none',
              cursor: 'pointer',
              padding: '8px',
              borderRadius: '8px',
              display: 'flex',
              alignItems: 'center',
              justifyContent: 'center',
              color: colors.text.secondary,
            }}
            title="Expand sidebar"
          >
            <Icons.ChevronRight style={{ width: 20, height: 20 }} />
          </button>
        ) : (
          <>
            <div>
              <div style={{
                fontSize: '24px',
                fontWeight: '700',
                background: 'linear-gradient(135deg, #ffffff 0%, rgba(255,255,255,0.7) 100%)',
                WebkitBackgroundClip: 'text',
                WebkitTextFillColor: 'transparent',
                letterSpacing: '-0.5px',
              }}>
                The Basement
              </div>
              <div style={{ fontSize: '11px', color: colors.text.tertiary, marginTop: '2px' }}>
                AI Video Production
              </div>
            </div>
            <button
              onClick={() => setIsCollapsed(true)}
              style={{
                background: 'none',
                border: 'none',
                cursor: 'pointer',
                color: colors.text.tertiary,
                padding: '4px',
                display: 'flex',
                alignItems: 'center',
                justifyContent: 'center',
              }}
              title="Collapse sidebar"
            >
              <Icons.ChevronLeft style={{ width: 18, height: 18 }} />
            </button>
          </>
        )}
      </div>
      
      {/* Current Project Indicator */}
      {currentProject && !isCollapsed && (
        <div style={{
          margin: '16px',
          padding: '12px',
          background: colors.bg.tertiary,
          borderRadius: '8px',
          border: `1px solid ${colors.border.subtle}`,
        }}>
          <div style={{ fontSize: '11px', color: colors.text.tertiary, marginBottom: '4px' }}>
            CURRENT PROJECT
          </div>
          <div style={{ fontSize: '14px', fontWeight: '500', color: colors.text.primary }}>
            {currentProject.title}
          </div>
          <div style={{ fontSize: '12px', color: colors.text.secondary }}>
            {currentProject.seasons} Seasons · {currentProject.totalEpisodes || currentProject.episodes?.length || 0} Episodes
          </div>
        </div>
      )}
      
      {/* Navigation */}
      <div style={{ flex: 1, padding: isCollapsed ? '16px 12px' : '16px 8px', overflowY: 'auto' }}>
        {navItems.map((item) => (
          <button
            key={item.id}
            onClick={() => setCurrentView(item.id)}
            style={{
              width: '100%',
              display: 'flex',
              alignItems: 'center',
              justifyContent: isCollapsed ? 'center' : 'flex-start',
              gap: isCollapsed ? '0' : '12px',
              padding: isCollapsed ? '12px' : '10px 16px',
              background: currentView === item.id ? colors.bg.tertiary : 'transparent',
              border: 'none',
              borderRadius: '8px',
              color: currentView === item.id ? colors.text.primary : colors.text.secondary,
              fontSize: '14px',
              fontWeight: currentView === item.id ? '500' : '400',
              cursor: 'pointer',
              transition: 'all 0.15s ease',
              textAlign: 'left',
              marginBottom: '2px',
            }}
            title={isCollapsed ? item.label : undefined}
          >
            <span style={{ display: 'flex', alignItems: 'center', justifyContent: 'center' }}>
              {item.icon}
            </span>
            {!isCollapsed && item.label}
          </button>
        ))}
      </div>
      
      {/* Footer */}
      <div style={{
        padding: isCollapsed ? '16px 12px' : '16px',
        borderTop: `1px solid ${colors.border.subtle}`,
        display: 'flex',
        alignItems: 'center',
        justifyContent: isCollapsed ? 'center' : 'space-between',
      }}>
        {isCollapsed ? (
          <div 
            style={{ 
              width: '8px', 
              height: '8px', 
              borderRadius: '50%', 
              background: colors.accent.success 
            }} 
            title="Credits: 100%"
          />
        ) : (
          <>
            <div style={{ fontSize: '12px', color: colors.text.tertiary }}>
              Credits: <span style={{ color: colors.accent.success }}>100%</span>
            </div>
            <Button variant="ghost" size="sm">Upgrade</Button>
          </>
        )}
      </div>
    </div>
  );
};

// ============================================================================
// TOP NAV COMPONENT
// ============================================================================
const TopNav = ({ currentProject, currentView }) => {
  // Page titles for different views
  const pageTitles = {
    'gen-space': 'Gen Space',
    'elements': 'Elements',
    'assets': 'My Assets',
    'promo-studio': 'Promo Studio',
    'settings': 'Settings',
  };
  
  const pageTitle = pageTitles[currentView] || currentView;
  
  return (
    <div style={{
      height: '56px',
      background: colors.bg.secondary,
      borderBottom: `1px solid ${colors.border.subtle}`,
      display: 'flex',
      alignItems: 'center',
      justifyContent: 'space-between',
      padding: '0 24px',
    }}>
      <div style={{ display: 'flex', alignItems: 'center', gap: '16px' }}>
        <h1 style={{ 
          fontSize: '18px', 
          fontWeight: '600', 
          color: colors.text.primary,
          margin: 0,
        }}>
          {pageTitle}
        </h1>
      </div>
      
      <div style={{ display: 'flex', alignItems: 'center', gap: '12px' }}>
        <div style={{
          width: '36px',
          height: '36px',
          borderRadius: '50%',
          background: colors.accent.primary,
          display: 'flex',
          alignItems: 'center',
          justifyContent: 'center',
          fontSize: '14px',
          fontWeight: '600',
        }}>
          U
        </div>
      </div>
    </div>
  );
};

// ============================================================================
// HOME VIEW
// ============================================================================
const HomeView = ({ setCurrentView, projects, setCurrentProject, generatedAssets = [] }) => {
  // Get phase info helper
  const getProjectPhase = (project) => {
    if (project.phase) return project.phase;
    const hasScenes = project.episodes?.some(ep => ep.scenes?.length > 0);
    const hasGeneratedContent = project.episodes?.some(ep => 
      ep.scenes?.some(scene => scene.shots?.some(shot => shot.generated))
    );
    if (!hasScenes) return 'script';
    if (!hasGeneratedContent) return 'storyboard';
    return 'roughcut';
  };
  
  const phases = {
    script: { label: 'Script', color: '#f59e0b', nextAction: 'Continue Writing' },
    storyboard: { label: 'Storyboard', color: '#8b5cf6', nextAction: 'Continue Storyboarding' },
    roughcut: { label: 'Rough Cut', color: '#3b82f6', nextAction: 'Continue Editing' },
    post: { label: 'Post', color: '#10b981', nextAction: 'Continue Post Production' },
    completed: { label: 'Completed', color: '#06b6d4', nextAction: 'View Project' },
  };
  
  // Get most recent project (last updated)
  const recentProject = projects.length > 0 
    ? [...projects].sort((a, b) => new Date(b.updatedAt || b.createdAt || 0) - new Date(a.updatedAt || a.createdAt || 0))[0]
    : null;
  
  // Get 4 most recent projects for grid
  const recentProjects = [...projects]
    .sort((a, b) => new Date(b.updatedAt || b.createdAt || 0) - new Date(a.updatedAt || a.createdAt || 0))
    .slice(0, 4);
  
  // Calculate stats
  const stats = {
    totalProjects: projects.length,
    totalEpisodes: projects.reduce((acc, p) => acc + (p.episodes?.length || 0), 0),
    totalAssets: generatedAssets?.length || 0,
    inProgress: projects.filter(p => getProjectPhase(p) !== 'completed').length,
  };
  
  // Time ago helper
  const getTimeAgo = (date) => {
    if (!date) return 'Unknown';
    const now = new Date();
    const then = new Date(date);
    const diffMs = now - then;
    const diffMins = Math.floor(diffMs / 60000);
    const diffHours = Math.floor(diffMs / 3600000);
    const diffDays = Math.floor(diffMs / 86400000);
    
    if (diffMins < 1) return 'Just now';
    if (diffMins < 60) return `${diffMins}m ago`;
    if (diffHours < 24) return `${diffHours}h ago`;
    if (diffDays < 7) return `${diffDays}d ago`;
    return then.toLocaleDateString();
  };
  
  // Quick action cards
  const quickActions = [
    { id: 'new-project', icon: '✨', label: 'New Project', desc: 'Start from scratch', color: '#8b5cf6' },
    { id: 'templates', icon: '📋', label: 'Templates', desc: 'Use a template', color: '#3b82f6' },
    { id: 'gen-space', icon: '🎨', label: 'Gen Space', desc: 'Generate content', color: '#10b981' },
    { id: 'elements', icon: '👤', label: 'Elements', desc: 'Manage characters', color: '#f59e0b' },
  ];
  
  return (
    <div style={{
      flex: 1,
      overflow: 'auto',
      padding: '32px 40px',
    }}>
      {/* Welcome Header */}
      <div style={{ marginBottom: '32px' }}>
        <h1 style={{ fontSize: '28px', fontWeight: '700', marginBottom: '8px' }}>
          Welcome back 👋
        </h1>
        <p style={{ fontSize: '15px', color: colors.text.secondary }}>
          Here's what's happening with your projects
        </p>
      </div>
      
      {/* Stats Row */}
      <div style={{
        display: 'grid',
        gridTemplateColumns: 'repeat(4, 1fr)',
        gap: '16px',
        marginBottom: '32px',
      }}>
        {[
          { label: 'Total Projects', value: stats.totalProjects, icon: '📁', color: '#8b5cf6' },
          { label: 'Episodes', value: stats.totalEpisodes, icon: '🎬', color: '#3b82f6' },
          { label: 'Assets Generated', value: stats.totalAssets, icon: '🖼️', color: '#10b981' },
          { label: 'In Progress', value: stats.inProgress, icon: '⚡', color: '#f59e0b' },
        ].map((stat, i) => (
          <div
            key={i}
            style={{
              background: colors.bg.secondary,
              border: `1px solid ${colors.border.subtle}`,
              borderRadius: '12px',
              padding: '20px',
              display: 'flex',
              alignItems: 'center',
              gap: '16px',
            }}
          >
            <div style={{
              width: '48px',
              height: '48px',
              borderRadius: '12px',
              background: `${stat.color}15`,
              display: 'flex',
              alignItems: 'center',
              justifyContent: 'center',
              fontSize: '24px',
            }}>
              {stat.icon}
            </div>
            <div>
              <div style={{ fontSize: '24px', fontWeight: '700', color: colors.text.primary }}>
                {stat.value}
              </div>
              <div style={{ fontSize: '13px', color: colors.text.tertiary }}>
                {stat.label}
              </div>
            </div>
          </div>
        ))}
      </div>
      
      {/* Continue Where You Left Off */}
      {recentProject && (
        <div style={{ marginBottom: '32px' }}>
          <h2 style={{ fontSize: '16px', fontWeight: '600', marginBottom: '16px', color: colors.text.secondary }}>
            Continue Where You Left Off
          </h2>
          <div
            onClick={() => {
              setCurrentProject(recentProject);
              setCurrentView('episode-setup');
            }}
            style={{
              background: `linear-gradient(135deg, ${colors.bg.secondary} 0%, ${colors.bg.tertiary} 100%)`,
              border: `1px solid ${colors.border.subtle}`,
              borderRadius: '16px',
              padding: '24px',
              cursor: 'pointer',
              transition: 'all 0.2s ease',
              display: 'flex',
              alignItems: 'center',
              gap: '24px',
            }}
            onMouseEnter={(e) => {
              e.currentTarget.style.borderColor = colors.accent.primary;
              e.currentTarget.style.transform = 'translateY(-2px)';
              e.currentTarget.style.boxShadow = '0 8px 30px rgba(0,0,0,0.2)';
            }}
            onMouseLeave={(e) => {
              e.currentTarget.style.borderColor = colors.border.subtle;
              e.currentTarget.style.transform = 'translateY(0)';
              e.currentTarget.style.boxShadow = 'none';
            }}
          >
            {/* Project Thumbnail */}
            <div style={{
              width: '120px',
              height: '80px',
              borderRadius: '10px',
              background: recentProject.coverGradient || `linear-gradient(135deg, ${colors.accent.primary}40 0%, ${colors.accent.secondary}40 100%)`,
              display: 'flex',
              alignItems: 'center',
              justifyContent: 'center',
              flexShrink: 0,
            }}>
              <span style={{ fontSize: '32px', opacity: 0.6 }}>
                {recentProject.projectType === 'series' ? '📺' : '🎬'}
              </span>
            </div>
            
            {/* Project Info */}
            <div style={{ flex: 1 }}>
              <div style={{ display: 'flex', alignItems: 'center', gap: '12px', marginBottom: '8px' }}>
                <h3 style={{ fontSize: '18px', fontWeight: '600' }}>
                  {recentProject.title || 'Untitled Project'}
                </h3>
                <span style={{
                  padding: '4px 10px',
                  background: phases[getProjectPhase(recentProject)]?.color || colors.accent.primary,
                  borderRadius: '6px',
                  fontSize: '11px',
                  fontWeight: '600',
                  color: '#fff',
                }}>
                  {phases[getProjectPhase(recentProject)]?.label || 'In Progress'}
                </span>
              </div>
              <p style={{ fontSize: '14px', color: colors.text.tertiary, marginBottom: '4px' }}>
                {recentProject.genre || 'No genre'} · {recentProject.episodes?.length || 0} episodes
              </p>
              <p style={{ fontSize: '12px', color: colors.text.tertiary }}>
                Last edited {getTimeAgo(recentProject.updatedAt || recentProject.createdAt)}
              </p>
            </div>
            
            {/* Action Button */}
            <button
              style={{
                padding: '12px 24px',
                background: colors.accent.primary,
                border: 'none',
                borderRadius: '8px',
                color: '#fff',
                fontSize: '14px',
                fontWeight: '600',
                cursor: 'pointer',
                display: 'flex',
                alignItems: 'center',
                gap: '8px',
                whiteSpace: 'nowrap',
              }}
            >
              {phases[getProjectPhase(recentProject)]?.nextAction || 'Continue'}
              <span>→</span>
            </button>
          </div>
        </div>
      )}
      
      {/* Two Column Layout */}
      <div style={{ display: 'grid', gridTemplateColumns: '1fr 300px', gap: '24px' }}>
        {/* Left Column - Recent Projects */}
        <div>
          <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center', marginBottom: '16px' }}>
            <h2 style={{ fontSize: '16px', fontWeight: '600', color: colors.text.secondary }}>
              Recent Projects
            </h2>
            {projects.length > 4 && (
              <button
                onClick={() => setCurrentView('projects')}
                style={{
                  background: 'none',
                  border: 'none',
                  color: colors.accent.primary,
                  fontSize: '13px',
                  cursor: 'pointer',
                  fontWeight: '500',
                }}
              >
                View All →
              </button>
            )}
          </div>
          
          {projects.length === 0 ? (
            <div style={{
              background: colors.bg.secondary,
              border: `1px solid ${colors.border.subtle}`,
              borderRadius: '12px',
              padding: '48px',
              textAlign: 'center',
            }}>
              <div style={{
                width: '64px',
                height: '64px',
                borderRadius: '16px',
                background: colors.bg.tertiary,
                display: 'flex',
                alignItems: 'center',
                justifyContent: 'center',
                margin: '0 auto 16px',
                fontSize: '28px',
              }}>
                🎬
              </div>
              <h3 style={{ fontSize: '16px', fontWeight: '500', marginBottom: '8px' }}>
                No projects yet
              </h3>
              <p style={{ fontSize: '14px', color: colors.text.tertiary, marginBottom: '20px' }}>
                Create your first project to get started
              </p>
              <Button variant="primary" onClick={() => setCurrentView('new-project')}>
                Create Project
              </Button>
            </div>
          ) : (
            <div style={{ display: 'grid', gridTemplateColumns: 'repeat(2, 1fr)', gap: '16px' }}>
              {recentProjects.map((project) => {
                const phase = getProjectPhase(project);
                const phaseInfo = phases[phase];
                
                return (
                  <div
                    key={project.id}
                    onClick={() => {
                      setCurrentProject(project);
                      setCurrentView('episode-setup');
                    }}
                    style={{
                      background: colors.bg.secondary,
                      border: `1px solid ${colors.border.subtle}`,
                      borderRadius: '12px',
                      overflow: 'hidden',
                      cursor: 'pointer',
                      transition: 'all 0.2s ease',
                    }}
                    onMouseEnter={(e) => {
                      e.currentTarget.style.borderColor = colors.accent.primary;
                      e.currentTarget.style.transform = 'translateY(-2px)';
                    }}
                    onMouseLeave={(e) => {
                      e.currentTarget.style.borderColor = colors.border.subtle;
                      e.currentTarget.style.transform = 'translateY(0)';
                    }}
                  >
                    <div style={{
                      height: '80px',
                      background: project.coverGradient || `linear-gradient(135deg, ${colors.accent.primary}30 0%, ${colors.accent.secondary}30 100%)`,
                      display: 'flex',
                      alignItems: 'center',
                      justifyContent: 'center',
                      position: 'relative',
                    }}>
                      <span style={{ fontSize: '32px', opacity: 0.5 }}>
                        {project.projectType === 'series' ? '📺' : '🎬'}
                      </span>
                      <span style={{
                        position: 'absolute',
                        bottom: '8px',
                        left: '8px',
                        padding: '3px 8px',
                        background: phaseInfo?.color || colors.accent.primary,
                        borderRadius: '4px',
                        fontSize: '10px',
                        fontWeight: '600',
                        color: '#fff',
                      }}>
                        {phaseInfo?.label || 'In Progress'}
                      </span>
                    </div>
                    <div style={{ padding: '14px' }}>
                      <h3 style={{ fontSize: '14px', fontWeight: '600', marginBottom: '4px' }}>
                        {project.title || 'Untitled Project'}
                      </h3>
                      <p style={{ fontSize: '12px', color: colors.text.tertiary }}>
                        {getTimeAgo(project.updatedAt || project.createdAt)}
                      </p>
                    </div>
                  </div>
                );
              })}
            </div>
          )}
        </div>
        
        {/* Right Column - Quick Actions */}
        <div>
          <h2 style={{ fontSize: '16px', fontWeight: '600', marginBottom: '16px', color: colors.text.secondary }}>
            Quick Actions
          </h2>
          <div style={{ display: 'flex', flexDirection: 'column', gap: '12px' }}>
            {quickActions.map((action) => (
              <button
                key={action.id}
                onClick={() => setCurrentView(action.id)}
                style={{
                  display: 'flex',
                  alignItems: 'center',
                  gap: '14px',
                  padding: '16px',
                  background: colors.bg.secondary,
                  border: `1px solid ${colors.border.subtle}`,
                  borderRadius: '12px',
                  cursor: 'pointer',
                  transition: 'all 0.2s ease',
                  textAlign: 'left',
                }}
                onMouseEnter={(e) => {
                  e.currentTarget.style.borderColor = action.color;
                  e.currentTarget.style.background = `${action.color}10`;
                }}
                onMouseLeave={(e) => {
                  e.currentTarget.style.borderColor = colors.border.subtle;
                  e.currentTarget.style.background = colors.bg.secondary;
                }}
              >
                <div style={{
                  width: '40px',
                  height: '40px',
                  borderRadius: '10px',
                  background: `${action.color}20`,
                  display: 'flex',
                  alignItems: 'center',
                  justifyContent: 'center',
                  fontSize: '20px',
                }}>
                  {action.icon}
                </div>
                <div>
                  <div style={{ fontSize: '14px', fontWeight: '600', color: colors.text.primary }}>
                    {action.label}
                  </div>
                  <div style={{ fontSize: '12px', color: colors.text.tertiary }}>
                    {action.desc}
                  </div>
                </div>
              </button>
            ))}
          </div>
          
          {/* Pro Tip */}
          <div style={{
            marginTop: '20px',
            padding: '16px',
            background: `linear-gradient(135deg, ${colors.accent.primary}10 0%, ${colors.accent.secondary}10 100%)`,
            border: `1px solid ${colors.accent.primary}30`,
            borderRadius: '12px',
          }}>
            <div style={{ display: 'flex', alignItems: 'center', gap: '8px', marginBottom: '8px' }}>
              <span style={{ fontSize: '16px' }}>💡</span>
              <span style={{ fontSize: '13px', fontWeight: '600', color: colors.accent.primary }}>Pro Tip</span>
            </div>
            <p style={{ fontSize: '12px', color: colors.text.secondary, lineHeight: '1.5' }}>
              Use Elements to create consistent characters that can be reused across all your projects.
            </p>
          </div>
        </div>
      </div>
    </div>
  );
};

// ============================================================================
// TEMPLATES VIEW
// ============================================================================
const TemplatesView = ({ setCurrentView }) => {
  const [selectedTemplate, setSelectedTemplate] = useState(null);
  const [showSettingsModal, setShowSettingsModal] = useState(false);
  const [searchQuery, setSearchQuery] = useState('');
  const [templateSettings, setTemplateSettings] = useState({
    duration: '15 seconds',
    topic: '',
  });
  
  // Template categories
  const templateCategories = [
    {
      title: 'Trends',
      templates: [
        { id: 'black-friday-ad', name: 'Black Friday Ad', thumbnail: 'linear-gradient(135deg, #1a1a2e 0%, #e94560 100%)', duration: '30s' },
        { id: 'black-friday-promo', name: 'Black Friday Promo', thumbnail: 'linear-gradient(135deg, #2d132c 0%, #ee4540 100%)', duration: '15s' },
        { id: 'black-friday-story', name: 'Black Friday Story', thumbnail: 'linear-gradient(135deg, #0f0c29 0%, #302b63 100%)', duration: '60s' },
        { id: 'live-in-videos', name: 'Black Friday Live', thumbnail: 'linear-gradient(135deg, #200122 0%, #6f0000 100%)', duration: '45s' },
      ]
    },
    {
      title: 'Top Picks',
      templates: [
        { id: 'ugc-ad', name: 'UGC Ad', thumbnail: 'linear-gradient(135deg, #667eea 0%, #764ba2 100%)', subtitle: 'with human avatar', duration: '15s' },
        { id: 'short-video', name: 'Short video', thumbnail: 'linear-gradient(135deg, #f093fb 0%, #f5576c 100%)', duration: '30s' },
        { id: 'explainer', name: 'Explainer video', thumbnail: 'linear-gradient(135deg, #4facfe 0%, #00f2fe 100%)', duration: '60s' },
        { id: 'use-my-script', name: 'Use my script', thumbnail: 'linear-gradient(135deg, #43e97b 0%, #38f9d7 100%)', duration: '30s' },
      ]
    },
    {
      title: 'Create Faceless Videos',
      templates: [
        { id: 'faceless-short', name: 'Faceless short video', thumbnail: 'linear-gradient(135deg, #a18cd1 0%, #fbc2eb 100%)', duration: '60s' },
        { id: 'script-to-video', name: 'Script to video', thumbnail: 'linear-gradient(135deg, #fa709a 0%, #fee140 100%)', duration: '30s' },
        { id: 'listicle', name: 'Listicle video', thumbnail: 'linear-gradient(135deg, #30cfd0 0%, #330867 100%)', duration: '45s' },
        { id: 'top-10', name: 'Top 10 Explainer', thumbnail: 'linear-gradient(135deg, #f857a6 0%, #ff5858 100%)', duration: '60s' },
        { id: 'faceless-explainer', name: 'Faceless explainer', thumbnail: 'linear-gradient(135deg, #667eea 0%, #764ba2 100%)', duration: '90s' },
      ]
    },
    {
      title: 'Create UGC Ads',
      templates: [
        { id: 'ugc-avatar', name: 'UGC Ad with avatar', thumbnail: 'linear-gradient(135deg, #667eea 0%, #764ba2 100%)', duration: '15s' },
        { id: 'script-ugc', name: 'Script to UGC Ad', thumbnail: 'linear-gradient(135deg, #f093fb 0%, #f5576c 100%)', duration: '30s' },
        { id: 'screenplay-ugc', name: 'Screenplay to UGC', thumbnail: 'linear-gradient(135deg, #4facfe 0%, #00f2fe 100%)', duration: '45s' },
        { id: 'amazon-ugc', name: 'Amazon link UGC', thumbnail: 'linear-gradient(135deg, #ff9a9e 0%, #fecfef 100%)', duration: '30s' },
      ]
    },
    {
      title: 'Create Ads & Marketing',
      templates: [
        { id: 'short-ad', name: 'Short ad video', thumbnail: 'linear-gradient(135deg, #a1c4fd 0%, #c2e9fb 100%)', duration: '15s' },
        { id: 'tiktok-shop', name: 'TikTok shop video', thumbnail: 'linear-gradient(135deg, #ffecd2 0%, #fcb69f 100%)', duration: '30s' },
        { id: 'generative-ad', name: 'Generative ad', thumbnail: 'linear-gradient(135deg, #d299c2 0%, #fef9d7 100%)', duration: '30s' },
        { id: 'brand-story', name: 'Brand story', thumbnail: 'linear-gradient(135deg, #89f7fe 0%, #66a6ff 100%)', duration: '60s' },
      ]
    },
    {
      title: 'Create Animated Videos',
      templates: [
        { id: 'short-animated', name: 'Short animated', thumbnail: 'linear-gradient(135deg, #f6d365 0%, #fda085 100%)', duration: '30s' },
        { id: 'disney-pixar', name: 'Disney Pixar style', thumbnail: 'linear-gradient(135deg, #84fab0 0%, #8fd3f4 100%)', duration: '60s' },
        { id: 'claymation', name: 'Claymation style', thumbnail: 'linear-gradient(135deg, #cfd9df 0%, #e2ebf0 100%)', duration: '45s' },
        { id: 'lego-style', name: 'Lego style', thumbnail: 'linear-gradient(135deg, #ffecd2 0%, #fcb69f 100%)', duration: '30s' },
      ]
    },
    {
      title: 'Create Generative Films',
      templates: [
        { id: 'short-film', name: 'Short film', thumbnail: 'linear-gradient(135deg, #0c3483 0%, #a2b6df 100%)', duration: '5min' },
        { id: 'hyper-realistic', name: 'Hyper realistic', thumbnail: 'linear-gradient(135deg, #1e3c72 0%, #2a5298 100%)', duration: '3min' },
        { id: 'documentary', name: 'Documentary', thumbnail: 'linear-gradient(135deg, #2c3e50 0%, #4ca1af 100%)', duration: '10min' },
        { id: 'animation-film', name: 'Animation film', thumbnail: 'linear-gradient(135deg, #ee9ca7 0%, #ffdde1 100%)', duration: '5min' },
      ]
    },
  ];
  
  const settingsOptions = {
    duration: ['15 seconds', '30 seconds', '45 seconds', '60 seconds', '90 seconds'],
    backgroundMusic: ['None', 'Upbeat', 'Cinematic', 'Calm', 'Energetic'],
    language: ['English', 'Spanish', 'French', 'German', 'Japanese'],
    subtitles: ['None', 'Auto-generated', 'Custom'],
    voiceActors: ['None', 'Male voice', 'Female voice', 'AI Avatar'],
    watermark: ['None', 'Bottom-left', 'Bottom-right'],
    musicPreference: ['AI Generated', 'Stock Music', 'Custom Upload'],
    stockGenerative: ['Stock Media', 'AI Generative', 'Mixed'],
  };
  
  const handleSelectTemplate = (template) => {
    setSelectedTemplate(template);
    setShowSettingsModal(true);
  };
  
  return (
    <div style={{
      flex: 1,
      overflow: 'auto',
      background: colors.bg.primary,
    }}>
      {/* Header */}
      <div style={{
        padding: '24px 40px',
        borderBottom: `1px solid ${colors.border.subtle}`,
        background: colors.bg.secondary,
      }}>
        <h1 style={{ fontSize: '28px', fontWeight: '700', marginBottom: '8px' }}>Templates</h1>
        <p style={{ fontSize: '14px', color: colors.text.secondary, marginBottom: '16px' }}>Start with a pre-built workflow template</p>
        
        {/* Search */}
        <div style={{
          display: 'flex',
          alignItems: 'center',
          gap: '12px',
          padding: '12px 16px',
          background: colors.bg.tertiary,
          borderRadius: '8px',
          border: `1px solid ${colors.border.default}`,
          maxWidth: '500px',
        }}>
          <Icons.Search style={{ width: 18, height: 18, color: colors.text.tertiary }} />
          <input
            type="text"
            placeholder="Search Flows"
            value={searchQuery}
            onChange={(e) => setSearchQuery(e.target.value)}
            style={{
              flex: 1,
              background: 'none',
              border: 'none',
              color: colors.text.primary,
              fontSize: '14px',
              outline: 'none',
            }}
          />
        </div>
      </div>
      
      {/* Template Categories */}
      <div style={{ padding: '24px 40px' }}>
        {templateCategories.map((category) => (
          <div key={category.title} style={{ marginBottom: '32px' }}>
            <div style={{ 
              display: 'flex', 
              justifyContent: 'space-between', 
              alignItems: 'center',
              marginBottom: '16px',
            }}>
              <h2 style={{ fontSize: '14px', fontWeight: '600', color: colors.text.secondary }}>
                {category.title}
              </h2>
              <button style={{
                background: 'none',
                border: 'none',
                color: colors.accent.primary,
                fontSize: '12px',
                cursor: 'pointer',
              }}>
                See all
              </button>
            </div>
            
            <div style={{ 
              display: 'grid', 
              gridTemplateColumns: 'repeat(auto-fill, minmax(180px, 1fr))', 
              gap: '16px',
            }}>
              {category.templates.map((template) => (
                <div
                  key={template.id}
                  onClick={() => handleSelectTemplate(template)}
                  style={{
                    background: template.thumbnail,
                    borderRadius: '12px',
                    padding: '16px',
                    cursor: 'pointer',
                    transition: 'all 0.2s ease',
                    position: 'relative',
                    minHeight: '120px',
                    display: 'flex',
                    flexDirection: 'column',
                    justifyContent: 'flex-end',
                  }}
                  onMouseEnter={(e) => e.currentTarget.style.transform = 'translateY(-4px)'}
                  onMouseLeave={(e) => e.currentTarget.style.transform = 'translateY(0)'}
                >
                  {/* Duration Badge */}
                  <div style={{
                    position: 'absolute',
                    top: '10px',
                    right: '10px',
                    padding: '3px 8px',
                    background: 'rgba(0,0,0,0.5)',
                    borderRadius: '4px',
                    fontSize: '10px',
                    color: '#fff',
                  }}>
                    {template.duration}
                  </div>
                  
                  {/* Info Row */}
                  <div style={{
                    display: 'flex',
                    alignItems: 'center',
                    gap: '8px',
                    marginBottom: '8px',
                  }}>
                    <span style={{ fontSize: '12px', color: 'rgba(255,255,255,0.7)' }}>🎬</span>
                    <span style={{ fontSize: '11px', color: 'rgba(255,255,255,0.7)' }}>0:00</span>
                  </div>
                  
                  {/* Name */}
                  <div style={{ 
                    fontSize: '14px', 
                    fontWeight: '600', 
                    color: '#fff', 
                    textShadow: '0 1px 4px rgba(0,0,0,0.5)',
                  }}>
                    {template.name}
                  </div>
                  {template.subtitle && (
                    <div style={{ fontSize: '11px', color: 'rgba(255,255,255,0.8)' }}>
                      {template.subtitle}
                    </div>
                  )}
                </div>
              ))}
            </div>
          </div>
        ))}
      </div>
      
      {/* Template Settings Modal */}
      {showSettingsModal && selectedTemplate && (
        <div style={{
          position: 'fixed',
          top: 0,
          left: 0,
          right: 0,
          bottom: 0,
          background: 'rgba(0,0,0,0.9)',
          display: 'flex',
          alignItems: 'center',
          justifyContent: 'center',
          zIndex: 1000,
        }}>
          <div style={{
            width: '700px',
            background: colors.bg.secondary,
            borderRadius: '16px',
            overflow: 'hidden',
          }}>
            {/* Header with Preview */}
            <div style={{
              height: '180px',
              background: selectedTemplate.thumbnail,
              display: 'flex',
              alignItems: 'flex-end',
              padding: '24px',
              position: 'relative',
            }}>
              <button
                onClick={() => {
                  setShowSettingsModal(false);
                  setSelectedTemplate(null);
                }}
                style={{
                  position: 'absolute',
                  top: '16px',
                  right: '16px',
                  width: '32px',
                  height: '32px',
                  borderRadius: '50%',
                  background: 'rgba(0,0,0,0.5)',
                  border: 'none',
                  color: '#fff',
                  cursor: 'pointer',
                  fontSize: '18px',
                }}
              >×</button>
              
              {/* Heart/favorite button */}
              <button
                style={{
                  position: 'absolute',
                  top: '16px',
                  right: '56px',
                  width: '32px',
                  height: '32px',
                  borderRadius: '50%',
                  background: 'rgba(0,0,0,0.5)',
                  border: 'none',
                  color: '#fff',
                  cursor: 'pointer',
                  fontSize: '14px',
                }}
              >♡</button>
              
              <div>
                <h2 style={{ fontSize: '24px', fontWeight: '600', color: '#fff', textShadow: '0 2px 8px rgba(0,0,0,0.5)' }}>
                  {selectedTemplate.name}
                </h2>
              </div>
            </div>
            
            {/* Settings */}
            <div style={{ padding: '24px' }}>
              <div style={{ display: 'flex', alignItems: 'center', gap: '8px', marginBottom: '20px', flexWrap: 'wrap' }}>
                <span style={{ color: colors.text.secondary }}>Create a</span>
                <select
                  value={templateSettings.duration}
                  onChange={(e) => setTemplateSettings(prev => ({ ...prev, duration: e.target.value }))}
                  style={{
                    padding: '8px 12px',
                    background: colors.bg.tertiary,
                    border: `1px solid ${colors.border.default}`,
                    borderRadius: '8px',
                    color: colors.text.primary,
                    fontSize: '14px',
                    fontWeight: '500',
                  }}
                >
                  {settingsOptions.duration.map(d => (
                    <option key={d} value={d}>{d}</option>
                  ))}
                </select>
                <span style={{ color: colors.text.secondary }}>{selectedTemplate.name.toLowerCase()} about</span>
              </div>
              
              <input
                type="text"
                placeholder={`My ${selectedTemplate.name.toLowerCase()} topic...`}
                value={templateSettings.topic}
                onChange={(e) => setTemplateSettings(prev => ({ ...prev, topic: e.target.value }))}
                style={{
                  width: '100%',
                  padding: '14px 16px',
                  background: colors.bg.tertiary,
                  border: `1px solid ${colors.border.default}`,
                  borderRadius: '10px',
                  color: colors.text.primary,
                  fontSize: '15px',
                  marginBottom: '24px',
                }}
              />
              
              <div style={{ marginBottom: '24px' }}>
                <div style={{ fontSize: '13px', color: colors.text.tertiary, marginBottom: '12px' }}>Settings:</div>
                <div style={{ display: 'flex', flexWrap: 'wrap', gap: '8px' }}>
                  {Object.keys(settingsOptions).slice(1).map((key) => (
                    <button
                      key={key}
                      style={{
                        padding: '8px 14px',
                        background: colors.bg.tertiary,
                        border: `1px solid ${colors.border.default}`,
                        borderRadius: '20px',
                        color: colors.text.secondary,
                        fontSize: '12px',
                        cursor: 'pointer',
                        display: 'flex',
                        alignItems: 'center',
                        gap: '6px',
                      }}
                    >
                      {key.replace(/([A-Z])/g, ' $1').trim()}
                      <span style={{ opacity: 0.5 }}>+</span>
                    </button>
                  ))}
                </div>
              </div>
              
              <div style={{ display: 'flex', justifyContent: 'flex-end', gap: '12px' }}>
                <Button variant="secondary" onClick={() => {
                  setShowSettingsModal(false);
                  setSelectedTemplate(null);
                }}>
                  Back
                </Button>
                <Button onClick={() => {
                  setShowSettingsModal(false);
                  setSelectedTemplate(null);
                  setCurrentView('new-project');
                }}>
                  Proceed
                </Button>
              </div>
            </div>
          </div>
        </div>
      )}
    </div>
  );
};

// ============================================================================
// PROJECTS VIEW - Projects Dashboard
// ============================================================================
const ProjectsView = ({ projects, setCurrentProject, setCurrentView, onDeleteProject }) => {
  const [viewMode, setViewMode] = useState('grid'); // 'grid' or 'list'
  const [sortBy, setSortBy] = useState('recent'); // 'recent', 'name', 'type', 'phase'
  const [filterType, setFilterType] = useState('all'); // 'all', 'series', 'film', 'short'
  const [filterPhase, setFilterPhase] = useState('all'); // 'all', 'script', 'storyboard', 'roughcut', 'post', 'completed'
  const [searchQuery, setSearchQuery] = useState('');
  const [activeMenu, setActiveMenu] = useState(null); // project id with open menu
  
  // Phase definitions
  const phases = [
    { id: 'all', label: 'All Phases', color: colors.text.secondary },
    { id: 'script', label: 'Script', color: '#f59e0b' },
    { id: 'storyboard', label: 'Storyboard', color: '#8b5cf6' },
    { id: 'roughcut', label: 'Rough Cut', color: '#3b82f6' },
    { id: 'post', label: 'Post', color: '#10b981' },
    { id: 'completed', label: 'Completed', color: '#06b6d4' },
  ];
  
  // Get phase for a project (based on its progress)
  const getProjectPhase = (project) => {
    if (project.phase) return project.phase; // If explicitly set
    // Otherwise infer from content
    const hasScenes = project.episodes?.some(ep => ep.scenes?.length > 0);
    const hasGeneratedContent = project.episodes?.some(ep => 
      ep.scenes?.some(scene => scene.shots?.some(shot => shot.generated))
    );
    if (!hasScenes) return 'script';
    if (!hasGeneratedContent) return 'storyboard';
    return 'roughcut';
  };
  
  // Get phase display info
  const getPhaseInfo = (phaseId) => {
    return phases.find(p => p.id === phaseId) || phases[0];
  };
  
  // Sort projects
  const sortedProjects = [...projects].sort((a, b) => {
    switch (sortBy) {
      case 'name':
        return (a.title || '').localeCompare(b.title || '');
      case 'type':
        return (a.projectType || '').localeCompare(b.projectType || '');
      case 'phase':
        return phases.findIndex(p => p.id === getProjectPhase(a)) - phases.findIndex(p => p.id === getProjectPhase(b));
      case 'recent':
      default:
        return new Date(b.updatedAt || b.createdAt || 0) - new Date(a.updatedAt || a.createdAt || 0);
    }
  });
  
  // Filter projects
  const filteredProjects = sortedProjects.filter(p => {
    // Type filter
    if (filterType !== 'all' && p.projectType !== filterType) return false;
    // Phase filter
    if (filterPhase !== 'all' && getProjectPhase(p) !== filterPhase) return false;
    // Search filter
    if (searchQuery) {
      const query = searchQuery.toLowerCase();
      return (
        (p.title || '').toLowerCase().includes(query) ||
        (p.logline || '').toLowerCase().includes(query) ||
        (p.genre || '').toLowerCase().includes(query)
      );
    }
    return true;
  });
  
  const getProjectIcon = (type) => {
    switch (type) {
      case 'series': return '📺';
      case 'film': return '🎬';
      case 'short': return '🎥';
      default: return '📁';
    }
  };
  
  const getProjectStats = (project) => {
    if (project.projectType === 'series') {
      return `${project.seasons || 1} Season${(project.seasons || 1) !== 1 ? 's' : ''} · ${project.episodes?.length || 0} Episodes`;
    }
    return `${project.runtime || 0} minutes`;
  };
  
  const getTimeAgo = (date) => {
    if (!date) return 'Unknown';
    const now = new Date();
    const then = new Date(date);
    const diffMs = now - then;
    const diffMins = Math.floor(diffMs / 60000);
    const diffHours = Math.floor(diffMs / 3600000);
    const diffDays = Math.floor(diffMs / 86400000);
    
    if (diffMins < 1) return 'Just now';
    if (diffMins < 60) return `${diffMins}m ago`;
    if (diffHours < 24) return `${diffHours}h ago`;
    if (diffDays < 7) return `${diffDays}d ago`;
    return then.toLocaleDateString();
  };
  
  // Quick actions
  const handleDuplicate = (project, e) => {
    e.stopPropagation();
    setActiveMenu(null);
    const duplicated = {
      ...project,
      id: Date.now().toString(),
      title: `${project.title} (Copy)`,
      createdAt: new Date().toISOString(),
      updatedAt: new Date().toISOString(),
    };
    // This would need to be passed up to parent - for now just alert
    alert(`Duplicate feature: Would create "${duplicated.title}"`);
  };
  
  const handleArchive = (project, e) => {
    e.stopPropagation();
    setActiveMenu(null);
    alert(`Archive feature: Would archive "${project.title}"`);
  };
  
  const handleDelete = (project, e) => {
    e.stopPropagation();
    setActiveMenu(null);
    if (window.confirm(`Are you sure you want to delete "${project.title}"? This cannot be undone.`)) {
      onDeleteProject(project.id);
    }
  };
  
  // Close menu when clicking outside
  React.useEffect(() => {
    const handleClickOutside = () => setActiveMenu(null);
    if (activeMenu) {
      document.addEventListener('click', handleClickOutside);
      return () => document.removeEventListener('click', handleClickOutside);
    }
  }, [activeMenu]);
  
  return (
    <div style={{
      flex: 1,
      overflow: 'auto',
      background: colors.bg.primary,
    }}>
      {/* Header */}
      <div style={{
        padding: '32px 40px 24px',
        borderBottom: `1px solid ${colors.border.subtle}`,
        background: colors.bg.secondary,
      }}>
        <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'flex-start', marginBottom: '24px' }}>
          <div>
            <h1 style={{ fontSize: '28px', fontWeight: '700', marginBottom: '8px' }}>Projects</h1>
            <p style={{ fontSize: '14px', color: colors.text.secondary }}>
              Manage all your video projects in one place
            </p>
          </div>
          <Button 
            onClick={() => setCurrentView('new-project')}
            style={{
              background: 'linear-gradient(135deg, #8b5cf6 0%, #a855f7 100%)',
              boxShadow: '0 4px 15px rgba(139, 92, 246, 0.4)',
            }}
          >
            <Icons.Plus style={{ width: 16, height: 16, marginRight: '8px' }} />
            Create New Project
          </Button>
        </div>
        
        {/* Search Bar */}
        <div style={{ marginBottom: '20px' }}>
          <div style={{
            position: 'relative',
            maxWidth: '400px',
          }}>
            <Icons.Search style={{
              position: 'absolute',
              left: '14px',
              top: '50%',
              transform: 'translateY(-50%)',
              width: 18,
              height: 18,
              color: colors.text.tertiary,
            }} />
            <input
              type="text"
              placeholder="Search projects..."
              value={searchQuery}
              onChange={(e) => setSearchQuery(e.target.value)}
              style={{
                width: '100%',
                padding: '12px 14px 12px 44px',
                background: colors.bg.tertiary,
                border: `1px solid ${colors.border.default}`,
                borderRadius: '10px',
                color: colors.text.primary,
                fontSize: '14px',
                outline: 'none',
              }}
            />
            {searchQuery && (
              <button
                onClick={() => setSearchQuery('')}
                style={{
                  position: 'absolute',
                  right: '12px',
                  top: '50%',
                  transform: 'translateY(-50%)',
                  background: 'none',
                  border: 'none',
                  color: colors.text.tertiary,
                  cursor: 'pointer',
                  fontSize: '18px',
                }}
              >
                ×
              </button>
            )}
          </div>
        </div>
        
        {/* Filters & View Controls */}
        <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center', flexWrap: 'wrap', gap: '16px' }}>
          {/* Filter Tabs */}
          <div style={{ display: 'flex', gap: '8px', flexWrap: 'wrap' }}>
            {/* Type Filters */}
            {[
              { id: 'all', label: 'All Projects' },
              { id: 'series', label: 'Series' },
              { id: 'film', label: 'Films' },
              { id: 'short', label: 'Shorts' },
            ].map(filter => (
              <button
                key={filter.id}
                onClick={() => setFilterType(filter.id)}
                style={{
                  padding: '8px 16px',
                  background: filterType === filter.id ? colors.bg.tertiary : 'transparent',
                  border: `1px solid ${filterType === filter.id ? colors.accent.primary : colors.border.default}`,
                  borderRadius: '20px',
                  color: filterType === filter.id ? colors.accent.primary : colors.text.secondary,
                  fontSize: '13px',
                  cursor: 'pointer',
                  transition: 'all 0.2s ease',
                }}
              >
                {filter.label}
              </button>
            ))}
            
            {/* Divider */}
            <div style={{ width: '1px', background: colors.border.default, margin: '0 8px' }} />
            
            {/* Phase Filters */}
            {phases.map(phase => (
              <button
                key={phase.id}
                onClick={() => setFilterPhase(phase.id)}
                style={{
                  padding: '8px 16px',
                  background: filterPhase === phase.id ? `${phase.color}20` : 'transparent',
                  border: `1px solid ${filterPhase === phase.id ? phase.color : colors.border.default}`,
                  borderRadius: '20px',
                  color: filterPhase === phase.id ? phase.color : colors.text.secondary,
                  fontSize: '13px',
                  cursor: 'pointer',
                  transition: 'all 0.2s ease',
                  display: 'flex',
                  alignItems: 'center',
                  gap: '6px',
                }}
              >
                {phase.id !== 'all' && (
                  <span style={{
                    width: '8px',
                    height: '8px',
                    borderRadius: '50%',
                    background: phase.color,
                  }} />
                )}
                {phase.label}
              </button>
            ))}
          </div>
          
          {/* Sort & View Controls */}
          <div style={{ display: 'flex', alignItems: 'center', gap: '12px' }}>
            <select
              value={sortBy}
              onChange={(e) => setSortBy(e.target.value)}
              style={{
                padding: '8px 12px',
                background: colors.bg.tertiary,
                border: `1px solid ${colors.border.default}`,
                borderRadius: '6px',
                color: colors.text.primary,
                fontSize: '13px',
              }}
            >
              <option value="recent">Last Updated</option>
              <option value="name">Name A-Z</option>
              <option value="type">By Type</option>
              <option value="phase">By Phase</option>
            </select>
            
            <div style={{ display: 'flex', gap: '4px' }}>
              <button
                onClick={() => setViewMode('grid')}
                style={{
                  padding: '8px',
                  background: viewMode === 'grid' ? colors.bg.tertiary : 'transparent',
                  border: `1px solid ${viewMode === 'grid' ? colors.accent.primary : colors.border.default}`,
                  borderRadius: '6px',
                  color: viewMode === 'grid' ? colors.accent.primary : colors.text.tertiary,
                  cursor: 'pointer',
                }}
              >
                <Icons.Layout style={{ width: 16, height: 16 }} />
              </button>
              <button
                onClick={() => setViewMode('list')}
                style={{
                  padding: '8px',
                  background: viewMode === 'list' ? colors.bg.tertiary : 'transparent',
                  border: `1px solid ${viewMode === 'list' ? colors.accent.primary : colors.border.default}`,
                  borderRadius: '6px',
                  color: viewMode === 'list' ? colors.accent.primary : colors.text.tertiary,
                  cursor: 'pointer',
                }}
              >
                <Icons.Menu style={{ width: 16, height: 16 }} />
              </button>
            </div>
          </div>
        </div>
      </div>
      
      {/* Projects Content */}
      <div style={{ padding: '24px 40px' }}>
        {/* Results Count */}
        {(searchQuery || filterType !== 'all' || filterPhase !== 'all') && (
          <div style={{ marginBottom: '16px', fontSize: '13px', color: colors.text.tertiary }}>
            Showing {filteredProjects.length} of {projects.length} projects
            {searchQuery && ` matching "${searchQuery}"`}
          </div>
        )}
        
        {filteredProjects.length === 0 ? (
          <div style={{
            background: colors.bg.secondary,
            border: `1px solid ${colors.border.subtle}`,
            borderRadius: '16px',
            padding: '80px 40px',
            textAlign: 'center',
          }}>
            <div style={{
              width: '80px',
              height: '80px',
              borderRadius: '20px',
              background: colors.bg.tertiary,
              display: 'flex',
              alignItems: 'center',
              justifyContent: 'center',
              margin: '0 auto 20px',
              fontSize: '32px',
            }}>
              {searchQuery ? '🔍' : '🎬'}
            </div>
            <h3 style={{ fontSize: '20px', fontWeight: '600', marginBottom: '8px' }}>
              {searchQuery ? 'No results found' : filterType === 'all' ? 'No projects yet' : `No ${filterType} projects`}
            </h3>
            <p style={{ fontSize: '14px', color: colors.text.tertiary, marginBottom: '24px', maxWidth: '400px', margin: '0 auto 24px' }}>
              {searchQuery 
                ? `Try adjusting your search or filters`
                : filterType === 'all' 
                  ? 'Create your first project to start building amazing video content'
                  : `You haven't created any ${filterType} projects yet`
              }
            </p>
            {!searchQuery && (
              <Button 
                onClick={() => setCurrentView('new-project')}
                style={{
                  background: 'linear-gradient(135deg, #8b5cf6 0%, #a855f7 100%)',
                }}
              >
                <Icons.Plus style={{ width: 16, height: 16, marginRight: '8px' }} />
                Create Your First Project
              </Button>
            )}
          </div>
        ) : viewMode === 'grid' ? (
          /* Grid View */
          <div style={{ 
            display: 'grid', 
            gridTemplateColumns: 'repeat(auto-fill, minmax(300px, 1fr))', 
            gap: '20px',
          }}>
            {filteredProjects.map((project) => {
              const phase = getProjectPhase(project);
              const phaseInfo = getPhaseInfo(phase);
              
              return (
                <div
                  key={project.id}
                  onClick={() => {
                    setCurrentProject(project);
                    setCurrentView('episode-setup');
                  }}
                  style={{
                    background: colors.bg.secondary,
                    border: `1px solid ${colors.border.subtle}`,
                    borderRadius: '12px',
                    overflow: 'hidden',
                    cursor: 'pointer',
                    transition: 'all 0.2s ease',
                    position: 'relative',
                  }}
                  onMouseEnter={(e) => {
                    e.currentTarget.style.borderColor = colors.accent.primary;
                    e.currentTarget.style.transform = 'translateY(-4px)';
                    e.currentTarget.style.boxShadow = '0 8px 25px rgba(0,0,0,0.3)';
                  }}
                  onMouseLeave={(e) => {
                    e.currentTarget.style.borderColor = colors.border.subtle;
                    e.currentTarget.style.transform = 'translateY(0)';
                    e.currentTarget.style.boxShadow = 'none';
                  }}
                >
                  {/* Cover Image */}
                  <div style={{
                    height: '140px',
                    background: project.coverGradient || `linear-gradient(135deg, ${colors.accent.primary}40 0%, ${colors.accent.secondary}40 100%)`,
                    display: 'flex',
                    alignItems: 'center',
                    justifyContent: 'center',
                    position: 'relative',
                  }}>
                    <span style={{ fontSize: '48px', opacity: 0.6 }}>
                      {getProjectIcon(project.projectType)}
                    </span>
                    
                    {/* Type Badge */}
                    <div style={{
                      position: 'absolute',
                      top: '12px',
                      left: '12px',
                      padding: '4px 10px',
                      background: 'rgba(0,0,0,0.6)',
                      borderRadius: '6px',
                      fontSize: '11px',
                      fontWeight: '500',
                      color: '#fff',
                      textTransform: 'capitalize',
                    }}>
                      {project.projectType || 'Project'}
                    </div>
                    
                    {/* Phase Badge */}
                    <div style={{
                      position: 'absolute',
                      bottom: '12px',
                      left: '12px',
                      padding: '4px 10px',
                      background: phaseInfo.color,
                      borderRadius: '6px',
                      fontSize: '11px',
                      fontWeight: '600',
                      color: '#fff',
                      display: 'flex',
                      alignItems: 'center',
                      gap: '4px',
                    }}>
                      {phaseInfo.label}
                    </div>
                    
                    {/* Menu Button */}
                    <div style={{ position: 'absolute', top: '12px', right: '12px' }}>
                      <button
                        onClick={(e) => {
                          e.stopPropagation();
                          setActiveMenu(activeMenu === project.id ? null : project.id);
                        }}
                        style={{
                          padding: '6px 10px',
                          background: 'rgba(0,0,0,0.6)',
                          border: 'none',
                          borderRadius: '6px',
                          color: '#fff',
                          cursor: 'pointer',
                          fontSize: '14px',
                        }}
                      >
                        ⋯
                      </button>
                      
                      {/* Dropdown Menu */}
                      {activeMenu === project.id && (
                        <div style={{
                          position: 'absolute',
                          top: '100%',
                          right: '0',
                          marginTop: '4px',
                          background: colors.bg.secondary,
                          border: `1px solid ${colors.border.default}`,
                          borderRadius: '8px',
                          boxShadow: '0 8px 24px rgba(0,0,0,0.4)',
                          overflow: 'hidden',
                          zIndex: 100,
                          minWidth: '150px',
                        }}>
                          <button
                            onClick={(e) => handleDuplicate(project, e)}
                            style={{
                              width: '100%',
                              padding: '10px 14px',
                              background: 'transparent',
                              border: 'none',
                              color: colors.text.primary,
                              fontSize: '13px',
                              cursor: 'pointer',
                              textAlign: 'left',
                              display: 'flex',
                              alignItems: 'center',
                              gap: '8px',
                            }}
                            onMouseEnter={(e) => e.currentTarget.style.background = colors.bg.tertiary}
                            onMouseLeave={(e) => e.currentTarget.style.background = 'transparent'}
                          >
                            <Icons.Copy style={{ width: 14, height: 14 }} />
                            Duplicate
                          </button>
                          <button
                            onClick={(e) => handleArchive(project, e)}
                            style={{
                              width: '100%',
                              padding: '10px 14px',
                              background: 'transparent',
                              border: 'none',
                              color: colors.text.primary,
                              fontSize: '13px',
                              cursor: 'pointer',
                              textAlign: 'left',
                              display: 'flex',
                              alignItems: 'center',
                              gap: '8px',
                            }}
                            onMouseEnter={(e) => e.currentTarget.style.background = colors.bg.tertiary}
                            onMouseLeave={(e) => e.currentTarget.style.background = 'transparent'}
                          >
                            <Icons.Folder style={{ width: 14, height: 14 }} />
                            Archive
                          </button>
                          <div style={{ height: '1px', background: colors.border.subtle }} />
                          <button
                            onClick={(e) => handleDelete(project, e)}
                            style={{
                              width: '100%',
                              padding: '10px 14px',
                              background: 'transparent',
                              border: 'none',
                              color: colors.accent.error,
                              fontSize: '13px',
                              cursor: 'pointer',
                              textAlign: 'left',
                              display: 'flex',
                              alignItems: 'center',
                              gap: '8px',
                            }}
                            onMouseEnter={(e) => e.currentTarget.style.background = colors.bg.tertiary}
                            onMouseLeave={(e) => e.currentTarget.style.background = 'transparent'}
                          >
                            <Icons.Trash style={{ width: 14, height: 14 }} />
                            Delete
                          </button>
                        </div>
                      )}
                    </div>
                  </div>
                  
                  {/* Content */}
                  <div style={{ padding: '16px' }}>
                    <h3 style={{ fontSize: '16px', fontWeight: '600', marginBottom: '6px' }}>
                      {project.title || 'Untitled Project'}
                    </h3>
                    <p style={{ fontSize: '13px', color: colors.text.tertiary, marginBottom: '12px' }}>
                      {project.genre || 'No genre'} · {project.filmStyle || 'No style'}
                    </p>
                    
                    <div style={{ 
                      display: 'flex', 
                      justifyContent: 'space-between',
                      alignItems: 'center',
                      paddingTop: '12px',
                      borderTop: `1px solid ${colors.border.subtle}`,
                    }}>
                      <span style={{ fontSize: '12px', color: colors.text.secondary }}>
                        {getProjectStats(project)}
                      </span>
                      <span style={{ fontSize: '11px', color: colors.text.tertiary }}>
                        {getTimeAgo(project.updatedAt || project.createdAt)}
                      </span>
                    </div>
                  </div>
                </div>
              );
            })}
          </div>
        ) : (
          /* List View */
          <div style={{ 
            background: colors.bg.secondary,
            borderRadius: '12px',
            border: `1px solid ${colors.border.subtle}`,
            overflow: 'hidden',
          }}>
            {/* Table Header */}
            <div style={{
              display: 'grid',
              gridTemplateColumns: '2fr 100px 100px 1fr 120px 80px',
              padding: '12px 20px',
              background: colors.bg.tertiary,
              borderBottom: `1px solid ${colors.border.subtle}`,
              fontSize: '12px',
              fontWeight: '600',
              color: colors.text.tertiary,
              textTransform: 'uppercase',
            }}>
              <span>Project</span>
              <span>Type</span>
              <span>Phase</span>
              <span>Details</span>
              <span>Updated</span>
              <span></span>
            </div>
            
            {/* Table Rows */}
            {filteredProjects.map((project, idx) => {
              const phase = getProjectPhase(project);
              const phaseInfo = getPhaseInfo(phase);
              
              return (
                <div
                  key={project.id}
                  onClick={() => {
                    setCurrentProject(project);
                    setCurrentView('episode-setup');
                  }}
                  style={{
                    display: 'grid',
                    gridTemplateColumns: '2fr 100px 100px 1fr 120px 80px',
                    padding: '16px 20px',
                    borderBottom: idx < filteredProjects.length - 1 ? `1px solid ${colors.border.subtle}` : 'none',
                    cursor: 'pointer',
                    transition: 'background 0.15s ease',
                    alignItems: 'center',
                  }}
                  onMouseEnter={(e) => e.currentTarget.style.background = colors.bg.tertiary}
                  onMouseLeave={(e) => e.currentTarget.style.background = 'transparent'}
                >
                  <div style={{ display: 'flex', alignItems: 'center', gap: '12px' }}>
                    <span style={{ fontSize: '24px' }}>{getProjectIcon(project.projectType)}</span>
                    <div>
                      <div style={{ fontSize: '14px', fontWeight: '500' }}>{project.title || 'Untitled'}</div>
                      <div style={{ fontSize: '12px', color: colors.text.tertiary }}>
                        {project.genre || 'No genre'}
                      </div>
                    </div>
                  </div>
                  <span style={{ 
                    fontSize: '12px', 
                    color: colors.text.secondary,
                    textTransform: 'capitalize',
                  }}>
                    {project.projectType || 'Unknown'}
                  </span>
                  <span style={{
                    padding: '4px 8px',
                    background: `${phaseInfo.color}20`,
                    color: phaseInfo.color,
                    fontSize: '11px',
                    fontWeight: '600',
                    borderRadius: '4px',
                    display: 'inline-block',
                    width: 'fit-content',
                  }}>
                    {phaseInfo.label}
                  </span>
                  <span style={{ fontSize: '12px', color: colors.text.secondary }}>
                    {getProjectStats(project)}
                  </span>
                  <span style={{ fontSize: '12px', color: colors.text.tertiary }}>
                    {getTimeAgo(project.updatedAt || project.createdAt)}
                  </span>
                  <button
                    onClick={(e) => {
                      e.stopPropagation();
                      setCurrentProject(project);
                      setCurrentView('episode-setup');
                    }}
                    style={{
                      padding: '6px 12px',
                      background: colors.accent.primary,
                      border: 'none',
                      borderRadius: '6px',
                      color: '#fff',
                      fontSize: '12px',
                      cursor: 'pointer',
                    }}
                  >
                    Open
                  </button>
                </div>
              );
            })}
          </div>
        )}
        
        {/* Stats Footer */}
        {projects.length > 0 && (
          <div style={{
            marginTop: '24px',
            padding: '16px 20px',
            background: colors.bg.secondary,
            borderRadius: '8px',
            display: 'flex',
            gap: '32px',
            fontSize: '13px',
            color: colors.text.secondary,
            flexWrap: 'wrap',
          }}>
            <span><strong style={{ color: colors.text.primary }}>{projects.length}</strong> Total Projects</span>
            <span><strong style={{ color: colors.text.primary }}>{projects.filter(p => p.projectType === 'series').length}</strong> Series</span>
            <span><strong style={{ color: colors.text.primary }}>{projects.filter(p => p.projectType === 'film').length}</strong> Films</span>
            <span><strong style={{ color: colors.text.primary }}>{projects.filter(p => p.projectType === 'short').length}</strong> Shorts</span>
            <span style={{ marginLeft: 'auto', color: colors.text.tertiary }}>
              {phases.slice(1).map(p => (
                <span key={p.id} style={{ marginLeft: '16px' }}>
                  <span style={{ 
                    display: 'inline-block',
                    width: '8px', 
                    height: '8px', 
                    borderRadius: '50%', 
                    background: p.color,
                    marginRight: '4px',
                  }} />
                  {projects.filter(proj => getProjectPhase(proj) === p.id).length}
                </span>
              ))}
            </span>
          </div>
        )}
      </div>
    </div>
  );
};

// ============================================================================
// NEW PROJECT WIZARD
// ============================================================================
const NewProjectWizard = ({ onComplete, onCancel }) => {
  const [step, setStep] = useState(0);
  const [hasUnsavedChanges, setHasUnsavedChanges] = useState(false);
  const [savedProject, setSavedProject] = useState(null); // Tracks last saved state
  const [project, setProject] = useState({
    title: '',
    projectType: '', // 'short', 'film', 'series'
    logline: '',
    theme: '',
    filmStyle: '',
    genre: '',
    subgenres: [],
    tones: [],
    referenceStudios: '',
    referenceFilms: '',
    // Series-specific
    seasons: 1,
    episodesPerSeason: 10,
    // Short/Film-specific
    runtime: 90, // minutes
    // Common
    episodeLength: 45,
    styleReferences: {
      visual: [],
      camera: [],
      tone: [],
      lighting: [],
    },
    videoStyle: '',
    // Generator config
    primaryImageGenerator: 'flux-pro',
    primaryVideoGenerator: 'sora-2',
  });
  
  const steps = ['Details', 'Technical', 'Creative'];
  
  const PROJECT_TYPES = [
    { 
      id: 'short', 
      name: 'Short Film', 
      icon: '🎬', 
      description: 'Under 40 minutes, single narrative',
      defaultRuntime: 15,
    },
    { 
      id: 'film', 
      name: 'Feature Film', 
      icon: '🎥', 
      description: '40+ minutes, full-length movie',
      defaultRuntime: 90,
    },
    { 
      id: 'series', 
      name: 'Series', 
      icon: '📺', 
      description: 'Multiple episodes across seasons',
      defaultRuntime: 45,
    },
  ];
  
  const IMAGE_GENERATORS = [
    { id: 'flux-pro', name: 'Flux Pro', provider: 'Black Forest Labs', badge: 'RECOMMENDED', features: 'Photorealistic, text rendering' },
    { id: 'nano-banana', name: 'Nano Banana Pro', provider: 'Banan', badge: 'BEST FOR SCENES', features: 'Background/lighting layers' },
    { id: 'midjourney', name: 'Midjourney v6', provider: 'Midjourney', features: 'Artistic, stylized' },
    { id: 'grok-imagine', name: 'Grok Imagine', provider: 'xAI', features: 'Fast, creative' },
  ];
  
  const VIDEO_GENERATORS = [
    { id: 'sora-2', name: 'Sora 2', provider: 'OpenAI', maxDuration: 20, badge: 'BEST QUALITY', features: 'Photorealistic, physics' },
    { id: 'runway-gen3', name: 'Runway Gen-3', provider: 'Runway', maxDuration: 10, features: 'Motion brush, extend' },
    { id: 'kling-1.6', name: 'Kling 1.6', provider: 'Kuaishou', maxDuration: 10, badge: 'FAST', features: 'Motion mode, lip sync' },
    { id: 'veo-2', name: 'Veo 2', provider: 'Google', maxDuration: 60, badge: 'LONG FORM', features: '4K, long clips' },
    { id: 'minimax', name: 'Minimax', provider: 'Minimax', maxDuration: 6, features: 'Director mode' },
    { id: 'luma-ray2', name: 'Luma Ray 2', provider: 'Luma AI', maxDuration: 9, features: 'Keyframes, extend' },
  ];
  
  const updateProject = (key, value) => {
    setProject((prev) => ({ ...prev, [key]: value }));
    setHasUnsavedChanges(true);
  };
  
  // Save current step progress
  const saveProgress = () => {
    setSavedProject({ ...project, lastSavedStep: step });
    setHasUnsavedChanges(false);
    console.log('Progress saved at step:', step);
  };
  
  // Handle going back
  const handleBack = () => {
    if (step > 0) {
      // Auto-save before going back if there are changes
      if (hasUnsavedChanges) {
        saveProgress();
      }
      setStep(step - 1);
    } else {
      onCancel();
    }
  };
  
  // Handle continue/next
  const handleContinue = () => {
    if (step < steps.length - 1) {
      saveProgress();
      setStep(step + 1);
    } else {
      // Final step - create project
      createProject();
    }
  };
  
  // Create the final project
  const createProject = () => {
    // Generate episode structure based on project type
    const episodes = [];
    const totalEpisodes = getTotalEpisodes();
    
    for (let i = 0; i < totalEpisodes; i++) {
      const seasonNum = isSeries ? Math.floor(i / project.episodesPerSeason) + 1 : 1;
      const episodeNum = isSeries ? (i % project.episodesPerSeason) + 1 : 1;
      
      episodes.push({
        id: `ep-${i + 1}`,
        seasonNumber: seasonNum,
        episodeNumber: episodeNum,
        title: isSeries ? `Episode ${episodeNum}` : project.title,
        logline: '',
        events: [],
        script: '',
        scenes: [],
        status: 'draft',
        duration: getEpisodeLength(),
      });
    }
    
    onComplete({
      ...project,
      id: Date.now().toString(),
      createdAt: new Date().toISOString(),
      totalEpisodes,
      episodes,
      imageGeneratorConfig: selectedImageGenerator,
      videoGeneratorConfig: selectedVideoGenerator,
      coverGradient: VIDEO_STYLES.find(s => s.id === project.videoStyle)?.preview,
    });
  };
  
  const toggleSubgenre = (subgenre) => {
    setProject((prev) => ({
      ...prev,
      subgenres: prev.subgenres.includes(subgenre)
        ? prev.subgenres.filter((s) => s !== subgenre)
        : [...prev.subgenres, subgenre],
    }));
    setHasUnsavedChanges(true);
  };
  
  const toggleTone = (tone) => {
    setProject((prev) => ({
      ...prev,
      tones: prev.tones.includes(tone)
        ? prev.tones.filter((t) => t !== tone)
        : [...prev.tones, tone],
    }));
    setHasUnsavedChanges(true);
  };
  
  const selectedGenre = GENRES.find((g) => g.id === project.genre);
  const selectedImageGenerator = IMAGE_GENERATORS.find((g) => g.id === project.primaryImageGenerator);
  const selectedVideoGenerator = VIDEO_GENERATORS.find((g) => g.id === project.primaryVideoGenerator);
  const isSeries = project.projectType === 'series';
  
  // Calculate total episodes based on project type
  const getTotalEpisodes = () => {
    if (project.projectType === 'series') {
      return project.seasons * project.episodesPerSeason;
    }
    return 1; // Short or Film = 1 episode
  };
  
  const getEpisodeLength = () => {
    if (project.projectType === 'series') {
      return project.episodeLength;
    }
    return project.runtime;
  };
  
  const canProceed = () => {
    switch (step) {
      case 0: // Details - Project Type, Title, Structure
        if (!project.title || !project.projectType) return false;
        if (project.projectType === 'series') {
          return project.seasons > 0 && project.episodesPerSeason > 0 && project.episodeLength > 0;
        }
        return project.runtime > 0;
      case 1: // Technical - Film Style, Video Style, Generators
        return project.filmStyle && project.videoStyle;
      case 2: // Creative - Everything else (optional but needs genre)
        return project.genre;
      default: return false;
    }
  };
  
  const renderStep = () => {
    switch (step) {
      case 0: // STEP 1: DETAILS - Project Type, Title, Structure
        return (
          <div style={{ animation: 'fadeIn 0.3s ease' }}>
            <h2 style={{ fontSize: '24px', fontWeight: '600', marginBottom: '8px' }}>
              Project Details
            </h2>
            <p style={{ color: colors.text.secondary, marginBottom: '32px' }}>
              Define the basic structure of your project
            </p>
            
            {/* Project Type Selection */}
            <div style={{ marginBottom: '32px' }}>
              <label style={{
                display: 'block',
                marginBottom: '12px',
                fontSize: '13px',
                fontWeight: '500',
                color: colors.text.secondary,
                textTransform: 'uppercase',
                letterSpacing: '0.5px',
              }}>
                Project Type
              </label>
              <div style={{ display: 'grid', gridTemplateColumns: 'repeat(3, 1fr)', gap: '12px' }}>
                {PROJECT_TYPES.map((type) => (
                  <button
                    key={type.id}
                    onClick={() => {
                      updateProject('projectType', type.id);
                      updateProject('runtime', type.defaultRuntime);
                      updateProject('episodeLength', type.defaultRuntime);
                    }}
                    style={{
                      padding: '24px 20px',
                      background: project.projectType === type.id ? `${colors.accent.primary}15` : colors.bg.tertiary,
                      border: `2px solid ${project.projectType === type.id ? colors.accent.primary : colors.border.subtle}`,
                      borderRadius: '12px',
                      cursor: 'pointer',
                      transition: 'all 0.2s ease',
                      textAlign: 'center',
                    }}
                  >
                    <div style={{ fontSize: '32px', marginBottom: '12px' }}>{type.icon}</div>
                    <div style={{
                      fontSize: '16px',
                      fontWeight: '600',
                      color: project.projectType === type.id ? colors.text.primary : colors.text.secondary,
                      marginBottom: '4px',
                    }}>
                      {type.name}
                    </div>
                    <div style={{ fontSize: '12px', color: colors.text.tertiary }}>
                      {type.description}
                    </div>
                  </button>
                ))}
              </div>
            </div>
            
            <Input
              label="Project Title"
              placeholder="Enter your project title..."
              value={project.title}
              onChange={(v) => updateProject('title', v)}
            />
            
            {/* Structure based on project type */}
            {isSeries ? (
              <>
                <div style={{ display: 'grid', gridTemplateColumns: '1fr 1fr 1fr', gap: '24px', marginBottom: '32px' }}>
                  <div>
                    <label style={{
                      display: 'block',
                      marginBottom: '8px',
                      fontSize: '13px',
                      fontWeight: '500',
                      color: colors.text.secondary,
                      textTransform: 'uppercase',
                    }}>
                      Number of Seasons
                    </label>
                    <input
                      type="number"
                      min="1"
                      max="20"
                      value={project.seasons}
                      onChange={(e) => updateProject('seasons', parseInt(e.target.value) || 1)}
                      style={{
                        width: '100%',
                        padding: '16px',
                        background: colors.bg.secondary,
                        border: `1px solid ${colors.border.subtle}`,
                        borderRadius: '8px',
                        color: colors.text.primary,
                        fontSize: '24px',
                        fontWeight: '600',
                        textAlign: 'center',
                      }}
                    />
                  </div>
                  
                  <div>
                    <label style={{
                      display: 'block',
                      marginBottom: '8px',
                      fontSize: '13px',
                      fontWeight: '500',
                      color: colors.text.secondary,
                      textTransform: 'uppercase',
                    }}>
                      Episodes per Season
                    </label>
                    <input
                      type="number"
                      min="1"
                      max="50"
                      value={project.episodesPerSeason}
                      onChange={(e) => updateProject('episodesPerSeason', parseInt(e.target.value) || 1)}
                      style={{
                        width: '100%',
                        padding: '16px',
                        background: colors.bg.secondary,
                        border: `1px solid ${colors.border.subtle}`,
                        borderRadius: '8px',
                        color: colors.text.primary,
                        fontSize: '24px',
                        fontWeight: '600',
                        textAlign: 'center',
                      }}
                    />
                  </div>
                  
                  <div>
                    <label style={{
                      display: 'block',
                      marginBottom: '8px',
                      fontSize: '13px',
                      fontWeight: '500',
                      color: colors.text.secondary,
                      textTransform: 'uppercase',
                    }}>
                      Episode Length (min)
                    </label>
                    <input
                      type="number"
                      min="5"
                      max="180"
                      value={project.episodeLength}
                      onChange={(e) => updateProject('episodeLength', parseInt(e.target.value) || 30)}
                      style={{
                        width: '100%',
                        padding: '16px',
                        background: colors.bg.secondary,
                        border: `1px solid ${colors.border.subtle}`,
                        borderRadius: '8px',
                        color: colors.text.primary,
                        fontSize: '24px',
                        fontWeight: '600',
                        textAlign: 'center',
                      }}
                    />
                  </div>
                </div>
                
                {/* Series Overview */}
                <div style={{
                  background: colors.bg.tertiary,
                  borderRadius: '12px',
                  padding: '24px',
                  border: `1px solid ${colors.border.subtle}`,
                }}>
                  <h3 style={{ fontSize: '16px', fontWeight: '600', marginBottom: '16px' }}>
                    Series Overview
                  </h3>
                  <div style={{ display: 'grid', gridTemplateColumns: 'repeat(4, 1fr)', gap: '16px' }}>
                    <div style={{ textAlign: 'center' }}>
                      <div style={{ fontSize: '32px', fontWeight: '700', color: colors.accent.primary }}>
                        {project.seasons}
                      </div>
                      <div style={{ fontSize: '13px', color: colors.text.secondary }}>Seasons</div>
                    </div>
                    <div style={{ textAlign: 'center' }}>
                      <div style={{ fontSize: '32px', fontWeight: '700', color: colors.accent.primary }}>
                        {project.seasons * project.episodesPerSeason}
                      </div>
                      <div style={{ fontSize: '13px', color: colors.text.secondary }}>Total Episodes</div>
                    </div>
                    <div style={{ textAlign: 'center' }}>
                      <div style={{ fontSize: '32px', fontWeight: '700', color: colors.accent.primary }}>
                        {Math.round((project.seasons * project.episodesPerSeason * project.episodeLength) / 60)}h
                      </div>
                      <div style={{ fontSize: '13px', color: colors.text.secondary }}>Total Runtime</div>
                    </div>
                    <div style={{ textAlign: 'center' }}>
                      <div style={{ fontSize: '32px', fontWeight: '700', color: colors.accent.primary }}>
                        ~{Math.round(project.episodeLength / 15 * 4)}
                      </div>
                      <div style={{ fontSize: '13px', color: colors.text.secondary }}>Scenes/Episode</div>
                    </div>
                  </div>
                </div>
              </>
            ) : project.projectType && (
              <>
                <div style={{ display: 'grid', gridTemplateColumns: '1fr 1fr', gap: '24px', marginBottom: '32px' }}>
                  <div>
                    <label style={{
                      display: 'block',
                      marginBottom: '8px',
                      fontSize: '13px',
                      fontWeight: '500',
                      color: colors.text.secondary,
                      textTransform: 'uppercase',
                    }}>
                      Runtime (minutes)
                    </label>
                    <input
                      type="number"
                      min="1"
                      max="300"
                      value={project.runtime}
                      onChange={(e) => updateProject('runtime', parseInt(e.target.value) || 15)}
                      style={{
                        width: '100%',
                        padding: '16px',
                        background: colors.bg.secondary,
                        border: `1px solid ${colors.border.subtle}`,
                        borderRadius: '8px',
                        color: colors.text.primary,
                        fontSize: '24px',
                        fontWeight: '600',
                        textAlign: 'center',
                      }}
                    />
                  </div>
                  
                  <div>
                    <label style={{
                      display: 'block',
                      marginBottom: '8px',
                      fontSize: '13px',
                      fontWeight: '500',
                      color: colors.text.secondary,
                      textTransform: 'uppercase',
                    }}>
                      Estimated Acts
                    </label>
                    <div style={{
                      width: '100%',
                      padding: '16px',
                      background: colors.bg.secondary,
                      border: `1px solid ${colors.border.subtle}`,
                      borderRadius: '8px',
                      color: colors.text.primary,
                      fontSize: '24px',
                      fontWeight: '600',
                      textAlign: 'center',
                    }}>
                      {project.runtime <= 15 ? '1-2' : project.runtime <= 40 ? '3' : '3-5'}
                    </div>
                  </div>
                </div>
                
                {/* Film Overview */}
                <div style={{
                  background: colors.bg.tertiary,
                  borderRadius: '12px',
                  padding: '24px',
                  border: `1px solid ${colors.border.subtle}`,
                }}>
                  <h3 style={{ fontSize: '16px', fontWeight: '600', marginBottom: '16px' }}>
                    {project.projectType === 'short' ? 'Short Film' : 'Feature Film'} Overview
                  </h3>
                  <div style={{ display: 'grid', gridTemplateColumns: 'repeat(3, 1fr)', gap: '16px' }}>
                    <div style={{ textAlign: 'center' }}>
                      <div style={{ fontSize: '32px', fontWeight: '700', color: colors.accent.primary }}>
                        {project.runtime}
                      </div>
                      <div style={{ fontSize: '13px', color: colors.text.secondary }}>Minutes</div>
                    </div>
                    <div style={{ textAlign: 'center' }}>
                      <div style={{ fontSize: '32px', fontWeight: '700', color: colors.accent.primary }}>
                        ~{Math.round(project.runtime / 15 * 4)}
                      </div>
                      <div style={{ fontSize: '13px', color: colors.text.secondary }}>Est. Scenes</div>
                    </div>
                    <div style={{ textAlign: 'center' }}>
                      <div style={{ fontSize: '32px', fontWeight: '700', color: colors.accent.primary }}>
                        {project.runtime <= 15 ? '1-2' : project.runtime <= 40 ? '3' : '3-5'}
                      </div>
                      <div style={{ fontSize: '13px', color: colors.text.secondary }}>Acts</div>
                    </div>
                  </div>
                </div>
              </>
            )}
          </div>
        );
        
      case 1: // STEP 2: TECHNICAL - Film Style, Video Style, AI Generators
        return (
          <div style={{ animation: 'fadeIn 0.3s ease' }}>
            <h2 style={{ fontSize: '24px', fontWeight: '600', marginBottom: '8px' }}>
              Technical Setup
            </h2>
            <p style={{ color: colors.text.secondary, marginBottom: '32px' }}>
              Configure the visual style and AI generation tools
            </p>
            
            {/* Film Style */}
            <div style={{ marginBottom: '32px' }}>
              <label style={{
                display: 'block',
                marginBottom: '12px',
                fontSize: '13px',
                fontWeight: '500',
                color: colors.text.secondary,
                textTransform: 'uppercase',
              }}>
                Film Style
              </label>
              <div style={{ display: 'grid', gridTemplateColumns: 'repeat(4, 1fr)', gap: '12px' }}>
                {FILM_STYLES.map((style) => (
                  <button
                    key={style.id}
                    onClick={() => updateProject('filmStyle', style.id)}
                    style={{
                      padding: '20px 16px',
                      background: project.filmStyle === style.id ? `${colors.accent.primary}20` : colors.bg.tertiary,
                      border: `2px solid ${project.filmStyle === style.id ? colors.accent.primary : colors.border.subtle}`,
                      borderRadius: '12px',
                      cursor: 'pointer',
                      textAlign: 'center',
                    }}
                  >
                    <div style={{ fontSize: '28px', marginBottom: '8px' }}>{style.icon}</div>
                    <div style={{
                      fontSize: '14px',
                      fontWeight: '500',
                      color: project.filmStyle === style.id ? colors.text.primary : colors.text.secondary,
                    }}>
                      {style.name}
                    </div>
                  </button>
                ))}
              </div>
            </div>
            
            {/* Video Style */}
            <div style={{ marginBottom: '32px' }}>
              <label style={{
                display: 'block',
                marginBottom: '12px',
                fontSize: '13px',
                fontWeight: '500',
                color: colors.text.secondary,
                textTransform: 'uppercase',
              }}>
                Video Style
              </label>
              <div style={{ display: 'grid', gridTemplateColumns: 'repeat(6, 1fr)', gap: '12px' }}>
                {VIDEO_STYLES.map((style) => (
                  <button
                    key={style.id}
                    onClick={() => updateProject('videoStyle', style.id)}
                    style={{
                      padding: '0',
                      background: 'transparent',
                      border: `2px solid ${project.videoStyle === style.id ? colors.accent.primary : colors.border.subtle}`,
                      borderRadius: '12px',
                      cursor: 'pointer',
                      overflow: 'hidden',
                    }}
                  >
                    <div style={{ height: '80px', background: style.preview }} />
                    <div style={{
                      padding: '10px',
                      fontSize: '12px',
                      fontWeight: '500',
                      color: project.videoStyle === style.id ? colors.text.primary : colors.text.secondary,
                      background: colors.bg.secondary,
                    }}>
                      {style.name}
                    </div>
                  </button>
                ))}
              </div>
            </div>
            
            {/* AI Generators */}
            <div style={{
              background: colors.bg.tertiary,
              borderRadius: '12px',
              padding: '24px',
              border: `1px solid ${colors.border.subtle}`,
            }}>
              <h3 style={{ fontSize: '16px', fontWeight: '600', marginBottom: '20px', display: 'flex', alignItems: 'center', gap: '8px' }}>
                <Icons.Sparkles style={{ width: '20px', height: '20px' }} />
                AI Generators
              </h3>
              
              {/* Image Generator */}
              <div style={{ marginBottom: '24px' }}>
                <label style={{
                  display: 'block',
                  marginBottom: '12px',
                  fontSize: '13px',
                  fontWeight: '500',
                  color: colors.text.secondary,
                  textTransform: 'uppercase',
                }}>
                  Image Generator <span style={{ color: colors.text.tertiary, fontWeight: '400', textTransform: 'none' }}>— For storyboard images</span>
                </label>
                <div style={{ display: 'grid', gridTemplateColumns: 'repeat(4, 1fr)', gap: '12px' }}>
                  {IMAGE_GENERATORS.map((gen) => (
                    <button
                      key={gen.id}
                      onClick={() => updateProject('primaryImageGenerator', gen.id)}
                      style={{
                        padding: '14px 16px',
                        background: project.primaryImageGenerator === gen.id ? `${colors.accent.primary}15` : colors.bg.secondary,
                        border: `2px solid ${project.primaryImageGenerator === gen.id ? colors.accent.primary : colors.border.subtle}`,
                        borderRadius: '10px',
                        cursor: 'pointer',
                        textAlign: 'left',
                      }}
                    >
                      <div style={{ display: 'flex', alignItems: 'center', justifyContent: 'space-between', marginBottom: '4px' }}>
                        <span style={{
                          fontSize: '14px',
                          fontWeight: '600',
                          color: project.primaryImageGenerator === gen.id ? colors.text.primary : colors.text.secondary,
                        }}>
                          {gen.name}
                        </span>
                        {gen.badge && (
                          <span style={{
                            padding: '2px 6px',
                            background: gen.badge === 'BEST FOR SCENES' ? colors.accent.success : colors.accent.primary,
                            borderRadius: '4px',
                            fontSize: '8px',
                            fontWeight: '700',
                            color: 'white',
                          }}>
                            {gen.badge}
                          </span>
                        )}
                      </div>
                      <div style={{ fontSize: '11px', color: colors.text.tertiary }}>{gen.provider}</div>
                      <div style={{ fontSize: '10px', color: colors.text.tertiary, marginTop: '4px' }}>{gen.features}</div>
                    </button>
                  ))}
                </div>
              </div>
              
              {/* Video Generator */}
              <div>
                <label style={{
                  display: 'block',
                  marginBottom: '12px',
                  fontSize: '13px',
                  fontWeight: '500',
                  color: colors.text.secondary,
                  textTransform: 'uppercase',
                }}>
                  Video Generator <span style={{ color: colors.text.tertiary, fontWeight: '400', textTransform: 'none' }}>— For video clips (determines shot length)</span>
                </label>
                <div style={{ display: 'grid', gridTemplateColumns: 'repeat(3, 1fr)', gap: '12px' }}>
                  {VIDEO_GENERATORS.map((gen) => (
                    <button
                      key={gen.id}
                      onClick={() => updateProject('primaryVideoGenerator', gen.id)}
                      style={{
                        padding: '14px 16px',
                        background: project.primaryVideoGenerator === gen.id ? `${colors.accent.primary}15` : colors.bg.secondary,
                        border: `2px solid ${project.primaryVideoGenerator === gen.id ? colors.accent.primary : colors.border.subtle}`,
                        borderRadius: '10px',
                        cursor: 'pointer',
                        textAlign: 'left',
                      }}
                    >
                      <div style={{ display: 'flex', alignItems: 'center', justifyContent: 'space-between', marginBottom: '4px' }}>
                        <span style={{
                          fontSize: '14px',
                          fontWeight: '600',
                          color: project.primaryVideoGenerator === gen.id ? colors.text.primary : colors.text.secondary,
                        }}>
                          {gen.name}
                        </span>
                        {gen.badge && (
                          <span style={{
                            padding: '2px 6px',
                            background: gen.badge === 'BEST QUALITY' ? colors.accent.success : 
                                       gen.badge === 'FAST' ? colors.accent.warning :
                                       gen.badge === 'LONG FORM' ? colors.accent.secondary : colors.accent.primary,
                            borderRadius: '4px',
                            fontSize: '8px',
                            fontWeight: '700',
                            color: 'white',
                          }}>
                            {gen.badge}
                          </span>
                        )}
                      </div>
                      <div style={{ fontSize: '11px', color: colors.text.tertiary }}>{gen.provider} · Max {gen.maxDuration}s</div>
                      <div style={{ fontSize: '10px', color: colors.text.tertiary, marginTop: '4px' }}>{gen.features}</div>
                    </button>
                  ))}
                </div>
                <p style={{ fontSize: '11px', color: colors.text.tertiary, marginTop: '8px' }}>
                  Scene breakdown will create shots up to {selectedVideoGenerator?.maxDuration || 20} seconds each.
                </p>
              </div>
            </div>
          </div>
        );
        
      case 2: // STEP 3: CREATIVE - Logline, Theme, Genre, Subgenres, Tones, References, Style Refs, Summary
        return (
          <div style={{ animation: 'fadeIn 0.3s ease' }}>
            <h2 style={{ fontSize: '24px', fontWeight: '600', marginBottom: '8px' }}>
              Creative Direction
            </h2>
            <p style={{ color: colors.text.secondary, marginBottom: '32px' }}>
              Define the story, tone, and creative references
            </p>
            
            <Input
              label="Creative Directive / Project Logline"
              placeholder="A one or two sentence summary of your story..."
              value={project.logline}
              onChange={(v) => updateProject('logline', v)}
              multiline
              rows={2}
            />
            
            <Input
              label="Theme"
              placeholder="The central theme or message (e.g., redemption, identity, power)..."
              value={project.theme}
              onChange={(v) => updateProject('theme', v)}
            />
            
            <Select
              label="Genre"
              placeholder="Select primary genre"
              value={project.genre}
              onChange={(v) => updateProject('genre', v)}
              options={GENRES}
            />
            
            {selectedGenre && (
              <div style={{ marginBottom: '24px' }}>
                <label style={{
                  display: 'block',
                  marginBottom: '12px',
                  fontSize: '13px',
                  fontWeight: '500',
                  color: colors.text.secondary,
                  textTransform: 'uppercase',
                }}>
                  Sub-genres
                </label>
                <div style={{ display: 'flex', flexWrap: 'wrap', gap: '8px' }}>
                  {selectedGenre.subgenres.map((sub) => (
                    <Chip
                      key={sub}
                      label={sub}
                      selected={project.subgenres.includes(sub)}
                      onClick={() => toggleSubgenre(sub)}
                    />
                  ))}
                </div>
              </div>
            )}
            
            <div style={{ marginBottom: '24px' }}>
              <label style={{
                display: 'block',
                marginBottom: '12px',
                fontSize: '13px',
                fontWeight: '500',
                color: colors.text.secondary,
                textTransform: 'uppercase',
              }}>
                Tone
              </label>
              <div style={{ display: 'flex', flexWrap: 'wrap', gap: '8px' }}>
                {TONES.map((tone) => (
                  <Chip
                    key={tone.id}
                    label={tone.name}
                    selected={project.tones.includes(tone.id)}
                    onClick={() => toggleTone(tone.id)}
                    color={tone.color}
                  />
                ))}
              </div>
            </div>
            
            <Input
              label="Reference Studios"
              placeholder="e.g., A24, HBO, Netflix, Studio Ghibli..."
              value={project.referenceStudios}
              onChange={(v) => updateProject('referenceStudios', v)}
            />
            
            <Input
              label="Reference Films/Shows"
              placeholder="e.g., Breaking Bad, Blade Runner, Spirited Away..."
              value={project.referenceFilms}
              onChange={(v) => updateProject('referenceFilms', v)}
            />
            
            {/* Style References */}
            <div style={{ marginTop: '32px', marginBottom: '32px' }}>
              <label style={{
                display: 'block',
                marginBottom: '16px',
                fontSize: '13px',
                fontWeight: '500',
                color: colors.text.secondary,
                textTransform: 'uppercase',
              }}>
                Style Reference Images
              </label>
              <div style={{ display: 'grid', gridTemplateColumns: '1fr 1fr', gap: '24px' }}>
                <ReferenceUpload
                  label="Visual Style"
                  description="Overall look and aesthetic"
                  images={project.styleReferences.visual}
                  onUpload={() => {/* Mock upload */}}
                  onRemove={(idx) => {
                    const newRefs = { ...project.styleReferences };
                    newRefs.visual.splice(idx, 1);
                    updateProject('styleReferences', newRefs);
                  }}
                />
                
                <ReferenceUpload
                  label="Camera & Composition"
                  description="Shot framing and angles"
                  images={project.styleReferences.camera}
                  onUpload={() => {/* Mock upload */}}
                  onRemove={(idx) => {
                    const newRefs = { ...project.styleReferences };
                    newRefs.camera.splice(idx, 1);
                    updateProject('styleReferences', newRefs);
                  }}
                />
                
                <ReferenceUpload
                  label="Tone & Mood"
                  description="Emotional atmosphere"
                  images={project.styleReferences.tone}
                  onUpload={() => {/* Mock upload */}}
                  onRemove={(idx) => {
                    const newRefs = { ...project.styleReferences };
                    newRefs.tone.splice(idx, 1);
                    updateProject('styleReferences', newRefs);
                  }}
                />
                
                <ReferenceUpload
                  label="Lighting"
                  description="Lighting style and color"
                  images={project.styleReferences.lighting}
                  onUpload={() => {/* Mock upload */}}
                  onRemove={(idx) => {
                    const newRefs = { ...project.styleReferences };
                    newRefs.lighting.splice(idx, 1);
                    updateProject('styleReferences', newRefs);
                  }}
                />
              </div>
            </div>
            
            {/* Project Summary */}
            <div style={{
              background: colors.bg.tertiary,
              borderRadius: '12px',
              padding: '24px',
              border: `1px solid ${colors.border.subtle}`,
            }}>
              <h3 style={{ fontSize: '16px', fontWeight: '600', marginBottom: '16px' }}>
                Project Summary
              </h3>
              <div style={{ display: 'grid', gridTemplateColumns: '1fr 1fr', gap: '16px' }}>
                <div>
                  <div style={{ fontSize: '13px', color: colors.text.tertiary, marginBottom: '4px' }}>Title</div>
                  <div style={{ fontSize: '15px', fontWeight: '500' }}>{project.title || '—'}</div>
                </div>
                <div>
                  <div style={{ fontSize: '13px', color: colors.text.tertiary, marginBottom: '4px' }}>Type</div>
                  <div style={{ fontSize: '15px', fontWeight: '500' }}>
                    {PROJECT_TYPES.find(t => t.id === project.projectType)?.name || '—'}
                  </div>
                </div>
                <div>
                  <div style={{ fontSize: '13px', color: colors.text.tertiary, marginBottom: '4px' }}>Genre</div>
                  <div style={{ fontSize: '15px', fontWeight: '500' }}>
                    {GENRES.find(g => g.id === project.genre)?.name || '—'}
                    {project.subgenres.length > 0 && ` (${project.subgenres.join(', ')})`}
                  </div>
                </div>
                <div>
                  <div style={{ fontSize: '13px', color: colors.text.tertiary, marginBottom: '4px' }}>Film Style</div>
                  <div style={{ fontSize: '15px', fontWeight: '500' }}>
                    {FILM_STYLES.find(s => s.id === project.filmStyle)?.name || '—'}
                  </div>
                </div>
                <div>
                  <div style={{ fontSize: '13px', color: colors.text.tertiary, marginBottom: '4px' }}>Structure</div>
                  <div style={{ fontSize: '15px', fontWeight: '500' }}>
                    {isSeries 
                      ? `${project.seasons} Season${project.seasons > 1 ? 's' : ''} × ${project.episodesPerSeason} Episodes × ${project.episodeLength}min`
                      : `${project.runtime} minutes`}
                  </div>
                </div>
                <div>
                  <div style={{ fontSize: '13px', color: colors.text.tertiary, marginBottom: '4px' }}>AI Tools</div>
                  <div style={{ fontSize: '15px', fontWeight: '500' }}>
                    {selectedImageGenerator?.name || '—'} + {selectedVideoGenerator?.name || '—'}
                  </div>
                </div>
              </div>
              {project.logline && (
                <div style={{ marginTop: '16px' }}>
                  <div style={{ fontSize: '13px', color: colors.text.tertiary, marginBottom: '4px' }}>Creative Directive</div>
                  <div style={{ fontSize: '14px', color: colors.text.secondary }}>{project.logline}</div>
                </div>
              )}
            </div>
          </div>
        );
        
      default:
        return null;
    }
  };
  
  return (
    <div style={{
      flex: 1,
      display: 'flex',
      flexDirection: 'column',
      overflow: 'hidden',
    }}>
      {/* Header */}
      <div style={{
        padding: '24px 40px',
        borderBottom: `1px solid ${colors.border.subtle}`,
        background: colors.bg.secondary,
      }}>
        <div style={{ display: 'flex', alignItems: 'center', gap: '16px', marginBottom: '24px' }}>
          <button
            onClick={onCancel}
            style={{
              display: 'flex',
              alignItems: 'center',
              gap: '8px',
              padding: '8px 12px',
              background: 'transparent',
              border: 'none',
              color: colors.text.secondary,
              fontSize: '14px',
              cursor: 'pointer',
            }}
          >
            <Icons.ArrowLeft />
            Back
          </button>
          <h1 style={{ fontSize: '20px', fontWeight: '600' }}>Create New Project</h1>
        </div>
        <ProgressSteps steps={steps} currentStep={step} />
      </div>
      
      {/* Content */}
      <div style={{
        flex: 1,
        overflow: 'auto',
        padding: '40px',
      }}>
        <div style={{ maxWidth: '900px', margin: '0 auto' }}>
          {renderStep()}
        </div>
      </div>
      
      {/* Footer */}
      <div style={{
        padding: '20px 40px',
        borderTop: `1px solid ${colors.border.subtle}`,
        background: colors.bg.secondary,
        display: 'flex',
        justifyContent: 'space-between',
        alignItems: 'center',
      }}>
        <Button
          variant="ghost"
          onClick={handleBack}
        >
          <Icons.ArrowLeft style={{ width: 16, height: 16, marginRight: '8px' }} />
          {step > 0 ? 'Back' : 'Cancel'}
        </Button>
        
        <div style={{ display: 'flex', alignItems: 'center', gap: '12px' }}>
          {/* Unsaved changes indicator */}
          {hasUnsavedChanges && (
            <span style={{ 
              fontSize: '12px', 
              color: colors.accent.warning,
              display: 'flex',
              alignItems: 'center',
              gap: '4px',
            }}>
              <span style={{ 
                width: '6px', 
                height: '6px', 
                borderRadius: '50%', 
                background: colors.accent.warning,
              }} />
              Unsaved changes
            </span>
          )}
          
          {/* Save button - only show if there are unsaved changes and not on last step */}
          {hasUnsavedChanges && step < steps.length - 1 && (
            <Button
              variant="secondary"
              onClick={saveProgress}
            >
              Save Changes
            </Button>
          )}
          
          <Button
            variant="primary"
            disabled={!canProceed()}
            onClick={handleContinue}
          >
            {step < steps.length - 1 ? 'Continue' : 'Create Project'}
            {step < steps.length - 1 && <Icons.ChevronRight style={{ width: 16, height: 16, marginLeft: '8px' }} />}
          </Button>
        </div>
      </div>
    </div>
  );
};

// ============================================================================
// EDIT PROJECT WIZARD - For editing existing project setup
// ============================================================================
const EditProjectWizard = ({ project, onSave, onCancel }) => {
  const [step, setStep] = useState(0);
  const [hasUnsavedChanges, setHasUnsavedChanges] = useState(false);
  const [editedProject, setEditedProject] = useState({ ...project });
  
  const steps = ['Details', 'Technical', 'Creative'];
  
  const PROJECT_TYPES = [
    { id: 'short', name: 'Short Film', icon: '🎬', description: 'Under 40 minutes', defaultRuntime: 15 },
    { id: 'film', name: 'Feature Film', icon: '🎥', description: '40+ minutes', defaultRuntime: 90 },
    { id: 'series', name: 'Series', icon: '📺', description: 'Multiple episodes', defaultRuntime: 45 },
  ];
  
  const IMAGE_GENERATORS = [
    { id: 'flux-pro', name: 'Flux Pro', provider: 'Black Forest Labs', badge: 'RECOMMENDED', features: 'Photorealistic' },
    { id: 'nano-banana', name: 'Nano Banana Pro', provider: 'Banan', badge: 'BEST FOR SCENES', features: 'Layers' },
    { id: 'midjourney', name: 'Midjourney v6', provider: 'Midjourney', features: 'Artistic' },
    { id: 'grok-imagine', name: 'Grok Imagine', provider: 'xAI', features: 'Fast' },
  ];
  
  const VIDEO_GENERATORS = [
    { id: 'sora-2', name: 'Sora 2', provider: 'OpenAI', maxDuration: 20, badge: 'BEST QUALITY' },
    { id: 'runway-gen3', name: 'Runway Gen-3', provider: 'Runway', maxDuration: 10 },
    { id: 'kling-1.6', name: 'Kling 1.6', provider: 'Kuaishou', maxDuration: 10, badge: 'FAST' },
    { id: 'veo-2', name: 'Veo 2', provider: 'Google', maxDuration: 60, badge: 'LONG FORM' },
  ];
  
  const updateProject = (key, value) => {
    setEditedProject(prev => ({ ...prev, [key]: value }));
    setHasUnsavedChanges(true);
  };
  
  const toggleSubgenre = (subgenre) => {
    setEditedProject(prev => ({
      ...prev,
      subgenres: prev.subgenres?.includes(subgenre)
        ? prev.subgenres.filter(s => s !== subgenre)
        : [...(prev.subgenres || []), subgenre],
    }));
    setHasUnsavedChanges(true);
  };
  
  const toggleTone = (tone) => {
    setEditedProject(prev => ({
      ...prev,
      tones: prev.tones?.includes(tone)
        ? prev.tones.filter(t => t !== tone)
        : [...(prev.tones || []), tone],
    }));
    setHasUnsavedChanges(true);
  };
  
  const selectedGenre = GENRES.find(g => g.id === editedProject.genre);
  const isSeries = editedProject.projectType === 'series';
  const selectedImageGenerator = IMAGE_GENERATORS.find(g => g.id === editedProject.primaryImageGenerator);
  const selectedVideoGenerator = VIDEO_GENERATORS.find(g => g.id === editedProject.primaryVideoGenerator);
  
  const handleSave = () => {
    onSave({
      ...editedProject,
      updatedAt: new Date().toISOString(),
    });
  };
  
  const renderStepContent = () => {
    switch (step) {
      case 0: // DETAILS - Project Type, Title, Structure
        return (
          <div>
            <h2 style={{ fontSize: '24px', fontWeight: '600', marginBottom: '8px' }}>Edit Details</h2>
            <p style={{ color: colors.text.secondary, marginBottom: '32px' }}>Update project type and structure</p>
            
            {/* Project Type */}
            <div style={{ marginBottom: '24px' }}>
              <label style={{ display: 'block', marginBottom: '12px', fontSize: '13px', fontWeight: '500', color: colors.text.secondary, textTransform: 'uppercase' }}>
                Project Type
              </label>
              <div style={{ display: 'grid', gridTemplateColumns: 'repeat(3, 1fr)', gap: '12px' }}>
                {PROJECT_TYPES.map(type => (
                  <button
                    key={type.id}
                    onClick={() => updateProject('projectType', type.id)}
                    style={{
                      padding: '20px',
                      background: editedProject.projectType === type.id ? `${colors.accent.primary}15` : colors.bg.tertiary,
                      border: `2px solid ${editedProject.projectType === type.id ? colors.accent.primary : colors.border.subtle}`,
                      borderRadius: '12px',
                      cursor: 'pointer',
                      textAlign: 'center',
                    }}
                  >
                    <div style={{ fontSize: '28px', marginBottom: '8px' }}>{type.icon}</div>
                    <div style={{ fontSize: '14px', fontWeight: '600', color: colors.text.primary }}>{type.name}</div>
                    <div style={{ fontSize: '12px', color: colors.text.tertiary }}>{type.description}</div>
                  </button>
                ))}
              </div>
            </div>
            
            {/* Title */}
            <div style={{ marginBottom: '24px' }}>
              <label style={{ display: 'block', marginBottom: '8px', fontSize: '13px', fontWeight: '500', color: colors.text.secondary }}>Title</label>
              <input
                type="text"
                value={editedProject.title || ''}
                onChange={(e) => updateProject('title', e.target.value)}
                style={{
                  width: '100%',
                  padding: '14px 16px',
                  background: colors.bg.tertiary,
                  border: `1px solid ${colors.border.default}`,
                  borderRadius: '10px',
                  color: colors.text.primary,
                  fontSize: '16px',
                }}
                placeholder="Enter project title..."
              />
            </div>
            
            {/* Structure */}
            {isSeries ? (
              <>
                <div style={{ display: 'grid', gridTemplateColumns: '1fr 1fr 1fr', gap: '24px', marginBottom: '24px' }}>
                  <div>
                    <label style={{ display: 'block', marginBottom: '8px', fontSize: '13px', fontWeight: '500', color: colors.text.secondary }}>Seasons</label>
                    <input
                      type="number"
                      min="1"
                      value={editedProject.seasons || 1}
                      onChange={(e) => updateProject('seasons', parseInt(e.target.value) || 1)}
                      style={{
                        width: '100%',
                        padding: '14px 16px',
                        background: colors.bg.tertiary,
                        border: `1px solid ${colors.border.default}`,
                        borderRadius: '10px',
                        color: colors.text.primary,
                        fontSize: '16px',
                      }}
                    />
                  </div>
                  <div>
                    <label style={{ display: 'block', marginBottom: '8px', fontSize: '13px', fontWeight: '500', color: colors.text.secondary }}>Episodes/Season</label>
                    <input
                      type="number"
                      min="1"
                      value={editedProject.episodesPerSeason || 10}
                      onChange={(e) => updateProject('episodesPerSeason', parseInt(e.target.value) || 1)}
                      style={{
                        width: '100%',
                        padding: '14px 16px',
                        background: colors.bg.tertiary,
                        border: `1px solid ${colors.border.default}`,
                        borderRadius: '10px',
                        color: colors.text.primary,
                        fontSize: '16px',
                      }}
                    />
                  </div>
                  <div>
                    <label style={{ display: 'block', marginBottom: '8px', fontSize: '13px', fontWeight: '500', color: colors.text.secondary }}>Episode Length (min)</label>
                    <input
                      type="number"
                      min="1"
                      value={editedProject.episodeLength || 45}
                      onChange={(e) => updateProject('episodeLength', parseInt(e.target.value) || 1)}
                      style={{
                        width: '100%',
                        padding: '14px 16px',
                        background: colors.bg.tertiary,
                        border: `1px solid ${colors.border.default}`,
                        borderRadius: '10px',
                        color: colors.text.primary,
                        fontSize: '16px',
                      }}
                    />
                  </div>
                </div>
                
                <div style={{ padding: '16px', background: colors.bg.tertiary, borderRadius: '10px' }}>
                  <div style={{ fontSize: '14px', color: colors.text.secondary }}>
                    Total: <strong style={{ color: colors.text.primary }}>{(editedProject.seasons || 1) * (editedProject.episodesPerSeason || 10)}</strong> episodes
                    {' × '}<strong style={{ color: colors.text.primary }}>{editedProject.episodeLength || 45}</strong> min
                    {' = '}<strong style={{ color: colors.accent.primary }}>{(((editedProject.seasons || 1) * (editedProject.episodesPerSeason || 10) * (editedProject.episodeLength || 45)) / 60).toFixed(1)}</strong> hours
                  </div>
                </div>
              </>
            ) : (
              <div style={{ marginBottom: '24px' }}>
                <label style={{ display: 'block', marginBottom: '8px', fontSize: '13px', fontWeight: '500', color: colors.text.secondary }}>Runtime (minutes)</label>
                <input
                  type="number"
                  min="1"
                  value={editedProject.runtime || 90}
                  onChange={(e) => updateProject('runtime', parseInt(e.target.value) || 1)}
                  style={{
                    width: '100%',
                    maxWidth: '200px',
                    padding: '14px 16px',
                    background: colors.bg.tertiary,
                    border: `1px solid ${colors.border.default}`,
                    borderRadius: '10px',
                    color: colors.text.primary,
                    fontSize: '16px',
                  }}
                />
              </div>
            )}
          </div>
        );
        
      case 1: // TECHNICAL - Film Style, Video Style, AI Generators
        return (
          <div>
            <h2 style={{ fontSize: '24px', fontWeight: '600', marginBottom: '8px' }}>Edit Technical</h2>
            <p style={{ color: colors.text.secondary, marginBottom: '32px' }}>Update visual style and AI tools</p>
            
            {/* Film Style */}
            <div style={{ marginBottom: '32px' }}>
              <label style={{ display: 'block', marginBottom: '12px', fontSize: '13px', fontWeight: '500', color: colors.text.secondary, textTransform: 'uppercase' }}>Film Style</label>
              <div style={{ display: 'grid', gridTemplateColumns: 'repeat(4, 1fr)', gap: '12px' }}>
                {FILM_STYLES.map(style => (
                  <button
                    key={style.id}
                    onClick={() => updateProject('filmStyle', style.id)}
                    style={{
                      padding: '16px',
                      background: editedProject.filmStyle === style.id ? `${colors.accent.primary}15` : colors.bg.tertiary,
                      border: `2px solid ${editedProject.filmStyle === style.id ? colors.accent.primary : colors.border.subtle}`,
                      borderRadius: '10px',
                      cursor: 'pointer',
                      textAlign: 'center',
                    }}
                  >
                    <div style={{ fontSize: '24px', marginBottom: '4px' }}>{style.icon}</div>
                    <div style={{ fontSize: '12px', fontWeight: '500', color: colors.text.primary }}>{style.name}</div>
                  </button>
                ))}
              </div>
            </div>
            
            {/* Video Style */}
            <div style={{ marginBottom: '32px' }}>
              <label style={{ display: 'block', marginBottom: '12px', fontSize: '13px', fontWeight: '500', color: colors.text.secondary, textTransform: 'uppercase' }}>Visual Style</label>
              <div style={{ display: 'grid', gridTemplateColumns: 'repeat(6, 1fr)', gap: '12px' }}>
                {VIDEO_STYLES.map(style => (
                  <button
                    key={style.id}
                    onClick={() => updateProject('videoStyle', style.id)}
                    style={{
                      padding: '0',
                      background: 'none',
                      border: `2px solid ${editedProject.videoStyle === style.id ? colors.accent.primary : 'transparent'}`,
                      borderRadius: '12px',
                      cursor: 'pointer',
                      overflow: 'hidden',
                    }}
                  >
                    <div style={{ height: '60px', background: style.preview }} />
                    <div style={{ padding: '8px', background: colors.bg.tertiary }}>
                      <div style={{ fontSize: '11px', fontWeight: '500', color: colors.text.primary }}>{style.name}</div>
                    </div>
                  </button>
                ))}
              </div>
            </div>
            
            {/* AI Generators */}
            <div style={{ background: colors.bg.tertiary, borderRadius: '12px', padding: '20px', border: `1px solid ${colors.border.subtle}` }}>
              <h3 style={{ fontSize: '14px', fontWeight: '600', marginBottom: '16px' }}>AI Generators</h3>
              
              <div style={{ marginBottom: '16px' }}>
                <label style={{ display: 'block', marginBottom: '8px', fontSize: '12px', color: colors.text.secondary }}>Image Generator</label>
                <div style={{ display: 'grid', gridTemplateColumns: 'repeat(4, 1fr)', gap: '8px' }}>
                  {IMAGE_GENERATORS.map(gen => (
                    <button
                      key={gen.id}
                      onClick={() => updateProject('primaryImageGenerator', gen.id)}
                      style={{
                        padding: '10px',
                        background: editedProject.primaryImageGenerator === gen.id ? `${colors.accent.primary}15` : colors.bg.secondary,
                        border: `1px solid ${editedProject.primaryImageGenerator === gen.id ? colors.accent.primary : colors.border.subtle}`,
                        borderRadius: '8px',
                        cursor: 'pointer',
                        textAlign: 'left',
                      }}
                    >
                      <div style={{ fontSize: '12px', fontWeight: '500', color: colors.text.primary }}>{gen.name}</div>
                      <div style={{ fontSize: '10px', color: colors.text.tertiary }}>{gen.provider}</div>
                    </button>
                  ))}
                </div>
              </div>
              
              <div>
                <label style={{ display: 'block', marginBottom: '8px', fontSize: '12px', color: colors.text.secondary }}>Video Generator</label>
                <div style={{ display: 'grid', gridTemplateColumns: 'repeat(4, 1fr)', gap: '8px' }}>
                  {VIDEO_GENERATORS.map(gen => (
                    <button
                      key={gen.id}
                      onClick={() => updateProject('primaryVideoGenerator', gen.id)}
                      style={{
                        padding: '10px',
                        background: editedProject.primaryVideoGenerator === gen.id ? `${colors.accent.primary}15` : colors.bg.secondary,
                        border: `1px solid ${editedProject.primaryVideoGenerator === gen.id ? colors.accent.primary : colors.border.subtle}`,
                        borderRadius: '8px',
                        cursor: 'pointer',
                        textAlign: 'left',
                      }}
                    >
                      <div style={{ fontSize: '12px', fontWeight: '500', color: colors.text.primary }}>{gen.name}</div>
                      <div style={{ fontSize: '10px', color: colors.text.tertiary }}>{gen.provider} · {gen.maxDuration}s</div>
                    </button>
                  ))}
                </div>
              </div>
            </div>
          </div>
        );
        
      case 2: // CREATIVE - Logline, Theme, Genre, Subgenres, Tones, References
        return (
          <div>
            <h2 style={{ fontSize: '24px', fontWeight: '600', marginBottom: '8px' }}>Edit Creative</h2>
            <p style={{ color: colors.text.secondary, marginBottom: '32px' }}>Update story, tone, and references</p>
            
            {/* Logline */}
            <div style={{ marginBottom: '24px' }}>
              <label style={{ display: 'block', marginBottom: '8px', fontSize: '13px', fontWeight: '500', color: colors.text.secondary }}>Creative Directive / Project Logline</label>
              <textarea
                value={editedProject.logline || ''}
                onChange={(e) => updateProject('logline', e.target.value)}
                style={{
                  width: '100%',
                  padding: '14px 16px',
                  background: colors.bg.tertiary,
                  border: `1px solid ${colors.border.default}`,
                  borderRadius: '10px',
                  color: colors.text.primary,
                  fontSize: '14px',
                  minHeight: '80px',
                  resize: 'vertical',
                }}
                placeholder="A one-sentence summary of your story..."
              />
            </div>
            
            {/* Theme */}
            <div style={{ marginBottom: '24px' }}>
              <label style={{ display: 'block', marginBottom: '8px', fontSize: '13px', fontWeight: '500', color: colors.text.secondary }}>Theme</label>
              <input
                type="text"
                value={editedProject.theme || ''}
                onChange={(e) => updateProject('theme', e.target.value)}
                style={{
                  width: '100%',
                  padding: '14px 16px',
                  background: colors.bg.tertiary,
                  border: `1px solid ${colors.border.default}`,
                  borderRadius: '10px',
                  color: colors.text.primary,
                  fontSize: '14px',
                }}
                placeholder="e.g., redemption, identity, power..."
              />
            </div>
            
            {/* Genre */}
            <div style={{ marginBottom: '24px' }}>
              <label style={{ display: 'block', marginBottom: '12px', fontSize: '13px', fontWeight: '500', color: colors.text.secondary, textTransform: 'uppercase' }}>Genre</label>
              <div style={{ display: 'grid', gridTemplateColumns: 'repeat(4, 1fr)', gap: '10px' }}>
                {GENRES.map(genre => (
                  <button
                    key={genre.id}
                    onClick={() => updateProject('genre', genre.id)}
                    style={{
                      padding: '12px',
                      background: editedProject.genre === genre.id ? `${colors.accent.primary}15` : colors.bg.tertiary,
                      border: `2px solid ${editedProject.genre === genre.id ? colors.accent.primary : colors.border.subtle}`,
                      borderRadius: '10px',
                      cursor: 'pointer',
                      textAlign: 'center',
                    }}
                  >
                    <div style={{ fontSize: '20px', marginBottom: '4px' }}>{genre.icon}</div>
                    <div style={{ fontSize: '12px', fontWeight: '500', color: colors.text.primary }}>{genre.name}</div>
                  </button>
                ))}
              </div>
            </div>
            
            {/* Subgenres */}
            {selectedGenre?.subgenres && (
              <div style={{ marginBottom: '24px' }}>
                <label style={{ display: 'block', marginBottom: '12px', fontSize: '13px', fontWeight: '500', color: colors.text.secondary }}>Subgenres</label>
                <div style={{ display: 'flex', flexWrap: 'wrap', gap: '8px' }}>
                  {selectedGenre.subgenres.map(sub => (
                    <button
                      key={sub}
                      onClick={() => toggleSubgenre(sub)}
                      style={{
                        padding: '8px 14px',
                        background: editedProject.subgenres?.includes(sub) ? colors.accent.primary : colors.bg.tertiary,
                        border: 'none',
                        borderRadius: '20px',
                        color: editedProject.subgenres?.includes(sub) ? 'white' : colors.text.secondary,
                        fontSize: '13px',
                        cursor: 'pointer',
                      }}
                    >
                      {sub}
                    </button>
                  ))}
                </div>
              </div>
            )}
            
            {/* Tones */}
            <div style={{ marginBottom: '24px' }}>
              <label style={{ display: 'block', marginBottom: '12px', fontSize: '13px', fontWeight: '500', color: colors.text.secondary }}>Tone</label>
              <div style={{ display: 'flex', flexWrap: 'wrap', gap: '8px' }}>
                {TONES.map(tone => (
                  <button
                    key={tone.id}
                    onClick={() => toggleTone(tone.id)}
                    style={{
                      padding: '8px 14px',
                      background: editedProject.tones?.includes(tone.id) ? colors.accent.primary : colors.bg.tertiary,
                      border: 'none',
                      borderRadius: '20px',
                      color: editedProject.tones?.includes(tone.id) ? 'white' : colors.text.secondary,
                      fontSize: '13px',
                      cursor: 'pointer',
                    }}
                  >
                    {tone.name}
                  </button>
                ))}
              </div>
            </div>
            
            {/* Reference Studios */}
            <div style={{ marginBottom: '24px' }}>
              <label style={{ display: 'block', marginBottom: '8px', fontSize: '13px', fontWeight: '500', color: colors.text.secondary }}>Reference Studios</label>
              <input
                type="text"
                value={editedProject.referenceStudios || ''}
                onChange={(e) => updateProject('referenceStudios', e.target.value)}
                style={{
                  width: '100%',
                  padding: '14px 16px',
                  background: colors.bg.tertiary,
                  border: `1px solid ${colors.border.default}`,
                  borderRadius: '10px',
                  color: colors.text.primary,
                  fontSize: '14px',
                }}
                placeholder="e.g., A24, Pixar, Studio Ghibli..."
              />
            </div>
            
            {/* Reference Films */}
            <div style={{ marginBottom: '24px' }}>
              <label style={{ display: 'block', marginBottom: '8px', fontSize: '13px', fontWeight: '500', color: colors.text.secondary }}>Reference Films/Shows</label>
              <textarea
                value={editedProject.referenceFilms || ''}
                onChange={(e) => updateProject('referenceFilms', e.target.value)}
                style={{
                  width: '100%',
                  padding: '14px 16px',
                  background: colors.bg.tertiary,
                  border: `1px solid ${colors.border.default}`,
                  borderRadius: '10px',
                  color: colors.text.primary,
                  fontSize: '14px',
                  minHeight: '80px',
                  resize: 'vertical',
                }}
                placeholder="List films or shows that inspire your project..."
              />
            </div>
            
            {/* Project Summary */}
            <div style={{ padding: '16px', background: colors.bg.tertiary, borderRadius: '10px' }}>
              <h3 style={{ fontSize: '14px', fontWeight: '600', marginBottom: '12px' }}>Project Summary</h3>
              <div style={{ display: 'grid', gridTemplateColumns: '1fr 1fr', gap: '12px', fontSize: '13px' }}>
                <div>
                  <span style={{ color: colors.text.tertiary }}>Title:</span> {editedProject.title || '—'}
                </div>
                <div>
                  <span style={{ color: colors.text.tertiary }}>Type:</span> {PROJECT_TYPES.find(t => t.id === editedProject.projectType)?.name || '—'}
                </div>
                <div>
                  <span style={{ color: colors.text.tertiary }}>Genre:</span> {GENRES.find(g => g.id === editedProject.genre)?.name || '—'}
                </div>
                <div>
                  <span style={{ color: colors.text.tertiary }}>Style:</span> {FILM_STYLES.find(s => s.id === editedProject.filmStyle)?.name || '—'}
                </div>
                <div>
                  <span style={{ color: colors.text.tertiary }}>AI Tools:</span> {selectedImageGenerator?.name || '—'} + {selectedVideoGenerator?.name || '—'}
                </div>
                <div>
                  <span style={{ color: colors.text.tertiary }}>Structure:</span> {isSeries 
                    ? `${editedProject.seasons}S × ${editedProject.episodesPerSeason}E × ${editedProject.episodeLength}min`
                    : `${editedProject.runtime} min`}
                </div>
              </div>
            </div>
          </div>
        );
        
      default:
        return null;
    }
  };
  
  return (
    <div style={{ flex: 1, display: 'flex', flexDirection: 'column', overflow: 'hidden', background: colors.bg.primary }}>
      {/* Header */}
      <div style={{
        padding: '20px 40px',
        borderBottom: `1px solid ${colors.border.subtle}`,
        background: colors.bg.secondary,
        display: 'flex',
        alignItems: 'center',
        justifyContent: 'space-between',
      }}>
        <div style={{ display: 'flex', alignItems: 'center', gap: '16px' }}>
          <button
            onClick={onCancel}
            style={{
              display: 'flex',
              alignItems: 'center',
              gap: '8px',
              padding: '8px 12px',
              background: 'transparent',
              border: 'none',
              color: colors.text.secondary,
              fontSize: '14px',
              cursor: 'pointer',
            }}
          >
            <Icons.ArrowLeft />
            Back to Episode
          </button>
          <h1 style={{ fontSize: '20px', fontWeight: '600' }}>Edit Project Setup</h1>
        </div>
        <ProgressSteps steps={steps} currentStep={step} />
      </div>
      
      {/* Content */}
      <div style={{ flex: 1, overflow: 'auto', padding: '40px' }}>
        <div style={{ maxWidth: '900px', margin: '0 auto' }}>
          {renderStepContent()}
        </div>
      </div>
      
      {/* Footer */}
      <div style={{
        padding: '20px 40px',
        borderTop: `1px solid ${colors.border.subtle}`,
        background: colors.bg.secondary,
        display: 'flex',
        justifyContent: 'space-between',
        alignItems: 'center',
      }}>
        <Button
          variant="ghost"
          onClick={() => step > 0 ? setStep(step - 1) : onCancel()}
        >
          <Icons.ArrowLeft style={{ width: 16, height: 16, marginRight: '8px' }} />
          {step > 0 ? 'Back' : 'Cancel'}
        </Button>
        
        <div style={{ display: 'flex', alignItems: 'center', gap: '12px' }}>
          {hasUnsavedChanges && (
            <span style={{ fontSize: '12px', color: colors.accent.warning, display: 'flex', alignItems: 'center', gap: '4px' }}>
              <span style={{ width: '6px', height: '6px', borderRadius: '50%', background: colors.accent.warning }} />
              Unsaved changes
            </span>
          )}
          
          {step < steps.length - 1 ? (
            <Button
              variant="primary"
              onClick={() => setStep(step + 1)}
            >
              Continue
              <Icons.ChevronRight style={{ width: 16, height: 16, marginLeft: '8px' }} />
            </Button>
          ) : (
            <Button
              variant="primary"
              onClick={handleSave}
              style={{ background: 'linear-gradient(135deg, #10b981 0%, #059669 100%)' }}
            >
              <Icons.Check style={{ width: 16, height: 16, marginRight: '8px' }} />
              Save Changes
            </Button>
          )}
        </div>
      </div>
    </div>
  );
};

// ============================================================================
// EPISODE SETUP VIEW
// ============================================================================
const EpisodeSetupView = ({ project, onUpdateProject, onNavigateToStoryboard, onEditProjectSetup }) => {
  // Main state
  const [selectedEpisode, setSelectedEpisode] = useState(null);
  const [activeSection, setActiveSection] = useState('details'); // 'details', 'script', 'scenes-cast', 'storyboard'
  const [editingEpisode, setEditingEpisode] = useState(null);
  const [showExportMenu, setShowExportMenu] = useState(false);
  
  // Collaboration state
  const [showShareModal, setShowShareModal] = useState(false);
  const [showCommentsPanel, setShowCommentsPanel] = useState(false);
  const [showVersionHistory, setShowVersionHistory] = useState(false);
  const [comments, setComments] = useState([
    { id: 1, user: 'Alex', avatar: '👤', text: 'Love the opening scene! Maybe add more dramatic lighting?', timestamp: new Date(Date.now() - 3600000), sceneId: 'scene-1' },
    { id: 2, user: 'Jordan', avatar: '👩', text: 'The dialogue in scene 3 feels a bit rushed. Can we extend it?', timestamp: new Date(Date.now() - 7200000), sceneId: 'scene-3' },
    { id: 3, user: 'You', avatar: '🧑', text: 'Good catch! I\'ll revise that section.', timestamp: new Date(Date.now() - 3000000), sceneId: 'scene-3', isReply: true },
  ]);
  const [newComment, setNewComment] = useState('');
  const [shareLink, setShareLink] = useState('');
  const [versionHistory, setVersionHistory] = useState([
    { id: 1, version: '1.3', user: 'You', timestamp: new Date(), changes: 'Updated scene 2 dialogue' },
    { id: 2, version: '1.2', user: 'Alex', timestamp: new Date(Date.now() - 86400000), changes: 'Added new character intro' },
    { id: 3, version: '1.1', user: 'Jordan', timestamp: new Date(Date.now() - 172800000), changes: 'Fixed shot durations' },
    { id: 4, version: '1.0', user: 'You', timestamp: new Date(Date.now() - 259200000), changes: 'Initial version' },
  ]);
  
  // Script state
  const [isGeneratingScript, setIsGeneratingScript] = useState(false);
  const [scriptContent, setScriptContent] = useState('');
  
  // Breakdown state
  const [isGeneratingBreakdown, setIsGeneratingBreakdown] = useState(false);
  
  // Cast state
  const [characters, setCharacters] = useState([]);
  const [selectedCharacter, setSelectedCharacter] = useState(null);
  const [showCharacterModal, setShowCharacterModal] = useState(false);
  const [characterModalTab, setCharacterModalTab] = useState('profile');
  const [isGeneratingAvatar, setIsGeneratingAvatar] = useState(false);
  
  // Scene element state
  const [selectedSceneIndex, setSelectedSceneIndex] = useState(0);
  const [showElementModal, setShowElementModal] = useState(false);
  const [elementModalType, setElementModalType] = useState(null);
  const [editingElement, setEditingElement] = useState(null);
  const [isGeneratingImage, setIsGeneratingImage] = useState(false);
  
  // Shot editing state
  const [editingShot, setEditingShot] = useState(null); // { sceneIdx, shotIdx }
  
  // Get max duration from video generator config
  const maxShotDuration = project?.videoGeneratorConfig?.maxDuration || 10;
  const minShotDuration = 3;
  
  // Guard against missing project
  if (!project) {
    return (
      <div style={{ flex: 1, display: 'flex', alignItems: 'center', justifyContent: 'center' }}>
        <p style={{ color: colors.text.secondary }}>Loading project...</p>
      </div>
    );
  }
  
  const isSeries = project.projectType === 'series';
  const episodes = Array.isArray(project.episodes) ? project.episodes : [];
  const episode = selectedEpisode || episodes[0];
  
  // Initialize episode if needed
  React.useEffect(() => {
    if (episodes.length > 0 && !selectedEpisode) {
      setSelectedEpisode(episodes[0]);
      if (episodes[0]?.script) {
        setScriptContent(episodes[0].script);
      }
      if (episodes[0]?.characters) {
        setCharacters(episodes[0].characters);
      }
    }
  }, [episodes]);
  
  // Section tabs config
  const sections = [
    { id: 'details', label: 'Details', icon: '📋' },
    { id: 'script', label: 'Script', icon: '📝' },
    { id: 'scenes-cast', label: 'Scenes & Cast', icon: '🎬' },
  ];
  
  // Update episode helper
  const updateEpisode = (updates) => {
    if (!episode) return;
    const updatedEpisodes = episodes.map(ep => 
      ep.id === episode.id ? { ...ep, ...updates } : ep
    );
    onUpdateProject({ ...project, episodes: updatedEpisodes });
    setSelectedEpisode({ ...episode, ...updates });
  };
  
  // ============================================================================
  // SHOT FUNCTIONS
  // ============================================================================
  
  const updateShot = (sceneIdx, shotIdx, updates) => {
    const updatedScenes = [...(episode?.scenes || [])];
    if (updatedScenes[sceneIdx]?.shots?.[shotIdx]) {
      updatedScenes[sceneIdx].shots[shotIdx] = {
        ...updatedScenes[sceneIdx].shots[shotIdx],
        ...updates,
      };
      updateEpisode({ scenes: updatedScenes });
    }
  };
  
  const addShot = (sceneIdx) => {
    const updatedScenes = [...(episode?.scenes || [])];
    const scene = updatedScenes[sceneIdx];
    if (scene) {
      const newShot = {
        id: `shot-${Date.now()}`,
        duration: maxShotDuration,
        type: 'medium',
        description: '',
        script: '',
        prompt: '',
        continuity: true,
      };
      scene.shots = [...(scene.shots || []), newShot];
      updateEpisode({ scenes: updatedScenes });
    }
  };
  
  const deleteShot = (sceneIdx, shotIdx) => {
    const updatedScenes = [...(episode?.scenes || [])];
    if (updatedScenes[sceneIdx]?.shots) {
      updatedScenes[sceneIdx].shots = updatedScenes[sceneIdx].shots.filter((_, i) => i !== shotIdx);
      updateEpisode({ scenes: updatedScenes });
    }
  };
  
  const duplicateShot = (sceneIdx, shotIdx) => {
    const updatedScenes = [...(episode?.scenes || [])];
    const shot = updatedScenes[sceneIdx]?.shots?.[shotIdx];
    if (shot) {
      const newShot = {
        ...shot,
        id: `shot-${Date.now()}`,
      };
      updatedScenes[sceneIdx].shots.splice(shotIdx + 1, 0, newShot);
      updateEpisode({ scenes: updatedScenes });
    }
  };
  
  // ============================================================================
  // CHARACTER FUNCTIONS
  // ============================================================================
  
  const openCharacterModal = (char) => {
    setSelectedCharacter(char);
    setCharacterModalTab('profile');
    setShowCharacterModal(true);
  };
  
  const updateCharacter = (charId, updates) => {
    setCharacters(prev => prev.map(c => 
      c.id === charId ? { ...c, ...updates } : c
    ));
  };
  
  const handleGenerateCharacterAvatar = (charId) => {
    setIsGeneratingAvatar(true);
    
    setTimeout(() => {
      setCharacters(prev => prev.map(char => {
        if (char.id === charId) {
          return {
            ...char,
            hasAvatar: true,
            generatedAvatars: [...(char.generatedAvatars || []), {
              id: `avatar-${Date.now()}`,
              isSelected: true,
              generatedAt: new Date(),
            }],
          };
        }
        return char;
      }));
      setIsGeneratingAvatar(false);
    }, 2000);
  };
  
  const generateAvatarPrompt = (char) => {
    const parts = [
      `Professional headshot portrait of ${char.name}`,
      char.gender?.toLowerCase(),
      char.ageRange && `${char.ageRange} years old`,
      char.ethnicity,
      char.physicalDescription,
      'clean white background, studio lighting, 8k, photorealistic',
    ].filter(Boolean);
    return parts.join(', ');
  };
  
  // ============================================================================
  // SCRIPT FUNCTIONS
  // ============================================================================
  
  const handleGenerateScript = () => {
    setIsGeneratingScript(true);
    
    // Simulate AI script generation
    setTimeout(() => {
      const generatedScript = `FADE IN:

INT. ${episode?.title?.toUpperCase() || 'LOCATION'} - DAY

${episode?.logline || 'A compelling story unfolds...'}

${(episode?.events || ['Event 1', 'Event 2', 'Event 3']).map((event, i) => `
SCENE ${i + 1}

${event}

`).join('')}

FADE OUT.

THE END`;
      
      setScriptContent(generatedScript);
      updateEpisode({ script: generatedScript, status: 'script-ready' });
      setIsGeneratingScript(false);
    }, 2500);
  };
  
  // ============================================================================
  // BREAKDOWN FUNCTIONS
  // ============================================================================
  
  const handleGenerateBreakdown = () => {
    setIsGeneratingBreakdown(true);
    
    setTimeout(() => {
      const mockScenes = [
        {
          id: `scene-${Date.now()}-1`,
          title: 'Opening',
          setting: 'INT. DETECTIVE OFFICE - NIGHT',
          timeOfDay: 'night',
          description: 'A dimly lit office. Rain patters against the window. Case files are scattered across the desk.',
          script: `MARCUS sits at his desk, studying old photographs.

MARCUS
Three years... and still nothing.

He picks up a worn PAGER, turns it over in his hands.`,
          cast: [],
          location: {
            id: 'loc-1',
            name: 'Detective Office',
            description: 'Cluttered 1990s detective office with filing cabinets',
            prompt: '',
            isApproved: false,
            generatedImages: [],
          },
          props: [
            { id: 'prop-1', name: 'Case Files', description: 'Worn manila folders with photographs', prompt: '', isApproved: false, isCritical: true, generatedImages: [] },
            { id: 'prop-2', name: 'Pager', description: '1990s Motorola pager', prompt: '', isApproved: false, isCritical: true, generatedImages: [] },
          ],
          extras: [],
          shots: [
            { 
              id: 'shot-1-1', 
              duration: Math.min(maxShotDuration, 8), 
              type: 'wide', 
              description: 'Establishing shot of office',
              script: 'MARCUS sits at his desk, studying old photographs.',
              prompt: 'Wide shot of dimly lit 1990s detective office, rain on window, man at cluttered desk with case files, film noir lighting',
              continuity: false 
            },
            { 
              id: 'shot-1-2', 
              duration: Math.min(maxShotDuration, 6), 
              type: 'close-up', 
              description: 'Marcus picks up the pager',
              script: 'MARCUS\nThree years... and still nothing.\n\nHe picks up a worn PAGER, turns it over in his hands.',
              prompt: 'Close-up of hands holding 1990s pager, desk with photographs in background, moody lighting',
              continuity: true 
            },
          ],
        },
        {
          id: `scene-${Date.now()}-2`,
          title: 'The Partner',
          setting: 'INT. DETECTIVE OFFICE - CONTINUOUS',
          timeOfDay: 'night',
          description: 'Sarah enters with coffee, breaking the silence.',
          script: `SARAH enters holding two COFFEE CUPS.

SARAH
Burning the midnight oil again?

MARCUS
(not looking up)
This case doesn't let go.`,
          cast: [],
          location: {
            id: 'loc-2',
            name: 'Detective Office',
            description: 'Same office, different angle',
            prompt: '',
            isApproved: false,
            generatedImages: [],
          },
          props: [
            { id: 'prop-3', name: 'Coffee Cups', description: 'Two paper coffee cups, steaming', prompt: '', isApproved: false, isCritical: false, generatedImages: [] },
          ],
          extras: [],
          shots: [
            { 
              id: 'shot-2-1', 
              duration: Math.min(maxShotDuration, 5), 
              type: 'medium', 
              description: 'Sarah enters with coffee',
              script: 'SARAH enters holding two COFFEE CUPS.\n\nSARAH\nBurning the midnight oil again?',
              prompt: 'Medium shot of woman entering dimly lit office holding two coffee cups, 1990s attire',
              continuity: false 
            },
            { 
              id: 'shot-2-2', 
              duration: Math.min(maxShotDuration, 8), 
              type: 'over-shoulder', 
              description: 'Dialogue between partners',
              script: 'MARCUS\n(not looking up)\nThis case doesn\'t let go.',
              prompt: 'Over-shoulder shot of man at desk, not looking up, moody lighting, case files visible',
              continuity: true 
            },
          ],
        },
        {
          id: `scene-${Date.now()}-3`,
          title: 'The Street',
          setting: 'EXT. CITY STREET - DAY',
          timeOfDay: 'day',
          description: 'The detectives walk through a busy downtown street.',
          script: `MARCUS and SARAH walk through the crowded street.

SARAH
The witness lives two blocks from here.

PEDESTRIANS bustle past. A HOMELESS MAN shuffles by, muttering.`,
          cast: [],
          location: {
            id: 'loc-3',
            name: 'City Street',
            description: 'Busy 1990s downtown street with shops',
            prompt: '',
            isApproved: false,
            generatedImages: [],
          },
          props: [],
          extras: [
            { id: 'extra-1', name: 'Pedestrians', description: 'Busy crowd, 1990s fashion', count: '15-20', prompt: '', isApproved: false },
            { id: 'extra-2', name: 'Homeless Man', description: 'Disheveled man shuffling past', count: '1', prompt: '', isApproved: false },
          ],
          shots: [
            { 
              id: 'shot-3-1', 
              duration: Math.min(maxShotDuration, 6), 
              type: 'wide', 
              description: 'Street establishing shot',
              script: 'MARCUS and SARAH walk through the crowded street.',
              prompt: 'Wide shot of busy 1990s downtown street, two detectives walking, pedestrians, shops',
              continuity: false 
            },
            { 
              id: 'shot-3-2', 
              duration: Math.min(maxShotDuration, 8), 
              type: 'tracking', 
              description: 'Following the detectives',
              script: 'SARAH\nThe witness lives two blocks from here.\n\nPEDESTRIANS bustle past. A HOMELESS MAN shuffles by, muttering.',
              prompt: 'Tracking shot following two detectives through busy street, homeless man passing by',
              continuity: true 
            },
          ],
        },
      ];
      
      // Generate default characters
      const mockCharacters = [
        {
          id: 'char-1',
          name: 'Marcus Chen',
          nickname: 'Marc',
          role: 'lead',
          tags: ['Detective', 'Veteran'],
          ageRange: '40-50',
          gender: 'Male',
          ethnicity: 'East Asian',
          physicalDescription: 'Tall, lean build with graying temples. Sharp, observant eyes.',
          signatureLook: 'Worn leather jacket, loosened tie',
          traits: ['Determined', 'Haunted', 'Observant'],
          hasAvatar: false,
          generatedAvatars: [],
          sceneAppearances: [0, 1, 2],
        },
        {
          id: 'char-2',
          name: 'Sarah Rodriguez',
          nickname: 'Rookie',
          role: 'lead',
          tags: ['Detective', 'Tech-savvy'],
          ageRange: '25-30',
          gender: 'Female',
          ethnicity: 'Latina',
          physicalDescription: 'Athletic build, dark curly hair usually tied back.',
          signatureLook: 'Modern blazer, always has her tablet',
          traits: ['Optimistic', 'Clever', 'Eager'],
          hasAvatar: false,
          generatedAvatars: [],
          sceneAppearances: [1, 2],
        },
      ];
      
      // Link characters to scenes
      const scenesWithCast = mockScenes.map((scene, idx) => ({
        ...scene,
        cast: mockCharacters
          .filter(char => char.sceneAppearances.includes(idx))
          .map(char => ({
            characterId: char.id,
            characterName: char.name,
            isApproved: false,
            costume: {
              id: `costume-${char.id}-${idx}`,
              name: 'Default',
              description: char.signatureLook,
              prompt: '',
              isApproved: false,
            },
          })),
      }));
      
      setCharacters(mockCharacters);
      updateEpisode({ 
        scenes: scenesWithCast, 
        characters: mockCharacters,
        status: 'breakdown-ready' 
      });
      setIsGeneratingBreakdown(false);
    }, 3000);
  };
  
  // ============================================================================
  // ELEMENT FUNCTIONS
  // ============================================================================
  
  const handleApproveElement = (sceneIdx, elementType, elementId) => {
    const updatedScenes = [...(episode?.scenes || [])];
    const scene = updatedScenes[sceneIdx];
    
    if (!scene) return;
    
    switch (elementType) {
      case 'location':
        scene.location = { ...scene.location, isApproved: true };
        break;
      case 'prop':
        scene.props = scene.props.map(p => p.id === elementId ? { ...p, isApproved: true } : p);
        break;
      case 'extra':
        scene.extras = scene.extras.map(e => e.id === elementId ? { ...e, isApproved: true } : e);
        break;
      case 'cast':
        scene.cast = scene.cast.map(c => c.characterId === elementId ? { ...c, isApproved: true } : c);
        break;
      case 'costume':
        scene.cast = scene.cast.map(c => 
          c.costume?.id === elementId ? { ...c, costume: { ...c.costume, isApproved: true } } : c
        );
        break;
    }
    
    updateEpisode({ scenes: updatedScenes });
  };
  
  const getSceneCompletionStatus = (scene) => {
    if (!scene) return { total: 0, approved: 0, percentage: 0 };
    
    let total = 0, approved = 0;
    
    // Location
    if (scene.location) {
      total++;
      if (scene.location.isApproved) approved++;
    }
    
    // Cast + costumes
    (scene.cast || []).forEach(c => {
      total += 2;
      if (c.isApproved) approved++;
      if (c.costume?.isApproved) approved++;
    });
    
    // Critical props
    (scene.props || []).filter(p => p.isCritical).forEach(p => {
      total++;
      if (p.isApproved) approved++;
    });
    
    // Extras
    (scene.extras || []).forEach(e => {
      total++;
      if (e.isApproved) approved++;
    });
    
    return { total, approved, percentage: total > 0 ? Math.round((approved / total) * 100) : 100 };
  };
  
  // Check readiness
  const canProceedToStoryboard = episode?.scenes?.length > 0 && 
    characters.filter(c => c.role !== 'background').every(c => c.hasAvatar);
  
  // ============================================================================
  // RENDER SECTIONS
  // ============================================================================
  
  // Details Section
  const renderDetailsSection = () => (
    <div style={{ padding: '24px', maxWidth: '800px', margin: '0 auto' }}>
      <h2 style={{ fontSize: '24px', fontWeight: '600', marginBottom: '24px' }}>Episode Details</h2>
      
      <div style={{ marginBottom: '24px' }}>
        <label style={{ display: 'block', fontSize: '13px', color: colors.text.secondary, marginBottom: '8px' }}>Title</label>
        <input
          type="text"
          value={episode?.title || ''}
          onChange={(e) => updateEpisode({ title: e.target.value })}
          placeholder="Episode title"
          style={{
            width: '100%',
            padding: '14px 16px',
            background: colors.bg.tertiary,
            border: `1px solid ${colors.border.default}`,
            borderRadius: '10px',
            color: colors.text.primary,
            fontSize: '16px',
          }}
        />
      </div>
      
      <div style={{ marginBottom: '24px' }}>
        <label style={{ display: 'block', fontSize: '13px', color: colors.text.secondary, marginBottom: '8px' }}>Logline</label>
        <textarea
          value={episode?.logline || ''}
          onChange={(e) => updateEpisode({ logline: e.target.value })}
          placeholder="A compelling one-sentence summary of this episode..."
          style={{
            width: '100%',
            padding: '14px 16px',
            background: colors.bg.tertiary,
            border: `1px solid ${colors.border.default}`,
            borderRadius: '10px',
            color: colors.text.primary,
            fontSize: '14px',
            minHeight: '80px',
            resize: 'vertical',
          }}
        />
      </div>
      
      <div style={{ marginBottom: '24px' }}>
        <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center', marginBottom: '12px' }}>
          <label style={{ fontSize: '13px', color: colors.text.secondary }}>Key Events / Beats</label>
          <button
            onClick={() => updateEpisode({ events: [...(episode?.events || []), ''] })}
            style={{
              padding: '6px 12px',
              background: colors.bg.tertiary,
              border: `1px solid ${colors.border.default}`,
              borderRadius: '6px',
              color: colors.text.secondary,
              cursor: 'pointer',
              fontSize: '13px',
            }}
          >
            + Add Event
          </button>
        </div>
        
        {(episode?.events || []).map((event, idx) => (
          <div key={idx} style={{ display: 'flex', gap: '8px', marginBottom: '8px' }}>
            <span style={{ 
              width: '28px', 
              height: '28px', 
              background: colors.accent.primary, 
              borderRadius: '50%', 
              display: 'flex', 
              alignItems: 'center', 
              justifyContent: 'center',
              fontSize: '13px',
              color: '#fff',
              flexShrink: 0,
              marginTop: '8px',
            }}>
              {idx + 1}
            </span>
            <textarea
              value={event}
              onChange={(e) => {
                const newEvents = [...(episode?.events || [])];
                newEvents[idx] = e.target.value;
                updateEpisode({ events: newEvents });
              }}
              placeholder="Describe what happens..."
              style={{
                flex: 1,
                padding: '12px',
                background: colors.bg.tertiary,
                border: `1px solid ${colors.border.default}`,
                borderRadius: '8px',
                color: colors.text.primary,
                fontSize: '14px',
                minHeight: '60px',
                resize: 'vertical',
              }}
            />
            <button
              onClick={() => {
                const newEvents = (episode?.events || []).filter((_, i) => i !== idx);
                updateEpisode({ events: newEvents });
              }}
              style={{
                padding: '8px',
                background: 'none',
                border: 'none',
                color: colors.text.tertiary,
                cursor: 'pointer',
                marginTop: '8px',
              }}
            >
              ✕
            </button>
          </div>
        ))}
      </div>
      
      <div style={{ display: 'flex', justifyContent: 'flex-end' }}>
        <Button onClick={() => setActiveSection('script')}>
          Continue to Script
          <Icons.ChevronRight style={{ width: 16, height: 16, marginLeft: '6px' }} />
        </Button>
      </div>
    </div>
  );
  
  // Script Section
  const renderScriptSection = () => (
    <div style={{ padding: '24px', maxWidth: '900px', margin: '0 auto' }}>
      <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center', marginBottom: '24px' }}>
        <h2 style={{ fontSize: '24px', fontWeight: '600' }}>Script</h2>
        <div style={{ display: 'flex', gap: '12px' }}>
          <Button variant="secondary">
            <Icons.Upload style={{ width: 16, height: 16, marginRight: '6px' }} />
            Import Script
          </Button>
          <Button 
            onClick={handleGenerateScript}
            disabled={isGeneratingScript || !episode?.logline}
          >
            {isGeneratingScript ? (
              <>
                <div style={{
                  width: '16px',
                  height: '16px',
                  border: '2px solid rgba(255,255,255,0.3)',
                  borderTopColor: '#fff',
                  borderRadius: '50%',
                  animation: 'spin 1s linear infinite',
                  marginRight: '8px',
                }} />
                Generating...
              </>
            ) : (
              <>
                <Icons.Sparkles style={{ width: 16, height: 16, marginRight: '6px' }} />
                Generate with AI
              </>
            )}
          </Button>
        </div>
      </div>
      
      {/* Logline reminder */}
      <div style={{
        padding: '16px',
        background: colors.bg.tertiary,
        borderRadius: '10px',
        marginBottom: '20px',
        borderLeft: `4px solid ${colors.accent.primary}`,
      }}>
        <div style={{ fontSize: '12px', color: colors.text.tertiary, marginBottom: '4px' }}>LOGLINE</div>
        <div style={{ fontSize: '14px', color: colors.text.primary }}>
          {episode?.logline || 'No logline set. Add one in Details section.'}
        </div>
      </div>
      
      {/* Script editor */}
      <textarea
        value={scriptContent}
        onChange={(e) => {
          setScriptContent(e.target.value);
          updateEpisode({ script: e.target.value });
        }}
        placeholder="Write or generate your script here..."
        style={{
          width: '100%',
          padding: '20px',
          background: colors.bg.tertiary,
          border: `1px solid ${colors.border.default}`,
          borderRadius: '10px',
          color: colors.text.primary,
          fontSize: '14px',
          fontFamily: 'Courier New, monospace',
          minHeight: '400px',
          resize: 'vertical',
          lineHeight: '1.6',
        }}
      />
      
      <div style={{ display: 'flex', justifyContent: 'space-between', marginTop: '24px' }}>
        <Button variant="secondary" onClick={() => setActiveSection('details')}>
          <Icons.ChevronLeft style={{ width: 16, height: 16, marginRight: '6px' }} />
          Back to Details
        </Button>
        <Button 
          onClick={() => setActiveSection('scenes-cast')}
          disabled={!scriptContent}
        >
          Continue to Scenes & Cast
          <Icons.ChevronRight style={{ width: 16, height: 16, marginLeft: '6px' }} />
        </Button>
      </div>
    </div>
  );
  

  // Scenes & Cast Section - Large editable scenes with tabbed avatar panel
  const [sceneElementTabs, setSceneElementTabs] = React.useState({}); // { sceneId: 'cast' | 'location' | 'props' | 'extras' }
  
  // Scene Element Modal State
  const [showSceneElementModal, setShowSceneElementModal] = React.useState(false);
  const [sceneElementModalData, setSceneElementModalData] = React.useState({
    sceneIdx: null,
    elementType: null, // 'cast', 'location', 'props', 'extras'
    existingElement: null, // For editing existing assignments
  });
  const [sceneElementForm, setSceneElementForm] = React.useState({
    selectedElement: null, // The element from Elements library
    referenceImage: null,
    // Character-specific fields
    facialExpression: '',
    tone: '',
    attitude: '',
    wardrobeElement: null, // Linked wardrobe element
    wardrobePrompt: '',
    propsElements: [], // Linked prop elements
    propsPrompt: '',
    // Non-character field
    status: '',
  });
  
  // Open scene element modal
  const openSceneElementModal = (sceneIdx, elementType, existingElement = null) => {
    setSceneElementModalData({
      sceneIdx,
      elementType,
      existingElement,
    });
    setSceneElementForm({
      selectedElement: existingElement?.element || null,
      referenceImage: existingElement?.element?.referenceImage || null,
      facialExpression: existingElement?.facialExpression || '',
      tone: existingElement?.tone || '',
      attitude: existingElement?.attitude || '',
      wardrobeElement: existingElement?.wardrobeElement || null,
      wardrobePrompt: existingElement?.wardrobePrompt || '',
      propsElements: existingElement?.propsElements || [],
      propsPrompt: existingElement?.propsPrompt || '',
      status: existingElement?.status || '',
    });
    setShowSceneElementModal(true);
  };
  
  // Mock elements for selection (in real app, would come from Elements page)
  const mockElementsLibrary = {
    characters: [
      { id: 'chr-1', name: 'Christian Ramirez', prompt: 'Latino male, early 20s, athletic build, short black hair', referenceImage: null },
      { id: 'chr-2', name: 'Maria Gonzalez', prompt: 'Latina female, early 20s, slim build, long dark wavy hair', referenceImage: null },
      { id: 'chr-3', name: 'Detective Santos', prompt: 'Latino male, mid 40s, stocky build, graying temples', referenceImage: null },
    ],
    locations: [
      { id: 'loc-1', name: "Christian's Apartment", prompt: 'Small urban apartment, modest furnishings', referenceImage: null },
      { id: 'loc-2', name: 'Barrio Street', prompt: 'Urban street in East LA, colorful murals', referenceImage: null },
    ],
    props: [
      { id: 'prop-1', name: "Christian's Phone", prompt: 'Older iPhone model, cracked screen', referenceImage: null },
      { id: 'prop-2', name: 'Gold Chain Necklace', prompt: 'Thick gold rope chain', referenceImage: null },
    ],
    wardrobe: [
      { id: 'ward-1', name: 'Christian Casual', prompt: 'White tank top, baggy dark jeans', referenceImage: null },
      { id: 'ward-2', name: 'Maria Sundress', prompt: 'Yellow floral sundress, knee length', referenceImage: null },
    ],
    extras: [
      { id: 'ext-1', name: 'Street Pedestrians', prompt: 'Various ages, casual clothing, walking', referenceImage: null },
      { id: 'ext-2', name: 'Bar Patrons', prompt: 'Mixed crowd, evening attire', referenceImage: null },
    ],
  };
  
  // Get element type label
  const getElementTypeLabel = (type) => {
    switch(type) {
      case 'cast': return 'Character';
      case 'location': return 'Location';
      case 'props': return 'Prop';
      case 'extras': return 'Extra';
      default: return 'Element';
    }
  };
  
  // Get available elements for selection
  const getAvailableElements = (type) => {
    switch(type) {
      case 'cast': return mockElementsLibrary.characters;
      case 'location': return mockElementsLibrary.locations;
      case 'props': return mockElementsLibrary.props;
      case 'extras': return mockElementsLibrary.extras;
      default: return [];
    }
  };
  
  const renderScenesCastSection = () => {
    
    const getTabForScene = (sceneId) => sceneElementTabs[sceneId] || 'cast';
    
    const setTabForScene = (sceneId, tab) => {
      setSceneElementTabs(prev => ({ ...prev, [sceneId]: tab }));
    };
    
    // Get status for each element category
    const getElementStatus = (scene, type) => {
      let total = 0, approved = 0;
      
      switch (type) {
        case 'cast':
          total = scene.cast?.length || 0;
          approved = scene.cast?.filter(c => c.isApproved).length || 0;
          break;
        case 'location':
          total = scene.location ? 1 : 0;
          approved = scene.location?.isApproved ? 1 : 0;
          break;
        case 'props':
          total = scene.props?.filter(p => p.isCritical).length || 0;
          approved = scene.props?.filter(p => p.isCritical && p.isApproved).length || 0;
          break;
        case 'extras':
          total = scene.extras?.length || 0;
          approved = scene.extras?.filter(e => e.isApproved).length || 0;
          break;
      }
      
      return { total, approved };
    };
    
    // Get tab color based on status
    const getTabColor = (scene, type) => {
      const status = getElementStatus(scene, type);
      if (status.total === 0) return colors.text.tertiary; // No items
      if (status.approved === 0) return '#ef4444'; // Red - none approved
      if (status.approved < status.total) return '#f59e0b'; // Orange - some approved
      return '#10b981'; // Green - all approved
    };
    
    return (
      <div style={{ display: 'flex', flexDirection: 'column', height: '100%', overflow: 'hidden' }}>
        {/* Script Header Bar */}
        <div style={{
          padding: '12px 24px',
          borderBottom: `1px solid ${colors.border.default}`,
          background: colors.bg.primary,
          display: 'flex',
          alignItems: 'center',
          justifyContent: 'space-between',
        }}>
          <div style={{ display: 'flex', alignItems: 'center', gap: '12px' }}>
            <h3 style={{ fontSize: '15px', fontWeight: '600' }}>Script</h3>
            <button
              onClick={handleGenerateBreakdown}
              disabled={isGeneratingBreakdown || !scriptContent}
              style={{
                padding: '6px 14px',
                background: isGeneratingBreakdown ? colors.bg.tertiary : 'linear-gradient(135deg, #8b5cf6 0%, #ec4899 100%)',
                border: 'none',
                borderRadius: '6px',
                color: '#fff',
                fontSize: '12px',
                fontWeight: '500',
                cursor: isGeneratingBreakdown ? 'not-allowed' : 'pointer',
                display: 'flex',
                alignItems: 'center',
                gap: '6px',
              }}
            >
              {isGeneratingBreakdown ? (
                <>
                  <div style={{
                    width: '12px',
                    height: '12px',
                    border: '2px solid rgba(255,255,255,0.3)',
                    borderTopColor: '#fff',
                    borderRadius: '50%',
                    animation: 'spin 1s linear infinite',
                  }} />
                  Analyzing...
                </>
              ) : (
                <>
                  <Icons.Sparkles style={{ width: 12, height: 12 }} />
                  AI Scene Breakdown
                </>
              )}
            </button>
          </div>
          
          <div style={{
            padding: '4px 10px',
            background: colors.bg.tertiary,
            borderRadius: '4px',
            fontSize: '12px',
            color: colors.text.secondary,
          }}>
            ~<strong style={{ color: colors.accent.primary }}>0:30</strong> ({episode?.scenes?.length || 0} scenes)
          </div>
        </div>
        
        {/* Scenes List */}
        <div style={{ flex: 1, overflow: 'auto', padding: '20px 24px', background: colors.bg.primary }}>
          {(episode?.scenes || []).map((scene, sceneIdx) => {
            const activeTab = getTabForScene(scene.id);
            
            const tabs = [
              { id: 'cast', label: 'Cast', icon: '👤' },
              { id: 'location', label: 'Location', icon: '📍' },
              { id: 'props', label: 'Props', icon: '📦' },
              { id: 'extras', label: 'Extras', icon: '👥' },
            ];
            
            return (
              <div key={scene.id} style={{
                display: 'flex',
                background: colors.bg.secondary,
                borderRadius: '12px',
                marginBottom: '16px',
                overflow: 'hidden',
                border: `1px solid ${colors.border.default}`,
              }}>
                {/* Left: Scene Content (large, editable) */}
                <div style={{ flex: 1, display: 'flex', flexDirection: 'column' }}>
                  {/* Scene Header */}
                  <div style={{
                    padding: '14px 18px',
                    borderBottom: `1px solid ${colors.border.default}`,
                    display: 'flex',
                    alignItems: 'center',
                    justifyContent: 'space-between',
                  }}>
                    <h4 style={{ fontSize: '15px', fontWeight: '600', margin: 0 }}>
                      Scene {sceneIdx + 1}: {scene.title}
                    </h4>
                    <button style={{
                      padding: '6px',
                      background: 'none',
                      border: 'none',
                      color: colors.text.tertiary,
                      cursor: 'pointer',
                      fontSize: '14px',
                    }}>🗑️</button>
                  </div>
                  
                  {/* Scene Description */}
                  <div style={{ padding: '14px 18px', borderBottom: `1px solid ${colors.border.subtle}` }}>
                    <p style={{ 
                      fontSize: '13px', 
                      color: colors.text.secondary, 
                      lineHeight: '1.6',
                      margin: 0,
                    }}>
                      {scene.description}
                      {scene.cast?.length > 0 && (
                        <>
                          {' '}
                          {scene.cast.map((c, i) => (
                            <span key={c.characterId}>
                              <span style={{ color: colors.accent.primary, fontWeight: '500' }}>@{c.characterName.split(' ')[0]}</span>
                              {i < scene.cast.length - 1 ? (i === scene.cast.length - 2 ? ' and ' : ', ') : ''}
                            </span>
                          ))}
                        </>
                      )}
                    </p>
                  </div>
                  
                  {/* Shots */}
                  <div style={{ padding: '14px 18px' }}>
                    {(scene.shots || []).map((shot, shotIdx) => {
                      const isEditing = editingShot?.sceneIdx === sceneIdx && editingShot?.shotIdx === shotIdx;
                      
                      return (
                        <div key={shot.id} style={{
                          marginBottom: shotIdx < (scene.shots?.length || 1) - 1 ? '16px' : 0,
                          border: isEditing ? `2px solid ${colors.accent.primary}` : `1px solid ${colors.border.subtle}`,
                          borderRadius: '10px',
                          overflow: 'hidden',
                          background: colors.bg.tertiary,
                        }}>
                          {/* Shot Header */}
                          <div style={{
                            padding: '10px 14px',
                            background: isEditing ? 'rgba(139,92,246,0.1)' : colors.bg.secondary,
                            borderBottom: `1px solid ${colors.border.subtle}`,
                            display: 'flex',
                            alignItems: 'center',
                            gap: '12px',
                          }}>
                            <div style={{
                              width: '10px',
                              height: '10px',
                              borderRadius: '50%',
                              background: shot.continuity ? colors.accent.primary : colors.text.tertiary,
                              border: `2px solid ${shot.continuity ? colors.accent.primary : colors.text.tertiary}`,
                            }} />
                            <span style={{ fontSize: '12px', fontWeight: '600', color: colors.text.primary }}>
                              Shot {shotIdx + 1}
                            </span>
                            
                            {/* Duration */}
                            <div style={{ display: 'flex', alignItems: 'center', gap: '4px', marginLeft: 'auto' }}>
                              <span style={{ fontSize: '10px', color: colors.text.tertiary }}>Duration:</span>
                              {isEditing ? (
                                <input
                                  type="number"
                                  min={minShotDuration}
                                  max={maxShotDuration}
                                  value={shot.duration}
                                  onChange={(e) => updateShot(sceneIdx, shotIdx, { 
                                    duration: Math.min(maxShotDuration, Math.max(minShotDuration, parseInt(e.target.value) || minShotDuration))
                                  })}
                                  style={{
                                    width: '50px',
                                    padding: '4px 6px',
                                    background: colors.bg.primary,
                                    border: `1px solid ${colors.border.default}`,
                                    borderRadius: '4px',
                                    color: colors.text.primary,
                                    fontSize: '11px',
                                    textAlign: 'center',
                                  }}
                                />
                              ) : (
                                <span style={{ 
                                  padding: '2px 8px',
                                  background: colors.bg.primary,
                                  borderRadius: '4px',
                                  fontSize: '11px',
                                  color: shot.duration > maxShotDuration ? '#ef4444' : colors.text.secondary,
                                  fontWeight: '500',
                                }}>
                                  {shot.duration}s
                                </span>
                              )}
                              <span style={{ fontSize: '9px', color: colors.text.tertiary }}>
                                (max {maxShotDuration}s)
                              </span>
                            </div>
                            
                            {/* Shot Type */}
                            {isEditing ? (
                              <select
                                value={shot.type}
                                onChange={(e) => updateShot(sceneIdx, shotIdx, { type: e.target.value })}
                                style={{
                                  padding: '4px 8px',
                                  background: colors.bg.primary,
                                  border: `1px solid ${colors.border.default}`,
                                  borderRadius: '4px',
                                  color: colors.text.primary,
                                  fontSize: '10px',
                                }}
                              >
                                <option value="wide">Wide</option>
                                <option value="medium">Medium</option>
                                <option value="close-up">Close-up</option>
                                <option value="over-shoulder">Over Shoulder</option>
                                <option value="tracking">Tracking</option>
                                <option value="pov">POV</option>
                                <option value="aerial">Aerial</option>
                              </select>
                            ) : (
                              <span style={{ 
                                padding: '2px 8px',
                                background: 'rgba(139,92,246,0.2)',
                                borderRadius: '4px',
                                fontSize: '10px',
                                color: colors.accent.primary,
                                textTransform: 'capitalize',
                              }}>
                                {shot.type}
                              </span>
                            )}
                            
                            {/* Edit/Save button */}
                            <button
                              onClick={() => setEditingShot(isEditing ? null : { sceneIdx, shotIdx })}
                              style={{
                                padding: '4px 10px',
                                background: isEditing ? colors.accent.primary : colors.bg.primary,
                                border: 'none',
                                borderRadius: '4px',
                                color: isEditing ? '#fff' : colors.text.secondary,
                                fontSize: '10px',
                                cursor: 'pointer',
                              }}
                            >
                              {isEditing ? '✓ Done' : '✎ Edit'}
                            </button>
                          </div>
                          
                          {/* Shot Content */}
                          <div style={{ padding: '12px 14px' }}>
                            {/* Description */}
                            <div style={{ marginBottom: '10px' }}>
                              <label style={{ fontSize: '10px', color: colors.text.tertiary, display: 'block', marginBottom: '4px' }}>
                                Description
                              </label>
                              {isEditing ? (
                                <input
                                  type="text"
                                  value={shot.description}
                                  onChange={(e) => updateShot(sceneIdx, shotIdx, { description: e.target.value })}
                                  placeholder="Describe what happens in this shot..."
                                  style={{
                                    width: '100%',
                                    padding: '8px 10px',
                                    background: colors.bg.primary,
                                    border: `1px solid ${colors.border.default}`,
                                    borderRadius: '6px',
                                    color: colors.text.primary,
                                    fontSize: '12px',
                                  }}
                                />
                              ) : (
                                <div style={{ fontSize: '12px', color: colors.text.primary }}>
                                  {shot.description || 'No description'}
                                </div>
                              )}
                            </div>
                            
                            {/* Script */}
                            <div style={{ marginBottom: '10px' }}>
                              <label style={{ fontSize: '10px', color: colors.text.tertiary, display: 'block', marginBottom: '4px' }}>
                                Script / Dialogue
                              </label>
                              {isEditing ? (
                                <textarea
                                  value={shot.script || ''}
                                  onChange={(e) => updateShot(sceneIdx, shotIdx, { script: e.target.value })}
                                  placeholder="Script content for this shot..."
                                  style={{
                                    width: '100%',
                                    padding: '8px 10px',
                                    background: colors.bg.primary,
                                    border: `1px solid ${colors.border.default}`,
                                    borderRadius: '6px',
                                    color: colors.text.primary,
                                    fontSize: '11px',
                                    fontFamily: 'monospace',
                                    minHeight: '80px',
                                    resize: 'vertical',
                                  }}
                                />
                              ) : (
                                <div style={{ 
                                  fontSize: '11px', 
                                  color: colors.text.secondary,
                                  fontFamily: 'monospace',
                                  whiteSpace: 'pre-wrap',
                                  background: colors.bg.secondary,
                                  padding: '8px 10px',
                                  borderRadius: '6px',
                                  maxHeight: '100px',
                                  overflow: 'auto',
                                }}>
                                  {shot.script || 'No script content'}
                                </div>
                              )}
                            </div>
                            
                            {/* Prompt (for generation) */}
                            {isEditing && (
                              <div>
                                <label style={{ fontSize: '10px', color: colors.text.tertiary, display: 'block', marginBottom: '4px' }}>
                                  Generation Prompt
                                </label>
                                <textarea
                                  value={shot.prompt || ''}
                                  onChange={(e) => updateShot(sceneIdx, shotIdx, { prompt: e.target.value })}
                                  placeholder="AI generation prompt for this shot..."
                                  style={{
                                    width: '100%',
                                    padding: '8px 10px',
                                    background: colors.bg.primary,
                                    border: `1px solid ${colors.border.default}`,
                                    borderRadius: '6px',
                                    color: colors.text.primary,
                                    fontSize: '11px',
                                    minHeight: '60px',
                                    resize: 'vertical',
                                  }}
                                />
                              </div>
                            )}
                          </div>
                          
                          {/* Shot Actions Footer */}
                          <div style={{
                            padding: '8px 14px',
                            background: colors.bg.secondary,
                            borderTop: `1px solid ${colors.border.subtle}`,
                            display: 'flex',
                            justifyContent: 'flex-end',
                            gap: '6px',
                          }}>
                            <button
                              onClick={() => addShot(sceneIdx)}
                              title="Add shot after"
                              style={{
                                padding: '4px 8px',
                                background: colors.bg.tertiary,
                                border: `1px solid ${colors.border.default}`,
                                borderRadius: '4px',
                                color: colors.text.secondary,
                                cursor: 'pointer',
                                fontSize: '10px',
                              }}
                            >+ Add</button>
                            <button
                              onClick={() => duplicateShot(sceneIdx, shotIdx)}
                              title="Duplicate shot"
                              style={{
                                padding: '4px 8px',
                                background: colors.bg.tertiary,
                                border: `1px solid ${colors.border.default}`,
                                borderRadius: '4px',
                                color: colors.text.secondary,
                                cursor: 'pointer',
                                fontSize: '10px',
                              }}
                            >⧉ Duplicate</button>
                            <button
                              onClick={() => deleteShot(sceneIdx, shotIdx)}
                              title="Delete shot"
                              style={{
                                padding: '4px 8px',
                                background: 'rgba(239,68,68,0.1)',
                                border: `1px solid rgba(239,68,68,0.3)`,
                                borderRadius: '4px',
                                color: '#ef4444',
                                cursor: 'pointer',
                                fontSize: '10px',
                              }}
                            >🗑 Delete</button>
                          </div>
                        </div>
                      );
                    })}
                    
                    {/* Add first shot if none */}
                    {(!scene.shots || scene.shots.length === 0) && (
                      <button
                        onClick={() => addShot(sceneIdx)}
                        style={{
                          width: '100%',
                          padding: '16px',
                          background: colors.bg.tertiary,
                          border: `2px dashed ${colors.border.default}`,
                          borderRadius: '8px',
                          color: colors.text.secondary,
                          cursor: 'pointer',
                          fontSize: '13px',
                        }}
                      >
                        + Add First Shot
                      </button>
                    )}
                  </div>
                </div>
                
                {/* Right: Avatar Panel with Tabs */}
                <div style={{
                  width: '200px',
                  borderLeft: `1px solid ${colors.border.default}`,
                  background: colors.bg.tertiary,
                  display: 'flex',
                  flexDirection: 'column',
                }}>
                  {/* Tabs */}
                  <div style={{
                    display: 'grid',
                    gridTemplateColumns: '1fr 1fr',
                    gap: '4px',
                    padding: '8px',
                    borderBottom: `1px solid ${colors.border.default}`,
                  }}>
                    {tabs.map(tab => {
                      const status = getElementStatus(scene, tab.id);
                      const tabColor = getTabColor(scene, tab.id);
                      const isActive = activeTab === tab.id;
                      
                      return (
                        <button
                          key={tab.id}
                          onClick={() => setTabForScene(scene.id, tab.id)}
                          style={{
                            padding: '6px 8px',
                            background: isActive ? colors.bg.secondary : 'transparent',
                            border: isActive ? `1px solid ${tabColor}` : `1px solid transparent`,
                            borderRadius: '6px',
                            color: tabColor,
                            fontSize: '10px',
                            fontWeight: '600',
                            cursor: 'pointer',
                            display: 'flex',
                            alignItems: 'center',
                            justifyContent: 'center',
                            gap: '4px',
                          }}
                        >
                          <span>{tab.icon}</span>
                          <span>{status.total > 0 ? `(${status.approved}/${status.total})` : '(0)'}</span>
                        </button>
                      );
                    })}
                  </div>
                  
                  {/* Avatar Content */}
                  <div style={{ flex: 1, padding: '12px', overflow: 'auto' }}>
                    {/* Cast Tab */}
                    {activeTab === 'cast' && (
                      <div style={{ display: 'flex', flexWrap: 'wrap', gap: '10px', justifyContent: 'center' }}>
                        {(scene.cast || []).map(castMember => {
                          const char = characters.find(c => c.id === castMember.characterId);
                          const isAssigned = castMember.isApproved;
                          return (
                            <div key={castMember.characterId} style={{ textAlign: 'center' }}>
                              <div 
                                onClick={() => openSceneElementModal(sceneIdx, 'cast', { 
                                  ...castMember, 
                                  element: char 
                                })}
                                style={{
                                  width: '44px',
                                  height: '44px',
                                  borderRadius: '50%',
                                  background: isAssigned 
                                    ? 'linear-gradient(135deg, #5eead4 0%, #2dd4bf 100%)' // Light turquoise when filled
                                    : colors.bg.secondary,
                                  border: `3px solid ${isAssigned ? '#14b8a6' : '#f472b6'}`, // Turquoise or Pink
                                  display: 'flex',
                                  alignItems: 'center',
                                  justifyContent: 'center',
                                  fontSize: '18px',
                                  cursor: 'pointer',
                                  transition: 'all 0.2s ease',
                                }}
                                onMouseEnter={(e) => e.currentTarget.style.transform = 'scale(1.1)'}
                                onMouseLeave={(e) => e.currentTarget.style.transform = 'scale(1)'}
                              >
                                {isAssigned ? '👤' : <Icons.Plus style={{ width: 16, height: 16, color: '#f472b6' }} />}
                              </div>
                              <div style={{ fontSize: '9px', color: colors.text.tertiary, marginTop: '4px' }}>
                                {castMember.characterName?.split(' ')[0] || 'Add'}
                              </div>
                            </div>
                          );
                        })}
                        {/* Add new cast button */}
                        <div style={{ textAlign: 'center' }}>
                          <div 
                            onClick={() => openSceneElementModal(sceneIdx, 'cast', null)}
                            style={{
                              width: '44px',
                              height: '44px',
                              borderRadius: '50%',
                              background: colors.bg.secondary,
                              border: `3px dashed #f472b6`, // Pink dashed for add
                              display: 'flex',
                              alignItems: 'center',
                              justifyContent: 'center',
                              cursor: 'pointer',
                              transition: 'all 0.2s ease',
                            }}
                            onMouseEnter={(e) => {
                              e.currentTarget.style.transform = 'scale(1.1)';
                              e.currentTarget.style.background = 'rgba(244, 114, 182, 0.1)';
                            }}
                            onMouseLeave={(e) => {
                              e.currentTarget.style.transform = 'scale(1)';
                              e.currentTarget.style.background = colors.bg.secondary;
                            }}
                          >
                            <Icons.Plus style={{ width: 16, height: 16, color: '#f472b6' }} />
                          </div>
                          <div style={{ fontSize: '9px', color: colors.text.tertiary, marginTop: '4px' }}>
                            Add
                          </div>
                        </div>
                      </div>
                    )}
                    
                    {/* Location Tab */}
                    {activeTab === 'location' && (
                      <div style={{ textAlign: 'center' }}>
                        {scene.location ? (
                          <>
                            <div 
                              onClick={() => openSceneElementModal(sceneIdx, 'location', {
                                ...scene.location,
                                element: scene.location,
                              })}
                              style={{
                                width: '56px',
                                height: '56px',
                                borderRadius: '10px',
                                background: scene.location.isApproved 
                                  ? 'linear-gradient(135deg, #5eead4 0%, #2dd4bf 100%)'
                                  : colors.bg.secondary,
                                border: `3px solid ${scene.location.isApproved ? '#14b8a6' : '#f472b6'}`,
                                display: 'flex',
                                alignItems: 'center',
                                justifyContent: 'center',
                                fontSize: '24px',
                                margin: '0 auto 8px',
                                cursor: 'pointer',
                                transition: 'all 0.2s ease',
                              }}
                              onMouseEnter={(e) => e.currentTarget.style.transform = 'scale(1.05)'}
                              onMouseLeave={(e) => e.currentTarget.style.transform = 'scale(1)'}
                            >
                              {scene.location.isApproved ? '📍' : <Icons.Plus style={{ width: 20, height: 20, color: '#f472b6' }} />}
                            </div>
                            <div style={{ fontSize: '11px', fontWeight: '500', marginBottom: '4px' }}>
                              {scene.location.name}
                            </div>
                            <div style={{ fontSize: '9px', color: colors.text.tertiary }}>
                              {scene.location.description?.slice(0, 40)}...
                            </div>
                          </>
                        ) : (
                          <div 
                            onClick={() => openSceneElementModal(sceneIdx, 'location', null)}
                            style={{
                              width: '56px',
                              height: '56px',
                              borderRadius: '10px',
                              background: colors.bg.secondary,
                              border: `3px dashed #f472b6`,
                              display: 'flex',
                              alignItems: 'center',
                              justifyContent: 'center',
                              margin: '0 auto 8px',
                              cursor: 'pointer',
                              transition: 'all 0.2s ease',
                            }}
                            onMouseEnter={(e) => {
                              e.currentTarget.style.transform = 'scale(1.05)';
                              e.currentTarget.style.background = 'rgba(244, 114, 182, 0.1)';
                            }}
                            onMouseLeave={(e) => {
                              e.currentTarget.style.transform = 'scale(1)';
                              e.currentTarget.style.background = colors.bg.secondary;
                            }}
                          >
                            <Icons.Plus style={{ width: 20, height: 20, color: '#f472b6' }} />
                          </div>
                        )}
                        {!scene.location && (
                          <div style={{ fontSize: '11px', color: colors.text.tertiary }}>
                            Add Location
                          </div>
                        )}
                      </div>
                    )}
                    
                    {/* Props Tab */}
                    {activeTab === 'props' && (
                      <div style={{ display: 'flex', flexWrap: 'wrap', gap: '10px', justifyContent: 'center' }}>
                        {(scene.props || []).map(prop => {
                          const isAssigned = prop.isApproved;
                          return (
                            <div key={prop.id} style={{ textAlign: 'center' }}>
                              <div 
                                onClick={() => openSceneElementModal(sceneIdx, 'props', {
                                  ...prop,
                                  element: prop,
                                })}
                                style={{
                                  width: '40px',
                                  height: '40px',
                                  borderRadius: '8px',
                                  background: isAssigned 
                                    ? 'linear-gradient(135deg, #5eead4 0%, #2dd4bf 100%)'
                                    : colors.bg.secondary,
                                  border: `3px solid ${isAssigned ? '#14b8a6' : '#f472b6'}`,
                                  display: 'flex',
                                  alignItems: 'center',
                                  justifyContent: 'center',
                                  fontSize: '16px',
                                  cursor: 'pointer',
                                  transition: 'all 0.2s ease',
                                }}
                                onMouseEnter={(e) => e.currentTarget.style.transform = 'scale(1.1)'}
                                onMouseLeave={(e) => e.currentTarget.style.transform = 'scale(1)'}
                              >
                                {isAssigned ? '📦' : <Icons.Plus style={{ width: 14, height: 14, color: '#f472b6' }} />}
                              </div>
                              <div style={{ 
                                fontSize: '8px', 
                                color: colors.text.tertiary, 
                                marginTop: '4px',
                                maxWidth: '40px',
                                overflow: 'hidden',
                                textOverflow: 'ellipsis',
                                whiteSpace: 'nowrap',
                              }}>
                                {prop.name || 'Add'}
                              </div>
                            </div>
                          );
                        })}
                        {/* Add new prop button */}
                        <div style={{ textAlign: 'center' }}>
                          <div 
                            onClick={() => openSceneElementModal(sceneIdx, 'props', null)}
                            style={{
                              width: '40px',
                              height: '40px',
                              borderRadius: '8px',
                              background: colors.bg.secondary,
                              border: `3px dashed #f472b6`,
                              display: 'flex',
                              alignItems: 'center',
                              justifyContent: 'center',
                              cursor: 'pointer',
                              transition: 'all 0.2s ease',
                            }}
                            onMouseEnter={(e) => {
                              e.currentTarget.style.transform = 'scale(1.1)';
                              e.currentTarget.style.background = 'rgba(244, 114, 182, 0.1)';
                            }}
                            onMouseLeave={(e) => {
                              e.currentTarget.style.transform = 'scale(1)';
                              e.currentTarget.style.background = colors.bg.secondary;
                            }}
                          >
                            <Icons.Plus style={{ width: 14, height: 14, color: '#f472b6' }} />
                          </div>
                          <div style={{ fontSize: '8px', color: colors.text.tertiary, marginTop: '4px' }}>Add</div>
                        </div>
                      </div>
                    )}
                    
                    {/* Extras Tab */}
                    {activeTab === 'extras' && (
                      <div style={{ display: 'flex', flexWrap: 'wrap', gap: '10px', justifyContent: 'center' }}>
                        {(scene.extras || []).map(extra => {
                          const isAssigned = extra.isApproved;
                          return (
                            <div key={extra.id} style={{ textAlign: 'center' }}>
                              <div 
                                onClick={() => openSceneElementModal(sceneIdx, 'extras', {
                                  ...extra,
                                  element: extra,
                                })}
                                style={{
                                  width: '40px',
                                  height: '40px',
                                  borderRadius: '8px',
                                  background: isAssigned 
                                    ? 'linear-gradient(135deg, #5eead4 0%, #2dd4bf 100%)'
                                    : colors.bg.secondary,
                                  border: `3px solid ${isAssigned ? '#14b8a6' : '#f472b6'}`,
                                  display: 'flex',
                                  alignItems: 'center',
                                  justifyContent: 'center',
                                  fontSize: '16px',
                                  cursor: 'pointer',
                                  transition: 'all 0.2s ease',
                                }}
                                onMouseEnter={(e) => e.currentTarget.style.transform = 'scale(1.1)'}
                                onMouseLeave={(e) => e.currentTarget.style.transform = 'scale(1)'}
                              >
                                {isAssigned ? '👥' : <Icons.Plus style={{ width: 14, height: 14, color: '#f472b6' }} />}
                              </div>
                              <div style={{ fontSize: '8px', color: colors.text.tertiary, marginTop: '4px' }}>
                                {isAssigned ? `×${extra.count}` : 'Add'}
                              </div>
                            </div>
                          );
                        })}
                        {/* Add new extra button */}
                        <div style={{ textAlign: 'center' }}>
                          <div 
                            onClick={() => openSceneElementModal(sceneIdx, 'extras', null)}
                            style={{
                              width: '40px',
                              height: '40px',
                              borderRadius: '8px',
                              background: colors.bg.secondary,
                              border: `3px dashed #f472b6`,
                              display: 'flex',
                              alignItems: 'center',
                              justifyContent: 'center',
                              cursor: 'pointer',
                              transition: 'all 0.2s ease',
                            }}
                            onMouseEnter={(e) => {
                              e.currentTarget.style.transform = 'scale(1.1)';
                              e.currentTarget.style.background = 'rgba(244, 114, 182, 0.1)';
                            }}
                            onMouseLeave={(e) => {
                              e.currentTarget.style.transform = 'scale(1)';
                              e.currentTarget.style.background = colors.bg.secondary;
                            }}
                          >
                            <Icons.Plus style={{ width: 14, height: 14, color: '#f472b6' }} />
                          </div>
                          <div style={{ fontSize: '8px', color: colors.text.tertiary, marginTop: '4px' }}>Add</div>
                        </div>
                      </div>
                    )}
                  </div>
                  
                  {/* Approve All Button */}
                  {activeTab === 'cast' && scene.cast?.some(c => !c.isApproved) && (
                    <div style={{ padding: '8px' }}>
                      <button
                        onClick={() => {
                          scene.cast.forEach(c => {
                            if (!c.isApproved) handleApproveElement(sceneIdx, 'cast', c.characterId);
                          });
                        }}
                        style={{
                          width: '100%',
                          padding: '8px',
                          background: '#10b981',
                          border: 'none',
                          borderRadius: '6px',
                          color: '#fff',
                          fontSize: '11px',
                          fontWeight: '500',
                          cursor: 'pointer',
                        }}
                      >
                        ✓ Approve All
                      </button>
                    </div>
                  )}
                  {activeTab === 'props' && scene.props?.some(p => p.isCritical && !p.isApproved) && (
                    <div style={{ padding: '8px' }}>
                      <button
                        onClick={() => {
                          scene.props.forEach(p => {
                            if (p.isCritical && !p.isApproved) handleApproveElement(sceneIdx, 'prop', p.id);
                          });
                        }}
                        style={{
                          width: '100%',
                          padding: '8px',
                          background: '#10b981',
                          border: 'none',
                          borderRadius: '6px',
                          color: '#fff',
                          fontSize: '11px',
                          fontWeight: '500',
                          cursor: 'pointer',
                        }}
                      >
                        ✓ Approve All
                      </button>
                    </div>
                  )}
                </div>
              </div>
            );
          })}
          
          {/* Empty State */}
          {(!episode?.scenes || episode.scenes.length === 0) && (
            <div style={{
              textAlign: 'center',
              padding: '60px 40px',
              color: colors.text.tertiary,
            }}>
              <Icons.Film style={{ width: 48, height: 48, marginBottom: '12px', opacity: 0.3 }} />
              <h3 style={{ fontSize: '16px', marginBottom: '8px', color: colors.text.secondary }}>No scenes yet</h3>
              <p style={{ fontSize: '13px' }}>
                Click "AI Scene Breakdown" above to analyze your script
              </p>
            </div>
          )}
        </div>
        
        {/* Scene Element Modal */}
        {showSceneElementModal && (
          <div style={{
            position: 'fixed',
            top: 0,
            left: 0,
            right: 0,
            bottom: 0,
            background: 'rgba(0,0,0,0.85)',
            display: 'flex',
            alignItems: 'center',
            justifyContent: 'center',
            zIndex: 1000,
          }}>
            <div style={{
              width: '600px',
              maxHeight: '85vh',
              background: colors.bg.secondary,
              borderRadius: '16px',
              overflow: 'hidden',
              display: 'flex',
              flexDirection: 'column',
            }}>
              {/* Modal Header */}
              <div style={{
                padding: '20px 24px',
                borderBottom: `1px solid ${colors.border.default}`,
                display: 'flex',
                justifyContent: 'space-between',
                alignItems: 'center',
              }}>
                <h2 style={{ fontSize: '18px', fontWeight: '600', margin: 0 }}>
                  {sceneElementModalData.existingElement ? 'Edit' : 'Add'} {getElementTypeLabel(sceneElementModalData.elementType)}
                </h2>
                <button
                  onClick={() => setShowSceneElementModal(false)}
                  style={{
                    background: 'none',
                    border: 'none',
                    color: colors.text.tertiary,
                    cursor: 'pointer',
                    fontSize: '24px',
                    padding: '4px',
                  }}
                >×</button>
              </div>
              
              {/* Modal Content */}
              <div style={{ flex: 1, overflow: 'auto', padding: '24px' }}>
                {/* Element Selection */}
                <div style={{ marginBottom: '24px' }}>
                  <label style={{ 
                    fontSize: '12px', 
                    fontWeight: '600', 
                    color: colors.text.secondary, 
                    display: 'block', 
                    marginBottom: '10px',
                    textTransform: 'uppercase',
                  }}>
                    Select {getElementTypeLabel(sceneElementModalData.elementType)}
                  </label>
                  <div style={{ display: 'flex', flexWrap: 'wrap', gap: '8px' }}>
                    {getAvailableElements(sceneElementModalData.elementType).map(el => (
                      <button
                        key={el.id}
                        onClick={() => setSceneElementForm(prev => ({ 
                          ...prev, 
                          selectedElement: el,
                          referenceImage: el.referenceImage,
                        }))}
                        style={{
                          padding: '10px 16px',
                          borderRadius: '8px',
                          border: `2px solid ${sceneElementForm.selectedElement?.id === el.id ? '#14b8a6' : colors.border.default}`,
                          background: sceneElementForm.selectedElement?.id === el.id 
                            ? 'linear-gradient(135deg, rgba(94, 234, 212, 0.2), rgba(45, 212, 191, 0.2))'
                            : colors.bg.tertiary,
                          color: sceneElementForm.selectedElement?.id === el.id ? '#14b8a6' : colors.text.primary,
                          fontSize: '13px',
                          fontWeight: '500',
                          cursor: 'pointer',
                          transition: 'all 0.2s ease',
                        }}
                      >
                        {el.name}
                      </button>
                    ))}
                    <button
                      onClick={() => alert('Navigate to Elements page to create new')}
                      style={{
                        padding: '10px 16px',
                        borderRadius: '8px',
                        border: `2px dashed #f472b6`,
                        background: 'transparent',
                        color: '#f472b6',
                        fontSize: '13px',
                        fontWeight: '500',
                        cursor: 'pointer',
                        display: 'flex',
                        alignItems: 'center',
                        gap: '6px',
                      }}
                    >
                      <Icons.Plus style={{ width: 14, height: 14 }} />
                      Create New
                    </button>
                  </div>
                </div>
                
                {/* Reference Image Preview */}
                {sceneElementForm.selectedElement && (
                  <div style={{ marginBottom: '24px' }}>
                    <label style={{ 
                      fontSize: '12px', 
                      fontWeight: '600', 
                      color: colors.text.secondary, 
                      display: 'block', 
                      marginBottom: '10px',
                      textTransform: 'uppercase',
                    }}>
                      Reference Image
                    </label>
                    <div style={{
                      display: 'flex',
                      alignItems: 'center',
                      gap: '16px',
                      padding: '16px',
                      background: colors.bg.tertiary,
                      borderRadius: '10px',
                      border: `1px solid ${colors.border.default}`,
                    }}>
                      <div style={{
                        width: '80px',
                        height: '80px',
                        borderRadius: '10px',
                        background: sceneElementForm.referenceImage 
                          ? 'linear-gradient(135deg, #667eea 0%, #764ba2 100%)'
                          : colors.bg.secondary,
                        display: 'flex',
                        alignItems: 'center',
                        justifyContent: 'center',
                        border: `2px dashed ${colors.border.default}`,
                      }}>
                        {sceneElementForm.referenceImage ? (
                          <Icons.Image style={{ width: 24, height: 24, color: 'white' }} />
                        ) : (
                          <Icons.Upload style={{ width: 24, height: 24, color: colors.text.tertiary }} />
                        )}
                      </div>
                      <div style={{ flex: 1 }}>
                        <div style={{ fontSize: '13px', color: colors.text.primary, marginBottom: '4px' }}>
                          {sceneElementForm.referenceImage ? 'Reference uploaded' : 'No reference image'}
                        </div>
                        <div style={{ fontSize: '11px', color: colors.text.tertiary }}>
                          {sceneElementForm.selectedElement?.prompt?.slice(0, 60)}...
                        </div>
                      </div>
                      <button
                        onClick={() => setSceneElementForm(prev => ({ 
                          ...prev, 
                          referenceImage: prev.referenceImage ? null : 'uploaded-ref.jpg' 
                        }))}
                        style={{
                          padding: '8px 14px',
                          background: colors.bg.secondary,
                          border: `1px solid ${colors.border.default}`,
                          borderRadius: '6px',
                          color: colors.text.secondary,
                          fontSize: '12px',
                          cursor: 'pointer',
                        }}
                      >
                        {sceneElementForm.referenceImage ? 'Remove' : 'Upload'}
                      </button>
                    </div>
                  </div>
                )}
                
                {/* Character-specific fields */}
                {sceneElementModalData.elementType === 'cast' && sceneElementForm.selectedElement && (
                  <>
                    {/* Facial Expression */}
                    <div style={{ marginBottom: '20px' }}>
                      <label style={{ 
                        fontSize: '12px', 
                        fontWeight: '600', 
                        color: colors.text.secondary, 
                        display: 'block', 
                        marginBottom: '8px',
                        textTransform: 'uppercase',
                      }}>
                        Facial Expression
                      </label>
                      <input
                        type="text"
                        value={sceneElementForm.facialExpression}
                        onChange={(e) => setSceneElementForm(prev => ({ ...prev, facialExpression: e.target.value }))}
                        placeholder="e.g., worried, smiling, angry, surprised..."
                        style={{
                          width: '100%',
                          padding: '12px 14px',
                          background: colors.bg.tertiary,
                          border: `1px solid ${colors.border.default}`,
                          borderRadius: '8px',
                          color: colors.text.primary,
                          fontSize: '13px',
                        }}
                      />
                    </div>
                    
                    {/* Tone */}
                    <div style={{ marginBottom: '20px' }}>
                      <label style={{ 
                        fontSize: '12px', 
                        fontWeight: '600', 
                        color: colors.text.secondary, 
                        display: 'block', 
                        marginBottom: '8px',
                        textTransform: 'uppercase',
                      }}>
                        Tone
                      </label>
                      <input
                        type="text"
                        value={sceneElementForm.tone}
                        onChange={(e) => setSceneElementForm(prev => ({ ...prev, tone: e.target.value }))}
                        placeholder="e.g., serious, playful, melancholic, aggressive..."
                        style={{
                          width: '100%',
                          padding: '12px 14px',
                          background: colors.bg.tertiary,
                          border: `1px solid ${colors.border.default}`,
                          borderRadius: '8px',
                          color: colors.text.primary,
                          fontSize: '13px',
                        }}
                      />
                    </div>
                    
                    {/* Attitude */}
                    <div style={{ marginBottom: '20px' }}>
                      <label style={{ 
                        fontSize: '12px', 
                        fontWeight: '600', 
                        color: colors.text.secondary, 
                        display: 'block', 
                        marginBottom: '8px',
                        textTransform: 'uppercase',
                      }}>
                        Attitude
                      </label>
                      <input
                        type="text"
                        value={sceneElementForm.attitude}
                        onChange={(e) => setSceneElementForm(prev => ({ ...prev, attitude: e.target.value }))}
                        placeholder="e.g., confident, nervous, defiant, reserved..."
                        style={{
                          width: '100%',
                          padding: '12px 14px',
                          background: colors.bg.tertiary,
                          border: `1px solid ${colors.border.default}`,
                          borderRadius: '8px',
                          color: colors.text.primary,
                          fontSize: '13px',
                        }}
                      />
                    </div>
                    
                    {/* Wardrobe */}
                    <div style={{ marginBottom: '20px' }}>
                      <label style={{ 
                        fontSize: '12px', 
                        fontWeight: '600', 
                        color: colors.text.secondary, 
                        display: 'block', 
                        marginBottom: '8px',
                        textTransform: 'uppercase',
                      }}>
                        Wardrobe
                      </label>
                      <div style={{ display: 'flex', gap: '8px', marginBottom: '8px' }}>
                        {sceneElementForm.wardrobeElement ? (
                          <div style={{
                            padding: '8px 12px',
                            background: 'linear-gradient(135deg, rgba(94, 234, 212, 0.2), rgba(45, 212, 191, 0.2))',
                            border: '2px solid #14b8a6',
                            borderRadius: '8px',
                            display: 'flex',
                            alignItems: 'center',
                            gap: '8px',
                          }}>
                            <span style={{ fontSize: '12px', color: '#14b8a6' }}>
                              {sceneElementForm.wardrobeElement.name}
                            </span>
                            <button
                              onClick={() => setSceneElementForm(prev => ({ ...prev, wardrobeElement: null }))}
                              style={{
                                background: 'none',
                                border: 'none',
                                color: '#14b8a6',
                                cursor: 'pointer',
                                padding: 0,
                                fontSize: '14px',
                              }}
                            >×</button>
                          </div>
                        ) : (
                          <button
                            onClick={() => setSceneElementForm(prev => ({ 
                              ...prev, 
                              wardrobeElement: mockElementsLibrary.wardrobe[0] 
                            }))}
                            style={{
                              padding: '8px 12px',
                              border: `2px dashed #f472b6`,
                              borderRadius: '8px',
                              background: 'transparent',
                              color: '#f472b6',
                              fontSize: '12px',
                              cursor: 'pointer',
                              display: 'flex',
                              alignItems: 'center',
                              gap: '6px',
                            }}
                          >
                            <Icons.Plus style={{ width: 12, height: 12 }} />
                            Add Element
                          </button>
                        )}
                      </div>
                      <input
                        type="text"
                        value={sceneElementForm.wardrobePrompt}
                        onChange={(e) => setSceneElementForm(prev => ({ ...prev, wardrobePrompt: e.target.value }))}
                        placeholder="Or describe wardrobe: e.g., torn white t-shirt, dirty jeans..."
                        style={{
                          width: '100%',
                          padding: '10px 12px',
                          background: colors.bg.tertiary,
                          border: `1px solid ${colors.border.default}`,
                          borderRadius: '8px',
                          color: colors.text.primary,
                          fontSize: '12px',
                        }}
                      />
                    </div>
                    
                    {/* Props */}
                    <div style={{ marginBottom: '20px' }}>
                      <label style={{ 
                        fontSize: '12px', 
                        fontWeight: '600', 
                        color: colors.text.secondary, 
                        display: 'block', 
                        marginBottom: '8px',
                        textTransform: 'uppercase',
                      }}>
                        Props (character is holding/using)
                      </label>
                      <div style={{ display: 'flex', flexWrap: 'wrap', gap: '8px', marginBottom: '8px' }}>
                        {sceneElementForm.propsElements.map((prop, idx) => (
                          <div
                            key={prop.id}
                            style={{
                              padding: '8px 12px',
                              background: 'linear-gradient(135deg, rgba(94, 234, 212, 0.2), rgba(45, 212, 191, 0.2))',
                              border: '2px solid #14b8a6',
                              borderRadius: '8px',
                              display: 'flex',
                              alignItems: 'center',
                              gap: '8px',
                            }}
                          >
                            <span style={{ fontSize: '12px', color: '#14b8a6' }}>{prop.name}</span>
                            <button
                              onClick={() => setSceneElementForm(prev => ({
                                ...prev,
                                propsElements: prev.propsElements.filter((_, i) => i !== idx),
                              }))}
                              style={{
                                background: 'none',
                                border: 'none',
                                color: '#14b8a6',
                                cursor: 'pointer',
                                padding: 0,
                                fontSize: '14px',
                              }}
                            >×</button>
                          </div>
                        ))}
                        <button
                          onClick={() => {
                            const availableProp = mockElementsLibrary.props.find(
                              p => !sceneElementForm.propsElements.some(ep => ep.id === p.id)
                            );
                            if (availableProp) {
                              setSceneElementForm(prev => ({
                                ...prev,
                                propsElements: [...prev.propsElements, availableProp],
                              }));
                            }
                          }}
                          style={{
                            padding: '8px 12px',
                            border: `2px dashed #f472b6`,
                            borderRadius: '8px',
                            background: 'transparent',
                            color: '#f472b6',
                            fontSize: '12px',
                            cursor: 'pointer',
                            display: 'flex',
                            alignItems: 'center',
                            gap: '6px',
                          }}
                        >
                          <Icons.Plus style={{ width: 12, height: 12 }} />
                          Add Prop
                        </button>
                      </div>
                      <input
                        type="text"
                        value={sceneElementForm.propsPrompt}
                        onChange={(e) => setSceneElementForm(prev => ({ ...prev, propsPrompt: e.target.value }))}
                        placeholder="Or describe props: e.g., holding a crumpled letter..."
                        style={{
                          width: '100%',
                          padding: '10px 12px',
                          background: colors.bg.tertiary,
                          border: `1px solid ${colors.border.default}`,
                          borderRadius: '8px',
                          color: colors.text.primary,
                          fontSize: '12px',
                        }}
                      />
                    </div>
                  </>
                )}
                
                {/* Non-character field: Status */}
                {sceneElementModalData.elementType !== 'cast' && sceneElementForm.selectedElement && (
                  <div style={{ marginBottom: '20px' }}>
                    <label style={{ 
                      fontSize: '12px', 
                      fontWeight: '600', 
                      color: colors.text.secondary, 
                      display: 'block', 
                      marginBottom: '8px',
                      textTransform: 'uppercase',
                    }}>
                      Status / Condition in Scene
                    </label>
                    <input
                      type="text"
                      value={sceneElementForm.status}
                      onChange={(e) => setSceneElementForm(prev => ({ ...prev, status: e.target.value }))}
                      placeholder={
                        sceneElementModalData.elementType === 'location' 
                          ? "e.g., crowded, dimly lit, raining outside, messy..."
                          : sceneElementModalData.elementType === 'props'
                          ? "e.g., damaged, glowing, open, bloodstained..."
                          : "e.g., busy, sparse, attentive..."
                      }
                      style={{
                        width: '100%',
                        padding: '12px 14px',
                        background: colors.bg.tertiary,
                        border: `1px solid ${colors.border.default}`,
                        borderRadius: '8px',
                        color: colors.text.primary,
                        fontSize: '13px',
                      }}
                    />
                    <p style={{ fontSize: '11px', color: colors.text.tertiary, marginTop: '6px' }}>
                      Describe how this {getElementTypeLabel(sceneElementModalData.elementType).toLowerCase()} appears specifically in this scene
                    </p>
                  </div>
                )}
              </div>
              
              {/* Modal Footer */}
              <div style={{
                padding: '16px 24px',
                borderTop: `1px solid ${colors.border.default}`,
                display: 'flex',
                justifyContent: 'flex-end',
                gap: '12px',
              }}>
                <Button variant="secondary" onClick={() => setShowSceneElementModal(false)}>
                  Cancel
                </Button>
                <Button 
                  onClick={() => {
                    // Would save the element assignment with context data
                    console.log('Saving element assignment:', {
                      sceneIdx: sceneElementModalData.sceneIdx,
                      elementType: sceneElementModalData.elementType,
                      element: sceneElementForm.selectedElement,
                      context: sceneElementModalData.elementType === 'cast' 
                        ? {
                            facialExpression: sceneElementForm.facialExpression,
                            tone: sceneElementForm.tone,
                            attitude: sceneElementForm.attitude,
                            wardrobeElement: sceneElementForm.wardrobeElement,
                            wardrobePrompt: sceneElementForm.wardrobePrompt,
                            propsElements: sceneElementForm.propsElements,
                            propsPrompt: sceneElementForm.propsPrompt,
                          }
                        : { status: sceneElementForm.status },
                    });
                    setShowSceneElementModal(false);
                    // In real implementation, would update scene data
                  }}
                  disabled={!sceneElementForm.selectedElement}
                  style={{
                    background: sceneElementForm.selectedElement 
                      ? 'linear-gradient(135deg, #14b8a6 0%, #0d9488 100%)'
                      : colors.bg.tertiary,
                  }}
                >
                  {sceneElementModalData.existingElement ? 'Update' : 'Add'} to Scene
                </Button>
              </div>
            </div>
          </div>
        )}
        <div style={{
          padding: '12px 24px',
          borderTop: `1px solid ${colors.border.default}`,
          background: colors.bg.secondary,
          display: 'flex',
          justifyContent: 'space-between',
          alignItems: 'center',
        }}>
          <Button variant="secondary" onClick={() => setActiveSection('script')}>
            <Icons.ChevronLeft style={{ width: 16, height: 16, marginRight: '6px' }} />
            Back to Script
          </Button>
          
          <div style={{ display: 'flex', gap: '12px' }}>
            <button style={{
              padding: '10px 20px',
              background: colors.bg.tertiary,
              border: `1px solid ${colors.border.default}`,
              borderRadius: '8px',
              color: colors.text.secondary,
              fontSize: '13px',
              cursor: 'pointer',
              display: 'flex',
              alignItems: 'center',
              gap: '8px',
            }}>
              Preview Storyboard
            </button>
            
            <Button 
              onClick={() => onNavigateToStoryboard(episode)}
              disabled={!canProceedToStoryboard}
            >
              Proceed to Storyboard
              <Icons.ChevronRight style={{ width: 16, height: 16, marginLeft: '6px' }} />
            </Button>
          </div>
        </div>
      </div>
    );
  };
  
  // ============================================================================
  // CHARACTER PROFILE MODAL
  // ============================================================================
  
  const renderCharacterModal = () => {
    if (!showCharacterModal || !selectedCharacter) return null;
    
    const char = selectedCharacter;
    const tabs = [
      { id: 'profile', label: '👤 Profile' },
      { id: 'personality', label: '💭 Personality' },
      { id: 'visuals', label: '🎨 Visuals' },
      { id: 'voice', label: '🎙️ Voice' },
    ];
    
    return (
      <div style={{
        position: 'fixed',
        top: 0,
        left: 0,
        right: 0,
        bottom: 0,
        background: 'rgba(0,0,0,0.85)',
        display: 'flex',
        alignItems: 'center',
        justifyContent: 'center',
        zIndex: 1000,
      }}>
        <div style={{
          width: '700px',
          maxHeight: '85vh',
          background: colors.bg.secondary,
          borderRadius: '16px',
          overflow: 'hidden',
          display: 'flex',
          flexDirection: 'column',
        }}>
          {/* Header */}
          <div style={{
            padding: '20px 24px',
            borderBottom: `1px solid ${colors.border.default}`,
            display: 'flex',
            alignItems: 'center',
            gap: '16px',
          }}>
            {/* Avatar */}
            <div style={{
              width: '64px',
              height: '64px',
              borderRadius: '50%',
              background: char.hasAvatar 
                ? 'linear-gradient(135deg, #667eea 0%, #764ba2 100%)'
                : colors.bg.tertiary,
              border: `3px solid ${char.hasAvatar ? '#10b981' : '#ef4444'}`,
              display: 'flex',
              alignItems: 'center',
              justifyContent: 'center',
              fontSize: '28px',
              position: 'relative',
            }}>
              👤
              {!char.hasAvatar && (
                <button
                  onClick={() => handleGenerateCharacterAvatar(char.id)}
                  disabled={isGeneratingAvatar}
                  style={{
                    position: 'absolute',
                    bottom: '-4px',
                    right: '-4px',
                    width: '24px',
                    height: '24px',
                    borderRadius: '50%',
                    background: colors.accent.primary,
                    border: '2px solid #1a1a1a',
                    color: '#fff',
                    fontSize: '12px',
                    cursor: 'pointer',
                    display: 'flex',
                    alignItems: 'center',
                    justifyContent: 'center',
                  }}
                >
                  {isGeneratingAvatar ? '...' : '✨'}
                </button>
              )}
            </div>
            
            {/* Name & Role */}
            <div style={{ flex: 1 }}>
              <input
                type="text"
                value={char.name}
                onChange={(e) => updateCharacter(char.id, { name: e.target.value })}
                style={{
                  fontSize: '20px',
                  fontWeight: '600',
                  background: 'none',
                  border: 'none',
                  borderBottom: `1px solid ${colors.border.default}`,
                  color: colors.text.primary,
                  width: '100%',
                  paddingBottom: '4px',
                }}
              />
              <div style={{ display: 'flex', alignItems: 'center', gap: '8px', marginTop: '6px' }}>
                <select
                  value={char.role}
                  onChange={(e) => updateCharacter(char.id, { role: e.target.value })}
                  style={{
                    padding: '4px 8px',
                    background: colors.bg.tertiary,
                    border: `1px solid ${colors.border.default}`,
                    borderRadius: '4px',
                    color: colors.text.primary,
                    fontSize: '12px',
                  }}
                >
                  <option value="lead">⭐ Lead</option>
                  <option value="supporting">👥 Supporting</option>
                  <option value="background">🎭 Background</option>
                </select>
                <span style={{ fontSize: '12px', color: colors.text.tertiary }}>
                  Appears in {char.sceneAppearances?.length || 0} scenes
                </span>
              </div>
            </div>
            
            {/* Close */}
            <button
              onClick={() => setShowCharacterModal(false)}
              style={{
                padding: '8px',
                background: 'none',
                border: 'none',
                color: colors.text.secondary,
                cursor: 'pointer',
                fontSize: '20px',
              }}
            >×</button>
          </div>
          
          {/* Tabs */}
          <div style={{
            display: 'flex',
            borderBottom: `1px solid ${colors.border.default}`,
            padding: '0 24px',
          }}>
            {tabs.map(tab => (
              <button
                key={tab.id}
                onClick={() => setCharacterModalTab(tab.id)}
                style={{
                  padding: '12px 20px',
                  background: 'none',
                  border: 'none',
                  borderBottom: characterModalTab === tab.id ? `2px solid ${colors.accent.primary}` : '2px solid transparent',
                  color: characterModalTab === tab.id ? colors.text.primary : colors.text.secondary,
                  fontSize: '13px',
                  fontWeight: characterModalTab === tab.id ? '600' : '400',
                  cursor: 'pointer',
                }}
              >
                {tab.label}
              </button>
            ))}
          </div>
          
          {/* Content */}
          <div style={{ flex: 1, overflow: 'auto', padding: '24px' }}>
            {/* Profile Tab */}
            {characterModalTab === 'profile' && (
              <div style={{ display: 'grid', gridTemplateColumns: '1fr 1fr', gap: '16px' }}>
                <div>
                  <label style={{ fontSize: '12px', color: colors.text.tertiary, display: 'block', marginBottom: '6px' }}>Age Range</label>
                  <select
                    value={char.ageRange || ''}
                    onChange={(e) => updateCharacter(char.id, { ageRange: e.target.value })}
                    style={{
                      width: '100%',
                      padding: '10px 12px',
                      background: colors.bg.tertiary,
                      border: `1px solid ${colors.border.default}`,
                      borderRadius: '8px',
                      color: colors.text.primary,
                      fontSize: '13px',
                    }}
                  >
                    <option value="">Select age range</option>
                    <option value="Child (0-12)">Child (0-12)</option>
                    <option value="Teen (13-19)">Teen (13-19)</option>
                    <option value="20s">20s</option>
                    <option value="30s">30s</option>
                    <option value="40-50">40-50</option>
                    <option value="50-60">50-60</option>
                    <option value="60+">60+</option>
                  </select>
                </div>
                
                <div>
                  <label style={{ fontSize: '12px', color: colors.text.tertiary, display: 'block', marginBottom: '6px' }}>Gender</label>
                  <input
                    type="text"
                    value={char.gender || ''}
                    onChange={(e) => updateCharacter(char.id, { gender: e.target.value })}
                    placeholder="e.g., Male, Female, Non-binary"
                    style={{
                      width: '100%',
                      padding: '10px 12px',
                      background: colors.bg.tertiary,
                      border: `1px solid ${colors.border.default}`,
                      borderRadius: '8px',
                      color: colors.text.primary,
                      fontSize: '13px',
                    }}
                  />
                </div>
                
                <div>
                  <label style={{ fontSize: '12px', color: colors.text.tertiary, display: 'block', marginBottom: '6px' }}>Ethnicity / Background</label>
                  <input
                    type="text"
                    value={char.ethnicity || ''}
                    onChange={(e) => updateCharacter(char.id, { ethnicity: e.target.value })}
                    placeholder="e.g., East Asian, Latino, etc."
                    style={{
                      width: '100%',
                      padding: '10px 12px',
                      background: colors.bg.tertiary,
                      border: `1px solid ${colors.border.default}`,
                      borderRadius: '8px',
                      color: colors.text.primary,
                      fontSize: '13px',
                    }}
                  />
                </div>
                
                <div>
                  <label style={{ fontSize: '12px', color: colors.text.tertiary, display: 'block', marginBottom: '6px' }}>Nickname</label>
                  <input
                    type="text"
                    value={char.nickname || ''}
                    onChange={(e) => updateCharacter(char.id, { nickname: e.target.value })}
                    placeholder="Optional nickname"
                    style={{
                      width: '100%',
                      padding: '10px 12px',
                      background: colors.bg.tertiary,
                      border: `1px solid ${colors.border.default}`,
                      borderRadius: '8px',
                      color: colors.text.primary,
                      fontSize: '13px',
                    }}
                  />
                </div>
                
                <div style={{ gridColumn: '1 / -1' }}>
                  <label style={{ fontSize: '12px', color: colors.text.tertiary, display: 'block', marginBottom: '6px' }}>Physical Description</label>
                  <textarea
                    value={char.physicalDescription || ''}
                    onChange={(e) => updateCharacter(char.id, { physicalDescription: e.target.value })}
                    placeholder="Describe physical appearance..."
                    style={{
                      width: '100%',
                      padding: '10px 12px',
                      background: colors.bg.tertiary,
                      border: `1px solid ${colors.border.default}`,
                      borderRadius: '8px',
                      color: colors.text.primary,
                      fontSize: '13px',
                      minHeight: '80px',
                      resize: 'vertical',
                    }}
                  />
                </div>
                
                <div style={{ gridColumn: '1 / -1' }}>
                  <label style={{ fontSize: '12px', color: colors.text.tertiary, display: 'block', marginBottom: '6px' }}>Signature Look / Style</label>
                  <textarea
                    value={char.signatureLook || ''}
                    onChange={(e) => updateCharacter(char.id, { signatureLook: e.target.value })}
                    placeholder="Describe their typical clothing and style..."
                    style={{
                      width: '100%',
                      padding: '10px 12px',
                      background: colors.bg.tertiary,
                      border: `1px solid ${colors.border.default}`,
                      borderRadius: '8px',
                      color: colors.text.primary,
                      fontSize: '13px',
                      minHeight: '60px',
                      resize: 'vertical',
                    }}
                  />
                </div>
              </div>
            )}
            
            {/* Personality Tab */}
            {characterModalTab === 'personality' && (
              <div>
                <div style={{ marginBottom: '20px' }}>
                  <label style={{ fontSize: '12px', color: colors.text.tertiary, display: 'block', marginBottom: '6px' }}>Character Traits</label>
                  <div style={{ display: 'flex', flexWrap: 'wrap', gap: '8px', marginBottom: '8px' }}>
                    {(char.traits || []).map((trait, idx) => (
                      <span key={idx} style={{
                        padding: '4px 12px',
                        background: 'rgba(139,92,246,0.2)',
                        borderRadius: '12px',
                        fontSize: '12px',
                        color: colors.accent.primary,
                        display: 'flex',
                        alignItems: 'center',
                        gap: '6px',
                      }}>
                        {trait}
                        <button
                          onClick={() => {
                            const newTraits = char.traits.filter((_, i) => i !== idx);
                            updateCharacter(char.id, { traits: newTraits });
                          }}
                          style={{ background: 'none', border: 'none', color: colors.accent.primary, cursor: 'pointer', fontSize: '14px' }}
                        >×</button>
                      </span>
                    ))}
                  </div>
                  <input
                    type="text"
                    placeholder="Add trait (press Enter)"
                    onKeyDown={(e) => {
                      if (e.key === 'Enter' && e.target.value.trim()) {
                        updateCharacter(char.id, { traits: [...(char.traits || []), e.target.value.trim()] });
                        e.target.value = '';
                      }
                    }}
                    style={{
                      width: '100%',
                      padding: '10px 12px',
                      background: colors.bg.tertiary,
                      border: `1px solid ${colors.border.default}`,
                      borderRadius: '8px',
                      color: colors.text.primary,
                      fontSize: '13px',
                    }}
                  />
                </div>
                
                <div style={{ marginBottom: '20px' }}>
                  <label style={{ fontSize: '12px', color: colors.text.tertiary, display: 'block', marginBottom: '6px' }}>Motivation / Goal</label>
                  <textarea
                    value={char.motivation || ''}
                    onChange={(e) => updateCharacter(char.id, { motivation: e.target.value })}
                    placeholder="What drives this character?"
                    style={{
                      width: '100%',
                      padding: '10px 12px',
                      background: colors.bg.tertiary,
                      border: `1px solid ${colors.border.default}`,
                      borderRadius: '8px',
                      color: colors.text.primary,
                      fontSize: '13px',
                      minHeight: '70px',
                      resize: 'vertical',
                    }}
                  />
                </div>
                
                <div style={{ marginBottom: '20px' }}>
                  <label style={{ fontSize: '12px', color: colors.text.tertiary, display: 'block', marginBottom: '6px' }}>Speech Pattern</label>
                  <input
                    type="text"
                    value={char.speechPattern || ''}
                    onChange={(e) => updateCharacter(char.id, { speechPattern: e.target.value })}
                    placeholder="How do they speak?"
                    style={{
                      width: '100%',
                      padding: '10px 12px',
                      background: colors.bg.tertiary,
                      border: `1px solid ${colors.border.default}`,
                      borderRadius: '8px',
                      color: colors.text.primary,
                      fontSize: '13px',
                    }}
                  />
                </div>
              </div>
            )}
            
            {/* Visuals Tab */}
            {characterModalTab === 'visuals' && (
              <div>
                <div style={{ marginBottom: '24px' }}>
                  <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center', marginBottom: '12px' }}>
                    <label style={{ fontSize: '14px', fontWeight: '600' }}>Generated Avatars</label>
                    <button
                      onClick={() => handleGenerateCharacterAvatar(char.id)}
                      disabled={isGeneratingAvatar}
                      style={{
                        padding: '8px 16px',
                        background: 'linear-gradient(135deg, #8b5cf6 0%, #ec4899 100%)',
                        border: 'none',
                        borderRadius: '8px',
                        color: '#fff',
                        fontSize: '12px',
                        cursor: isGeneratingAvatar ? 'not-allowed' : 'pointer',
                        display: 'flex',
                        alignItems: 'center',
                        gap: '6px',
                      }}
                    >
                      {isGeneratingAvatar ? 'Generating...' : '✨ Generate Avatar'}
                    </button>
                  </div>
                  
                  <div style={{ display: 'grid', gridTemplateColumns: 'repeat(4, 1fr)', gap: '12px' }}>
                    {(char.generatedAvatars || []).map((avatar, idx) => (
                      <div key={avatar.id} style={{
                        aspectRatio: '1',
                        borderRadius: '12px',
                        background: 'linear-gradient(135deg, #667eea 0%, #764ba2 100%)',
                        border: avatar.isSelected ? `3px solid #10b981` : `2px solid ${colors.border.default}`,
                        display: 'flex',
                        alignItems: 'center',
                        justifyContent: 'center',
                        fontSize: '32px',
                        cursor: 'pointer',
                        position: 'relative',
                      }}>
                        👤
                        {avatar.isSelected && (
                          <div style={{
                            position: 'absolute',
                            top: '4px',
                            right: '4px',
                            background: '#10b981',
                            borderRadius: '50%',
                            width: '20px',
                            height: '20px',
                            display: 'flex',
                            alignItems: 'center',
                            justifyContent: 'center',
                            fontSize: '12px',
                            color: '#fff',
                          }}>✓</div>
                        )}
                      </div>
                    ))}
                    
                    {(!char.generatedAvatars || char.generatedAvatars.length === 0) && (
                      <div style={{
                        gridColumn: '1 / -1',
                        padding: '40px',
                        textAlign: 'center',
                        color: colors.text.tertiary,
                        background: colors.bg.tertiary,
                        borderRadius: '12px',
                      }}>
                        No avatars generated yet. Click "Generate Avatar" to create one.
                      </div>
                    )}
                  </div>
                </div>
                
                <div>
                  <label style={{ fontSize: '12px', color: colors.text.tertiary, display: 'block', marginBottom: '6px' }}>Generation Prompt</label>
                  <textarea
                    value={generateAvatarPrompt(char)}
                    readOnly
                    style={{
                      width: '100%',
                      padding: '10px 12px',
                      background: colors.bg.tertiary,
                      border: `1px solid ${colors.border.default}`,
                      borderRadius: '8px',
                      color: colors.text.secondary,
                      fontSize: '12px',
                      minHeight: '80px',
                      resize: 'none',
                    }}
                  />
                </div>
              </div>
            )}
            
            {/* Voice Tab */}
            {characterModalTab === 'voice' && (
              <div>
                <div style={{ marginBottom: '20px' }}>
                  <label style={{ fontSize: '12px', color: colors.text.tertiary, display: 'block', marginBottom: '6px' }}>Voice Type</label>
                  <select
                    value={char.voiceType || ''}
                    onChange={(e) => updateCharacter(char.id, { voiceType: e.target.value })}
                    style={{
                      width: '100%',
                      padding: '10px 12px',
                      background: colors.bg.tertiary,
                      border: `1px solid ${colors.border.default}`,
                      borderRadius: '8px',
                      color: colors.text.primary,
                      fontSize: '13px',
                    }}
                  >
                    <option value="">Select voice type</option>
                    <option value="Deep, gravelly">Deep, gravelly</option>
                    <option value="Deep, smooth">Deep, smooth</option>
                    <option value="Medium, clear">Medium, clear</option>
                    <option value="High, bright">High, bright</option>
                    <option value="Soft, gentle">Soft, gentle</option>
                    <option value="Raspy, worn">Raspy, worn</option>
                    <option value="Energetic, youthful">Energetic, youthful</option>
                  </select>
                </div>
                
                <div style={{ marginBottom: '20px' }}>
                  <label style={{ fontSize: '12px', color: colors.text.tertiary, display: 'block', marginBottom: '6px' }}>Accent</label>
                  <input
                    type="text"
                    value={char.accent || ''}
                    onChange={(e) => updateCharacter(char.id, { accent: e.target.value })}
                    placeholder="e.g., Slight New York accent"
                    style={{
                      width: '100%',
                      padding: '10px 12px',
                      background: colors.bg.tertiary,
                      border: `1px solid ${colors.border.default}`,
                      borderRadius: '8px',
                      color: colors.text.primary,
                      fontSize: '13px',
                    }}
                  />
                </div>
                
                <div style={{
                  padding: '24px',
                  background: colors.bg.tertiary,
                  borderRadius: '12px',
                  textAlign: 'center',
                }}>
                  <div style={{ fontSize: '32px', marginBottom: '8px' }}>🎙️</div>
                  <div style={{ fontSize: '14px', color: colors.text.secondary }}>Voice Generation</div>
                  <div style={{ fontSize: '12px', color: colors.text.tertiary }}>Coming soon</div>
                </div>
              </div>
            )}
          </div>
          
          {/* Footer */}
          <div style={{
            padding: '16px 24px',
            borderTop: `1px solid ${colors.border.default}`,
            display: 'flex',
            justifyContent: 'space-between',
          }}>
            {/* Character navigation */}
            <div style={{ display: 'flex', gap: '8px' }}>
              {characters.map((c, idx) => (
                <button
                  key={c.id}
                  onClick={() => setSelectedCharacter(c)}
                  style={{
                    width: '32px',
                    height: '32px',
                    borderRadius: '50%',
                    background: c.id === char.id ? colors.accent.primary : colors.bg.tertiary,
                    border: `2px solid ${c.hasAvatar ? '#10b981' : '#ef4444'}`,
                    color: c.id === char.id ? '#fff' : colors.text.secondary,
                    cursor: 'pointer',
                    fontSize: '12px',
                  }}
                >
                  {idx + 1}
                </button>
              ))}
            </div>
            
            <Button onClick={() => setShowCharacterModal(false)}>
              Done
            </Button>
          </div>
        </div>
      </div>
    );
  };
  
  // ============================================================================
  // EXPORT FUNCTIONS
  // ============================================================================
  
  const exportStoryboardPDF = () => {
    const scenes = episode?.scenes || [];
    let content = `STORYBOARD: ${project?.title || 'Untitled'}\n`;
    content += `Episode: ${episode?.title || 'Untitled Episode'}\n`;
    content += `Generated: ${new Date().toLocaleDateString()}\n`;
    content += `${'='.repeat(50)}\n\n`;
    
    scenes.forEach((scene, sIdx) => {
      content += `SCENE ${sIdx + 1}: ${scene.location || 'Unknown Location'}\n`;
      content += `Time: ${scene.timeOfDay || 'Day'}\n`;
      content += `Description: ${scene.description || 'No description'}\n`;
      content += `-`.repeat(40) + '\n';
      
      (scene.shots || []).forEach((shot, shIdx) => {
        content += `  Shot ${sIdx + 1}.${shIdx + 1}\n`;
        content += `    Type: ${shot.type || 'medium'}\n`;
        content += `    Duration: ${shot.duration || 5}s\n`;
        content += `    Description: ${shot.description || 'No description'}\n`;
        content += `    Prompt: ${shot.prompt || 'No prompt'}\n\n`;
      });
      content += '\n';
    });
    
    // Create and download file
    const blob = new Blob([content], { type: 'text/plain' });
    const url = URL.createObjectURL(blob);
    const a = document.createElement('a');
    a.href = url;
    a.download = `${project?.title || 'storyboard'}_storyboard.txt`;
    document.body.appendChild(a);
    a.click();
    document.body.removeChild(a);
    URL.revokeObjectURL(url);
    setShowExportMenu(false);
  };
  
  const exportShotListCSV = () => {
    const scenes = episode?.scenes || [];
    let csv = 'Scene,Shot,Type,Duration,Location,Time of Day,Description,Prompt,Characters\n';
    
    scenes.forEach((scene, sIdx) => {
      (scene.shots || []).forEach((shot, shIdx) => {
        const row = [
          sIdx + 1,
          `${sIdx + 1}.${shIdx + 1}`,
          shot.type || 'medium',
          shot.duration || 5,
          `"${(scene.location || '').replace(/"/g, '""')}"`,
          scene.timeOfDay || 'Day',
          `"${(shot.description || '').replace(/"/g, '""')}"`,
          `"${(shot.prompt || '').replace(/"/g, '""')}"`,
          `"${(scene.characters || []).map(c => c.name).join(', ')}"`,
        ];
        csv += row.join(',') + '\n';
      });
    });
    
    const blob = new Blob([csv], { type: 'text/csv' });
    const url = URL.createObjectURL(blob);
    const a = document.createElement('a');
    a.href = url;
    a.download = `${project?.title || 'shotlist'}_shots.csv`;
    document.body.appendChild(a);
    a.click();
    document.body.removeChild(a);
    URL.revokeObjectURL(url);
    setShowExportMenu(false);
  };
  
  const exportScriptTXT = () => {
    let content = `SCRIPT: ${project?.title || 'Untitled'}\n`;
    content += `Episode: ${episode?.title || 'Untitled Episode'}\n`;
    content += `${'='.repeat(50)}\n\n`;
    content += episode?.script || scriptContent || 'No script content';
    
    const blob = new Blob([content], { type: 'text/plain' });
    const url = URL.createObjectURL(blob);
    const a = document.createElement('a');
    a.href = url;
    a.download = `${project?.title || 'script'}_script.txt`;
    document.body.appendChild(a);
    a.click();
    document.body.removeChild(a);
    URL.revokeObjectURL(url);
    setShowExportMenu(false);
  };
  
  const exportProjectJSON = () => {
    const data = {
      project: {
        title: project?.title,
        type: project?.projectType,
        genre: project?.genre,
        logline: project?.logline,
      },
      episode: {
        title: episode?.title,
        script: episode?.script || scriptContent,
        scenes: episode?.scenes || [],
        characters: characters,
      },
      exportedAt: new Date().toISOString(),
    };
    
    const blob = new Blob([JSON.stringify(data, null, 2)], { type: 'application/json' });
    const url = URL.createObjectURL(blob);
    const a = document.createElement('a');
    a.href = url;
    a.download = `${project?.title || 'project'}_data.json`;
    document.body.appendChild(a);
    a.click();
    document.body.removeChild(a);
    URL.revokeObjectURL(url);
    setShowExportMenu(false);
  };
  
  // ============================================================================
  // COLLABORATION FUNCTIONS
  // ============================================================================
  
  const generateShareLink = () => {
    const link = `https://thebasement.app/share/${project?.id || 'demo'}?token=${Date.now().toString(36)}`;
    setShareLink(link);
    setShowShareModal(true);
  };
  
  const copyShareLink = () => {
    navigator.clipboard.writeText(shareLink).then(() => {
      alert('Link copied to clipboard!');
    });
  };
  
  const addComment = () => {
    if (!newComment.trim()) return;
    const comment = {
      id: Date.now(),
      user: 'You',
      avatar: '🧑',
      text: newComment,
      timestamp: new Date(),
      sceneId: episode?.scenes?.[0]?.id || 'general',
    };
    setComments(prev => [comment, ...prev]);
    setNewComment('');
  };
  
  const formatTimeAgo = (date) => {
    const now = new Date();
    const diffMs = now - new Date(date);
    const diffMins = Math.floor(diffMs / 60000);
    const diffHours = Math.floor(diffMs / 3600000);
    const diffDays = Math.floor(diffMs / 86400000);
    
    if (diffMins < 1) return 'Just now';
    if (diffMins < 60) return `${diffMins}m ago`;
    if (diffHours < 24) return `${diffHours}h ago`;
    if (diffDays < 7) return `${diffDays}d ago`;
    return new Date(date).toLocaleDateString();
  };
  
  // ============================================================================
  // MAIN RENDER
  // ============================================================================
  
  return (
    <div style={{ flex: 1, display: 'flex', flexDirection: 'column', overflow: 'hidden' }}>
      {/* Project Header Bar */}
      <div style={{
        padding: '16px 24px',
        borderBottom: `1px solid ${colors.border.subtle}`,
        background: colors.bg.secondary,
        display: 'flex',
        alignItems: 'center',
        justifyContent: 'space-between',
      }}>
        <div style={{ display: 'flex', alignItems: 'center', gap: '16px' }}>
          <div style={{
            width: '48px',
            height: '48px',
            borderRadius: '12px',
            background: project?.coverGradient || 'linear-gradient(135deg, #667eea 0%, #764ba2 100%)',
            display: 'flex',
            alignItems: 'center',
            justifyContent: 'center',
            fontSize: '24px',
          }}>
            {project?.projectType === 'series' ? '📺' : project?.projectType === 'film' ? '🎥' : '🎬'}
          </div>
          <div>
            <h1 style={{ fontSize: '20px', fontWeight: '700', marginBottom: '2px' }}>
              {project?.title || 'Untitled Project'}
            </h1>
            <div style={{ fontSize: '13px', color: colors.text.secondary, display: 'flex', alignItems: 'center', gap: '8px' }}>
              <span style={{ textTransform: 'capitalize' }}>{project?.projectType || 'Project'}</span>
              <span>•</span>
              <span>{project?.genre || 'No genre'}</span>
              {project?.filmStyle && (
                <>
                  <span>•</span>
                  <span>{project?.filmStyle}</span>
                </>
              )}
            </div>
          </div>
        </div>
        
        <button
          onClick={onEditProjectSetup}
          style={{
            display: 'flex',
            alignItems: 'center',
            gap: '8px',
            padding: '10px 16px',
            background: colors.bg.tertiary,
            border: `1px solid ${colors.border.default}`,
            borderRadius: '8px',
            color: colors.text.secondary,
            fontSize: '13px',
            fontWeight: '500',
            cursor: 'pointer',
            transition: 'all 0.2s',
          }}
          onMouseEnter={(e) => {
            e.currentTarget.style.background = colors.bg.hover;
            e.currentTarget.style.color = colors.text.primary;
          }}
          onMouseLeave={(e) => {
            e.currentTarget.style.background = colors.bg.tertiary;
            e.currentTarget.style.color = colors.text.secondary;
          }}
        >
          <Icons.Settings style={{ width: 16, height: 16 }} />
          Edit Project Setup
        </button>
      </div>
      
      {/* Top Navigation Tabs */}
      <div style={{
        padding: '0 24px',
        borderBottom: `1px solid ${colors.border.default}`,
        background: colors.bg.secondary,
        display: 'flex',
        alignItems: 'center',
        justifyContent: 'space-between',
      }}>
        <div style={{ display: 'flex' }}>
          {sections.map((section) => (
            <button
              key={section.id}
              onClick={() => setActiveSection(section.id)}
              style={{
                padding: '16px 24px',
                background: 'none',
                border: 'none',
                borderBottom: activeSection === section.id ? `3px solid ${colors.accent.primary}` : '3px solid transparent',
                color: activeSection === section.id ? colors.text.primary : colors.text.secondary,
                fontSize: '14px',
                fontWeight: activeSection === section.id ? '600' : '400',
                cursor: 'pointer',
                display: 'flex',
                alignItems: 'center',
                gap: '8px',
                transition: 'all 0.2s',
              }}
            >
              <span>{section.icon}</span>
              {section.label}
            </button>
          ))}
        </div>
        
        <div style={{ display: 'flex', alignItems: 'center', gap: '12px' }}>
          {/* Collaboration Buttons */}
          <button
            onClick={() => setShowCommentsPanel(!showCommentsPanel)}
            style={{
              padding: '10px',
              background: showCommentsPanel ? `${colors.accent.primary}20` : colors.bg.tertiary,
              border: `1px solid ${showCommentsPanel ? colors.accent.primary : colors.border.default}`,
              borderRadius: '8px',
              color: showCommentsPanel ? colors.accent.primary : colors.text.secondary,
              cursor: 'pointer',
              display: 'flex',
              alignItems: 'center',
              justifyContent: 'center',
              position: 'relative',
            }}
            title="Comments"
          >
            <Icons.MessageCircle style={{ width: 18, height: 18 }} />
            {comments.length > 0 && (
              <span style={{
                position: 'absolute',
                top: '-4px',
                right: '-4px',
                width: '16px',
                height: '16px',
                background: colors.accent.error,
                borderRadius: '50%',
                fontSize: '10px',
                fontWeight: '600',
                color: 'white',
                display: 'flex',
                alignItems: 'center',
                justifyContent: 'center',
              }}>
                {comments.length}
              </span>
            )}
          </button>
          
          <button
            onClick={() => setShowVersionHistory(!showVersionHistory)}
            style={{
              padding: '10px',
              background: showVersionHistory ? `${colors.accent.primary}20` : colors.bg.tertiary,
              border: `1px solid ${showVersionHistory ? colors.accent.primary : colors.border.default}`,
              borderRadius: '8px',
              color: showVersionHistory ? colors.accent.primary : colors.text.secondary,
              cursor: 'pointer',
              display: 'flex',
              alignItems: 'center',
              justifyContent: 'center',
            }}
            title="Version History"
          >
            <Icons.History style={{ width: 18, height: 18 }} />
          </button>
          
          <button
            onClick={generateShareLink}
            style={{
              padding: '10px 16px',
              background: colors.bg.tertiary,
              border: `1px solid ${colors.border.default}`,
              borderRadius: '8px',
              color: colors.text.secondary,
              fontSize: '14px',
              cursor: 'pointer',
              display: 'flex',
              alignItems: 'center',
              gap: '8px',
            }}
          >
            <Icons.Share style={{ width: 16, height: 16 }} />
            Share
          </button>
          
          {/* Export Button */}
          <div style={{ position: 'relative' }}>
            <button
              onClick={() => setShowExportMenu(!showExportMenu)}
              style={{
                padding: '10px 16px',
                background: colors.bg.tertiary,
                border: `1px solid ${colors.border.default}`,
                borderRadius: '8px',
                color: colors.text.secondary,
                fontSize: '14px',
                cursor: 'pointer',
                display: 'flex',
                alignItems: 'center',
                gap: '8px',
              }}
            >
              <Icons.Download style={{ width: 16, height: 16 }} />
              Export
              <Icons.ChevronDown style={{ width: 14, height: 14 }} />
            </button>
            
            {showExportMenu && (
              <div style={{
                position: 'absolute',
                top: '100%',
                right: 0,
                marginTop: '4px',
                width: '220px',
                background: colors.bg.secondary,
                border: `1px solid ${colors.border.default}`,
                borderRadius: '10px',
                boxShadow: '0 8px 24px rgba(0,0,0,0.3)',
                overflow: 'hidden',
                zIndex: 100,
              }}>
                <div style={{ padding: '8px 12px', borderBottom: `1px solid ${colors.border.subtle}`, fontSize: '11px', color: colors.text.tertiary, fontWeight: '600', textTransform: 'uppercase' }}>
                  Export Options
                </div>
                <button
                  onClick={exportStoryboardPDF}
                  style={{
                    width: '100%',
                    padding: '12px 16px',
                    background: 'transparent',
                    border: 'none',
                    color: colors.text.primary,
                    fontSize: '13px',
                    cursor: 'pointer',
                    textAlign: 'left',
                    display: 'flex',
                    alignItems: 'center',
                    gap: '10px',
                  }}
                  onMouseEnter={(e) => e.currentTarget.style.background = colors.bg.tertiary}
                  onMouseLeave={(e) => e.currentTarget.style.background = 'transparent'}
                >
                  <span style={{ fontSize: '16px' }}>📄</span>
                  <div>
                    <div style={{ fontWeight: '500' }}>Storyboard (TXT)</div>
                    <div style={{ fontSize: '11px', color: colors.text.tertiary }}>Scenes & shots breakdown</div>
                  </div>
                </button>
                <button
                  onClick={exportShotListCSV}
                  style={{
                    width: '100%',
                    padding: '12px 16px',
                    background: 'transparent',
                    border: 'none',
                    color: colors.text.primary,
                    fontSize: '13px',
                    cursor: 'pointer',
                    textAlign: 'left',
                    display: 'flex',
                    alignItems: 'center',
                    gap: '10px',
                  }}
                  onMouseEnter={(e) => e.currentTarget.style.background = colors.bg.tertiary}
                  onMouseLeave={(e) => e.currentTarget.style.background = 'transparent'}
                >
                  <span style={{ fontSize: '16px' }}>📊</span>
                  <div>
                    <div style={{ fontWeight: '500' }}>Shot List (CSV)</div>
                    <div style={{ fontSize: '11px', color: colors.text.tertiary }}>Spreadsheet format</div>
                  </div>
                </button>
                <button
                  onClick={exportScriptTXT}
                  style={{
                    width: '100%',
                    padding: '12px 16px',
                    background: 'transparent',
                    border: 'none',
                    color: colors.text.primary,
                    fontSize: '13px',
                    cursor: 'pointer',
                    textAlign: 'left',
                    display: 'flex',
                    alignItems: 'center',
                    gap: '10px',
                  }}
                  onMouseEnter={(e) => e.currentTarget.style.background = colors.bg.tertiary}
                  onMouseLeave={(e) => e.currentTarget.style.background = 'transparent'}
                >
                  <span style={{ fontSize: '16px' }}>📝</span>
                  <div>
                    <div style={{ fontWeight: '500' }}>Script (TXT)</div>
                    <div style={{ fontSize: '11px', color: colors.text.tertiary }}>Full script text</div>
                  </div>
                </button>
                <div style={{ height: '1px', background: colors.border.subtle }} />
                <button
                  onClick={exportProjectJSON}
                  style={{
                    width: '100%',
                    padding: '12px 16px',
                    background: 'transparent',
                    border: 'none',
                    color: colors.text.primary,
                    fontSize: '13px',
                    cursor: 'pointer',
                    textAlign: 'left',
                    display: 'flex',
                    alignItems: 'center',
                    gap: '10px',
                  }}
                  onMouseEnter={(e) => e.currentTarget.style.background = colors.bg.tertiary}
                  onMouseLeave={(e) => e.currentTarget.style.background = 'transparent'}
                >
                  <span style={{ fontSize: '16px' }}>💾</span>
                  <div>
                    <div style={{ fontWeight: '500' }}>Project Data (JSON)</div>
                    <div style={{ fontSize: '11px', color: colors.text.tertiary }}>Full project backup</div>
                  </div>
                </button>
              </div>
            )}
          </div>
          
          <Button 
            onClick={() => onNavigateToStoryboard(episode)}
            disabled={!canProceedToStoryboard}
            style={{ opacity: canProceedToStoryboard ? 1 : 0.5 }}
          >
            Proceed to Storyboard
            <Icons.ChevronRight style={{ width: 16, height: 16, marginLeft: '6px' }} />
          </Button>
        </div>
      </div>
      
      {/* Content */}
      <div style={{ flex: 1, overflow: 'auto', background: colors.bg.primary }}>
        {activeSection === 'details' && renderDetailsSection()}
        {activeSection === 'script' && renderScriptSection()}
        {activeSection === 'scenes-cast' && renderScenesCastSection()}
      </div>
      
      {/* Character Profile Modal */}
      {renderCharacterModal()}
      
      {/* Share Modal */}
      {showShareModal && (
        <div style={{ position: 'fixed', top: 0, left: 0, right: 0, bottom: 0, background: 'rgba(0,0,0,0.85)', display: 'flex', alignItems: 'center', justifyContent: 'center', zIndex: 1000 }}>
          <div style={{ width: '450px', background: colors.bg.secondary, borderRadius: '16px', overflow: 'hidden' }}>
            <div style={{ padding: '20px 24px', borderBottom: `1px solid ${colors.border.subtle}`, display: 'flex', justifyContent: 'space-between', alignItems: 'center' }}>
              <h2 style={{ fontSize: '18px', fontWeight: '600', margin: 0 }}>Share Project</h2>
              <button onClick={() => setShowShareModal(false)} style={{ background: 'none', border: 'none', color: colors.text.tertiary, cursor: 'pointer', fontSize: '20px' }}>×</button>
            </div>
            <div style={{ padding: '24px' }}>
              <p style={{ fontSize: '14px', color: colors.text.secondary, marginBottom: '20px' }}>
                Share this link with collaborators to give them access to view and comment on your project.
              </p>
              <div style={{ display: 'flex', gap: '8px', marginBottom: '20px' }}>
                <input
                  type="text"
                  value={shareLink}
                  readOnly
                  style={{
                    flex: 1,
                    padding: '12px 14px',
                    background: colors.bg.tertiary,
                    border: `1px solid ${colors.border.default}`,
                    borderRadius: '8px',
                    color: colors.text.primary,
                    fontSize: '13px',
                  }}
                />
                <Button onClick={copyShareLink}>Copy</Button>
              </div>
              <div style={{ padding: '16px', background: colors.bg.tertiary, borderRadius: '10px', marginBottom: '20px' }}>
                <div style={{ fontSize: '13px', fontWeight: '600', marginBottom: '8px' }}>Access Permissions</div>
                <div style={{ display: 'flex', flexDirection: 'column', gap: '8px' }}>
                  {['Can view', 'Can comment', 'Can edit'].map((perm, i) => (
                    <label key={perm} style={{ display: 'flex', alignItems: 'center', gap: '8px', fontSize: '13px', color: colors.text.secondary }}>
                      <input type="radio" name="permission" defaultChecked={i === 1} />
                      {perm}
                    </label>
                  ))}
                </div>
              </div>
              <div style={{ fontSize: '12px', color: colors.text.tertiary }}>
                🔒 Link expires in 7 days. Only people with the link can access.
              </div>
            </div>
          </div>
        </div>
      )}
      
      {/* Comments Panel (Slide-in) */}
      {showCommentsPanel && (
        <div style={{
          position: 'fixed',
          top: 0,
          right: 0,
          bottom: 0,
          width: '360px',
          background: colors.bg.secondary,
          borderLeft: `1px solid ${colors.border.default}`,
          boxShadow: '-4px 0 20px rgba(0,0,0,0.3)',
          zIndex: 999,
          display: 'flex',
          flexDirection: 'column',
        }}>
          <div style={{ padding: '16px 20px', borderBottom: `1px solid ${colors.border.subtle}`, display: 'flex', justifyContent: 'space-between', alignItems: 'center' }}>
            <h3 style={{ fontSize: '16px', fontWeight: '600', margin: 0 }}>Comments</h3>
            <button onClick={() => setShowCommentsPanel(false)} style={{ background: 'none', border: 'none', color: colors.text.tertiary, cursor: 'pointer', fontSize: '20px' }}>×</button>
          </div>
          
          {/* Add Comment */}
          <div style={{ padding: '16px 20px', borderBottom: `1px solid ${colors.border.subtle}` }}>
            <textarea
              placeholder="Add a comment..."
              value={newComment}
              onChange={(e) => setNewComment(e.target.value)}
              style={{
                width: '100%',
                padding: '12px',
                background: colors.bg.tertiary,
                border: `1px solid ${colors.border.default}`,
                borderRadius: '8px',
                color: colors.text.primary,
                fontSize: '13px',
                resize: 'none',
                minHeight: '80px',
              }}
            />
            <div style={{ display: 'flex', justifyContent: 'flex-end', marginTop: '8px' }}>
              <Button onClick={addComment} disabled={!newComment.trim()}>
                Post Comment
              </Button>
            </div>
          </div>
          
          {/* Comments List */}
          <div style={{ flex: 1, overflow: 'auto', padding: '16px 20px' }}>
            {comments.map((comment) => (
              <div key={comment.id} style={{ marginBottom: '16px', paddingLeft: comment.isReply ? '24px' : 0 }}>
                <div style={{ display: 'flex', alignItems: 'flex-start', gap: '10px' }}>
                  <div style={{
                    width: '32px',
                    height: '32px',
                    borderRadius: '50%',
                    background: colors.bg.tertiary,
                    display: 'flex',
                    alignItems: 'center',
                    justifyContent: 'center',
                    fontSize: '16px',
                  }}>
                    {comment.avatar}
                  </div>
                  <div style={{ flex: 1 }}>
                    <div style={{ display: 'flex', alignItems: 'center', gap: '8px', marginBottom: '4px' }}>
                      <span style={{ fontSize: '13px', fontWeight: '600' }}>{comment.user}</span>
                      <span style={{ fontSize: '11px', color: colors.text.tertiary }}>{formatTimeAgo(comment.timestamp)}</span>
                    </div>
                    <p style={{ fontSize: '13px', color: colors.text.secondary, margin: 0, lineHeight: '1.5' }}>{comment.text}</p>
                    <button style={{ background: 'none', border: 'none', color: colors.text.tertiary, fontSize: '12px', cursor: 'pointer', marginTop: '6px', padding: 0 }}>
                      Reply
                    </button>
                  </div>
                </div>
              </div>
            ))}
          </div>
        </div>
      )}
      
      {/* Version History Panel (Slide-in) */}
      {showVersionHistory && (
        <div style={{
          position: 'fixed',
          top: 0,
          right: 0,
          bottom: 0,
          width: '360px',
          background: colors.bg.secondary,
          borderLeft: `1px solid ${colors.border.default}`,
          boxShadow: '-4px 0 20px rgba(0,0,0,0.3)',
          zIndex: 999,
          display: 'flex',
          flexDirection: 'column',
        }}>
          <div style={{ padding: '16px 20px', borderBottom: `1px solid ${colors.border.subtle}`, display: 'flex', justifyContent: 'space-between', alignItems: 'center' }}>
            <h3 style={{ fontSize: '16px', fontWeight: '600', margin: 0 }}>Version History</h3>
            <button onClick={() => setShowVersionHistory(false)} style={{ background: 'none', border: 'none', color: colors.text.tertiary, cursor: 'pointer', fontSize: '20px' }}>×</button>
          </div>
          
          <div style={{ flex: 1, overflow: 'auto' }}>
            {versionHistory.map((version, idx) => (
              <div
                key={version.id}
                style={{
                  padding: '16px 20px',
                  borderBottom: `1px solid ${colors.border.subtle}`,
                  cursor: 'pointer',
                  background: idx === 0 ? `${colors.accent.primary}10` : 'transparent',
                }}
                onMouseEnter={(e) => idx !== 0 && (e.currentTarget.style.background = colors.bg.tertiary)}
                onMouseLeave={(e) => idx !== 0 && (e.currentTarget.style.background = 'transparent')}
              >
                <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'flex-start', marginBottom: '6px' }}>
                  <div style={{ display: 'flex', alignItems: 'center', gap: '8px' }}>
                    <span style={{
                      padding: '2px 8px',
                      background: idx === 0 ? colors.accent.primary : colors.bg.tertiary,
                      color: idx === 0 ? 'white' : colors.text.secondary,
                      borderRadius: '4px',
                      fontSize: '12px',
                      fontWeight: '600',
                    }}>
                      v{version.version}
                    </span>
                    {idx === 0 && <span style={{ fontSize: '11px', color: colors.accent.primary }}>Current</span>}
                  </div>
                  <span style={{ fontSize: '11px', color: colors.text.tertiary }}>{formatTimeAgo(version.timestamp)}</span>
                </div>
                <div style={{ fontSize: '13px', color: colors.text.primary, marginBottom: '4px' }}>{version.changes}</div>
                <div style={{ fontSize: '12px', color: colors.text.tertiary }}>by {version.user}</div>
              </div>
            ))}
          </div>
          
          <div style={{ padding: '16px 20px', borderTop: `1px solid ${colors.border.subtle}` }}>
            <button style={{
              width: '100%',
              padding: '10px',
              background: colors.bg.tertiary,
              border: `1px solid ${colors.border.default}`,
              borderRadius: '8px',
              color: colors.text.secondary,
              fontSize: '13px',
              cursor: 'pointer',
            }}>
              Restore Selected Version
            </button>
          </div>
        </div>
      )}
      
      <style>{`
        @keyframes spin {
          to { transform: rotate(360deg); }
        }
      `}</style>
    </div>
  );
};
// CAST & CHARACTERS VIEW - Character profiles and avatar generation
// ============================================================================
const CastCharactersView = ({ project, episode, onUpdateProject, onBack, onProceedToStoryboard }) => {
  const [characters, setCharacters] = useState([]);
  const [selectedCharacter, setSelectedCharacter] = useState(null);
  const [showCreateModal, setShowCreateModal] = useState(false);
  const [activeTab, setActiveTab] = useState('profile');
  const [isExtracting, setIsExtracting] = useState(false);
  const [isGeneratingAvatar, setIsGeneratingAvatar] = useState(false);
  const [avatarPrompt, setAvatarPrompt] = useState('');
  const [showAvatarGenerator, setShowAvatarGenerator] = useState(false);
  
  // Character form state
  const [characterForm, setCharacterForm] = useState({
    name: '',
    nickname: '',
    role: 'supporting', // lead, supporting, background
    tags: [],
    // Profile tab
    ageRange: '',
    gender: '',
    ethnicity: '',
    physicalDescription: '',
    signatureLook: '',
    // Personality tab
    traits: [],
    motivation: '',
    fears: '',
    speechPattern: '',
    quirks: '',
    // Story tab
    backstory: '',
    arc: '',
    relationships: [],
    // Visuals tab
    referenceImages: [],
    generatedAvatars: [],
    visualNotes: '',
    // Voice tab
    voiceType: '',
    accent: '',
    voiceNotes: '',
  });
  
  // Initialize with extracted characters from episode
  React.useEffect(() => {
    if (episode?.characters && episode.characters.length > 0) {
      setCharacters(episode.characters);
      if (!selectedCharacter) {
        setSelectedCharacter(episode.characters[0]);
      }
    } else {
      // Demo characters for testing
      const demoCharacters = [
        {
          id: 'char-1',
          name: 'Marcus Chen',
          nickname: 'Marc',
          role: 'lead',
          tags: ['Detective', 'Veteran', 'Haunted'],
          ageRange: '40-50',
          gender: 'Male',
          ethnicity: 'East Asian',
          physicalDescription: 'Tall, lean build with graying temples. Sharp eyes that miss nothing. A small scar above his left eyebrow.',
          signatureLook: 'Always wears a worn leather jacket over a white shirt. Never without his father\'s vintage watch.',
          traits: ['Determined', 'Observant', 'Guarded'],
          motivation: 'To solve the case that destroyed his partner',
          fears: 'Failure, losing someone else he cares about',
          speechPattern: 'Short, clipped sentences. Rarely wastes words.',
          quirks: 'Taps his watch when thinking',
          backstory: 'Former homicide detective who left the force after a case went wrong...',
          arc: 'From isolated loner to trusting partner',
          relationships: [{ characterId: 'char-2', relationship: 'Reluctant partner' }],
          referenceImages: [],
          generatedAvatars: [],
          visualNotes: 'Film noir aesthetic, always partially in shadow',
          voiceType: 'Deep, gravelly',
          accent: 'Slight New York accent',
          voiceNotes: 'Speaks slowly, deliberately',
          sceneAppearances: [0, 1, 3, 4],
          hasAvatar: false,
        },
        {
          id: 'char-2',
          name: 'Sarah Rodriguez',
          nickname: 'Rookie',
          role: 'lead',
          tags: ['Rookie Detective', 'Eager', 'Tech-savvy'],
          ageRange: '25-30',
          gender: 'Female',
          ethnicity: 'Latina',
          physicalDescription: 'Athletic build, dark curly hair usually tied back. Bright, alert eyes.',
          signatureLook: 'Modern professional attire, always has her tablet and bluetooth earpiece.',
          traits: ['Optimistic', 'Clever', 'Impulsive'],
          motivation: 'To prove herself and make a difference',
          fears: 'Being seen as just a diversity hire',
          speechPattern: 'Quick, enthusiastic. Uses tech jargon.',
          quirks: 'Constantly checking her smart devices',
          backstory: 'Top of her class at the academy, transferred from cyber crimes...',
          arc: 'From proving herself to finding her own path',
          relationships: [{ characterId: 'char-1', relationship: 'New partner' }],
          referenceImages: [],
          generatedAvatars: [],
          visualNotes: 'Bright, modern look contrasting with Marcus',
          voiceType: 'Clear, energetic',
          accent: 'California neutral',
          voiceNotes: 'Speaks fast when excited',
          sceneAppearances: [1, 2, 3, 4],
          hasAvatar: false,
        },
        {
          id: 'char-3',
          name: 'Victor Kaine',
          nickname: 'The Ghost',
          role: 'supporting',
          tags: ['Antagonist', 'Mysterious', 'Wealthy'],
          ageRange: '50-60',
          gender: 'Male',
          ethnicity: 'Caucasian',
          physicalDescription: 'Distinguished, silver hair swept back. Cold blue eyes. Impeccable posture.',
          signatureLook: 'Bespoke three-piece suits, always in dark colors. Silver cufflinks.',
          traits: ['Calculating', 'Charming', 'Ruthless'],
          motivation: 'Power and control over the city',
          fears: 'Exposure, loss of control',
          speechPattern: 'Eloquent, measured. Never raises his voice.',
          quirks: 'Always adjusts his cufflinks before lying',
          backstory: 'Built his empire from nothing, or so the story goes...',
          arc: 'Revealed as the mastermind',
          relationships: [],
          referenceImages: [],
          generatedAvatars: [],
          visualNotes: 'Always perfectly lit, almost unnaturally so',
          voiceType: 'Smooth, cultured',
          accent: 'Mid-Atlantic',
          voiceNotes: 'Speaks like every word is rehearsed',
          sceneAppearances: [2, 4],
          hasAvatar: false,
        },
      ];
      setCharacters(demoCharacters);
      setSelectedCharacter(demoCharacters[0]);
    }
  }, [episode]);
  
  // Generate avatar prompt from character profile
  const generateAvatarPrompt = (char) => {
    const parts = [
      `Professional headshot portrait of ${char.name}`,
      char.gender && `${char.gender.toLowerCase()}`,
      char.ageRange && `${char.ageRange} years old`,
      char.ethnicity && `${char.ethnicity}`,
      char.physicalDescription && char.physicalDescription,
      char.signatureLook && `wearing ${char.signatureLook}`,
      'clean white background',
      'studio lighting',
      'high quality',
      '8k',
      'photorealistic' ,
    ].filter(Boolean);
    
    return parts.join(', ');
  };
  
  // Extract characters from script using AI
  const handleExtractCharacters = () => {
    setIsExtracting(true);
    // Simulate AI extraction - would call N8N endpoint
    setTimeout(() => {
      setIsExtracting(false);
      // Characters would be populated from API response
    }, 2000);
  };
  
  // Generate avatar image
  const handleGenerateAvatar = () => {
    if (!selectedCharacter || !avatarPrompt.trim()) return;
    
    setIsGeneratingAvatar(true);
    
    // Simulate API call to N8N
    setTimeout(() => {
      const newAvatar = {
        id: `avatar-${Date.now()}`,
        url: null, // Would be filled by API
        prompt: avatarPrompt,
        generatedAt: new Date(),
        isSelected: true,
      };
      
      // Update character with new avatar
      setCharacters(prev => prev.map(char => {
        if (char.id === selectedCharacter.id) {
          const updatedAvatars = char.generatedAvatars.map(a => ({ ...a, isSelected: false }));
          return {
            ...char,
            generatedAvatars: [...updatedAvatars, newAvatar],
            hasAvatar: true,
          };
        }
        return char;
      }));
      
      setSelectedCharacter(prev => ({
        ...prev,
        generatedAvatars: [...prev.generatedAvatars.map(a => ({ ...a, isSelected: false })), newAvatar],
        hasAvatar: true,
      }));
      
      setIsGeneratingAvatar(false);
      setShowAvatarGenerator(false);
    }, 2500);
  };
  
  // Save character
  const handleSaveCharacter = () => {
    if (selectedCharacter) {
      // Update existing character
      setCharacters(prev => prev.map(char => 
        char.id === selectedCharacter.id ? selectedCharacter : char
      ));
    }
  };
  
  // Create new character
  const handleCreateCharacter = () => {
    const newCharacter = {
      id: `char-${Date.now()}`,
      ...characterForm,
      generatedAvatars: [],
      hasAvatar: false,
      sceneAppearances: [],
    };
    
    setCharacters(prev => [...prev, newCharacter]);
    setSelectedCharacter(newCharacter);
    setShowCreateModal(false);
    setCharacterForm({
      name: '',
      nickname: '',
      role: 'supporting',
      tags: [],
      ageRange: '',
      gender: '',
      ethnicity: '',
      physicalDescription: '',
      signatureLook: '',
      traits: [],
      motivation: '',
      fears: '',
      speechPattern: '',
      quirks: '',
      backstory: '',
      arc: '',
      relationships: [],
      referenceImages: [],
      generatedAvatars: [],
      visualNotes: '',
      voiceType: '',
      accent: '',
      voiceNotes: '',
    });
  };
  
  // Check if all required characters have avatars
  const allCharactersHaveAvatars = characters.filter(c => c.role !== 'background').every(c => c.hasAvatar);
  
  // Render character card (IG style)
  const renderCharacterCard = (char) => {
    const isSelected = selectedCharacter?.id === char.id;
    const roleColors = {
      lead: '#8b5cf6',
      supporting: '#3b82f6',
      background: '#6b7280',
    };
    
    return (
      <div
        key={char.id}
        onClick={() => setSelectedCharacter(char)}
        style={{
          background: isSelected ? 'rgba(139, 92, 246, 0.15)' : colors.bg.secondary,
          border: `2px solid ${isSelected ? colors.accent.primary : colors.border.subtle}`,
          borderRadius: '16px',
          padding: '16px',
          cursor: 'pointer',
          transition: 'all 0.2s ease',
        }}
      >
        {/* Avatar */}
        <div style={{
          width: '80px',
          height: '80px',
          borderRadius: '50%',
          background: char.hasAvatar 
            ? `linear-gradient(135deg, ${roleColors[char.role]} 0%, ${roleColors[char.role]}88 100%)`
            : colors.bg.tertiary,
          margin: '0 auto 12px',
          display: 'flex',
          alignItems: 'center',
          justifyContent: 'center',
          border: `3px solid ${roleColors[char.role]}`,
          position: 'relative',
        }}>
          {char.hasAvatar ? (
            <span style={{ fontSize: '32px' }}>👤</span>
          ) : (
            <Icons.User style={{ width: 32, height: 32, color: colors.text.tertiary }} />
          )}
          {!char.hasAvatar && (
            <div style={{
              position: 'absolute',
              bottom: '-4px',
              right: '-4px',
              background: '#f59e0b',
              borderRadius: '50%',
              width: '24px',
              height: '24px',
              display: 'flex',
              alignItems: 'center',
              justifyContent: 'center',
            }}>
              <span style={{ fontSize: '12px' }}>!</span>
            </div>
          )}
        </div>
        
        {/* Name */}
        <div style={{ textAlign: 'center' }}>
          <div style={{ fontSize: '14px', fontWeight: '600', color: colors.text.primary, marginBottom: '4px' }}>
            {char.name}
          </div>
          {char.nickname && (
            <div style={{ fontSize: '12px', color: colors.text.tertiary, marginBottom: '8px' }}>
              "{char.nickname}"
            </div>
          )}
          <span style={{
            display: 'inline-block',
            padding: '4px 10px',
            background: `${roleColors[char.role]}20`,
            color: roleColors[char.role],
            borderRadius: '12px',
            fontSize: '11px',
            fontWeight: '500',
            textTransform: 'capitalize',
          }}>
            {char.role}
          </span>
        </div>
      </div>
    );
  };
  
  // Render tab content
  const renderTabContent = () => {
    if (!selectedCharacter) return null;
    
    switch (activeTab) {
      case 'profile':
        return (
          <div style={{ display: 'flex', flexDirection: 'column', gap: '20px' }}>
            {/* Basic Info Row */}
            <div style={{ display: 'grid', gridTemplateColumns: '1fr 1fr 1fr', gap: '16px' }}>
              <div>
                <label style={{ display: 'block', fontSize: '12px', color: colors.text.tertiary, marginBottom: '6px' }}>Age Range</label>
                <select
                  value={selectedCharacter.ageRange}
                  onChange={(e) => setSelectedCharacter(prev => ({ ...prev, ageRange: e.target.value }))}
                  style={{
                    width: '100%',
                    padding: '10px 12px',
                    background: colors.bg.tertiary,
                    border: `1px solid ${colors.border.default}`,
                    borderRadius: '8px',
                    color: colors.text.primary,
                    fontSize: '14px',
                  }}
                >
                  <option value="">Select age range</option>
                  <option value="Child (0-12)">Child (0-12)</option>
                  <option value="Teen (13-19)">Teen (13-19)</option>
                  <option value="20s">20s</option>
                  <option value="30s">30s</option>
                  <option value="40-50">40-50</option>
                  <option value="50-60">50-60</option>
                  <option value="60+">60+</option>
                </select>
              </div>
              <div>
                <label style={{ display: 'block', fontSize: '12px', color: colors.text.tertiary, marginBottom: '6px' }}>Gender</label>
                <input
                  type="text"
                  value={selectedCharacter.gender}
                  onChange={(e) => setSelectedCharacter(prev => ({ ...prev, gender: e.target.value }))}
                  placeholder="e.g., Female, Male, Non-binary"
                  style={{
                    width: '100%',
                    padding: '10px 12px',
                    background: colors.bg.tertiary,
                    border: `1px solid ${colors.border.default}`,
                    borderRadius: '8px',
                    color: colors.text.primary,
                    fontSize: '14px',
                  }}
                />
              </div>
              <div>
                <label style={{ display: 'block', fontSize: '12px', color: colors.text.tertiary, marginBottom: '6px' }}>Ethnicity/Background</label>
                <input
                  type="text"
                  value={selectedCharacter.ethnicity}
                  onChange={(e) => setSelectedCharacter(prev => ({ ...prev, ethnicity: e.target.value }))}
                  placeholder="e.g., East Asian, Latino"
                  style={{
                    width: '100%',
                    padding: '10px 12px',
                    background: colors.bg.tertiary,
                    border: `1px solid ${colors.border.default}`,
                    borderRadius: '8px',
                    color: colors.text.primary,
                    fontSize: '14px',
                  }}
                />
              </div>
            </div>
            
            {/* Physical Description */}
            <div>
              <label style={{ display: 'block', fontSize: '12px', color: colors.text.tertiary, marginBottom: '6px' }}>Physical Description</label>
              <textarea
                value={selectedCharacter.physicalDescription}
                onChange={(e) => setSelectedCharacter(prev => ({ ...prev, physicalDescription: e.target.value }))}
                placeholder="Describe height, build, hair color, eye color, distinguishing features..."
                style={{
                  width: '100%',
                  padding: '12px',
                  background: colors.bg.tertiary,
                  border: `1px solid ${colors.border.default}`,
                  borderRadius: '8px',
                  color: colors.text.primary,
                  fontSize: '14px',
                  minHeight: '100px',
                  resize: 'vertical',
                }}
              />
            </div>
            
            {/* Signature Look */}
            <div>
              <label style={{ display: 'block', fontSize: '12px', color: colors.text.tertiary, marginBottom: '6px' }}>Signature Look / Style</label>
              <textarea
                value={selectedCharacter.signatureLook}
                onChange={(e) => setSelectedCharacter(prev => ({ ...prev, signatureLook: e.target.value }))}
                placeholder="What does this character typically wear? Any accessories they're known for?"
                style={{
                  width: '100%',
                  padding: '12px',
                  background: colors.bg.tertiary,
                  border: `1px solid ${colors.border.default}`,
                  borderRadius: '8px',
                  color: colors.text.primary,
                  fontSize: '14px',
                  minHeight: '80px',
                  resize: 'vertical',
                }}
              />
            </div>
          </div>
        );
        
      case 'personality':
        return (
          <div style={{ display: 'flex', flexDirection: 'column', gap: '20px' }}>
            {/* Traits */}
            <div>
              <label style={{ display: 'block', fontSize: '12px', color: colors.text.tertiary, marginBottom: '6px' }}>Personality Traits</label>
              <div style={{ display: 'flex', flexWrap: 'wrap', gap: '8px', marginBottom: '8px' }}>
                {(selectedCharacter.traits || []).map((trait, idx) => (
                  <span
                    key={idx}
                    style={{
                      padding: '6px 12px',
                      background: 'rgba(139, 92, 246, 0.2)',
                      color: colors.accent.primary,
                      borderRadius: '16px',
                      fontSize: '13px',
                      display: 'flex',
                      alignItems: 'center',
                      gap: '6px',
                    }}
                  >
                    {trait}
                    <button
                      onClick={() => setSelectedCharacter(prev => ({
                        ...prev,
                        traits: prev.traits.filter((_, i) => i !== idx)
                      }))}
                      style={{ background: 'none', border: 'none', color: colors.accent.primary, cursor: 'pointer', padding: 0 }}
                    >×</button>
                  </span>
                ))}
              </div>
              <input
                type="text"
                placeholder="Add trait and press Enter"
                onKeyDown={(e) => {
                  if (e.key === 'Enter' && e.target.value.trim()) {
                    setSelectedCharacter(prev => ({
                      ...prev,
                      traits: [...(prev.traits || []), e.target.value.trim()]
                    }));
                    e.target.value = '';
                  }
                }}
                style={{
                  width: '100%',
                  padding: '10px 12px',
                  background: colors.bg.tertiary,
                  border: `1px solid ${colors.border.default}`,
                  borderRadius: '8px',
                  color: colors.text.primary,
                  fontSize: '14px',
                }}
              />
            </div>
            
            {/* Motivation */}
            <div>
              <label style={{ display: 'block', fontSize: '12px', color: colors.text.tertiary, marginBottom: '6px' }}>Motivation / Goal</label>
              <textarea
                value={selectedCharacter.motivation}
                onChange={(e) => setSelectedCharacter(prev => ({ ...prev, motivation: e.target.value }))}
                placeholder="What drives this character? What do they want?"
                style={{
                  width: '100%',
                  padding: '12px',
                  background: colors.bg.tertiary,
                  border: `1px solid ${colors.border.default}`,
                  borderRadius: '8px',
                  color: colors.text.primary,
                  fontSize: '14px',
                  minHeight: '80px',
                  resize: 'vertical',
                }}
              />
            </div>
            
            {/* Fears */}
            <div>
              <label style={{ display: 'block', fontSize: '12px', color: colors.text.tertiary, marginBottom: '6px' }}>Fears / Weaknesses</label>
              <textarea
                value={selectedCharacter.fears}
                onChange={(e) => setSelectedCharacter(prev => ({ ...prev, fears: e.target.value }))}
                placeholder="What are they afraid of? What holds them back?"
                style={{
                  width: '100%',
                  padding: '12px',
                  background: colors.bg.tertiary,
                  border: `1px solid ${colors.border.default}`,
                  borderRadius: '8px',
                  color: colors.text.primary,
                  fontSize: '14px',
                  minHeight: '80px',
                  resize: 'vertical',
                }}
              />
            </div>
            
            {/* Speech Pattern */}
            <div style={{ display: 'grid', gridTemplateColumns: '1fr 1fr', gap: '16px' }}>
              <div>
                <label style={{ display: 'block', fontSize: '12px', color: colors.text.tertiary, marginBottom: '6px' }}>Speech Pattern</label>
                <input
                  type="text"
                  value={selectedCharacter.speechPattern}
                  onChange={(e) => setSelectedCharacter(prev => ({ ...prev, speechPattern: e.target.value }))}
                  placeholder="How do they speak?"
                  style={{
                    width: '100%',
                    padding: '10px 12px',
                    background: colors.bg.tertiary,
                    border: `1px solid ${colors.border.default}`,
                    borderRadius: '8px',
                    color: colors.text.primary,
                    fontSize: '14px',
                  }}
                />
              </div>
              <div>
                <label style={{ display: 'block', fontSize: '12px', color: colors.text.tertiary, marginBottom: '6px' }}>Quirks / Habits</label>
                <input
                  type="text"
                  value={selectedCharacter.quirks}
                  onChange={(e) => setSelectedCharacter(prev => ({ ...prev, quirks: e.target.value }))}
                  placeholder="Any distinctive behaviors?"
                  style={{
                    width: '100%',
                    padding: '10px 12px',
                    background: colors.bg.tertiary,
                    border: `1px solid ${colors.border.default}`,
                    borderRadius: '8px',
                    color: colors.text.primary,
                    fontSize: '14px',
                  }}
                />
              </div>
            </div>
          </div>
        );
        
      case 'story':
        return (
          <div style={{ display: 'flex', flexDirection: 'column', gap: '20px' }}>
            {/* Backstory */}
            <div>
              <label style={{ display: 'block', fontSize: '12px', color: colors.text.tertiary, marginBottom: '6px' }}>Backstory</label>
              <textarea
                value={selectedCharacter.backstory}
                onChange={(e) => setSelectedCharacter(prev => ({ ...prev, backstory: e.target.value }))}
                placeholder="What's their history? Where do they come from?"
                style={{
                  width: '100%',
                  padding: '12px',
                  background: colors.bg.tertiary,
                  border: `1px solid ${colors.border.default}`,
                  borderRadius: '8px',
                  color: colors.text.primary,
                  fontSize: '14px',
                  minHeight: '120px',
                  resize: 'vertical',
                }}
              />
            </div>
            
            {/* Character Arc */}
            <div>
              <label style={{ display: 'block', fontSize: '12px', color: colors.text.tertiary, marginBottom: '6px' }}>Character Arc</label>
              <textarea
                value={selectedCharacter.arc}
                onChange={(e) => setSelectedCharacter(prev => ({ ...prev, arc: e.target.value }))}
                placeholder="How does this character change throughout the story?"
                style={{
                  width: '100%',
                  padding: '12px',
                  background: colors.bg.tertiary,
                  border: `1px solid ${colors.border.default}`,
                  borderRadius: '8px',
                  color: colors.text.primary,
                  fontSize: '14px',
                  minHeight: '100px',
                  resize: 'vertical',
                }}
              />
            </div>
            
            {/* Scene Appearances */}
            <div>
              <label style={{ display: 'block', fontSize: '12px', color: colors.text.tertiary, marginBottom: '6px' }}>Scene Appearances</label>
              <div style={{ display: 'flex', flexWrap: 'wrap', gap: '8px' }}>
                {(selectedCharacter.sceneAppearances || []).map((sceneIdx) => (
                  <span
                    key={sceneIdx}
                    style={{
                      padding: '6px 12px',
                      background: colors.bg.tertiary,
                      borderRadius: '8px',
                      fontSize: '13px',
                      color: colors.text.secondary,
                    }}
                  >
                    Scene {sceneIdx + 1}
                  </span>
                ))}
                {(!selectedCharacter.sceneAppearances || selectedCharacter.sceneAppearances.length === 0) && (
                  <span style={{ color: colors.text.tertiary, fontSize: '13px' }}>No scenes assigned yet</span>
                )}
              </div>
            </div>
          </div>
        );
        
      case 'visuals':
        return (
          <div style={{ display: 'flex', flexDirection: 'column', gap: '20px' }}>
            {/* Generated Avatars */}
            <div>
              <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center', marginBottom: '12px' }}>
                <label style={{ fontSize: '12px', color: colors.text.tertiary }}>Generated Avatars</label>
                <button
                  onClick={() => {
                    setAvatarPrompt(generateAvatarPrompt(selectedCharacter));
                    setShowAvatarGenerator(true);
                  }}
                  style={{
                    padding: '8px 16px',
                    background: 'linear-gradient(135deg, #8b5cf6 0%, #ec4899 100%)',
                    border: 'none',
                    borderRadius: '8px',
                    color: '#fff',
                    fontSize: '13px',
                    fontWeight: '500',
                    cursor: 'pointer',
                    display: 'flex',
                    alignItems: 'center',
                    gap: '6px',
                  }}
                >
                  <Icons.Sparkles style={{ width: 14, height: 14 }} />
                  Generate Avatar
                </button>
              </div>
              
              {selectedCharacter.generatedAvatars && selectedCharacter.generatedAvatars.length > 0 ? (
                <div style={{ display: 'grid', gridTemplateColumns: 'repeat(4, 1fr)', gap: '12px' }}>
                  {selectedCharacter.generatedAvatars.map((avatar) => (
                    <div
                      key={avatar.id}
                      onClick={() => {
                        // Select this avatar
                        setSelectedCharacter(prev => ({
                          ...prev,
                          generatedAvatars: prev.generatedAvatars.map(a => ({
                            ...a,
                            isSelected: a.id === avatar.id
                          }))
                        }));
                      }}
                      style={{
                        aspectRatio: '1',
                        borderRadius: '12px',
                        background: 'linear-gradient(135deg, #8b5cf6 0%, #6366f1 100%)',
                        border: avatar.isSelected ? '3px solid #10b981' : '3px solid transparent',
                        cursor: 'pointer',
                        display: 'flex',
                        alignItems: 'center',
                        justifyContent: 'center',
                        position: 'relative',
                      }}
                    >
                      <Icons.User style={{ width: 40, height: 40, color: 'rgba(255,255,255,0.5)' }} />
                      {avatar.isSelected && (
                        <div style={{
                          position: 'absolute',
                          top: '8px',
                          right: '8px',
                          background: '#10b981',
                          borderRadius: '50%',
                          width: '24px',
                          height: '24px',
                          display: 'flex',
                          alignItems: 'center',
                          justifyContent: 'center',
                        }}>
                          <Icons.Check style={{ width: 14, height: 14, color: '#fff' }} />
                        </div>
                      )}
                    </div>
                  ))}
                </div>
              ) : (
                <div style={{
                  padding: '40px',
                  background: colors.bg.tertiary,
                  borderRadius: '12px',
                  textAlign: 'center',
                  border: `2px dashed ${colors.border.default}`,
                }}>
                  <Icons.User style={{ width: 48, height: 48, color: colors.text.tertiary, marginBottom: '12px' }} />
                  <p style={{ color: colors.text.secondary, marginBottom: '4px' }}>No avatars generated yet</p>
                  <p style={{ color: colors.text.tertiary, fontSize: '13px' }}>Click "Generate Avatar" to create one</p>
                </div>
              )}
            </div>
            
            {/* Reference Images */}
            <div>
              <label style={{ display: 'block', fontSize: '12px', color: colors.text.tertiary, marginBottom: '12px' }}>Reference Images</label>
              <div style={{
                padding: '30px',
                background: colors.bg.tertiary,
                borderRadius: '12px',
                textAlign: 'center',
                border: `2px dashed ${colors.border.default}`,
                cursor: 'pointer',
              }}>
                <Icons.Upload style={{ width: 32, height: 32, color: colors.text.tertiary, marginBottom: '8px' }} />
                <p style={{ color: colors.text.secondary, fontSize: '14px' }}>Drop images here or click to upload</p>
              </div>
            </div>
            
            {/* Visual Notes */}
            <div>
              <label style={{ display: 'block', fontSize: '12px', color: colors.text.tertiary, marginBottom: '6px' }}>Visual Notes</label>
              <textarea
                value={selectedCharacter.visualNotes}
                onChange={(e) => setSelectedCharacter(prev => ({ ...prev, visualNotes: e.target.value }))}
                placeholder="Any specific visual direction for this character..."
                style={{
                  width: '100%',
                  padding: '12px',
                  background: colors.bg.tertiary,
                  border: `1px solid ${colors.border.default}`,
                  borderRadius: '8px',
                  color: colors.text.primary,
                  fontSize: '14px',
                  minHeight: '80px',
                  resize: 'vertical',
                }}
              />
            </div>
          </div>
        );
        
      case 'voice':
        return (
          <div style={{ display: 'flex', flexDirection: 'column', gap: '20px' }}>
            <div style={{ display: 'grid', gridTemplateColumns: '1fr 1fr', gap: '16px' }}>
              <div>
                <label style={{ display: 'block', fontSize: '12px', color: colors.text.tertiary, marginBottom: '6px' }}>Voice Type</label>
                <select
                  value={selectedCharacter.voiceType}
                  onChange={(e) => setSelectedCharacter(prev => ({ ...prev, voiceType: e.target.value }))}
                  style={{
                    width: '100%',
                    padding: '10px 12px',
                    background: colors.bg.tertiary,
                    border: `1px solid ${colors.border.default}`,
                    borderRadius: '8px',
                    color: colors.text.primary,
                    fontSize: '14px',
                  }}
                >
                  <option value="">Select voice type</option>
                  <option value="Deep, gravelly">Deep, gravelly</option>
                  <option value="Deep, smooth">Deep, smooth</option>
                  <option value="Medium, clear">Medium, clear</option>
                  <option value="High, bright">High, bright</option>
                  <option value="Soft, gentle">Soft, gentle</option>
                  <option value="Raspy, worn">Raspy, worn</option>
                  <option value="Energetic, youthful">Energetic, youthful</option>
                </select>
              </div>
              <div>
                <label style={{ display: 'block', fontSize: '12px', color: colors.text.tertiary, marginBottom: '6px' }}>Accent</label>
                <input
                  type="text"
                  value={selectedCharacter.accent}
                  onChange={(e) => setSelectedCharacter(prev => ({ ...prev, accent: e.target.value }))}
                  placeholder="e.g., British, Southern, New York"
                  style={{
                    width: '100%',
                    padding: '10px 12px',
                    background: colors.bg.tertiary,
                    border: `1px solid ${colors.border.default}`,
                    borderRadius: '8px',
                    color: colors.text.primary,
                    fontSize: '14px',
                  }}
                />
              </div>
            </div>
            
            <div>
              <label style={{ display: 'block', fontSize: '12px', color: colors.text.tertiary, marginBottom: '6px' }}>Voice Notes</label>
              <textarea
                value={selectedCharacter.voiceNotes}
                onChange={(e) => setSelectedCharacter(prev => ({ ...prev, voiceNotes: e.target.value }))}
                placeholder="Any specific notes about how this character should sound..."
                style={{
                  width: '100%',
                  padding: '12px',
                  background: colors.bg.tertiary,
                  border: `1px solid ${colors.border.default}`,
                  borderRadius: '8px',
                  color: colors.text.primary,
                  fontSize: '14px',
                  minHeight: '100px',
                  resize: 'vertical',
                }}
              />
            </div>
            
            {/* Voice Preview Placeholder */}
            <div style={{
              padding: '24px',
              background: colors.bg.tertiary,
              borderRadius: '12px',
              textAlign: 'center',
            }}>
              <span style={{ fontSize: '32px', marginBottom: '12px', display: 'block' }}>🎙️</span>
              <p style={{ color: colors.text.secondary, marginBottom: '8px' }}>Voice Generation</p>
              <p style={{ color: colors.text.tertiary, fontSize: '13px' }}>Coming soon - Generate voice samples for this character</p>
            </div>
          </div>
        );
        
      default:
        return null;
    }
  };
  
  return (
    <div style={{ flex: 1, display: 'flex', flexDirection: 'column', overflow: 'hidden' }}>
      {/* Header */}
      <div style={{
        padding: '16px 24px',
        borderBottom: `1px solid ${colors.border.default}`,
        display: 'flex',
        alignItems: 'center',
        justifyContent: 'space-between',
        background: colors.bg.secondary,
      }}>
        <div style={{ display: 'flex', alignItems: 'center', gap: '16px' }}>
          <button
            onClick={onBack}
            style={{ background: 'none', border: 'none', cursor: 'pointer', color: colors.text.secondary }}
          >
            <Icons.ChevronLeft style={{ width: 24, height: 24 }} />
          </button>
          <div>
            <h1 style={{ fontSize: '20px', fontWeight: '600', margin: 0 }}>Cast & Characters</h1>
            <p style={{ fontSize: '13px', color: colors.text.secondary, margin: 0 }}>
              Define your characters before proceeding to storyboard
            </p>
          </div>
        </div>
        
        <div style={{ display: 'flex', alignItems: 'center', gap: '12px' }}>
          {!allCharactersHaveAvatars && (
            <span style={{
              padding: '8px 12px',
              background: 'rgba(245, 158, 11, 0.2)',
              color: '#f59e0b',
              borderRadius: '8px',
              fontSize: '13px',
            }}>
              ⚠️ {characters.filter(c => c.role !== 'background' && !c.hasAvatar).length} characters need avatars
            </span>
          )}
          <Button
            onClick={() => setShowCreateModal(true)}
            variant="secondary"
          >
            <Icons.Plus style={{ width: 16, height: 16, marginRight: '6px' }} />
            Add Character
          </Button>
          <Button
            onClick={() => onProceedToStoryboard(characters)}
            disabled={!allCharactersHaveAvatars}
            style={{
              opacity: allCharactersHaveAvatars ? 1 : 0.5,
            }}
          >
            Proceed to Storyboard
            <Icons.ChevronRight style={{ width: 16, height: 16, marginLeft: '6px' }} />
          </Button>
        </div>
      </div>
      
      {/* Main Content */}
      <div style={{ flex: 1, display: 'flex', overflow: 'hidden' }}>
        {/* Characters List (Left) */}
        <div style={{
          width: '280px',
          borderRight: `1px solid ${colors.border.default}`,
          background: colors.bg.primary,
          overflow: 'auto',
          padding: '16px',
        }}>
          <div style={{ marginBottom: '16px' }}>
            <button
              onClick={handleExtractCharacters}
              disabled={isExtracting}
              style={{
                width: '100%',
                padding: '12px',
                background: isExtracting ? colors.bg.tertiary : 'linear-gradient(135deg, #8b5cf6 0%, #6366f1 100%)',
                border: 'none',
                borderRadius: '8px',
                color: '#fff',
                fontSize: '13px',
                fontWeight: '500',
                cursor: isExtracting ? 'not-allowed' : 'pointer',
                display: 'flex',
                alignItems: 'center',
                justifyContent: 'center',
                gap: '8px',
              }}
            >
              {isExtracting ? (
                <>
                  <div style={{
                    width: '16px',
                    height: '16px',
                    border: '2px solid rgba(255,255,255,0.3)',
                    borderTopColor: '#fff',
                    borderRadius: '50%',
                    animation: 'spin 1s linear infinite',
                  }} />
                  Extracting...
                </>
              ) : (
                <>
                  <Icons.Sparkles style={{ width: 16, height: 16 }} />
                  Extract from Script
                </>
              )}
            </button>
          </div>
          
          <div style={{ display: 'flex', flexDirection: 'column', gap: '12px' }}>
            {characters.map(renderCharacterCard)}
          </div>
        </div>
        
        {/* Character Detail (Right) */}
        <div style={{ flex: 1, overflow: 'auto', background: colors.bg.primary }}>
          {selectedCharacter ? (
            <div style={{ padding: '24px' }}>
              {/* Character Header */}
              <div style={{
                background: colors.bg.secondary,
                borderRadius: '16px',
                padding: '20px',
                marginBottom: '24px',
                display: 'flex',
                gap: '20px',
                alignItems: 'flex-start',
              }}>
                {/* Avatar */}
                <div style={{
                  width: '100px',
                  height: '100px',
                  borderRadius: '50%',
                  background: selectedCharacter.hasAvatar 
                    ? 'linear-gradient(135deg, #8b5cf6 0%, #6366f1 100%)'
                    : colors.bg.tertiary,
                  display: 'flex',
                  alignItems: 'center',
                  justifyContent: 'center',
                  border: '4px solid rgba(139, 92, 246, 0.3)',
                  position: 'relative',
                  flexShrink: 0,
                }}>
                  {selectedCharacter.hasAvatar ? (
                    <span style={{ fontSize: '40px' }}>👤</span>
                  ) : (
                    <Icons.User style={{ width: 40, height: 40, color: colors.text.tertiary }} />
                  )}
                  <button
                    onClick={() => {
                      setAvatarPrompt(generateAvatarPrompt(selectedCharacter));
                      setShowAvatarGenerator(true);
                    }}
                    style={{
                      position: 'absolute',
                      bottom: '-4px',
                      right: '-4px',
                      background: colors.accent.primary,
                      border: 'none',
                      borderRadius: '50%',
                      width: '32px',
                      height: '32px',
                      cursor: 'pointer',
                      display: 'flex',
                      alignItems: 'center',
                      justifyContent: 'center',
                    }}
                  >
                    <Icons.Sparkles style={{ width: 16, height: 16, color: '#fff' }} />
                  </button>
                </div>
                
                {/* Name & Role */}
                <div style={{ flex: 1 }}>
                  <input
                    type="text"
                    value={selectedCharacter.name}
                    onChange={(e) => setSelectedCharacter(prev => ({ ...prev, name: e.target.value }))}
                    placeholder="Character Name"
                    style={{
                      width: '100%',
                      padding: '8px 0',
                      background: 'transparent',
                      border: 'none',
                      borderBottom: `1px solid ${colors.border.default}`,
                      color: colors.text.primary,
                      fontSize: '24px',
                      fontWeight: '600',
                      marginBottom: '8px',
                    }}
                  />
                  <div style={{ display: 'flex', gap: '12px', alignItems: 'center', marginBottom: '12px' }}>
                    <input
                      type="text"
                      value={selectedCharacter.nickname || ''}
                      onChange={(e) => setSelectedCharacter(prev => ({ ...prev, nickname: e.target.value }))}
                      placeholder="Nickname or alias..."
                      style={{
                        padding: '6px 12px',
                        background: colors.bg.tertiary,
                        border: `1px solid ${colors.border.default}`,
                        borderRadius: '6px',
                        color: colors.text.secondary,
                        fontSize: '14px',
                        width: '180px',
                      }}
                    />
                    <select
                      value={selectedCharacter.role}
                      onChange={(e) => setSelectedCharacter(prev => ({ ...prev, role: e.target.value }))}
                      style={{
                        padding: '6px 12px',
                        background: colors.bg.tertiary,
                        border: `1px solid ${colors.border.default}`,
                        borderRadius: '6px',
                        color: colors.text.primary,
                        fontSize: '14px',
                      }}
                    >
                      <option value="lead">⭐ Lead</option>
                      <option value="supporting">👥 Supporting</option>
                      <option value="background">🎭 Background</option>
                    </select>
                  </div>
                  
                  {/* Tags */}
                  <div style={{ display: 'flex', flexWrap: 'wrap', gap: '8px', alignItems: 'center' }}>
                    {(selectedCharacter.tags || []).map((tag, idx) => (
                      <span
                        key={idx}
                        style={{
                          padding: '4px 10px',
                          background: 'rgba(139, 92, 246, 0.2)',
                          color: colors.accent.primary,
                          borderRadius: '12px',
                          fontSize: '12px',
                          display: 'flex',
                          alignItems: 'center',
                          gap: '4px',
                        }}
                      >
                        {tag}
                        <button
                          onClick={() => setSelectedCharacter(prev => ({
                            ...prev,
                            tags: prev.tags.filter((_, i) => i !== idx)
                          }))}
                          style={{ background: 'none', border: 'none', color: colors.accent.primary, cursor: 'pointer', padding: 0, fontSize: '14px' }}
                        >×</button>
                      </span>
                    ))}
                    <input
                      type="text"
                      placeholder="Add tag..."
                      onKeyDown={(e) => {
                        if (e.key === 'Enter' && e.target.value.trim()) {
                          setSelectedCharacter(prev => ({
                            ...prev,
                            tags: [...(prev.tags || []), e.target.value.trim()]
                          }));
                          e.target.value = '';
                        }
                      }}
                      style={{
                        padding: '4px 10px',
                        background: colors.bg.tertiary,
                        border: `1px solid ${colors.border.default}`,
                        borderRadius: '12px',
                        color: colors.text.primary,
                        fontSize: '12px',
                        width: '100px',
                      }}
                    />
                  </div>
                </div>
                
                {/* Save Button */}
                <button
                  onClick={handleSaveCharacter}
                  style={{
                    padding: '10px 20px',
                    background: colors.bg.tertiary,
                    border: `1px solid ${colors.border.default}`,
                    borderRadius: '8px',
                    color: colors.text.primary,
                    fontSize: '14px',
                    cursor: 'pointer',
                    display: 'flex',
                    alignItems: 'center',
                    gap: '8px',
                  }}
                >
                  <Icons.Save style={{ width: 16, height: 16 }} />
                  Save Character
                </button>
              </div>
              
              {/* Tabs */}
              <div style={{
                display: 'flex',
                gap: '8px',
                marginBottom: '24px',
                borderBottom: `1px solid ${colors.border.default}`,
                paddingBottom: '12px',
              }}>
                {[
                  { id: 'profile', icon: <Icons.User />, label: 'Profile' },
                  { id: 'personality', icon: '💭', label: 'Personality' },
                  { id: 'story', icon: '📖', label: 'Story' },
                  { id: 'visuals', icon: '🎨', label: 'Visuals' },
                  { id: 'voice', icon: '🎙️', label: 'Voice' },
                ].map(tab => (
                  <button
                    key={tab.id}
                    onClick={() => setActiveTab(tab.id)}
                    style={{
                      padding: '10px 16px',
                      background: activeTab === tab.id ? 'rgba(139, 92, 246, 0.2)' : 'transparent',
                      border: 'none',
                      borderRadius: '8px',
                      color: activeTab === tab.id ? colors.accent.primary : colors.text.secondary,
                      fontSize: '14px',
                      cursor: 'pointer',
                      display: 'flex',
                      alignItems: 'center',
                      gap: '8px',
                      fontWeight: activeTab === tab.id ? '500' : '400',
                    }}
                  >
                    {typeof tab.icon === 'string' ? tab.icon : React.cloneElement(tab.icon, { style: { width: 16, height: 16 } })}
                    {tab.label}
                  </button>
                ))}
              </div>
              
              {/* Tab Content */}
              {renderTabContent()}
            </div>
          ) : (
            <div style={{
              height: '100%',
              display: 'flex',
              alignItems: 'center',
              justifyContent: 'center',
              flexDirection: 'column',
              color: colors.text.tertiary,
            }}>
              <Icons.Users style={{ width: 64, height: 64, marginBottom: '16px', opacity: 0.3 }} />
              <p>Select a character to view details</p>
            </div>
          )}
        </div>
      </div>
      
      {/* Avatar Generator Modal */}
      {showAvatarGenerator && selectedCharacter && (
        <div style={{
          position: 'fixed',
          top: 0,
          left: 0,
          right: 0,
          bottom: 0,
          background: 'rgba(0,0,0,0.8)',
          display: 'flex',
          alignItems: 'center',
          justifyContent: 'center',
          zIndex: 1000,
        }}>
          <div style={{
            width: '600px',
            background: colors.bg.secondary,
            borderRadius: '16px',
            overflow: 'hidden',
          }}>
            {/* Header */}
            <div style={{
              padding: '16px 24px',
              borderBottom: `1px solid ${colors.border.default}`,
              display: 'flex',
              alignItems: 'center',
              justifyContent: 'space-between',
            }}>
              <div style={{ display: 'flex', alignItems: 'center', gap: '12px' }}>
                <Icons.Sparkles style={{ width: 20, height: 20, color: colors.accent.primary }} />
                <h3 style={{ fontSize: '18px', fontWeight: '600', margin: 0 }}>Generate Avatar</h3>
              </div>
              <button
                onClick={() => setShowAvatarGenerator(false)}
                style={{ background: 'none', border: 'none', cursor: 'pointer', color: colors.text.secondary }}
              >
                <Icons.X style={{ width: 20, height: 20 }} />
              </button>
            </div>
            
            {/* Content */}
            <div style={{ padding: '24px' }}>
              <p style={{ color: colors.text.secondary, marginBottom: '16px', fontSize: '14px' }}>
                The prompt below was auto-generated from {selectedCharacter.name}'s profile. Edit as needed before generating.
              </p>
              
              <textarea
                value={avatarPrompt}
                onChange={(e) => setAvatarPrompt(e.target.value)}
                style={{
                  width: '100%',
                  padding: '14px',
                  background: colors.bg.tertiary,
                  border: `1px solid ${colors.border.default}`,
                  borderRadius: '8px',
                  color: colors.text.primary,
                  fontSize: '14px',
                  minHeight: '120px',
                  resize: 'vertical',
                  marginBottom: '16px',
                }}
              />
              
              {/* Reference Images */}
              <div style={{ marginBottom: '20px' }}>
                <label style={{ display: 'block', fontSize: '13px', color: colors.text.secondary, marginBottom: '8px' }}>
                  Reference Images (optional)
                </label>
                <div style={{
                  padding: '20px',
                  background: colors.bg.tertiary,
                  borderRadius: '8px',
                  border: `2px dashed ${colors.border.default}`,
                  textAlign: 'center',
                  cursor: 'pointer',
                }}>
                  <Icons.Upload style={{ width: 24, height: 24, color: colors.text.tertiary, marginBottom: '8px' }} />
                  <p style={{ color: colors.text.tertiary, fontSize: '13px', margin: 0 }}>Drop images or click to upload</p>
                </div>
              </div>
              
              {/* Actions */}
              <div style={{ display: 'flex', gap: '12px', justifyContent: 'flex-end' }}>
                <Button variant="secondary" onClick={() => setShowAvatarGenerator(false)}>
                  Cancel
                </Button>
                <Button onClick={handleGenerateAvatar} disabled={isGeneratingAvatar}>
                  {isGeneratingAvatar ? (
                    <>
                      <div style={{
                        width: '16px',
                        height: '16px',
                        border: '2px solid rgba(255,255,255,0.3)',
                        borderTopColor: '#fff',
                        borderRadius: '50%',
                        animation: 'spin 1s linear infinite',
                        marginRight: '8px',
                      }} />
                      Generating...
                    </>
                  ) : (
                    <>
                      <Icons.Sparkles style={{ width: 16, height: 16, marginRight: '8px' }} />
                      Generate Avatar
                    </>
                  )}
                </Button>
              </div>
            </div>
          </div>
        </div>
      )}
      
      {/* Create Character Modal */}
      {showCreateModal && (
        <div style={{
          position: 'fixed',
          top: 0,
          left: 0,
          right: 0,
          bottom: 0,
          background: 'rgba(0,0,0,0.8)',
          display: 'flex',
          alignItems: 'center',
          justifyContent: 'center',
          zIndex: 1000,
        }}>
          <div style={{
            width: '500px',
            background: colors.bg.secondary,
            borderRadius: '16px',
            overflow: 'hidden',
          }}>
            <div style={{
              padding: '16px 24px',
              borderBottom: `1px solid ${colors.border.default}`,
              display: 'flex',
              alignItems: 'center',
              justifyContent: 'space-between',
            }}>
              <h3 style={{ fontSize: '18px', fontWeight: '600', margin: 0 }}>New Character</h3>
              <button
                onClick={() => setShowCreateModal(false)}
                style={{ background: 'none', border: 'none', cursor: 'pointer', color: colors.text.secondary }}
              >
                <Icons.X style={{ width: 20, height: 20 }} />
              </button>
            </div>
            
            <div style={{ padding: '24px' }}>
              <div style={{ marginBottom: '16px' }}>
                <label style={{ display: 'block', fontSize: '13px', color: colors.text.secondary, marginBottom: '6px' }}>Character Name *</label>
                <input
                  type="text"
                  value={characterForm.name}
                  onChange={(e) => setCharacterForm(prev => ({ ...prev, name: e.target.value }))}
                  placeholder="Enter character name"
                  style={{
                    width: '100%',
                    padding: '12px',
                    background: colors.bg.tertiary,
                    border: `1px solid ${colors.border.default}`,
                    borderRadius: '8px',
                    color: colors.text.primary,
                    fontSize: '14px',
                  }}
                />
              </div>
              
              <div style={{ display: 'grid', gridTemplateColumns: '1fr 1fr', gap: '16px', marginBottom: '16px' }}>
                <div>
                  <label style={{ display: 'block', fontSize: '13px', color: colors.text.secondary, marginBottom: '6px' }}>Nickname</label>
                  <input
                    type="text"
                    value={characterForm.nickname}
                    onChange={(e) => setCharacterForm(prev => ({ ...prev, nickname: e.target.value }))}
                    placeholder="Optional"
                    style={{
                      width: '100%',
                      padding: '10px 12px',
                      background: colors.bg.tertiary,
                      border: `1px solid ${colors.border.default}`,
                      borderRadius: '8px',
                      color: colors.text.primary,
                      fontSize: '14px',
                    }}
                  />
                </div>
                <div>
                  <label style={{ display: 'block', fontSize: '13px', color: colors.text.secondary, marginBottom: '6px' }}>Role</label>
                  <select
                    value={characterForm.role}
                    onChange={(e) => setCharacterForm(prev => ({ ...prev, role: e.target.value }))}
                    style={{
                      width: '100%',
                      padding: '10px 12px',
                      background: colors.bg.tertiary,
                      border: `1px solid ${colors.border.default}`,
                      borderRadius: '8px',
                      color: colors.text.primary,
                      fontSize: '14px',
                    }}
                  >
                    <option value="lead">⭐ Lead</option>
                    <option value="supporting">👥 Supporting</option>
                    <option value="background">🎭 Background</option>
                  </select>
                </div>
              </div>
              
              <div style={{ display: 'flex', gap: '12px', justifyContent: 'flex-end' }}>
                <Button variant="secondary" onClick={() => setShowCreateModal(false)}>
                  Cancel
                </Button>
                <Button onClick={handleCreateCharacter} disabled={!characterForm.name.trim()}>
                  Create Character
                </Button>
              </div>
            </div>
          </div>
        </div>
      )}
      
      <style>{`
        @keyframes spin {
          to { transform: rotate(360deg); }
        }
      `}</style>
    </div>
  );
};

// ============================================================================
// SCENE BUILDER VIEW - Per-scene setup with cast, locations, props, extras
// ============================================================================
const SceneBuilderView = ({ project, episode, characters, onUpdateProject, onBack, onProceedToStoryboard }) => {
  const [scenes, setScenes] = useState([]);
  const [selectedSceneIndex, setSelectedSceneIndex] = useState(0);
  const [showElementModal, setShowElementModal] = useState(false);
  const [elementModalType, setElementModalType] = useState(null); // 'character', 'location', 'prop', 'extra', 'costume'
  const [editingElement, setEditingElement] = useState(null);
  const [isGenerating, setIsGenerating] = useState(false);
  const [generatingElementId, setGeneratingElementId] = useState(null);
  
  // Element form state
  const [elementForm, setElementForm] = useState({
    name: '',
    description: '',
    prompt: '',
    timePeriodNotes: '',
    referenceImages: [],
    generatedImages: [],
    isApproved: false,
  });
  
  // Initialize scenes from episode
  React.useEffect(() => {
    if (episode?.scenes && episode.scenes.length > 0) {
      // Enrich scenes with element tracking
      const enrichedScenes = episode.scenes.map((scene, idx) => ({
        ...scene,
        id: scene.id || `scene-${idx}`,
        // Cast - characters in this scene with their costumes
        cast: scene.cast || extractCharactersFromScene(scene, characters),
        // Location
        location: scene.location || {
          id: `loc-${idx}`,
          name: scene.setting || 'Unknown Location',
          description: '',
          prompt: '',
          isApproved: false,
          generatedImages: [],
        },
        // Props - critical objects
        props: scene.props || detectPropsFromScene(scene),
        // Extras - background actors
        extras: scene.extras || [],
      }));
      setScenes(enrichedScenes);
    } else {
      // Demo scenes for testing
      const demoScenes = [
        {
          id: 'scene-1',
          title: 'The Cold Case',
          setting: "INT. DETECTIVE'S OFFICE - NIGHT",
          timeOfDay: 'night',
          description: 'A dimly lit office cluttered with case files. Rain patters against the window.',
          script: `MARCUS sits at his desk, illuminated only by a desk lamp. He stares at an old case file, photographs spread before him.

MARCUS
(quietly)
Three years. Three years and still nothing.

He picks up a PAGER from the desk, turns it over in his hands.

SARAH enters, holding two coffee cups.

SARAH
Burning the midnight oil again?

MARCUS
(not looking up)
This case... it doesn't let go.`,
          cast: [
            {
              characterId: 'char-1',
              characterName: 'Marcus Chen',
              costume: {
                id: 'costume-1-1',
                name: 'Worn suit, loosened tie',
                description: 'Disheveled suit showing long hours. Sleeves rolled up, tie loosened.',
                prompt: '',
                isApproved: false,
              },
              isApproved: false,
            },
            {
              characterId: 'char-2',
              characterName: 'Sarah Rodriguez',
              costume: {
                id: 'costume-2-1',
                name: 'Professional blazer',
                description: 'Sharp blazer over casual top. Fresh compared to Marcus.',
                prompt: '',
                isApproved: false,
              },
              isApproved: false,
            },
          ],
          location: {
            id: 'loc-1',
            name: "Detective's Office",
            description: 'Cluttered desk, filing cabinets, rain-streaked window, dim lighting',
            prompt: 'Dimly lit 1990s detective office interior, cluttered desk with case files and photographs, filing cabinets, rain on window, single desk lamp illumination, noir atmosphere, film grain',
            isApproved: false,
            generatedImages: [],
          },
          props: [
            {
              id: 'prop-1-1',
              name: 'Case File',
              description: 'Thick manila folder with photographs spilling out',
              prompt: '1990s police case file, manila folder, crime scene photographs, typed reports, worn edges, desk lamp lighting',
              isApproved: false,
              isCritical: true,
              generatedImages: [],
            },
            {
              id: 'prop-1-2',
              name: 'Pager',
              description: 'Motorola pager from the 1990s',
              prompt: '1990s Motorola pager, black, small LCD screen, belt clip, period accurate, product photography on white background',
              isApproved: false,
              isCritical: true,
              generatedImages: [],
            },
            {
              id: 'prop-1-3',
              name: 'Coffee Cups',
              description: 'Two paper coffee cups',
              prompt: 'Two paper coffee cups, steam rising, 1990s style, disposable, white with generic pattern',
              isApproved: false,
              isCritical: false,
              generatedImages: [],
            },
          ],
          extras: [],
        },
        {
          id: 'scene-2',
          title: 'The Witness',
          setting: 'EXT. CITY STREET - DAY',
          timeOfDay: 'day',
          description: 'A busy downtown street. People rushing past.',
          script: `MARCUS and SARAH walk through the crowded street.

SARAH
The witness lives two blocks from here. Mrs. Chen saw something that night.

A HOMELESS MAN shuffles past, muttering.

MARCUS
After three years, memories fade.

They stop at a crosswalk. A STREET VENDOR sells newspapers nearby.

SARAH
Or sharpen. Trauma has a way of burning details into people.`,
          cast: [
            {
              characterId: 'char-1',
              characterName: 'Marcus Chen',
              costume: {
                id: 'costume-1-2',
                name: 'Trenchcoat and fedora',
                description: 'Classic detective look. Tan trenchcoat, dark fedora.',
                prompt: '',
                isApproved: false,
              },
              isApproved: false,
            },
            {
              characterId: 'char-2',
              characterName: 'Sarah Rodriguez',
              costume: {
                id: 'costume-2-2',
                name: 'Smart casual',
                description: 'Modern professional look. Leather jacket over blouse.',
                prompt: '',
                isApproved: false,
              },
              isApproved: false,
            },
          ],
          location: {
            id: 'loc-2',
            name: 'Downtown City Street',
            description: 'Busy urban street with pedestrians, shops, crosswalks',
            prompt: '1990s downtown city street, busy with pedestrians, storefronts, newspaper stands, crosswalk, overcast day, film photography look',
            isApproved: false,
            generatedImages: [],
          },
          props: [
            {
              id: 'prop-2-1',
              name: 'Newspaper Stand',
              description: '1990s style newspaper stand with headlines',
              prompt: '1990s newspaper stand, metal rack, various newspapers and magazines, urban street corner',
              isApproved: false,
              isCritical: false,
              generatedImages: [],
            },
          ],
          extras: [
            {
              id: 'extra-2-1',
              name: 'Street Pedestrians',
              description: 'Busy crowd of people walking, 1990s fashion',
              prompt: 'Crowd of pedestrians walking on city street, 1990s fashion, diverse, business casual, urban',
              isApproved: false,
              count: '15-20',
            },
            {
              id: 'extra-2-2',
              name: 'Homeless Man',
              description: 'Disheveled man shuffling past',
              prompt: 'Homeless man, layered worn clothing, shuffling walk, urban setting, 1990s',
              isApproved: false,
              count: '1',
            },
            {
              id: 'extra-2-3',
              name: 'Street Vendor',
              description: 'Newspaper seller at stand',
              prompt: 'Street vendor selling newspapers, 1990s, casual clothing, urban',
              isApproved: false,
              count: '1',
            },
          ],
        },
      ];
      setScenes(demoScenes);
    }
  }, [episode, characters]);
  
  // Helper: Extract character references from scene text
  const extractCharactersFromScene = (scene, allCharacters) => {
    if (!allCharacters) return [];
    return allCharacters
      .filter(char => {
        const sceneText = `${scene.description || ''} ${scene.script || ''}`.toUpperCase();
        return sceneText.includes(char.name.toUpperCase());
      })
      .map(char => ({
        characterId: char.id,
        characterName: char.name,
        costume: {
          id: `costume-${char.id}-default`,
          name: 'Default costume',
          description: char.signatureLook || '',
          prompt: '',
          isApproved: false,
        },
        isApproved: char.hasAvatar || false,
      }));
  };
  
  // Helper: Detect props from scene script (basic keyword detection)
  const detectPropsFromScene = (scene) => {
    const props = [];
    const script = scene.script || '';
    
    // Look for items in ALL CAPS (standard screenplay format for props)
    const capsMatches = script.match(/\b[A-Z]{2,}(?:\s+[A-Z]+)*\b/g) || [];
    const commonWords = ['INT', 'EXT', 'DAY', 'NIGHT', 'CONT', 'CUT', 'TO', 'THE', 'AND', 'BUT', 'FOR'];
    
    capsMatches.forEach((match, idx) => {
      if (!commonWords.includes(match) && match.length > 2) {
        props.push({
          id: `prop-auto-${idx}`,
          name: match.charAt(0) + match.slice(1).toLowerCase(),
          description: '',
          prompt: '',
          isApproved: false,
          isCritical: true,
          generatedImages: [],
        });
      }
    });
    
    return props.slice(0, 5); // Limit to 5 auto-detected
  };
  
  // Get current scene
  const currentScene = scenes[selectedSceneIndex];
  
  // Calculate scene completion status
  const getSceneCompletionStatus = (scene) => {
    if (!scene) return { total: 0, approved: 0, percentage: 0 };
    
    let total = 0;
    let approved = 0;
    
    // Cast
    (scene.cast || []).forEach(c => {
      total += 2; // Character + costume
      if (c.isApproved) approved++;
      if (c.costume?.isApproved) approved++;
    });
    
    // Location
    if (scene.location) {
      total++;
      if (scene.location.isApproved) approved++;
    }
    
    // Props
    (scene.props || []).filter(p => p.isCritical).forEach(p => {
      total++;
      if (p.isApproved) approved++;
    });
    
    // Extras (optional, count if any)
    (scene.extras || []).forEach(e => {
      total++;
      if (e.isApproved) approved++;
    });
    
    return {
      total,
      approved,
      percentage: total > 0 ? Math.round((approved / total) * 100) : 0,
    };
  };
  
  // Check if all scenes are complete
  const allScenesComplete = scenes.every(scene => {
    const status = getSceneCompletionStatus(scene);
    return status.percentage === 100;
  });
  
  // Open element modal
  const openElementModal = (type, element = null) => {
    setElementModalType(type);
    setEditingElement(element);
    if (element) {
      setElementForm({
        name: element.name || '',
        description: element.description || '',
        prompt: element.prompt || '',
        timePeriodNotes: element.timePeriodNotes || '',
        referenceImages: element.referenceImages || [],
        generatedImages: element.generatedImages || [],
        isApproved: element.isApproved || false,
      });
    } else {
      setElementForm({
        name: '',
        description: '',
        prompt: '',
        timePeriodNotes: '',
        referenceImages: [],
        generatedImages: [],
        isApproved: false,
      });
    }
    setShowElementModal(true);
  };
  
  // Generate prompt from element info
  const generatePromptFromElement = (type, element) => {
    const timePeriod = project?.timePeriod || '1990s';
    const style = project?.filmStyle || 'cinematic';
    
    let prompt = '';
    
    switch (type) {
      case 'location':
        prompt = `${element.description}, ${timePeriod} era, ${style} style, detailed environment, establishing shot`;
        break;
      case 'prop':
        prompt = `${element.name}, ${element.description}, ${timePeriod} period accurate, product photography, clean white background, detailed`;
        break;
      case 'extra':
        prompt = `${element.description}, ${timePeriod} fashion, background actor, natural pose`;
        break;
      case 'costume':
        prompt = `${element.description}, ${timePeriod} fashion, costume design, detailed fabric textures`;
        break;
      default:
        prompt = `${element.name}, ${element.description}`;
    }
    
    return prompt;
  };
  
  // Generate image for element
  const handleGenerateImage = (elementId, type) => {
    setGeneratingElementId(elementId);
    setIsGenerating(true);
    
    // Simulate API call
    setTimeout(() => {
      const newImage = {
        id: `img-${Date.now()}`,
        url: null, // Would come from API
        generatedAt: new Date(),
      };
      
      // Update the appropriate element
      setScenes(prev => prev.map((scene, idx) => {
        if (idx !== selectedSceneIndex) return scene;
        
        switch (type) {
          case 'location':
            return {
              ...scene,
              location: {
                ...scene.location,
                generatedImages: [...(scene.location.generatedImages || []), newImage],
              },
            };
          case 'prop':
            return {
              ...scene,
              props: scene.props.map(p => 
                p.id === elementId 
                  ? { ...p, generatedImages: [...(p.generatedImages || []), newImage] }
                  : p
              ),
            };
          default:
            return scene;
        }
      }));
      
      setIsGenerating(false);
      setGeneratingElementId(null);
    }, 2000);
  };
  
  // Approve element
  const handleApproveElement = (elementId, type) => {
    setScenes(prev => prev.map((scene, idx) => {
      if (idx !== selectedSceneIndex) return scene;
      
      switch (type) {
        case 'location':
          return { ...scene, location: { ...scene.location, isApproved: true } };
        case 'prop':
          return {
            ...scene,
            props: scene.props.map(p => p.id === elementId ? { ...p, isApproved: true } : p),
          };
        case 'extra':
          return {
            ...scene,
            extras: scene.extras.map(e => e.id === elementId ? { ...e, isApproved: true } : e),
          };
        case 'cast':
          return {
            ...scene,
            cast: scene.cast.map(c => c.characterId === elementId ? { ...c, isApproved: true } : c),
          };
        case 'costume':
          return {
            ...scene,
            cast: scene.cast.map(c => 
              c.costume?.id === elementId 
                ? { ...c, costume: { ...c.costume, isApproved: true } }
                : c
            ),
          };
        default:
          return scene;
      }
    }));
  };
  
  // Save element from modal
  const handleSaveElement = () => {
    setScenes(prev => prev.map((scene, idx) => {
      if (idx !== selectedSceneIndex) return scene;
      
      switch (elementModalType) {
        case 'location':
          return {
            ...scene,
            location: {
              ...scene.location,
              ...elementForm,
            },
          };
        case 'prop':
          if (editingElement) {
            return {
              ...scene,
              props: scene.props.map(p => 
                p.id === editingElement.id ? { ...p, ...elementForm } : p
              ),
            };
          } else {
            return {
              ...scene,
              props: [...scene.props, {
                id: `prop-${Date.now()}`,
                ...elementForm,
                isCritical: true,
                generatedImages: [],
              }],
            };
          }
        case 'extra':
          if (editingElement) {
            return {
              ...scene,
              extras: scene.extras.map(e => 
                e.id === editingElement.id ? { ...e, ...elementForm } : e
              ),
            };
          } else {
            return {
              ...scene,
              extras: [...scene.extras, {
                id: `extra-${Date.now()}`,
                ...elementForm,
                count: '1',
              }],
            };
          }
        default:
          return scene;
      }
    }));
    
    setShowElementModal(false);
    setEditingElement(null);
  };
  
  // Render element avatar
  const renderElementAvatar = (element, type, size = 48) => {
    const isApproved = element?.isApproved;
    const hasImage = element?.generatedImages?.length > 0;
    
    const icons = {
      character: '👤',
      location: '📍',
      prop: '📦',
      extra: '👥',
      costume: '👔',
    };
    
    return (
      <div
        style={{
          width: size,
          height: size,
          borderRadius: type === 'character' ? '50%' : '8px',
          background: hasImage 
            ? 'linear-gradient(135deg, #8b5cf6 0%, #6366f1 100%)'
            : colors.bg.tertiary,
          border: `2px solid ${isApproved ? '#10b981' : '#ef4444'}`,
          display: 'flex',
          alignItems: 'center',
          justifyContent: 'center',
          fontSize: size * 0.4,
          flexShrink: 0,
        }}
      >
        {icons[type] || '?'}
      </div>
    );
  };
  
  // Render element row
  const renderElementRow = (element, type, showCostume = false) => {
    return (
      <div
        key={element.id || element.characterId}
        style={{
          display: 'flex',
          alignItems: 'center',
          gap: '12px',
          padding: '12px',
          background: colors.bg.tertiary,
          borderRadius: '8px',
          marginBottom: '8px',
        }}
      >
        {renderElementAvatar(element, type)}
        
        <div style={{ flex: 1 }}>
          <div style={{ fontSize: '14px', fontWeight: '500', color: colors.text.primary }}>
            {element.name || element.characterName}
          </div>
          {element.description && (
            <div style={{ fontSize: '12px', color: colors.text.tertiary, marginTop: '2px' }}>
              {element.description.slice(0, 50)}{element.description.length > 50 ? '...' : ''}
            </div>
          )}
          {showCostume && element.costume && (
            <div style={{ 
              display: 'flex', 
              alignItems: 'center', 
              gap: '8px', 
              marginTop: '8px',
              padding: '6px 10px',
              background: colors.bg.secondary,
              borderRadius: '6px',
            }}>
              {renderElementAvatar(element.costume, 'costume', 24)}
              <span style={{ fontSize: '12px', color: colors.text.secondary }}>
                {element.costume.name}
              </span>
              <span style={{
                marginLeft: 'auto',
                padding: '2px 8px',
                borderRadius: '4px',
                fontSize: '10px',
                background: element.costume.isApproved ? 'rgba(16,185,129,0.2)' : 'rgba(239,68,68,0.2)',
                color: element.costume.isApproved ? '#10b981' : '#ef4444',
              }}>
                {element.costume.isApproved ? 'Approved' : 'Needs Setup'}
              </span>
            </div>
          )}
        </div>
        
        <div style={{ display: 'flex', alignItems: 'center', gap: '8px' }}>
          {!element.isApproved && element.prompt && (
            <button
              onClick={() => handleApproveElement(element.id || element.characterId, type)}
              style={{
                padding: '6px 12px',
                background: '#10b981',
                border: 'none',
                borderRadius: '6px',
                color: '#fff',
                fontSize: '12px',
                cursor: 'pointer',
              }}
            >
              ✓ Approve
            </button>
          )}
          <button
            onClick={() => openElementModal(type, element)}
            style={{
              padding: '6px 12px',
              background: colors.bg.secondary,
              border: `1px solid ${colors.border.default}`,
              borderRadius: '6px',
              color: colors.text.secondary,
              fontSize: '12px',
              cursor: 'pointer',
            }}
          >
            Edit
          </button>
        </div>
      </div>
    );
  };
  
  return (
    <div style={{ flex: 1, display: 'flex', flexDirection: 'column', overflow: 'hidden' }}>
      {/* Header */}
      <div style={{
        padding: '16px 24px',
        borderBottom: `1px solid ${colors.border.default}`,
        display: 'flex',
        alignItems: 'center',
        justifyContent: 'space-between',
        background: colors.bg.secondary,
      }}>
        <div style={{ display: 'flex', alignItems: 'center', gap: '16px' }}>
          <button
            onClick={onBack}
            style={{ background: 'none', border: 'none', cursor: 'pointer', color: colors.text.secondary }}
          >
            <Icons.ChevronLeft style={{ width: 24, height: 24 }} />
          </button>
          <div>
            <h1 style={{ fontSize: '20px', fontWeight: '600', margin: 0 }}>Scene Builder</h1>
            <p style={{ fontSize: '13px', color: colors.text.secondary, margin: 0 }}>
              Set up cast, locations, props, and extras for each scene
            </p>
          </div>
        </div>
        
        <div style={{ display: 'flex', alignItems: 'center', gap: '12px' }}>
          <div style={{
            padding: '8px 16px',
            background: allScenesComplete ? 'rgba(16,185,129,0.2)' : 'rgba(245,158,11,0.2)',
            color: allScenesComplete ? '#10b981' : '#f59e0b',
            borderRadius: '8px',
            fontSize: '13px',
          }}>
            {allScenesComplete ? '✓ All scenes ready' : `${scenes.filter(s => getSceneCompletionStatus(s).percentage === 100).length}/${scenes.length} scenes complete`}
          </div>
          <Button
            onClick={() => onProceedToStoryboard(scenes)}
            disabled={!allScenesComplete}
            style={{ opacity: allScenesComplete ? 1 : 0.5 }}
          >
            Proceed to Storyboard
            <Icons.ChevronRight style={{ width: 16, height: 16, marginLeft: '6px' }} />
          </Button>
        </div>
      </div>
      
      {/* Main Content */}
      <div style={{ flex: 1, display: 'flex', overflow: 'hidden' }}>
        {/* Scene List (Left) */}
        <div style={{
          width: '280px',
          borderRight: `1px solid ${colors.border.default}`,
          background: colors.bg.primary,
          overflow: 'auto',
          padding: '16px',
        }}>
          <h3 style={{ fontSize: '13px', color: colors.text.tertiary, marginBottom: '12px', fontWeight: '500' }}>
            SCENES ({scenes.length})
          </h3>
          
          {scenes.map((scene, idx) => {
            const status = getSceneCompletionStatus(scene);
            const isSelected = idx === selectedSceneIndex;
            
            return (
              <div
                key={scene.id}
                onClick={() => setSelectedSceneIndex(idx)}
                style={{
                  padding: '12px',
                  background: isSelected ? 'rgba(139,92,246,0.15)' : colors.bg.secondary,
                  border: `2px solid ${isSelected ? colors.accent.primary : colors.border.subtle}`,
                  borderRadius: '12px',
                  marginBottom: '8px',
                  cursor: 'pointer',
                  transition: 'all 0.2s',
                }}
              >
                <div style={{ display: 'flex', alignItems: 'center', justifyContent: 'space-between', marginBottom: '8px' }}>
                  <span style={{ fontSize: '12px', color: colors.text.tertiary }}>Scene {idx + 1}</span>
                  <span style={{
                    padding: '2px 8px',
                    borderRadius: '10px',
                    fontSize: '11px',
                    background: status.percentage === 100 ? 'rgba(16,185,129,0.2)' : 'rgba(245,158,11,0.2)',
                    color: status.percentage === 100 ? '#10b981' : '#f59e0b',
                  }}>
                    {status.percentage}%
                  </span>
                </div>
                <div style={{ fontSize: '14px', fontWeight: '500', color: colors.text.primary, marginBottom: '4px' }}>
                  {scene.title || scene.setting}
                </div>
                <div style={{ fontSize: '11px', color: colors.text.tertiary }}>
                  {scene.cast?.length || 0} cast · {scene.props?.length || 0} props
                </div>
                
                {/* Mini progress bar */}
                <div style={{
                  marginTop: '8px',
                  height: '4px',
                  background: colors.bg.tertiary,
                  borderRadius: '2px',
                  overflow: 'hidden',
                }}>
                  <div style={{
                    width: `${status.percentage}%`,
                    height: '100%',
                    background: status.percentage === 100 ? '#10b981' : '#f59e0b',
                    transition: 'width 0.3s',
                  }} />
                </div>
              </div>
            );
          })}
        </div>
        
        {/* Scene Detail (Right) */}
        <div style={{ flex: 1, overflow: 'auto', background: colors.bg.primary, padding: '24px' }}>
          {currentScene ? (
            <>
              {/* Scene Header */}
              <div style={{
                background: colors.bg.secondary,
                borderRadius: '16px',
                padding: '20px',
                marginBottom: '24px',
              }}>
                <div style={{ display: 'flex', gap: '24px' }}>
                  {/* Left: Setting & Script */}
                  <div style={{ flex: 1 }}>
                    <div style={{
                      padding: '8px 12px',
                      background: colors.bg.tertiary,
                      borderRadius: '8px',
                      marginBottom: '12px',
                      fontFamily: 'monospace',
                      fontSize: '14px',
                      color: colors.text.primary,
                    }}>
                      {currentScene.setting}
                    </div>
                    
                    <p style={{ color: colors.text.secondary, fontSize: '14px', marginBottom: '16px' }}>
                      {currentScene.description}
                    </p>
                    
                    {/* Script excerpt */}
                    <div style={{
                      padding: '16px',
                      background: colors.bg.tertiary,
                      borderRadius: '8px',
                      fontFamily: 'monospace',
                      fontSize: '12px',
                      color: colors.text.secondary,
                      whiteSpace: 'pre-wrap',
                      maxHeight: '200px',
                      overflow: 'auto',
                    }}>
                      {currentScene.script || 'No script excerpt available'}
                    </div>
                  </div>
                  
                  {/* Right: Quick Status */}
                  <div style={{ width: '200px' }}>
                    <h4 style={{ fontSize: '12px', color: colors.text.tertiary, marginBottom: '12px' }}>SCENE STATUS</h4>
                    
                    {[
                      { label: 'Cast', count: currentScene.cast?.length || 0, approved: currentScene.cast?.filter(c => c.isApproved).length || 0 },
                      { label: 'Location', count: 1, approved: currentScene.location?.isApproved ? 1 : 0 },
                      { label: 'Props', count: currentScene.props?.filter(p => p.isCritical).length || 0, approved: currentScene.props?.filter(p => p.isCritical && p.isApproved).length || 0 },
                      { label: 'Extras', count: currentScene.extras?.length || 0, approved: currentScene.extras?.filter(e => e.isApproved).length || 0 },
                    ].map(item => (
                      <div key={item.label} style={{
                        display: 'flex',
                        alignItems: 'center',
                        justifyContent: 'space-between',
                        padding: '8px 0',
                        borderBottom: `1px solid ${colors.border.subtle}`,
                      }}>
                        <span style={{ fontSize: '13px', color: colors.text.secondary }}>{item.label}</span>
                        <span style={{
                          fontSize: '13px',
                          color: item.count === item.approved ? '#10b981' : '#f59e0b',
                        }}>
                          {item.approved}/{item.count}
                        </span>
                      </div>
                    ))}
                  </div>
                </div>
              </div>
              
              {/* Elements Sections */}
              <div style={{ display: 'grid', gridTemplateColumns: '1fr 1fr', gap: '24px' }}>
                {/* Cast */}
                <div style={{
                  background: colors.bg.secondary,
                  borderRadius: '12px',
                  padding: '20px',
                }}>
                  <div style={{ display: 'flex', alignItems: 'center', justifyContent: 'space-between', marginBottom: '16px' }}>
                    <h3 style={{ fontSize: '15px', fontWeight: '600', color: colors.text.primary, display: 'flex', alignItems: 'center', gap: '8px' }}>
                      👤 Cast
                      <span style={{ fontSize: '12px', color: colors.text.tertiary, fontWeight: '400' }}>
                        ({currentScene.cast?.length || 0})
                      </span>
                    </h3>
                  </div>
                  
                  {(currentScene.cast || []).map(castMember => renderElementRow(castMember, 'cast', true))}
                  
                  {(!currentScene.cast || currentScene.cast.length === 0) && (
                    <div style={{ textAlign: 'center', padding: '20px', color: colors.text.tertiary }}>
                      No cast assigned to this scene
                    </div>
                  )}
                </div>
                
                {/* Location */}
                <div style={{
                  background: colors.bg.secondary,
                  borderRadius: '12px',
                  padding: '20px',
                }}>
                  <div style={{ display: 'flex', alignItems: 'center', justifyContent: 'space-between', marginBottom: '16px' }}>
                    <h3 style={{ fontSize: '15px', fontWeight: '600', color: colors.text.primary, display: 'flex', alignItems: 'center', gap: '8px' }}>
                      📍 Location
                    </h3>
                    <button
                      onClick={() => handleGenerateImage(currentScene.location?.id, 'location')}
                      disabled={isGenerating || !currentScene.location?.prompt}
                      style={{
                        padding: '6px 12px',
                        background: 'linear-gradient(135deg, #8b5cf6 0%, #6366f1 100%)',
                        border: 'none',
                        borderRadius: '6px',
                        color: '#fff',
                        fontSize: '12px',
                        cursor: currentScene.location?.prompt ? 'pointer' : 'not-allowed',
                        opacity: currentScene.location?.prompt ? 1 : 0.5,
                      }}
                    >
                      {isGenerating && generatingElementId === currentScene.location?.id ? 'Generating...' : '✨ Generate'}
                    </button>
                  </div>
                  
                  {currentScene.location && renderElementRow(currentScene.location, 'location')}
                </div>
                
                {/* Props */}
                <div style={{
                  background: colors.bg.secondary,
                  borderRadius: '12px',
                  padding: '20px',
                }}>
                  <div style={{ display: 'flex', alignItems: 'center', justifyContent: 'space-between', marginBottom: '16px' }}>
                    <h3 style={{ fontSize: '15px', fontWeight: '600', color: colors.text.primary, display: 'flex', alignItems: 'center', gap: '8px' }}>
                      📦 Props
                      <span style={{ fontSize: '12px', color: colors.text.tertiary, fontWeight: '400' }}>
                        ({currentScene.props?.length || 0})
                      </span>
                    </h3>
                    <button
                      onClick={() => openElementModal('prop')}
                      style={{
                        padding: '6px 12px',
                        background: colors.bg.tertiary,
                        border: `1px solid ${colors.border.default}`,
                        borderRadius: '6px',
                        color: colors.text.secondary,
                        fontSize: '12px',
                        cursor: 'pointer',
                      }}
                    >
                      + Add Prop
                    </button>
                  </div>
                  
                  {(currentScene.props || []).map(prop => renderElementRow(prop, 'prop'))}
                  
                  {(!currentScene.props || currentScene.props.length === 0) && (
                    <div style={{ textAlign: 'center', padding: '20px', color: colors.text.tertiary }}>
                      No props in this scene
                    </div>
                  )}
                </div>
                
                {/* Extras */}
                <div style={{
                  background: colors.bg.secondary,
                  borderRadius: '12px',
                  padding: '20px',
                }}>
                  <div style={{ display: 'flex', alignItems: 'center', justifyContent: 'space-between', marginBottom: '16px' }}>
                    <h3 style={{ fontSize: '15px', fontWeight: '600', color: colors.text.primary, display: 'flex', alignItems: 'center', gap: '8px' }}>
                      👥 Extras
                      <span style={{ fontSize: '12px', color: colors.text.tertiary, fontWeight: '400' }}>
                        ({currentScene.extras?.length || 0})
                      </span>
                    </h3>
                    <button
                      onClick={() => openElementModal('extra')}
                      style={{
                        padding: '6px 12px',
                        background: colors.bg.tertiary,
                        border: `1px solid ${colors.border.default}`,
                        borderRadius: '6px',
                        color: colors.text.secondary,
                        fontSize: '12px',
                        cursor: 'pointer',
                      }}
                    >
                      + Add Extra
                    </button>
                  </div>
                  
                  {(currentScene.extras || []).map(extra => renderElementRow(extra, 'extra'))}
                  
                  {(!currentScene.extras || currentScene.extras.length === 0) && (
                    <div style={{ textAlign: 'center', padding: '20px', color: colors.text.tertiary }}>
                      No extras in this scene
                    </div>
                  )}
                </div>
              </div>
            </>
          ) : (
            <div style={{
              height: '100%',
              display: 'flex',
              alignItems: 'center',
              justifyContent: 'center',
              color: colors.text.tertiary,
            }}>
              Select a scene to view details
            </div>
          )}
        </div>
      </div>
      
      {/* Element Edit Modal */}
      {showElementModal && (
        <div style={{
          position: 'fixed',
          top: 0,
          left: 0,
          right: 0,
          bottom: 0,
          background: 'rgba(0,0,0,0.8)',
          display: 'flex',
          alignItems: 'center',
          justifyContent: 'center',
          zIndex: 1000,
        }}>
          <div style={{
            width: '600px',
            maxHeight: '80vh',
            background: colors.bg.secondary,
            borderRadius: '16px',
            overflow: 'hidden',
            display: 'flex',
            flexDirection: 'column',
          }}>
            {/* Header */}
            <div style={{
              padding: '16px 24px',
              borderBottom: `1px solid ${colors.border.default}`,
              display: 'flex',
              alignItems: 'center',
              justifyContent: 'space-between',
            }}>
              <h3 style={{ fontSize: '18px', fontWeight: '600', margin: 0 }}>
                {editingElement ? 'Edit' : 'Add'} {elementModalType?.charAt(0).toUpperCase() + elementModalType?.slice(1)}
              </h3>
              <button
                onClick={() => setShowElementModal(false)}
                style={{ background: 'none', border: 'none', cursor: 'pointer', color: colors.text.secondary }}
              >
                <Icons.X style={{ width: 20, height: 20 }} />
              </button>
            </div>
            
            {/* Content */}
            <div style={{ padding: '24px', overflow: 'auto' }}>
              <div style={{ marginBottom: '16px' }}>
                <label style={{ display: 'block', fontSize: '13px', color: colors.text.secondary, marginBottom: '6px' }}>Name</label>
                <input
                  type="text"
                  value={elementForm.name}
                  onChange={(e) => setElementForm(prev => ({ ...prev, name: e.target.value }))}
                  placeholder={`Enter ${elementModalType} name`}
                  style={{
                    width: '100%',
                    padding: '12px',
                    background: colors.bg.tertiary,
                    border: `1px solid ${colors.border.default}`,
                    borderRadius: '8px',
                    color: colors.text.primary,
                    fontSize: '14px',
                  }}
                />
              </div>
              
              <div style={{ marginBottom: '16px' }}>
                <label style={{ display: 'block', fontSize: '13px', color: colors.text.secondary, marginBottom: '6px' }}>Description</label>
                <textarea
                  value={elementForm.description}
                  onChange={(e) => setElementForm(prev => ({ ...prev, description: e.target.value }))}
                  placeholder="Describe this element in detail..."
                  style={{
                    width: '100%',
                    padding: '12px',
                    background: colors.bg.tertiary,
                    border: `1px solid ${colors.border.default}`,
                    borderRadius: '8px',
                    color: colors.text.primary,
                    fontSize: '14px',
                    minHeight: '80px',
                    resize: 'vertical',
                  }}
                />
              </div>
              
              <div style={{ marginBottom: '16px' }}>
                <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center', marginBottom: '6px' }}>
                  <label style={{ fontSize: '13px', color: colors.text.secondary }}>Generation Prompt</label>
                  <button
                    onClick={() => {
                      const autoPrompt = generatePromptFromElement(elementModalType, elementForm);
                      setElementForm(prev => ({ ...prev, prompt: autoPrompt }));
                    }}
                    style={{
                      padding: '4px 10px',
                      background: colors.accent.primary,
                      border: 'none',
                      borderRadius: '4px',
                      color: '#fff',
                      fontSize: '11px',
                      cursor: 'pointer',
                    }}
                  >
                    ✨ Auto-generate
                  </button>
                </div>
                <textarea
                  value={elementForm.prompt}
                  onChange={(e) => setElementForm(prev => ({ ...prev, prompt: e.target.value }))}
                  placeholder="Enter prompt for image generation..."
                  style={{
                    width: '100%',
                    padding: '12px',
                    background: colors.bg.tertiary,
                    border: `1px solid ${colors.border.default}`,
                    borderRadius: '8px',
                    color: colors.text.primary,
                    fontSize: '14px',
                    minHeight: '100px',
                    resize: 'vertical',
                  }}
                />
              </div>
              
              <div style={{ marginBottom: '16px' }}>
                <label style={{ display: 'block', fontSize: '13px', color: colors.text.secondary, marginBottom: '6px' }}>
                  Time Period / Era Notes
                </label>
                <input
                  type="text"
                  value={elementForm.timePeriodNotes}
                  onChange={(e) => setElementForm(prev => ({ ...prev, timePeriodNotes: e.target.value }))}
                  placeholder="e.g., Must be period-accurate to 1990s"
                  style={{
                    width: '100%',
                    padding: '10px 12px',
                    background: colors.bg.tertiary,
                    border: `1px solid ${colors.border.default}`,
                    borderRadius: '8px',
                    color: colors.text.primary,
                    fontSize: '14px',
                  }}
                />
              </div>
              
              {/* Reference Images */}
              <div style={{ marginBottom: '16px' }}>
                <label style={{ display: 'block', fontSize: '13px', color: colors.text.secondary, marginBottom: '6px' }}>
                  Reference Images
                </label>
                <div style={{
                  padding: '24px',
                  background: colors.bg.tertiary,
                  borderRadius: '8px',
                  border: `2px dashed ${colors.border.default}`,
                  textAlign: 'center',
                  cursor: 'pointer',
                }}>
                  <Icons.Upload style={{ width: 24, height: 24, color: colors.text.tertiary, marginBottom: '8px' }} />
                  <p style={{ color: colors.text.tertiary, fontSize: '13px', margin: 0 }}>Drop images or click to upload</p>
                </div>
              </div>
            </div>
            
            {/* Footer */}
            <div style={{
              padding: '16px 24px',
              borderTop: `1px solid ${colors.border.default}`,
              display: 'flex',
              justifyContent: 'flex-end',
              gap: '12px',
            }}>
              <Button variant="secondary" onClick={() => setShowElementModal(false)}>
                Cancel
              </Button>
              <Button onClick={handleSaveElement} disabled={!elementForm.name.trim()}>
                {editingElement ? 'Save Changes' : 'Add Element'}
              </Button>
            </div>
          </div>
        </div>
      )}
      
      <style>{`
        @keyframes spin {
          to { transform: rotate(360deg); }
        }
      `}</style>
    </div>
  );
};

// ============================================================================
// STORYBOARD VIEW - Visual shot-by-shot storyboard
// ============================================================================
const StoryboardView = ({ project, episode, onUpdateProject, onBack, onNavigateToRoughCut }) => {
  const [selectedScene, setSelectedScene] = useState(0);
  const [selectedShot, setSelectedShot] = useState(null);
  const [isGenerating, setIsGenerating] = useState(null); // shotId being generated
  const [generatedImages, setGeneratedImages] = useState({});
  const [showPreviewModal, setShowPreviewModal] = useState(false);
  
  // Guard clauses
  if (!project) {
    return (
      <div style={{ flex: 1, display: 'flex', alignItems: 'center', justifyContent: 'center' }}>
        <div style={{ textAlign: 'center' }}>
          <Icons.AlertCircle style={{ width: 48, height: 48, color: colors.text.tertiary, marginBottom: '16px' }} />
          <h2 style={{ fontSize: '18px', marginBottom: '8px' }}>No Project Selected</h2>
          <p style={{ color: colors.text.secondary, marginBottom: '20px' }}>Please select a project first</p>
          <Button onClick={onBack}>Go Back</Button>
        </div>
      </div>
    );
  }
  
  // Get the episode to display - either passed episode or first episode with scenes
  const displayEpisode = episode || project.episodes?.find(ep => ep.scenes?.length > 0) || project.episodes?.[0];
  
  if (!displayEpisode) {
    return (
      <div style={{ flex: 1, display: 'flex', alignItems: 'center', justifyContent: 'center' }}>
        <div style={{ textAlign: 'center' }}>
          <Icons.Film style={{ width: 48, height: 48, color: colors.text.tertiary, marginBottom: '16px' }} />
          <h2 style={{ fontSize: '18px', marginBottom: '8px' }}>No Episodes Available</h2>
          <p style={{ color: colors.text.secondary, marginBottom: '20px' }}>Create episodes in Episode Setup first</p>
          <Button onClick={onBack}>Go to Episode Setup</Button>
        </div>
      </div>
    );
  }
  
  const scenes = displayEpisode.scenes || [];
  const currentScene = scenes[selectedScene];
  const shots = currentScene?.shots || [];
  
  if (scenes.length === 0) {
    return (
      <div style={{ flex: 1, display: 'flex', alignItems: 'center', justifyContent: 'center' }}>
        <div style={{ textAlign: 'center' }}>
          <Icons.Layout style={{ width: 48, height: 48, color: colors.text.tertiary, marginBottom: '16px' }} />
          <h2 style={{ fontSize: '18px', marginBottom: '8px' }}>No Scenes Yet</h2>
          <p style={{ color: colors.text.secondary, marginBottom: '20px' }}>
            Generate a scene breakdown in Episode Setup to populate the storyboard
          </p>
          <Button onClick={onBack}>Go to Episode Setup</Button>
        </div>
      </div>
    );
  }
  
  const handleGenerateImage = (shot) => {
    setIsGenerating(shot.id);
    
    // Simulate image generation
    setTimeout(() => {
      // Create a placeholder gradient as "generated image"
      const gradients = [
        'linear-gradient(135deg, #667eea 0%, #764ba2 100%)',
        'linear-gradient(135deg, #f093fb 0%, #f5576c 100%)',
        'linear-gradient(135deg, #4facfe 0%, #00f2fe 100%)',
        'linear-gradient(135deg, #43e97b 0%, #38f9d7 100%)',
        'linear-gradient(135deg, #fa709a 0%, #fee140 100%)',
        'linear-gradient(135deg, #a18cd1 0%, #fbc2eb 100%)',
      ];
      const randomGradient = gradients[Math.floor(Math.random() * gradients.length)];
      
      setGeneratedImages(prev => ({
        ...prev,
        [shot.id]: {
          gradient: randomGradient,
          generatedAt: new Date().toISOString(),
          prompt: `${currentScene?.title || 'Scene'}: ${shot.description || 'Shot'}`,
        }
      }));
      setIsGenerating(null);
    }, 2000);
  };
  
  const handleGenerateVideo = (shot) => {
    // Similar to image but for video
    setIsGenerating(shot.id + '-video');
    setTimeout(() => {
      setGeneratedImages(prev => ({
        ...prev,
        [shot.id]: {
          ...prev[shot.id],
          hasVideo: true,
          videoGeneratedAt: new Date().toISOString(),
        }
      }));
      setIsGenerating(null);
    }, 3000);
  };
  
  // Shot Card Component
  const ShotCard = ({ shot, index, isSelected, onClick }) => {
    const generated = generatedImages[shot.id];
    const isGeneratingThis = isGenerating === shot.id || isGenerating === shot.id + '-video';
    
    return (
      <div
        onClick={onClick}
        style={{
          background: colors.bg.secondary,
          borderRadius: '12px',
          border: `2px solid ${isSelected ? colors.accent.primary : colors.border.subtle}`,
          overflow: 'hidden',
          cursor: 'pointer',
          transition: 'all 0.2s ease',
          position: 'relative',
        }}
      >
        {/* Continuity Indicator */}
        {shot.continuity && index > 0 && (
          <div style={{
            position: 'absolute',
            top: '-12px',
            left: '50%',
            transform: 'translateX(-50%)',
            background: colors.accent.primary,
            color: '#fff',
            width: '24px',
            height: '24px',
            borderRadius: '50%',
            display: 'flex',
            alignItems: 'center',
            justifyContent: 'center',
            fontSize: '14px',
            fontWeight: '600',
            zIndex: 10,
            border: `2px solid ${colors.bg.primary}`,
          }}>
            ∞
          </div>
        )}
        
        {/* Image/Placeholder Area */}
        <div style={{
          aspectRatio: '16/9',
          background: generated?.gradient || colors.bg.tertiary,
          display: 'flex',
          alignItems: 'center',
          justifyContent: 'center',
          position: 'relative',
        }}>
          {isGeneratingThis ? (
            <div style={{ textAlign: 'center' }}>
              <div style={{
                width: '32px',
                height: '32px',
                border: `3px solid ${colors.accent.primary}`,
                borderTopColor: 'transparent',
                borderRadius: '50%',
                animation: 'spin 1s linear infinite',
                margin: '0 auto 8px',
              }} />
              <span style={{ fontSize: '12px', color: colors.text.secondary }}>
                {isGenerating?.includes('-video') ? 'Generating video...' : 'Generating image...'}
              </span>
            </div>
          ) : generated ? (
            <>
              {generated.hasVideo && (
                <div style={{
                  position: 'absolute',
                  top: '8px',
                  right: '8px',
                  background: colors.accent.success,
                  color: '#fff',
                  padding: '4px 8px',
                  borderRadius: '4px',
                  fontSize: '10px',
                  fontWeight: '600',
                }}>
                  VIDEO
                </div>
              )}
              <Icons.Image style={{ width: 32, height: 32, color: '#fff', opacity: 0.8 }} />
            </>
          ) : (
            <div style={{ textAlign: 'center', color: colors.text.tertiary }}>
              <Icons.Image style={{ width: 32, height: 32, marginBottom: '8px' }} />
              <div style={{ fontSize: '12px' }}>Click to generate</div>
            </div>
          )}
        </div>
        
        {/* Shot Info */}
        <div style={{ padding: '12px' }}>
          <div style={{ display: 'flex', alignItems: 'center', justifyContent: 'space-between', marginBottom: '4px' }}>
            <span style={{ fontSize: '12px', fontWeight: '600', color: colors.text.secondary }}>
              Shot {index + 1}
            </span>
            <span style={{ fontSize: '11px', color: colors.text.tertiary }}>
              {shot.duration}s · {shot.type}
            </span>
          </div>
          <div style={{ fontSize: '13px', color: colors.text.primary, lineHeight: '1.4' }}>
            {shot.description || 'No description'}
          </div>
        </div>
      </div>
    );
  };
  
  return (
    <div style={{ flex: 1, display: 'flex', flexDirection: 'column', overflow: 'hidden' }}>
      {/* Add keyframe animation for spinner */}
      <style>{`
        @keyframes spin {
          to { transform: rotate(360deg); }
        }
      `}</style>
      
      {/* Header */}
      <div style={{
        padding: '16px 24px',
        borderBottom: `1px solid ${colors.border.subtle}`,
        background: colors.bg.primary,
        display: 'flex',
        alignItems: 'center',
        justifyContent: 'space-between',
      }}>
        <div style={{ display: 'flex', alignItems: 'center', gap: '16px' }}>
          <button
            onClick={onBack}
            style={{
              background: 'none',
              border: 'none',
              color: colors.text.secondary,
              cursor: 'pointer',
              display: 'flex',
              alignItems: 'center',
              gap: '8px',
              fontSize: '14px',
            }}
          >
            <Icons.ChevronLeft style={{ width: 20, height: 20 }} />
            Back
          </button>
          <div style={{ height: '24px', width: '1px', background: colors.border.subtle }} />
          <div>
            <h1 style={{ fontSize: '18px', fontWeight: '600', marginBottom: '2px' }}>
              {displayEpisode.title || 'Untitled Episode'}
            </h1>
            <span style={{ fontSize: '13px', color: colors.text.secondary }}>
              {project.projectType === 'series' 
                ? `S${displayEpisode.seasonNumber} E${displayEpisode.episodeNumber}`
                : project.title
              } · {scenes.length} scenes · {shots.length} shots in current scene
            </span>
          </div>
        </div>
        
        <div style={{ display: 'flex', gap: '12px' }}>
          <Button 
            onClick={() => setShowPreviewModal(true)}
            style={{
              background: 'linear-gradient(135deg, #8b5cf6 0%, #a855f7 100%)',
              boxShadow: '0 4px 15px rgba(139, 92, 246, 0.3)',
            }}
          >
            <Icons.Play style={{ width: 14, height: 14, marginRight: '6px' }} />
            Preview
          </Button>
        </div>
      </div>
      
      {/* Main Content */}
      <div style={{ flex: 1, display: 'flex', overflow: 'hidden' }}>
        {/* Left Sidebar - Scene List & Script */}
        <div style={{
          width: '280px',
          borderRight: `1px solid ${colors.border.subtle}`,
          background: colors.bg.primary,
          display: 'flex',
          flexDirection: 'column',
          overflow: 'hidden',
        }}>
          {/* Scene Tabs */}
          <div style={{
            padding: '16px',
            borderBottom: `1px solid ${colors.border.subtle}`,
          }}>
            <div style={{ fontSize: '12px', fontWeight: '600', color: colors.text.tertiary, marginBottom: '12px', textTransform: 'uppercase' }}>
              Scenes
            </div>
            <div style={{ display: 'flex', flexDirection: 'column', gap: '8px' }}>
              {scenes.map((scene, idx) => (
                <button
                  key={scene.id}
                  onClick={() => {
                    setSelectedScene(idx);
                    setSelectedShot(null);
                  }}
                  style={{
                    padding: '12px',
                    background: selectedScene === idx ? colors.bg.tertiary : 'transparent',
                    border: `1px solid ${selectedScene === idx ? colors.accent.primary : colors.border.subtle}`,
                    borderRadius: '8px',
                    cursor: 'pointer',
                    textAlign: 'left',
                  }}
                >
                  <div style={{ fontSize: '13px', fontWeight: '600', color: colors.text.primary, marginBottom: '4px' }}>
                    Scene {idx + 1}: {scene.title}
                  </div>
                  <div style={{ fontSize: '11px', color: colors.text.tertiary }}>
                    {scene.shots?.length || 0} shots
                  </div>
                </button>
              ))}
            </div>
          </div>
          
          {/* Scene Description */}
          <div style={{ flex: 1, padding: '16px', overflow: 'auto' }}>
            <div style={{ fontSize: '12px', fontWeight: '600', color: colors.text.tertiary, marginBottom: '8px', textTransform: 'uppercase' }}>
              Scene Description
            </div>
            <p style={{ fontSize: '13px', color: colors.text.secondary, lineHeight: '1.6' }}>
              {currentScene?.description || 'No description available'}
            </p>
            
            {displayEpisode.script && (
              <>
                <div style={{ fontSize: '12px', fontWeight: '600', color: colors.text.tertiary, marginBottom: '8px', marginTop: '20px', textTransform: 'uppercase' }}>
                  Script Excerpt
                </div>
                <div style={{
                  fontSize: '12px',
                  color: colors.text.secondary,
                  lineHeight: '1.6',
                  fontFamily: 'monospace',
                  background: colors.bg.secondary,
                  padding: '12px',
                  borderRadius: '8px',
                  maxHeight: '200px',
                  overflow: 'auto',
                  whiteSpace: 'pre-wrap',
                }}>
                  {displayEpisode.script.slice(0, 500)}...
                </div>
              </>
            )}
          </div>
        </div>
        
        {/* Main Storyboard Area */}
        <div style={{ flex: 1, overflow: 'auto', padding: '24px', background: colors.bg.secondary }}>
          <div style={{ marginBottom: '20px' }}>
            <h2 style={{ fontSize: '16px', fontWeight: '600', marginBottom: '4px' }}>
              Scene {selectedScene + 1}: {currentScene?.title}
            </h2>
            <p style={{ fontSize: '13px', color: colors.text.secondary }}>
              Click on a shot to select it, then use the panel on the right to generate images and video
            </p>
          </div>
          
          {/* Shots Grid */}
          <div style={{
            display: 'grid',
            gridTemplateColumns: 'repeat(auto-fill, minmax(280px, 1fr))',
            gap: '24px',
          }}>
            {shots.map((shot, idx) => (
              <ShotCard
                key={shot.id}
                shot={shot}
                index={idx}
                isSelected={selectedShot?.id === shot.id}
                onClick={() => setSelectedShot(shot)}
              />
            ))}
            
            {/* Add Shot Button */}
            <div
              style={{
                background: colors.bg.primary,
                borderRadius: '12px',
                border: `2px dashed ${colors.border.default}`,
                display: 'flex',
                alignItems: 'center',
                justifyContent: 'center',
                minHeight: '200px',
                cursor: 'pointer',
                transition: 'all 0.2s ease',
              }}
              onClick={() => {
                // Add new shot logic
                console.log('Add new shot');
              }}
            >
              <div style={{ textAlign: 'center', color: colors.text.tertiary }}>
                <Icons.Plus style={{ width: 24, height: 24, marginBottom: '8px' }} />
                <div style={{ fontSize: '13px' }}>Add Shot</div>
              </div>
            </div>
          </div>
        </div>
        
        {/* Right Sidebar - Shot Details & Generation */}
        <div style={{
          width: '320px',
          borderLeft: `1px solid ${colors.border.subtle}`,
          background: colors.bg.primary,
          display: 'flex',
          flexDirection: 'column',
          overflow: 'hidden',
        }}>
          {selectedShot ? (
            <>
              {/* Shot Preview */}
              <div style={{
                aspectRatio: '16/9',
                background: generatedImages[selectedShot.id]?.gradient || colors.bg.tertiary,
                display: 'flex',
                alignItems: 'center',
                justifyContent: 'center',
              }}>
                {generatedImages[selectedShot.id] ? (
                  <Icons.Image style={{ width: 48, height: 48, color: '#fff', opacity: 0.8 }} />
                ) : (
                  <Icons.Image style={{ width: 48, height: 48, color: colors.text.tertiary }} />
                )}
              </div>
              
              {/* Shot Info */}
              <div style={{ flex: 1, overflow: 'auto', padding: '20px' }}>
                <div style={{ marginBottom: '20px' }}>
                  <div style={{ fontSize: '12px', color: colors.text.tertiary, marginBottom: '4px' }}>
                    Shot {shots.findIndex(s => s.id === selectedShot.id) + 1} of {shots.length}
                  </div>
                  <h3 style={{ fontSize: '16px', fontWeight: '600', marginBottom: '8px' }}>
                    {selectedShot.type?.charAt(0).toUpperCase() + selectedShot.type?.slice(1)} Shot
                  </h3>
                  <p style={{ fontSize: '13px', color: colors.text.secondary, lineHeight: '1.5' }}>
                    {selectedShot.description || 'No description'}
                  </p>
                </div>
                
                <div style={{ display: 'grid', gridTemplateColumns: '1fr 1fr', gap: '12px', marginBottom: '20px' }}>
                  <div style={{ background: colors.bg.secondary, padding: '12px', borderRadius: '8px' }}>
                    <div style={{ fontSize: '11px', color: colors.text.tertiary, marginBottom: '4px' }}>Duration</div>
                    <div style={{ fontSize: '14px', fontWeight: '600' }}>{selectedShot.duration}s</div>
                  </div>
                  <div style={{ background: colors.bg.secondary, padding: '12px', borderRadius: '8px' }}>
                    <div style={{ fontSize: '11px', color: colors.text.tertiary, marginBottom: '4px' }}>Type</div>
                    <div style={{ fontSize: '14px', fontWeight: '600' }}>{selectedShot.type}</div>
                  </div>
                </div>
                
                {selectedShot.continuity && (
                  <div style={{
                    background: `${colors.accent.primary}20`,
                    border: `1px solid ${colors.accent.primary}`,
                    borderRadius: '8px',
                    padding: '12px',
                    marginBottom: '20px',
                    display: 'flex',
                    alignItems: 'center',
                    gap: '8px',
                  }}>
                    <span style={{ fontSize: '18px' }}>∞</span>
                    <span style={{ fontSize: '13px', color: colors.accent.primary }}>
                      Continuity shot - linked to previous
                    </span>
                  </div>
                )}
                
                {/* Generation Buttons */}
                <div style={{ display: 'flex', flexDirection: 'column', gap: '12px' }}>
                  <Button
                    onClick={() => handleGenerateImage(selectedShot)}
                    disabled={isGenerating === selectedShot.id}
                    style={{ width: '100%' }}
                  >
                    {isGenerating === selectedShot.id ? (
                      'Generating Image...'
                    ) : generatedImages[selectedShot.id] ? (
                      <>
                        <Icons.RefreshCw style={{ width: 14, height: 14, marginRight: '8px' }} />
                        Regenerate Image
                      </>
                    ) : (
                      <>
                        <Icons.Sparkles style={{ width: 14, height: 14, marginRight: '8px' }} />
                        Generate Image
                      </>
                    )}
                  </Button>
                  
                  {generatedImages[selectedShot.id] && (
                    <Button
                      variant="secondary"
                      onClick={() => handleGenerateVideo(selectedShot)}
                      disabled={isGenerating === selectedShot.id + '-video'}
                      style={{ width: '100%' }}
                    >
                      {isGenerating === selectedShot.id + '-video' ? (
                        'Generating Video...'
                      ) : generatedImages[selectedShot.id]?.hasVideo ? (
                        <>
                          <Icons.RefreshCw style={{ width: 14, height: 14, marginRight: '8px' }} />
                          Regenerate Video
                        </>
                      ) : (
                        <>
                          <Icons.Film style={{ width: 14, height: 14, marginRight: '8px' }} />
                          Generate Video
                        </>
                      )}
                    </Button>
                  )}
                </div>
                
                {generatedImages[selectedShot.id] && (
                  <div style={{ marginTop: '20px', fontSize: '12px', color: colors.text.tertiary }}>
                    <div>Image generated: {new Date(generatedImages[selectedShot.id].generatedAt).toLocaleTimeString()}</div>
                    {generatedImages[selectedShot.id].hasVideo && (
                      <div>Video generated: {new Date(generatedImages[selectedShot.id].videoGeneratedAt).toLocaleTimeString()}</div>
                    )}
                  </div>
                )}
                
                {/* Proceed to Rough Cut button */}
                <div style={{ marginTop: '24px', paddingTop: '20px', borderTop: `1px solid ${colors.border.subtle}` }}>
                  <Button
                    onClick={() => onNavigateToRoughCut && onNavigateToRoughCut(displayEpisode)}
                    style={{ width: '100%' }}
                  >
                    <Icons.Scissors style={{ width: 14, height: 14, marginRight: '8px' }} />
                    Proceed to Rough Cut
                  </Button>
                  <p style={{ fontSize: '11px', color: colors.text.tertiary, marginTop: '8px', textAlign: 'center' }}>
                    Assemble your shots into a timeline
                  </p>
                </div>
              </div>
            </>
          ) : (
            <div style={{ flex: 1, display: 'flex', alignItems: 'center', justifyContent: 'center', padding: '20px' }}>
              <div style={{ textAlign: 'center', color: colors.text.tertiary }}>
                <Icons.MousePointer style={{ width: 32, height: 32, marginBottom: '12px', opacity: 0.5 }} />
                <p style={{ fontSize: '14px' }}>Select a shot to view details and generate content</p>
              </div>
            </div>
          )}
        </div>
      </div>
      
      {/* Preview Modal */}
      {showPreviewModal && (
        <div style={{
          position: 'fixed',
          top: 0,
          left: 0,
          right: 0,
          bottom: 0,
          background: 'rgba(0,0,0,0.9)',
          display: 'flex',
          alignItems: 'center',
          justifyContent: 'center',
          zIndex: 1000,
        }}>
          <div style={{
            width: '90%',
            maxWidth: '1200px',
            background: colors.bg.secondary,
            borderRadius: '16px',
            overflow: 'hidden',
          }}>
            {/* Header */}
            <div style={{
              padding: '16px 24px',
              borderBottom: `1px solid ${colors.border.default}`,
              display: 'flex',
              justifyContent: 'space-between',
              alignItems: 'center',
            }}>
              <h2 style={{ fontSize: '18px', fontWeight: '600' }}>
                <Icons.Play style={{ width: 20, height: 20, marginRight: '8px', display: 'inline' }} />
                Storyboard Preview
              </h2>
              <button
                onClick={() => setShowPreviewModal(false)}
                style={{
                  padding: '8px',
                  background: 'none',
                  border: 'none',
                  color: colors.text.secondary,
                  cursor: 'pointer',
                  fontSize: '24px',
                }}
              >×</button>
            </div>
            
            {/* Preview Content */}
            <div style={{ padding: '24px' }}>
              {/* Main Preview Area */}
              <div style={{
                aspectRatio: '16/9',
                background: colors.bg.tertiary,
                borderRadius: '12px',
                display: 'flex',
                alignItems: 'center',
                justifyContent: 'center',
                marginBottom: '20px',
                position: 'relative',
                overflow: 'hidden',
              }}>
                {currentScene && generatedImages[shots[0]?.id] ? (
                  <div style={{
                    width: '100%',
                    height: '100%',
                    background: generatedImages[shots[0]?.id]?.gradient || colors.bg.tertiary,
                    display: 'flex',
                    alignItems: 'center',
                    justifyContent: 'center',
                  }}>
                    <div style={{ textAlign: 'center', color: '#fff' }}>
                      <Icons.Play style={{ width: 64, height: 64, opacity: 0.8 }} />
                      <div style={{ marginTop: '12px', fontSize: '14px' }}>Scene {selectedScene + 1}: {currentScene.title}</div>
                    </div>
                  </div>
                ) : (
                  <div style={{ textAlign: 'center', color: colors.text.tertiary }}>
                    <Icons.Film style={{ width: 48, height: 48, marginBottom: '12px', opacity: 0.5 }} />
                    <p>Generate images for shots to see preview</p>
                  </div>
                )}
              </div>
              
              {/* Shot Thumbnails Strip */}
              <div style={{
                display: 'flex',
                gap: '12px',
                overflowX: 'auto',
                paddingBottom: '8px',
              }}>
                {scenes.flatMap((scene, sceneIdx) => 
                  (scene.shots || []).map((shot, shotIdx) => (
                    <div
                      key={`${sceneIdx}-${shotIdx}`}
                      style={{
                        minWidth: '120px',
                        background: generatedImages[shot.id]?.gradient || colors.bg.tertiary,
                        borderRadius: '8px',
                        padding: '8px',
                        border: `2px solid ${colors.border.subtle}`,
                      }}
                    >
                      <div style={{
                        aspectRatio: '16/9',
                        background: 'rgba(0,0,0,0.2)',
                        borderRadius: '4px',
                        marginBottom: '6px',
                        display: 'flex',
                        alignItems: 'center',
                        justifyContent: 'center',
                      }}>
                        {generatedImages[shot.id] ? (
                          <Icons.Check style={{ width: 16, height: 16, color: '#10b981' }} />
                        ) : (
                          <Icons.Image style={{ width: 16, height: 16, color: colors.text.tertiary }} />
                        )}
                      </div>
                      <div style={{ fontSize: '10px', color: colors.text.secondary, textAlign: 'center' }}>
                        S{sceneIdx + 1} Shot {shotIdx + 1}
                      </div>
                      <div style={{ fontSize: '9px', color: colors.text.tertiary, textAlign: 'center' }}>
                        {shot.duration}s
                      </div>
                    </div>
                  ))
                )}
              </div>
            </div>
            
            {/* Footer */}
            <div style={{
              padding: '16px 24px',
              borderTop: `1px solid ${colors.border.default}`,
              display: 'flex',
              justifyContent: 'space-between',
              alignItems: 'center',
            }}>
              <div style={{ fontSize: '13px', color: colors.text.secondary }}>
                {scenes.length} scenes · {scenes.reduce((acc, s) => acc + (s.shots?.length || 0), 0)} shots · 
                ~{scenes.reduce((acc, s) => acc + (s.shots || []).reduce((a, shot) => a + (shot.duration || 5), 0), 0)}s total
              </div>
              <Button onClick={() => setShowPreviewModal(false)}>
                Close Preview
              </Button>
            </div>
          </div>
        </div>
      )}
    </div>
  );
};

// ============================================================================
// ROUGH CUT VIEW - Timeline Editor for Assembling Clips
// ============================================================================
const RoughCutView = ({ project, episode, onBack, onNavigateToPost }) => {
  const [timelineClips, setTimelineClips] = useState([]);
  const [selectedClip, setSelectedClip] = useState(null);
  const [zoom, setZoom] = useState(1); // 1 = 100%, affects timeline scale
  const [playheadPosition, setPlayheadPosition] = useState(0);
  const [isPlaying, setIsPlaying] = useState(false);
  const [clipEditorOpen, setClipEditorOpen] = useState(false); // Full screen clip editor
  const [editingPrompt, setEditingPrompt] = useState('');
  const [isGenerating, setIsGenerating] = useState(false);
  const [generationType, setGenerationType] = useState('video'); // 'image' or 'video'
  const [showPreviewModal, setShowPreviewModal] = useState(false);
  
  // Assets library - stores all generated content organized by scene
  const [assetsLibrary, setAssetsLibrary] = useState({});
  
  // Generation settings
  const [genSettings, setGenSettings] = useState({
    model: 'LTX-2 Pro',
    duration: '8 Sec',
    resolution: '1080p',
    aspectRatio: '16:9',
    audioOn: true,
    style: 'Standard',
  });
  
  // Generate placeholder thumbnails for clips
  const getThumbnailGradient = (sceneIndex) => {
    const gradients = [
      'linear-gradient(135deg, #667eea 0%, #764ba2 100%)',
      'linear-gradient(135deg, #f093fb 0%, #f5576c 100%)',
      'linear-gradient(135deg, #4facfe 0%, #00f2fe 100%)',
      'linear-gradient(135deg, #43e97b 0%, #38f9d7 100%)',
      'linear-gradient(135deg, #fa709a 0%, #fee140 100%)',
      'linear-gradient(135deg, #a18cd1 0%, #fbc2eb 100%)',
    ];
    return gradients[sceneIndex % gradients.length];
  };
  
  // Get all shots from episode scenes
  const displayEpisode = episode || project?.episodes?.[0];
  const allShots = React.useMemo(() => {
    if (!displayEpisode?.scenes) return [];
    return displayEpisode.scenes.flatMap((scene, sceneIdx) => 
      (scene.shots || []).map((shot, shotIdx) => ({
        ...shot,
        sceneTitle: scene.title,
        sceneDescription: scene.description,
        sceneIndex: sceneIdx,
        shotIndex: shotIdx,
        fullId: `scene-${sceneIdx}-shot-${shotIdx}`,
        thumbnail: getThumbnailGradient(sceneIdx),
      }))
    );
  }, [displayEpisode]);
  
  // Initialize timeline with all shots if empty
  React.useEffect(() => {
    if (timelineClips.length === 0 && allShots.length > 0) {
      const initialClips = allShots.map((shot, idx) => ({
        id: `clip-${idx}`,
        shotId: shot.id,
        shotData: shot,
        startTime: allShots.slice(0, idx).reduce((acc, s) => acc + (s.duration || 5), 0),
        duration: shot.duration || 5,
        track: 0,
        volume: 100,
        versions: [], // Store all generated versions here
        currentVersion: 0,
      }));
      setTimelineClips(initialClips);
    }
  }, [allShots]);
  
  // Calculate total duration
  const totalDuration = timelineClips.reduce((acc, clip) => 
    Math.max(acc, clip.startTime + clip.duration), 0
  );
  
  // Pixels per second based on zoom
  const pxPerSecond = 20 * zoom;
  
  // Handle clip drag
  const handleClipDrag = (clipId, newStartTime) => {
    setTimelineClips(prev => prev.map(clip => 
      clip.id === clipId ? { ...clip, startTime: Math.max(0, newStartTime) } : clip
    ));
  };
  
  // Handle clip trim
  const handleClipTrim = (clipId, newDuration) => {
    setTimelineClips(prev => prev.map(clip => 
      clip.id === clipId ? { ...clip, duration: Math.max(1, newDuration) } : clip
    ));
  };
  
  // Handle volume change
  const handleVolumeChange = (clipId, newVolume) => {
    setTimelineClips(prev => prev.map(clip => 
      clip.id === clipId ? { ...clip, volume: newVolume } : clip
    ));
    if (selectedClip?.id === clipId) {
      setSelectedClip(prev => ({ ...prev, volume: newVolume }));
    }
  };
  
  // Delete clip from timeline (but keep in assets)
  const handleDeleteClip = (clipId) => {
    setTimelineClips(prev => prev.filter(clip => clip.id !== clipId));
    if (selectedClip?.id === clipId) {
      setSelectedClip(null);
      setClipEditorOpen(false);
    }
  };
  
  // Duplicate clip
  const handleDuplicateClip = (clipId) => {
    const clip = timelineClips.find(c => c.id === clipId);
    if (clip) {
      const newClip = {
        ...clip,
        id: `clip-${Date.now()}`,
        startTime: clip.startTime + clip.duration,
      };
      setTimelineClips(prev => [...prev, newClip]);
    }
  };
  
  // Open clip editor (like LTX Timeline Clip Selection)
  const handleOpenClipEditor = () => {
    if (selectedClip) {
      setEditingPrompt(selectedClip.shotData?.description || '');
      setClipEditorOpen(true);
    }
  };
  
  // Generate new version of clip
  const handleGenerate = () => {
    if (!selectedClip) return;
    
    setIsGenerating(true);
    
    // Simulate generation
    setTimeout(() => {
      const newVersion = {
        id: `version-${Date.now()}`,
        type: generationType,
        prompt: editingPrompt,
        thumbnail: getThumbnailGradient(Math.floor(Math.random() * 6)),
        generatedAt: new Date().toISOString(),
        settings: { ...genSettings },
      };
      
      // Add to clip versions
      setTimelineClips(prev => prev.map(clip => 
        clip.id === selectedClip.id 
          ? { 
              ...clip, 
              versions: [...(clip.versions || []), newVersion],
              currentVersion: (clip.versions || []).length,
              shotData: { ...clip.shotData, description: editingPrompt }
            }
          : clip
      ));
      
      // Add to assets library
      const sceneKey = `scene-${selectedClip.shotData?.sceneIndex || 0}`;
      setAssetsLibrary(prev => ({
        ...prev,
        [sceneKey]: [...(prev[sceneKey] || []), newVersion]
      }));
      
      // Update selected clip
      setSelectedClip(prev => ({
        ...prev,
        versions: [...(prev.versions || []), newVersion],
        currentVersion: (prev.versions || []).length,
        shotData: { ...prev.shotData, description: editingPrompt }
      }));
      
      setIsGenerating(false);
    }, 2500);
  };
  
  // Apply changes and close editor
  const handleApplyChanges = () => {
    setClipEditorOpen(false);
  };
  
  // Format time as MM:SS
  const formatTime = (seconds) => {
    const mins = Math.floor(seconds / 60);
    const secs = Math.floor(seconds % 60);
    return `${mins}:${secs.toString().padStart(2, '0')}`;
  };
  
  // Guard clause
  if (!project) {
    return (
      <div style={{ flex: 1, display: 'flex', alignItems: 'center', justifyContent: 'center' }}>
        <div style={{ textAlign: 'center' }}>
          <Icons.AlertCircle style={{ width: 48, height: 48, color: colors.text.tertiary, marginBottom: '16px' }} />
          <h2 style={{ fontSize: '18px', marginBottom: '8px' }}>No Project Selected</h2>
          <p style={{ color: colors.text.secondary, marginBottom: '20px' }}>Please select a project first</p>
          <Button onClick={onBack}>Go Back</Button>
        </div>
      </div>
    );
  }
  
  // Timeline Clip Component
  const TimelineClip = ({ clip }) => {
    const isSelected = selectedClip?.id === clip.id;
    const width = clip.duration * pxPerSecond;
    const left = clip.startTime * pxPerSecond;
    
    // Generate a color based on scene
    const sceneColors = [
      colors.accent.primary,
      colors.accent.secondary,
      colors.accent.success,
      colors.accent.warning,
      '#ec4899', // pink
      '#8b5cf6', // purple
    ];
    const clipColor = sceneColors[clip.shotData?.sceneIndex % sceneColors.length] || colors.accent.primary;
    const clipGradient = clip.shotData?.thumbnail || getThumbnailGradient(clip.shotData?.sceneIndex || 0);
    
    return (
      <div
        onClick={() => {
          setSelectedClip(clip);
          setEditMode(false);
        }}
        style={{
          position: 'absolute',
          left: `${left}px`,
          width: `${width}px`,
          height: '60px',
          background: clipGradient,
          borderRadius: '4px',
          border: `2px solid ${isSelected ? '#fff' : 'transparent'}`,
          cursor: 'pointer',
          overflow: 'hidden',
          display: 'flex',
          alignItems: 'center',
          transition: 'border-color 0.15s ease',
        }}
      >
        {/* Thumbnail Icon */}
        <div style={{
          position: 'absolute',
          top: '50%',
          left: '50%',
          transform: 'translate(-50%, -50%)',
          opacity: 0.4,
        }}>
          <Icons.Image style={{ width: 20, height: 20, color: '#fff' }} />
        </div>
        
        {/* Duration badge */}
        <div style={{
          position: 'absolute',
          bottom: '4px',
          right: '4px',
          background: 'rgba(0,0,0,0.7)',
          padding: '2px 6px',
          borderRadius: '3px',
          fontSize: '9px',
          color: '#fff',
        }}>
          {clip.duration}s
        </div>
        
        {/* Selected indicator / continuity */}
        {clip.shotData?.continuity && (
          <div style={{
            position: 'absolute',
            top: '4px',
            left: '4px',
            background: colors.accent.primary,
            borderRadius: '50%',
            width: '16px',
            height: '16px',
            display: 'flex',
            alignItems: 'center',
            justifyContent: 'center',
            fontSize: '10px',
            color: '#fff',
          }}>
            ∞
          </div>
        )}
        
        {/* Trim Handles */}
        {isSelected && (
          <>
            <div style={{
              position: 'absolute',
              left: 0,
              top: 0,
              bottom: 0,
              width: '4px',
              background: '#fff',
              cursor: 'ew-resize',
              borderRadius: '4px 0 0 4px',
            }} />
            <div style={{
              position: 'absolute',
              right: 0,
              top: 0,
              bottom: 0,
              width: '4px',
              background: '#fff',
              cursor: 'ew-resize',
              borderRadius: '0 4px 4px 0',
            }} />
          </>
        )}
      </div>
    );
  };
  
  return (
    <div style={{ flex: 1, display: 'flex', flexDirection: 'column', overflow: 'hidden' }}>
      {/* Header */}
      <div style={{
        padding: '16px 24px',
        borderBottom: `1px solid ${colors.border.subtle}`,
        background: colors.bg.primary,
        display: 'flex',
        alignItems: 'center',
        justifyContent: 'space-between',
      }}>
        <div style={{ display: 'flex', alignItems: 'center', gap: '16px' }}>
          <button
            onClick={onBack}
            style={{
              background: 'none',
              border: 'none',
              color: colors.text.secondary,
              cursor: 'pointer',
              display: 'flex',
              alignItems: 'center',
              gap: '8px',
              fontSize: '14px',
            }}
          >
            <Icons.ChevronLeft style={{ width: 20, height: 20 }} />
            Back
          </button>
          <div style={{ height: '24px', width: '1px', background: colors.border.subtle }} />
          <div>
            <h1 style={{ fontSize: '18px', fontWeight: '600', marginBottom: '2px' }}>
              Rough Cut Editor
            </h1>
            <span style={{ fontSize: '13px', color: colors.text.secondary }}>
              {displayEpisode?.title || 'Untitled'} · {timelineClips.length} clips · {formatTime(totalDuration)} total
            </span>
          </div>
        </div>
        
        <div style={{ display: 'flex', gap: '12px' }}>
          <Button 
            onClick={() => setShowPreviewModal(true)}
            style={{
              background: 'linear-gradient(135deg, #8b5cf6 0%, #a855f7 100%)',
              boxShadow: '0 4px 15px rgba(139, 92, 246, 0.3)',
            }}
          >
            <Icons.Play style={{ width: 14, height: 14, marginRight: '6px' }} />
            Preview
          </Button>
          <Button size="sm" onClick={() => onNavigateToPost && onNavigateToPost(displayEpisode)}>
            <Icons.Sliders style={{ width: 14, height: 14, marginRight: '6px' }} />
            Proceed to Post
          </Button>
        </div>
      </div>
      
      {/* Main Content */}
      <div style={{ flex: 1, display: 'flex', overflow: 'hidden' }}>
        {/* Left Panel - Clips Library */}
        <div style={{
          width: '280px',
          borderRight: `1px solid ${colors.border.subtle}`,
          background: colors.bg.primary,
          display: 'flex',
          flexDirection: 'column',
          overflow: 'hidden',
        }}>
          <div style={{
            padding: '16px',
            borderBottom: `1px solid ${colors.border.subtle}`,
          }}>
            <div style={{ fontSize: '12px', fontWeight: '600', color: colors.text.tertiary, marginBottom: '12px', textTransform: 'uppercase' }}>
              My Assets
            </div>
            <div style={{ fontSize: '12px', color: colors.text.secondary }}>
              Click to add to timeline
            </div>
          </div>
          
          <div style={{ flex: 1, overflow: 'auto', padding: '12px' }}>
            {/* Grid of shot thumbnails */}
            <div style={{ display: 'grid', gridTemplateColumns: '1fr 1fr', gap: '8px' }}>
              {allShots.map((shot, idx) => (
                <div
                  key={shot.fullId}
                  onClick={() => {
                    // Add shot to end of timeline
                    const newClip = {
                      id: `clip-${Date.now()}`,
                      shotId: shot.id,
                      shotData: shot,
                      startTime: totalDuration,
                      duration: shot.duration || 5,
                      track: 0,
                      volume: 100,
                    };
                    setTimelineClips(prev => [...prev, newClip]);
                  }}
                  style={{
                    background: colors.bg.secondary,
                    borderRadius: '8px',
                    cursor: 'pointer',
                    border: `1px solid ${colors.border.subtle}`,
                    overflow: 'hidden',
                    transition: 'all 0.15s ease',
                  }}
                >
                  {/* Thumbnail */}
                  <div style={{
                    aspectRatio: '16/9',
                    background: shot.thumbnail || getThumbnailGradient(shot.sceneIndex),
                    display: 'flex',
                    alignItems: 'center',
                    justifyContent: 'center',
                    position: 'relative',
                  }}>
                    <Icons.Image style={{ width: 20, height: 20, color: '#fff', opacity: 0.6 }} />
                    {/* Duration badge */}
                    <div style={{
                      position: 'absolute',
                      bottom: '4px',
                      right: '4px',
                      background: 'rgba(0,0,0,0.7)',
                      padding: '2px 6px',
                      borderRadius: '4px',
                      fontSize: '10px',
                      color: '#fff',
                    }}>
                      {shot.duration || 5}s
                    </div>
                  </div>
                  {/* Shot info */}
                  <div style={{ padding: '8px' }}>
                    <div style={{ fontSize: '11px', fontWeight: '600', color: colors.text.primary, marginBottom: '2px', whiteSpace: 'nowrap', overflow: 'hidden', textOverflow: 'ellipsis' }}>
                      {shot.sceneTitle}
                    </div>
                    <div style={{ fontSize: '10px', color: colors.text.tertiary }}>
                      Shot {shot.shotIndex + 1} · {shot.type || 'wide'}
                    </div>
                  </div>
                </div>
              ))}
            </div>
            
            {allShots.length === 0 && (
              <div style={{ textAlign: 'center', padding: '40px 20px', color: colors.text.tertiary }}>
                <Icons.Film style={{ width: 32, height: 32, marginBottom: '12px', opacity: 0.5 }} />
                <p style={{ fontSize: '13px' }}>No shots available</p>
                <p style={{ fontSize: '12px', marginTop: '4px' }}>Generate a scene breakdown first</p>
              </div>
            )}
          </div>
        </div>
        
        {/* Center - Preview & Timeline */}
        <div style={{ flex: 1, display: 'flex', flexDirection: 'column', overflow: 'hidden' }}>
          {/* Preview Area */}
          <div style={{
            height: '300px',
            background: colors.bg.tertiary,
            display: 'flex',
            alignItems: 'center',
            justifyContent: 'center',
            borderBottom: `1px solid ${colors.border.subtle}`,
            position: 'relative',
          }}>
            {selectedClip ? (
              <div style={{ textAlign: 'center' }}>
                <div style={{
                  width: '400px',
                  height: '225px',
                  background: `linear-gradient(135deg, ${colors.accent.primary} 0%, ${colors.accent.secondary} 100%)`,
                  borderRadius: '8px',
                  display: 'flex',
                  alignItems: 'center',
                  justifyContent: 'center',
                  marginBottom: '12px',
                }}>
                  <Icons.Film style={{ width: 48, height: 48, color: '#fff', opacity: 0.5 }} />
                </div>
                <div style={{ fontSize: '13px', color: colors.text.secondary }}>
                  {selectedClip.shotData?.sceneTitle} - Shot {(selectedClip.shotData?.shotIndex || 0) + 1}
                </div>
              </div>
            ) : (
              <div style={{ textAlign: 'center', color: colors.text.tertiary }}>
                <Icons.Play style={{ width: 48, height: 48, marginBottom: '12px', opacity: 0.3 }} />
                <p style={{ fontSize: '14px' }}>Select a clip to preview</p>
              </div>
            )}
            
            {/* Playback controls */}
            <div style={{
              position: 'absolute',
              bottom: '16px',
              left: '50%',
              transform: 'translateX(-50%)',
              display: 'flex',
              alignItems: 'center',
              gap: '16px',
              background: colors.bg.elevated,
              padding: '8px 16px',
              borderRadius: '24px',
            }}>
              <button
                onClick={() => setPlayheadPosition(0)}
                style={{ background: 'none', border: 'none', color: colors.text.secondary, cursor: 'pointer' }}
              >
                <Icons.ChevronLeft style={{ width: 20, height: 20 }} />
              </button>
              <button
                onClick={() => setIsPlaying(!isPlaying)}
                style={{
                  background: colors.accent.primary,
                  border: 'none',
                  color: '#fff',
                  cursor: 'pointer',
                  width: '40px',
                  height: '40px',
                  borderRadius: '50%',
                  display: 'flex',
                  alignItems: 'center',
                  justifyContent: 'center',
                }}
              >
                {isPlaying ? (
                  <div style={{ width: 12, height: 14, display: 'flex', gap: '3px' }}>
                    <div style={{ width: 4, height: '100%', background: '#fff', borderRadius: 1 }} />
                    <div style={{ width: 4, height: '100%', background: '#fff', borderRadius: 1 }} />
                  </div>
                ) : (
                  <Icons.Play style={{ width: 18, height: 18 }} />
                )}
              </button>
              <button
                onClick={() => setPlayheadPosition(totalDuration)}
                style={{ background: 'none', border: 'none', color: colors.text.secondary, cursor: 'pointer' }}
              >
                <Icons.ChevronRight style={{ width: 20, height: 20 }} />
              </button>
              <span style={{ fontSize: '12px', color: colors.text.secondary, marginLeft: '8px' }}>
                {formatTime(playheadPosition)} / {formatTime(totalDuration)}
              </span>
            </div>
          </div>
          
          {/* Timeline Controls */}
          <div style={{
            padding: '12px 16px',
            background: colors.bg.primary,
            borderBottom: `1px solid ${colors.border.subtle}`,
            display: 'flex',
            alignItems: 'center',
            justifyContent: 'space-between',
          }}>
            <div style={{ display: 'flex', alignItems: 'center', gap: '12px' }}>
              <span style={{ fontSize: '12px', color: colors.text.secondary }}>Zoom:</span>
              <input
                type="range"
                min="0.5"
                max="3"
                step="0.1"
                value={zoom}
                onChange={(e) => setZoom(parseFloat(e.target.value))}
                style={{ width: '100px' }}
              />
              <span style={{ fontSize: '12px', color: colors.text.tertiary }}>{Math.round(zoom * 100)}%</span>
            </div>
            
            <div style={{ display: 'flex', alignItems: 'center', gap: '8px' }}>
              {selectedClip && (
                <>
                  <Button variant="ghost" size="sm" onClick={() => handleDuplicateClip(selectedClip.id)}>
                    <Icons.Plus style={{ width: 14, height: 14, marginRight: '4px' }} />
                    Duplicate
                  </Button>
                  <Button variant="ghost" size="sm" onClick={() => handleDeleteClip(selectedClip.id)}>
                    <Icons.X style={{ width: 14, height: 14, marginRight: '4px' }} />
                    Delete
                  </Button>
                </>
              )}
            </div>
          </div>
          
          {/* Timeline */}
          <div style={{
            flex: 1,
            overflow: 'auto',
            background: colors.bg.secondary,
          }}>
            {/* Time Ruler */}
            <div style={{
              height: '30px',
              background: colors.bg.primary,
              borderBottom: `1px solid ${colors.border.subtle}`,
              position: 'sticky',
              top: 0,
              zIndex: 10,
              display: 'flex',
              alignItems: 'flex-end',
            }}>
              <div style={{ width: '100px', flexShrink: 0 }} />
              <div style={{ position: 'relative', flex: 1 }}>
                {Array.from({ length: Math.ceil(totalDuration / 5) + 1 }).map((_, i) => (
                  <div
                    key={i}
                    style={{
                      position: 'absolute',
                      left: `${i * 5 * pxPerSecond}px`,
                      bottom: '4px',
                      fontSize: '10px',
                      color: colors.text.tertiary,
                    }}
                  >
                    {formatTime(i * 5)}
                  </div>
                ))}
              </div>
            </div>
            
            {/* Video Track */}
            <div style={{ display: 'flex' }}>
              <div style={{
                width: '100px',
                flexShrink: 0,
                padding: '12px 16px',
                borderRight: `1px solid ${colors.border.subtle}`,
                background: colors.bg.primary,
              }}>
                <div style={{ fontSize: '12px', fontWeight: '600', color: colors.text.secondary }}>Video</div>
              </div>
              <div style={{
                flex: 1,
                height: '80px',
                position: 'relative',
                background: colors.bg.tertiary,
                minWidth: `${(totalDuration + 30) * pxPerSecond}px`,
              }}>
                {/* Playhead */}
                <div style={{
                  position: 'absolute',
                  left: `${playheadPosition * pxPerSecond}px`,
                  top: 0,
                  bottom: 0,
                  width: '2px',
                  background: colors.accent.primary,
                  zIndex: 5,
                }}>
                  <div style={{
                    position: 'absolute',
                    top: '-8px',
                    left: '-6px',
                    width: 0,
                    height: 0,
                    borderLeft: '6px solid transparent',
                    borderRight: '6px solid transparent',
                    borderTop: `8px solid ${colors.accent.primary}`,
                  }} />
                </div>
                
                {/* Clips */}
                <div style={{ position: 'absolute', top: '10px', left: 0, right: 0 }}>
                  {timelineClips.filter(c => c.track === 0).map(clip => (
                    <TimelineClip key={clip.id} clip={clip} />
                  ))}
                </div>
              </div>
            </div>
            
            {/* Audio Track */}
            <div style={{ display: 'flex' }}>
              <div style={{
                width: '100px',
                flexShrink: 0,
                padding: '12px 16px',
                borderRight: `1px solid ${colors.border.subtle}`,
                background: colors.bg.primary,
              }}>
                <div style={{ fontSize: '12px', fontWeight: '600', color: colors.text.secondary }}>Audio</div>
              </div>
              <div style={{
                flex: 1,
                height: '50px',
                position: 'relative',
                background: colors.bg.secondary,
                minWidth: `${(totalDuration + 30) * pxPerSecond}px`,
              }}>
                {/* Audio waveform placeholder */}
                <div style={{
                  position: 'absolute',
                  top: '50%',
                  left: '16px',
                  right: '16px',
                  transform: 'translateY(-50%)',
                  height: '2px',
                  background: colors.border.subtle,
                }} />
              </div>
            </div>
          </div>
        </div>
        
        {/* Right Panel - Edit Video / Clip Properties */}
        <div style={{
          width: '280px',
          borderLeft: `1px solid ${colors.border.subtle}`,
          background: colors.bg.primary,
          display: 'flex',
          flexDirection: 'column',
          overflow: 'hidden',
        }}>
          {selectedClip ? (
            /* Clip Properties Panel */
            <>
              {/* Clip Thumbnail */}
              <div style={{
                aspectRatio: '16/9',
                background: selectedClip.shotData?.thumbnail || getThumbnailGradient(selectedClip.shotData?.sceneIndex || 0),
                display: 'flex',
                alignItems: 'center',
                justifyContent: 'center',
                position: 'relative',
              }}>
                <Icons.Film style={{ width: 32, height: 32, color: '#fff', opacity: 0.6 }} />
                {/* Play button */}
                <div style={{
                  position: 'absolute',
                  bottom: '8px',
                  left: '8px',
                  display: 'flex',
                  alignItems: 'center',
                  gap: '4px',
                  background: 'rgba(0,0,0,0.7)',
                  padding: '4px 8px',
                  borderRadius: '4px',
                }}>
                  <Icons.Play style={{ width: 12, height: 12, color: '#fff' }} />
                </div>
                {/* Expand */}
                <button 
                  onClick={handleOpenClipEditor}
                  style={{
                    position: 'absolute',
                    top: '8px',
                    right: '8px',
                    background: 'rgba(0,0,0,0.7)',
                    border: 'none',
                    borderRadius: '4px',
                    padding: '6px',
                    cursor: 'pointer',
                  }}
                >
                  <Icons.Eye style={{ width: 14, height: 14, color: '#fff' }} />
                </button>
              </div>
              
              <div style={{ flex: 1, padding: '16px', overflow: 'auto' }}>
                {/* Volume Control */}
                <div style={{ marginBottom: '16px' }}>
                  <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center', marginBottom: '8px' }}>
                    <span style={{ fontSize: '12px', color: colors.text.secondary }}>VOLUME</span>
                    <span style={{ fontSize: '12px', color: colors.text.primary }}>{selectedClip.volume || 100}%</span>
                  </div>
                  <input
                    type="range"
                    min="0"
                    max="100"
                    value={selectedClip.volume || 100}
                    onChange={(e) => handleVolumeChange(selectedClip.id, parseInt(e.target.value))}
                    style={{ width: '100%' }}
                  />
                </div>
                
                {/* Edit Button - Opens Clip Editor */}
                <Button onClick={handleOpenClipEditor} style={{ width: '100%', marginBottom: '12px' }}>
                  <Icons.Sliders style={{ width: 14, height: 14, marginRight: '6px' }} />
                  Edit in Gen Space
                </Button>
                
                <Button variant="ghost" onClick={() => handleDeleteClip(selectedClip.id)} style={{ width: '100%' }}>
                  <Icons.X style={{ width: 14, height: 14, marginRight: '6px' }} />
                  Delete
                </Button>
                
                {/* Versions Info */}
                {(selectedClip.versions || []).length > 0 && (
                  <div style={{
                    padding: '12px',
                    background: colors.bg.secondary,
                    borderRadius: '8px',
                    marginTop: '16px',
                  }}>
                    <div style={{ fontSize: '11px', color: colors.text.tertiary, marginBottom: '8px' }}>
                      {selectedClip.versions.length} version(s) in My Assets
                    </div>
                  </div>
                )}
                
                {/* Shot Info */}
                <div style={{
                  padding: '12px',
                  background: colors.bg.secondary,
                  borderRadius: '8px',
                  marginTop: '12px',
                }}>
                  <div style={{ fontSize: '12px', fontWeight: '600', color: colors.text.primary, marginBottom: '4px' }}>
                    {selectedClip.shotData?.sceneTitle} - Shot {(selectedClip.shotData?.shotIndex || 0) + 1}
                  </div>
                  <p style={{ fontSize: '11px', color: colors.text.secondary, marginBottom: '8px' }}>
                    {selectedClip.shotData?.description || 'No description'}
                  </p>
                  <div style={{ display: 'flex', gap: '12px', fontSize: '11px', color: colors.text.tertiary }}>
                    <span>{selectedClip.shotData?.type || 'wide'}</span>
                    <span>{selectedClip.duration}s</span>
                  </div>
                </div>
              </div>
            </>
          ) : (
            <div style={{ flex: 1, display: 'flex', alignItems: 'center', justifyContent: 'center', padding: '20px' }}>
              <div style={{ textAlign: 'center', color: colors.text.tertiary }}>
                <Icons.MousePointer style={{ width: 32, height: 32, marginBottom: '12px', opacity: 0.5 }} />
                <p style={{ fontSize: '14px' }}>Select a clip to edit</p>
              </div>
            </div>
          )}
        </div>
      </div>
      
      {/* Clip Editor Overlay - Like LTX Timeline Clip Selection */}
      {clipEditorOpen && selectedClip && (
        <div style={{
          position: 'fixed',
          top: 0,
          left: 0,
          right: 0,
          bottom: 0,
          background: colors.bg.primary,
          zIndex: 1000,
          display: 'flex',
          flexDirection: 'column',
        }}>
          {/* Editor Header */}
          <div style={{
            padding: '12px 24px',
            borderBottom: `1px solid ${colors.border.subtle}`,
            display: 'flex',
            alignItems: 'center',
            justifyContent: 'space-between',
          }}>
            <div style={{ display: 'flex', alignItems: 'center', gap: '16px' }}>
              <button
                onClick={() => setClipEditorOpen(false)}
                style={{
                  background: 'none',
                  border: 'none',
                  color: colors.text.secondary,
                  cursor: 'pointer',
                  display: 'flex',
                  alignItems: 'center',
                  gap: '8px',
                  fontSize: '14px',
                }}
              >
                <Icons.ChevronLeft style={{ width: 20, height: 20 }} />
              </button>
              <span style={{ fontSize: '14px', color: colors.text.secondary }}>Timeline Clip Selection</span>
            </div>
            <Button onClick={handleApplyChanges}>
              Apply Changes
            </Button>
          </div>
          
          {/* Editor Content */}
          <div style={{ flex: 1, display: 'flex', overflow: 'hidden' }}>
            {/* Main Content Area */}
            <div style={{ flex: 1, display: 'flex', flexDirection: 'column', padding: '24px', overflow: 'auto' }}>
              {/* Session Title */}
              <div style={{ marginBottom: '16px' }}>
                <h2 style={{ fontSize: '16px', fontWeight: '600', marginBottom: '8px' }}>
                  {selectedClip.shotData?.sceneTitle || 'Scene'} - Shot {(selectedClip.shotData?.shotIndex || 0) + 1}
                </h2>
                <p style={{ fontSize: '13px', color: colors.text.secondary }}>
                  {editingPrompt || 'No description'}
                </p>
              </div>
              
              {/* Tags/Labels */}
              <div style={{ display: 'flex', gap: '8px', marginBottom: '20px', flexWrap: 'wrap' }}>
                <span style={{ padding: '4px 10px', background: colors.bg.tertiary, borderRadius: '4px', fontSize: '12px', color: colors.text.secondary }}>
                  🎨 {genSettings.style}
                </span>
                <span style={{ padding: '4px 10px', background: colors.bg.tertiary, borderRadius: '4px', fontSize: '12px', color: colors.text.secondary }}>
                  📍 {selectedClip.shotData?.type || 'wide'}
                </span>
              </div>
              
              {/* Current Version Preview */}
              <div style={{
                aspectRatio: '16/9',
                maxWidth: '800px',
                background: selectedClip.shotData?.thumbnail || getThumbnailGradient(selectedClip.shotData?.sceneIndex || 0),
                borderRadius: '12px',
                display: 'flex',
                alignItems: 'center',
                justifyContent: 'center',
                marginBottom: '16px',
                position: 'relative',
              }}>
                <Icons.Film style={{ width: 64, height: 64, color: '#fff', opacity: 0.4 }} />
                {/* Playback time */}
                <div style={{
                  position: 'absolute',
                  bottom: '12px',
                  left: '12px',
                  background: 'rgba(0,0,0,0.7)',
                  padding: '4px 10px',
                  borderRadius: '4px',
                  fontSize: '12px',
                  color: '#fff',
                }}>
                  00:{String(selectedClip.duration || 8).padStart(2, '0')}
                </div>
                {/* Applied to Clip badge */}
                <div style={{
                  position: 'absolute',
                  bottom: '12px',
                  left: '80px',
                  background: colors.accent.success,
                  padding: '4px 10px',
                  borderRadius: '4px',
                  fontSize: '11px',
                  color: '#fff',
                  display: 'flex',
                  alignItems: 'center',
                  gap: '4px',
                }}>
                  <Icons.Check style={{ width: 12, height: 12 }} />
                  Applied to Clip
                </div>
              </div>
              
              {/* Version info */}
              <div style={{ display: 'flex', gap: '16px', marginBottom: '24px', fontSize: '12px', color: colors.text.tertiary }}>
                <span>🎬 {genSettings.model}</span>
                <span>♪ Audio</span>
                <span>📺 {genSettings.resolution}</span>
              </div>
              
              {/* Previous Versions */}
              {(selectedClip.versions || []).length > 0 && (
                <div style={{ marginBottom: '24px' }}>
                  <h3 style={{ fontSize: '14px', fontWeight: '600', marginBottom: '12px', color: colors.text.secondary }}>
                    Previous Versions ({selectedClip.versions.length})
                  </h3>
                  <div style={{ display: 'flex', gap: '12px', flexWrap: 'wrap' }}>
                    {selectedClip.versions.map((version, idx) => (
                      <div
                        key={version.id}
                        style={{
                          width: '160px',
                          background: colors.bg.secondary,
                          borderRadius: '8px',
                          overflow: 'hidden',
                          cursor: 'pointer',
                          border: `2px solid ${idx === selectedClip.currentVersion ? colors.accent.primary : 'transparent'}`,
                        }}
                      >
                        <div style={{
                          aspectRatio: '16/9',
                          background: version.thumbnail,
                          display: 'flex',
                          alignItems: 'center',
                          justifyContent: 'center',
                        }}>
                          <Icons.Image style={{ width: 20, height: 20, color: '#fff', opacity: 0.5 }} />
                        </div>
                        <div style={{ padding: '8px', fontSize: '11px', color: colors.text.tertiary }}>
                          Version {idx + 1}
                        </div>
                      </div>
                    ))}
                  </div>
                </div>
              )}
            </div>
            
            {/* Right Sidebar - Versions History */}
            <div style={{
              width: '100px',
              borderLeft: `1px solid ${colors.border.subtle}`,
              background: colors.bg.secondary,
              padding: '16px 12px',
              overflow: 'auto',
            }}>
              <div style={{ fontSize: '11px', color: colors.text.tertiary, marginBottom: '12px', textAlign: 'center' }}>
                All Versions
              </div>
              {(selectedClip.versions || []).map((version, idx) => (
                <div
                  key={version.id}
                  style={{
                    width: '100%',
                    aspectRatio: '1',
                    background: version.thumbnail,
                    borderRadius: '8px',
                    marginBottom: '8px',
                    cursor: 'pointer',
                    border: `2px solid ${idx === selectedClip.currentVersion ? colors.accent.primary : 'transparent'}`,
                    display: 'flex',
                    alignItems: 'center',
                    justifyContent: 'center',
                  }}
                >
                  <Icons.Image style={{ width: 16, height: 16, color: '#fff', opacity: 0.5 }} />
                </div>
              ))}
              {/* Add new version button */}
              <div
                onClick={handleGenerate}
                style={{
                  width: '100%',
                  aspectRatio: '1',
                  background: colors.bg.tertiary,
                  borderRadius: '8px',
                  cursor: 'pointer',
                  display: 'flex',
                  alignItems: 'center',
                  justifyContent: 'center',
                  border: `1px dashed ${colors.border.default}`,
                }}
              >
                <Icons.Plus style={{ width: 20, height: 20, color: colors.text.tertiary }} />
              </div>
            </div>
          </div>
          
          {/* Bottom Generation Bar */}
          <div style={{
            padding: '16px 24px',
            borderTop: `1px solid ${colors.border.subtle}`,
            background: colors.bg.secondary,
          }}>
            <div style={{ display: 'flex', alignItems: 'center', gap: '16px' }}>
              {/* Image/Video Toggle */}
              <div style={{ display: 'flex', background: colors.bg.tertiary, borderRadius: '8px', padding: '4px' }}>
                <button
                  onClick={() => setGenerationType('image')}
                  style={{
                    padding: '8px 16px',
                    background: generationType === 'image' ? colors.bg.primary : 'transparent',
                    border: 'none',
                    borderRadius: '6px',
                    color: generationType === 'image' ? colors.text.primary : colors.text.tertiary,
                    cursor: 'pointer',
                    fontSize: '12px',
                    display: 'flex',
                    alignItems: 'center',
                    gap: '6px',
                  }}
                >
                  <Icons.Image style={{ width: 14, height: 14 }} />
                  IMAGE
                </button>
                <button
                  onClick={() => setGenerationType('video')}
                  style={{
                    padding: '8px 16px',
                    background: generationType === 'video' ? colors.bg.primary : 'transparent',
                    border: 'none',
                    borderRadius: '6px',
                    color: generationType === 'video' ? colors.text.primary : colors.text.tertiary,
                    cursor: 'pointer',
                    fontSize: '12px',
                    display: 'flex',
                    alignItems: 'center',
                    gap: '6px',
                  }}
                >
                  <Icons.Film style={{ width: 14, height: 14 }} />
                  VIDEO
                </button>
              </div>
              
              {/* Thumbnail */}
              <div style={{
                width: '48px',
                height: '48px',
                borderRadius: '6px',
                background: selectedClip.shotData?.thumbnail || getThumbnailGradient(0),
                flexShrink: 0,
              }} />
              
              {/* Prompt Input */}
              <div style={{ flex: 1, position: 'relative' }}>
                <input
                  type="text"
                  value={editingPrompt}
                  onChange={(e) => setEditingPrompt(e.target.value)}
                  placeholder="Describe what you want to generate..."
                  style={{
                    width: '100%',
                    padding: '12px 16px',
                    paddingRight: '50px',
                    background: colors.bg.primary,
                    border: `1px solid ${colors.border.default}`,
                    borderRadius: '8px',
                    color: colors.text.primary,
                    fontSize: '14px',
                  }}
                />
                <button
                  onClick={handleGenerate}
                  disabled={isGenerating}
                  style={{
                    position: 'absolute',
                    right: '8px',
                    top: '50%',
                    transform: 'translateY(-50%)',
                    background: colors.accent.primary,
                    border: 'none',
                    borderRadius: '6px',
                    padding: '8px',
                    cursor: isGenerating ? 'not-allowed' : 'pointer',
                    opacity: isGenerating ? 0.6 : 1,
                  }}
                >
                  {isGenerating ? (
                    <div style={{ width: 16, height: 16, border: '2px solid #fff', borderTopColor: 'transparent', borderRadius: '50%', animation: 'spin 1s linear infinite' }} />
                  ) : (
                    <Icons.Sparkles style={{ width: 16, height: 16, color: '#fff' }} />
                  )}
                </button>
              </div>
              
              {/* Settings */}
              <div style={{ display: 'flex', gap: '8px', alignItems: 'center' }}>
                <select
                  value={genSettings.style}
                  onChange={(e) => setGenSettings(prev => ({ ...prev, style: e.target.value }))}
                  style={{
                    padding: '8px 12px',
                    background: colors.bg.primary,
                    border: `1px solid ${colors.border.default}`,
                    borderRadius: '6px',
                    color: colors.text.primary,
                    fontSize: '12px',
                  }}
                >
                  <option value="Standard">Standard</option>
                  <option value="Cinematic">Cinematic</option>
                  <option value="Anime">Anime</option>
                  <option value="Documentary">Documentary</option>
                </select>
                
                <span style={{ fontSize: '12px', color: colors.text.secondary }}>{genSettings.model}</span>
                <span style={{ fontSize: '12px', color: colors.text.secondary }}>♪ Audio On</span>
                <span style={{ fontSize: '12px', color: colors.text.secondary }}>{genSettings.duration}</span>
                <span style={{ fontSize: '12px', color: colors.text.secondary }}>{genSettings.resolution}</span>
                <span style={{ fontSize: '12px', color: colors.text.secondary }}>{genSettings.aspectRatio}</span>
              </div>
            </div>
          </div>
          
          {/* Spin animation */}
          <style>{`
            @keyframes spin {
              to { transform: translateY(-50%) rotate(360deg); }
            }
          `}</style>
        </div>
      )}
      
      {/* Preview Modal */}
      {showPreviewModal && (
        <div style={{
          position: 'fixed',
          top: 0,
          left: 0,
          right: 0,
          bottom: 0,
          background: 'rgba(0,0,0,0.95)',
          display: 'flex',
          alignItems: 'center',
          justifyContent: 'center',
          zIndex: 1000,
        }}>
          <div style={{
            width: '90%',
            maxWidth: '1200px',
            background: colors.bg.secondary,
            borderRadius: '16px',
            overflow: 'hidden',
          }}>
            {/* Header */}
            <div style={{
              padding: '16px 24px',
              borderBottom: `1px solid ${colors.border.default}`,
              display: 'flex',
              justifyContent: 'space-between',
              alignItems: 'center',
            }}>
              <h2 style={{ fontSize: '18px', fontWeight: '600' }}>
                <Icons.Play style={{ width: 20, height: 20, marginRight: '8px', display: 'inline' }} />
                Rough Cut Preview
              </h2>
              <button
                onClick={() => setShowPreviewModal(false)}
                style={{
                  padding: '8px',
                  background: 'none',
                  border: 'none',
                  color: colors.text.secondary,
                  cursor: 'pointer',
                  fontSize: '24px',
                }}
              >×</button>
            </div>
            
            {/* Preview Content */}
            <div style={{ padding: '24px' }}>
              {/* Main Preview Area */}
              <div style={{
                aspectRatio: '16/9',
                background: timelineClips[0]?.shotData?.thumbnail || colors.bg.tertiary,
                borderRadius: '12px',
                display: 'flex',
                alignItems: 'center',
                justifyContent: 'center',
                marginBottom: '20px',
                position: 'relative',
              }}>
                <div style={{ textAlign: 'center', color: '#fff' }}>
                  <div style={{
                    width: '80px',
                    height: '80px',
                    borderRadius: '50%',
                    background: 'rgba(255,255,255,0.2)',
                    display: 'flex',
                    alignItems: 'center',
                    justifyContent: 'center',
                    margin: '0 auto 16px',
                    cursor: 'pointer',
                  }}>
                    <Icons.Play style={{ width: 40, height: 40 }} />
                  </div>
                  <div style={{ fontSize: '14px', opacity: 0.9 }}>Click to play preview</div>
                </div>
                
                {/* Timeline position */}
                <div style={{
                  position: 'absolute',
                  bottom: '16px',
                  left: '16px',
                  padding: '6px 12px',
                  background: 'rgba(0,0,0,0.7)',
                  borderRadius: '6px',
                  fontSize: '12px',
                  color: '#fff',
                }}>
                  {formatTime(playheadPosition)} / {formatTime(totalDuration)}
                </div>
              </div>
              
              {/* Timeline Thumbnail Strip */}
              <div style={{
                display: 'flex',
                gap: '4px',
                overflowX: 'auto',
                paddingBottom: '8px',
                background: colors.bg.tertiary,
                borderRadius: '8px',
                padding: '12px',
              }}>
                {timelineClips.map((clip, idx) => (
                  <div
                    key={clip.id}
                    style={{
                      minWidth: `${Math.max(60, clip.duration * 10)}px`,
                      height: '50px',
                      background: clip.shotData?.thumbnail || colors.bg.primary,
                      borderRadius: '4px',
                      display: 'flex',
                      alignItems: 'center',
                      justifyContent: 'center',
                      fontSize: '10px',
                      color: '#fff',
                      position: 'relative',
                      border: `2px solid ${selectedClip?.id === clip.id ? colors.accent.primary : 'transparent'}`,
                    }}
                  >
                    <span style={{ 
                      position: 'absolute', 
                      bottom: '2px', 
                      right: '4px', 
                      fontSize: '9px',
                      background: 'rgba(0,0,0,0.5)',
                      padding: '1px 4px',
                      borderRadius: '2px',
                    }}>
                      {clip.duration}s
                    </span>
                  </div>
                ))}
              </div>
            </div>
            
            {/* Footer */}
            <div style={{
              padding: '16px 24px',
              borderTop: `1px solid ${colors.border.default}`,
              display: 'flex',
              justifyContent: 'space-between',
              alignItems: 'center',
            }}>
              <div style={{ fontSize: '13px', color: colors.text.secondary }}>
                {timelineClips.length} clips · {formatTime(totalDuration)} total
              </div>
              <div style={{ display: 'flex', gap: '12px' }}>
                <Button variant="secondary" onClick={() => setShowPreviewModal(false)}>
                  Close
                </Button>
                <Button onClick={() => {
                  setShowPreviewModal(false);
                  onNavigateToPost && onNavigateToPost(displayEpisode);
                }}>
                  Proceed to Post
                </Button>
              </div>
            </div>
          </div>
        </div>
      )}
    </div>
  );
};

// ============================================================================
// POST PRODUCTION VIEW - Multi-Track Timeline Editor (CapCut-style)
// ============================================================================
const PostProductionView = ({ project, episode, onBack, onExport }) => {
  // Timeline state
  const [tracks, setTracks] = useState([]);
  const [selectedTrack, setSelectedTrack] = useState(null);
  const [selectedClip, setSelectedClip] = useState(null);
  const [zoom, setZoom] = useState(1);
  const [playheadPosition, setPlayheadPosition] = useState(0);
  const [isPlaying, setIsPlaying] = useState(false);
  const [currentTime, setCurrentTime] = useState(0);
  const [totalDuration, setTotalDuration] = useState(60);
  const [showPreviewModal, setShowPreviewModal] = useState(false);
  
  // Panel state
  const [activePanel, setActivePanel] = useState('media'); // media, video, photo, audio, text, transitions, effect, sticker, adjustment, settings
  const [showAIAnalyzer, setShowAIAnalyzer] = useState(false);
  const [isAnalyzing, setIsAnalyzing] = useState(false);
  const [analysisResults, setAnalysisResults] = useState(null);
  
  // Audio Workspace state
  const [showAudioWorkspace, setShowAudioWorkspace] = useState(false);
  const [audioWorkspaceTab, setAudioWorkspaceTab] = useState('music'); // 'music' or 'sfx'
  const [audioPrompt, setAudioPrompt] = useState('');
  const [audioGenSettings, setAudioGenSettings] = useState({
    genre: 'cinematic',
    mood: 'epic',
    tempo: 'medium',
    duration: 30,
    instruments: [],
  });
  const [isGeneratingAudio, setIsGeneratingAudio] = useState(false);
  const [generatedAudioFiles, setGeneratedAudioFiles] = useState([
    { id: 'gen-1', name: 'Epic Battle Theme', type: 'music', duration: 45, createdAt: new Date(), url: null },
    { id: 'gen-2', name: 'Ambient Forest', type: 'music', duration: 60, createdAt: new Date(), url: null },
    { id: 'gen-3', name: 'Sword Clash', type: 'sfx', duration: 1.2, createdAt: new Date(), url: null },
    { id: 'gen-4', name: 'Thunder Rumble', type: 'sfx', duration: 3, createdAt: new Date(), url: null },
  ]);
  
  // Editing state
  const [clipboardClip, setClipboardClip] = useState(null);
  const [draggedClip, setDraggedClip] = useState(null);
  const [isDragging, setIsDragging] = useState(false);
  const [trimMode, setTrimMode] = useState(null); // 'start' | 'end' | null
  const [history, setHistory] = useState([]);
  const [historyIndex, setHistoryIndex] = useState(-1);
  
  // Assets
  const [mediaAssets, setMediaAssets] = useState([]);
  const [audioAssets, setAudioAssets] = useState([]);
  
  // ============================================================================
  // TIMELINE EDITING FUNCTIONS
  // ============================================================================
  
  // Save state to history for undo/redo
  const saveToHistory = (newTracks) => {
    const newHistory = history.slice(0, historyIndex + 1);
    newHistory.push(JSON.parse(JSON.stringify(newTracks)));
    setHistory(newHistory);
    setHistoryIndex(newHistory.length - 1);
  };
  
  // Undo
  const handleUndo = () => {
    if (historyIndex > 0) {
      setHistoryIndex(historyIndex - 1);
      setTracks(JSON.parse(JSON.stringify(history[historyIndex - 1])));
    }
  };
  
  // Redo
  const handleRedo = () => {
    if (historyIndex < history.length - 1) {
      setHistoryIndex(historyIndex + 1);
      setTracks(JSON.parse(JSON.stringify(history[historyIndex + 1])));
    }
  };
  
  // Split clip at playhead
  const handleSplitClip = () => {
    if (!selectedClip) return;
    
    const trackIndex = tracks.findIndex(t => t.clips.some(c => c.id === selectedClip.id));
    if (trackIndex === -1) return;
    
    const clipIndex = tracks[trackIndex].clips.findIndex(c => c.id === selectedClip.id);
    const clip = tracks[trackIndex].clips[clipIndex];
    
    // Check if playhead is within the clip
    if (playheadPosition <= clip.startTime || playheadPosition >= clip.startTime + clip.duration) {
      return; // Playhead not within clip
    }
    
    const splitPoint = playheadPosition - clip.startTime;
    
    // Create two new clips from the split
    const clip1 = {
      ...clip,
      id: `${clip.id}-a`,
      duration: splitPoint,
    };
    
    const clip2 = {
      ...clip,
      id: `${clip.id}-b`,
      startTime: playheadPosition,
      duration: clip.duration - splitPoint,
    };
    
    const newTracks = tracks.map((track, idx) => {
      if (idx === trackIndex) {
        const newClips = [...track.clips];
        newClips.splice(clipIndex, 1, clip1, clip2);
        return { ...track, clips: newClips };
      }
      return track;
    });
    
    saveToHistory(newTracks);
    setTracks(newTracks);
    setSelectedClip(clip2);
  };
  
  // Delete selected clip
  const handleDeleteClip = () => {
    if (!selectedClip) return;
    
    const newTracks = tracks.map(track => ({
      ...track,
      clips: track.clips.filter(c => c.id !== selectedClip.id)
    }));
    
    saveToHistory(newTracks);
    setTracks(newTracks);
    setSelectedClip(null);
  };
  
  // Duplicate selected clip
  const handleDuplicateClip = () => {
    if (!selectedClip) return;
    
    const trackIndex = tracks.findIndex(t => t.clips.some(c => c.id === selectedClip.id));
    if (trackIndex === -1) return;
    
    const newClip = {
      ...selectedClip,
      id: `${selectedClip.id}-copy-${Date.now()}`,
      startTime: selectedClip.startTime + selectedClip.duration,
    };
    
    const newTracks = tracks.map((track, idx) => {
      if (idx === trackIndex) {
        return { ...track, clips: [...track.clips, newClip] };
      }
      return track;
    });
    
    saveToHistory(newTracks);
    setTracks(newTracks);
    setSelectedClip(newClip);
  };
  
  // Copy clip to clipboard
  const handleCopyClip = () => {
    if (selectedClip) {
      setClipboardClip({ ...selectedClip });
    }
  };
  
  // Paste clip from clipboard
  const handlePasteClip = () => {
    if (!clipboardClip) return;
    
    const trackIndex = tracks.findIndex(t => t.type === (clipboardClip.type === 'video' ? 'video' : 'audio'));
    if (trackIndex === -1) return;
    
    const newClip = {
      ...clipboardClip,
      id: `${clipboardClip.id}-paste-${Date.now()}`,
      startTime: playheadPosition,
    };
    
    const newTracks = tracks.map((track, idx) => {
      if (idx === trackIndex) {
        return { ...track, clips: [...track.clips, newClip] };
      }
      return track;
    });
    
    saveToHistory(newTracks);
    setTracks(newTracks);
    setSelectedClip(newClip);
  };
  
  // Trim clip start
  const handleTrimStart = (clipId, newStartTime) => {
    const newTracks = tracks.map(track => ({
      ...track,
      clips: track.clips.map(clip => {
        if (clip.id === clipId) {
          const delta = newStartTime - clip.startTime;
          return {
            ...clip,
            startTime: newStartTime,
            duration: Math.max(0.5, clip.duration - delta),
          };
        }
        return clip;
      })
    }));
    
    setTracks(newTracks);
  };
  
  // Trim clip end
  const handleTrimEnd = (clipId, newDuration) => {
    const newTracks = tracks.map(track => ({
      ...track,
      clips: track.clips.map(clip => {
        if (clip.id === clipId) {
          return { ...clip, duration: Math.max(0.5, newDuration) };
        }
        return clip;
      })
    }));
    
    setTracks(newTracks);
  };
  
  // Move clip to new position
  const handleMoveClip = (clipId, newStartTime, newTrackId) => {
    let movedClip = null;
    
    // Remove clip from current track
    let newTracks = tracks.map(track => {
      const clipIndex = track.clips.findIndex(c => c.id === clipId);
      if (clipIndex !== -1) {
        movedClip = { ...track.clips[clipIndex], startTime: Math.max(0, newStartTime) };
        return { ...track, clips: track.clips.filter(c => c.id !== clipId) };
      }
      return track;
    });
    
    // Add to new track (or same track at new position)
    if (movedClip) {
      newTracks = newTracks.map(track => {
        if (track.id === newTrackId) {
          return { ...track, clips: [...track.clips, movedClip] };
        }
        return track;
      });
    }
    
    saveToHistory(newTracks);
    setTracks(newTracks);
  };
  
  // Apply effect to clip
  const handleApplyEffect = (clipId, effectId, effectParams = {}) => {
    const newTracks = tracks.map(track => ({
      ...track,
      clips: track.clips.map(clip => {
        if (clip.id === clipId) {
          const existingEffects = clip.effects || [];
          return {
            ...clip,
            effects: [...existingEffects, { id: effectId, params: effectParams }]
          };
        }
        return clip;
      })
    }));
    
    saveToHistory(newTracks);
    setTracks(newTracks);
  };
  
  // Remove effect from clip
  const handleRemoveEffect = (clipId, effectIndex) => {
    const newTracks = tracks.map(track => ({
      ...track,
      clips: track.clips.map(clip => {
        if (clip.id === clipId && clip.effects) {
          const newEffects = [...clip.effects];
          newEffects.splice(effectIndex, 1);
          return { ...clip, effects: newEffects };
        }
        return clip;
      })
    }));
    
    saveToHistory(newTracks);
    setTracks(newTracks);
  };
  
  // Apply transition between clips
  const handleApplyTransition = (clipId, transitionId, position = 'end') => {
    const newTracks = tracks.map(track => ({
      ...track,
      clips: track.clips.map(clip => {
        if (clip.id === clipId) {
          return {
            ...clip,
            transition: position === 'end' ? { type: transitionId, duration: 0.5 } : clip.transition,
            transitionIn: position === 'start' ? { type: transitionId, duration: 0.5 } : clip.transitionIn,
          };
        }
        return clip;
      })
    }));
    
    saveToHistory(newTracks);
    setTracks(newTracks);
  };
  
  // Set clip volume
  const handleSetClipVolume = (clipId, volume) => {
    const newTracks = tracks.map(track => ({
      ...track,
      clips: track.clips.map(clip => {
        if (clip.id === clipId) {
          return { ...clip, volume };
        }
        return clip;
      })
    }));
    
    setTracks(newTracks);
  };
  
  // Set clip speed
  const handleSetClipSpeed = (clipId, speed) => {
    const newTracks = tracks.map(track => ({
      ...track,
      clips: track.clips.map(clip => {
        if (clip.id === clipId) {
          return { ...clip, speed };
        }
        return clip;
      })
    }));
    
    saveToHistory(newTracks);
    setTracks(newTracks);
  };
  
  // ============================================================================
  // AUDIO GENERATION FUNCTIONS
  // ============================================================================
  
  const handleGenerateAudio = () => {
    if (!audioPrompt.trim()) return;
    
    setIsGeneratingAudio(true);
    
    // Simulate API call to N8N
    setTimeout(() => {
      const newAudioFile = {
        id: `gen-${Date.now()}`,
        name: audioPrompt.slice(0, 30) + (audioPrompt.length > 30 ? '...' : ''),
        type: audioWorkspaceTab === 'music' ? 'music' : 'sfx',
        duration: audioWorkspaceTab === 'music' ? audioGenSettings.duration : Math.random() * 3 + 0.5,
        createdAt: new Date(),
        url: null, // Would be filled by N8N response
        settings: { ...audioGenSettings },
        prompt: audioPrompt,
      };
      
      setGeneratedAudioFiles(prev => [newAudioFile, ...prev]);
      setIsGeneratingAudio(false);
      setAudioPrompt('');
    }, 2500);
  };
  
  const handleAddGeneratedAudioToTimeline = (audioFile) => {
    const newClip = {
      id: `audio-${Date.now()}`,
      type: audioFile.type,
      name: audioFile.name,
      startTime: playheadPosition,
      duration: audioFile.duration,
      color: audioFile.type === 'music' ? '#00b894' : '#f39c12',
      audioFileId: audioFile.id,
    };
    
    const targetTrackId = audioFile.type === 'music' ? 'music-1' : 'audio-original';
    
    const newTracks = tracks.map(track => {
      if (track.id === targetTrackId) {
        return { ...track, clips: [...track.clips, newClip] };
      }
      return track;
    });
    
    saveToHistory(newTracks);
    setTracks(newTracks);
    setShowAudioWorkspace(false);
  };
  
  // Effects and transitions
  const transitions = [
    { id: 'fade', name: 'Fade', icon: '◐', duration: 0.5 },
    { id: 'dissolve', name: 'Dissolve', icon: '◑', duration: 0.5 },
    { id: 'wipe-left', name: 'Wipe Left', icon: '◧', duration: 0.5 },
    { id: 'wipe-right', name: 'Wipe Right', icon: '◨', duration: 0.5 },
    { id: 'zoom', name: 'Zoom', icon: '⊕', duration: 0.5 },
    { id: 'blur', name: 'Blur', icon: '◌', duration: 0.5 },
    { id: 'slide-up', name: 'Slide Up', icon: '↑', duration: 0.5 },
    { id: 'slide-down', name: 'Slide Down', icon: '↓', duration: 0.5 },
  ];
  
  const effects = [
    { id: 'color-grade', name: 'Color Grading', icon: '🎨', category: 'color' },
    { id: 'brightness', name: 'Brightness', icon: '☀️', category: 'adjustment' },
    { id: 'contrast', name: 'Contrast', icon: '◐', category: 'adjustment' },
    { id: 'saturation', name: 'Saturation', icon: '🌈', category: 'color' },
    { id: 'vignette', name: 'Vignette', icon: '⬭', category: 'stylize' },
    { id: 'blur-bg', name: 'Background Blur', icon: '◌', category: 'stylize' },
    { id: 'sharpen', name: 'Sharpen', icon: '◇', category: 'adjustment' },
    { id: 'noise-reduce', name: 'Noise Reduction', icon: '🔇', category: 'audio' },
    { id: 'stabilize', name: 'Stabilize', icon: '▣', category: 'motion' },
    { id: 'speed-ramp', name: 'Speed Ramp', icon: '⏩', category: 'motion' },
    { id: 'slow-mo', name: 'Slow Motion', icon: '🐢', category: 'motion' },
    { id: 'reverse', name: 'Reverse', icon: '⏪', category: 'motion' },
  ];
  
  const colorPresets = [
    { id: 'cinematic', name: 'Cinematic', colors: ['#1a1a2e', '#16213e', '#0f3460'], filter: 'contrast(1.1) saturate(0.9) sepia(0.1)' },
    { id: 'warm', name: 'Warm Sunset', colors: ['#ff6b6b', '#ffa500', '#ffd93d'], filter: 'sepia(0.3) saturate(1.3) brightness(1.05)' },
    { id: 'cool', name: 'Cool Blue', colors: ['#74b9ff', '#0984e3', '#2d3436'], filter: 'saturate(0.9) hue-rotate(10deg) brightness(0.95)' },
    { id: 'vintage', name: 'Vintage', colors: ['#d4a373', '#ccd5ae', '#e9edc9'], filter: 'sepia(0.4) contrast(0.9) brightness(1.1)' },
    { id: 'noir', name: 'Film Noir', colors: ['#2d2d2d', '#1a1a1a', '#0d0d0d'], filter: 'grayscale(1) contrast(1.3)' },
    { id: 'vibrant', name: 'Vibrant', colors: ['#e056fd', '#f0932b', '#6ab04c'], filter: 'saturate(1.5) contrast(1.1)' },
    { id: 'muted', name: 'Muted', colors: ['#636e72', '#b2bec3', '#dfe6e9'], filter: 'saturate(0.6) brightness(1.05)' },
    { id: 'teal-orange', name: 'Teal & Orange', colors: ['#008080', '#ff7f50', '#2f4f4f'], filter: 'contrast(1.15) saturate(1.2)' },
  ];
  
  const musicTracks = [
    { id: 'ambient-1', name: 'Calm Relaxing Ambient', duration: 180, genre: 'Ambient', bpm: 80 },
    { id: 'upbeat-1', name: 'Upbeat Corporate', duration: 120, genre: 'Corporate', bpm: 120 },
    { id: 'dramatic-1', name: 'Epic Cinematic', duration: 240, genre: 'Cinematic', bpm: 90 },
    { id: 'electronic-1', name: 'Modern Electronic', duration: 150, genre: 'Electronic', bpm: 128 },
    { id: 'acoustic-1', name: 'Acoustic Folk', duration: 200, genre: 'Folk', bpm: 100 },
    { id: 'jazz-1', name: 'Smooth Jazz', duration: 180, genre: 'Jazz', bpm: 95 },
  ];
  
  const soundFX = [
    { id: 'whoosh-1', name: 'Whoosh', duration: 0.5, category: 'transition' },
    { id: 'impact-1', name: 'Impact Hit', duration: 0.3, category: 'impact' },
    { id: 'rise-1', name: 'Cinematic Rise', duration: 2, category: 'tension' },
    { id: 'click-1', name: 'UI Click', duration: 0.1, category: 'ui' },
    { id: 'swoosh-1', name: 'Swoosh', duration: 0.4, category: 'transition' },
    { id: 'boom-1', name: 'Deep Boom', duration: 1, category: 'impact' },
  ];
  
  // Initialize tracks from episode
  const displayEpisode = episode || project?.episodes?.[0];
  
  React.useEffect(() => {
    if (displayEpisode?.scenes && tracks.length === 0) {
      // Create video track with clips
      const videoClips = [];
      let currentTime = 0;
      
      displayEpisode.scenes.forEach((scene, sceneIdx) => {
        (scene.shots || []).forEach((shot, shotIdx) => {
          videoClips.push({
            id: `video-${sceneIdx}-${shotIdx}`,
            type: 'video',
            name: `${scene.title} - Shot ${shotIdx + 1}`,
            startTime: currentTime,
            duration: shot.duration || 5,
            sceneIndex: sceneIdx,
            shotIndex: shotIdx,
            effects: [],
            color: `hsl(${(sceneIdx * 60) % 360}, 60%, 50%)`,
          });
          currentTime += shot.duration || 5;
        });
      });
      
      setTracks([
        { id: 'video-1', name: 'Video', type: 'video', clips: videoClips, locked: false, visible: true, muted: false },
        { id: 'audio-original', name: 'Original Sound', type: 'audio', clips: videoClips.map(c => ({ ...c, id: `audio-orig-${c.id}`, type: 'audio', color: '#00b894' })), locked: false, visible: true, muted: false },
        { id: 'effects-1', name: 'Black White Effect', type: 'effect', clips: [], locked: false, visible: true, muted: false },
        { id: 'effects-2', name: 'Block Flashes', type: 'effect', clips: [], locked: false, visible: true, muted: false },
        { id: 'effects-3', name: 'Pull In Effect', type: 'effect', clips: [], locked: false, visible: true, muted: false },
        { id: 'music-1', name: 'Music', type: 'music', clips: [], locked: false, visible: true, muted: false },
      ]);
      
      setTotalDuration(currentTime);
      
      // Create media assets from scenes
      const assets = displayEpisode.scenes.flatMap((scene, sceneIdx) =>
        (scene.shots || []).map((shot, shotIdx) => ({
          id: `asset-${sceneIdx}-${shotIdx}`,
          name: `Vid_${String(sceneIdx).padStart(3, '0')}${String(shotIdx).padStart(3, '0')}`,
          type: 'video',
          duration: shot.duration || 5,
          thumbnail: `hsl(${(sceneIdx * 60) % 360}, 40%, 30%)`,
        }))
      );
      setMediaAssets(assets);
    }
  }, [displayEpisode]);
  
  // Format time as HH:MM:SS:FF
  const formatTimecode = (seconds) => {
    const hrs = Math.floor(seconds / 3600);
    const mins = Math.floor((seconds % 3600) / 60);
    const secs = Math.floor(seconds % 60);
    const frames = Math.floor((seconds % 1) * 24);
    return `${String(hrs).padStart(2, '0')}:${String(mins).padStart(2, '0')}:${String(secs).padStart(2, '0')}:${String(frames).padStart(2, '0')}`;
  };
  
  // Format time as M:SS
  const formatTime = (seconds) => {
    const mins = Math.floor(seconds / 60);
    const secs = Math.floor(seconds % 60);
    return `${mins}:${String(secs).padStart(2, '0')}`;
  };
  
  // Pixels per second
  const pxPerSecond = 15 * zoom;
  
  // AI Analyzer
  const runAIAnalysis = () => {
    setIsAnalyzing(true);
    setShowAIAnalyzer(true);
    
    setTimeout(() => {
      setAnalysisResults({
        colorGrading: {
          suggestion: 'Teal & Orange',
          confidence: 0.89,
          reason: 'Detected outdoor urban scenes - teal/orange provides cinematic contrast',
        },
        pacing: {
          currentAvg: 4.2,
          suggestedAvg: 3.5,
          cuts: [
            { time: 12.5, type: 'too-slow', suggestion: 'Cut 1.5s earlier for better rhythm' },
            { time: 28.0, type: 'good', suggestion: 'Good cut timing' },
          ],
        },
        audio: {
          missingMusic: true,
          suggestedTrack: 'Epic Cinematic',
          lowAudioSpots: [{ start: 5, end: 12, suggestion: 'Add ambient sound' }],
        },
        transitions: {
          suggestions: [
            { between: [0, 1], type: 'dissolve', reason: 'Scene continuity' },
            { between: [3, 4], type: 'fade', reason: 'Time skip detected' },
          ],
        },
        effects: {
          stabilizationNeeded: [2, 4],
          colorCorrection: [{ clip: 1, issue: 'Underexposed', fix: 'Increase brightness +15%' }],
        },
      });
      setIsAnalyzing(false);
    }, 3000);
  };
  
  // Apply AI suggestions
  const applyAISuggestion = (type, suggestion) => {
    // Simulate applying suggestion
    console.log('Applying:', type, suggestion);
  };
  
  // Panel content renderer
  const renderPanelContent = () => {
    switch (activePanel) {
      case 'media':
        return (
          <div style={{ padding: '12px' }}>
            <div style={{ display: 'flex', gap: '8px', marginBottom: '12px' }}>
              <button style={{
                padding: '8px 16px',
                background: 'linear-gradient(135deg, #8b5cf6 0%, #6366f1 100%)',
                border: 'none',
                borderRadius: '6px',
                color: '#fff',
                cursor: 'pointer',
                display: 'flex',
                alignItems: 'center',
                gap: '6px',
                fontSize: '12px',
                fontWeight: '500',
              }}>
                <Icons.Upload style={{ width: 14, height: 14 }} />
                Upload
              </button>
              <button style={{
                padding: '6px 10px',
                background: colors.bg.tertiary,
                border: 'none',
                borderRadius: '6px',
                color: colors.text.secondary,
                cursor: 'pointer',
                fontSize: '12px',
              }}>
                Sort ↕
              </button>
            </div>
            <div style={{ display: 'grid', gridTemplateColumns: '1fr 1fr', gap: '8px' }}>
              {mediaAssets.map(asset => (
                <div
                  key={asset.id}
                  onClick={() => {
                    // Add to timeline
                    const newClip = {
                      id: `video-new-${Date.now()}`,
                      type: 'video',
                      name: asset.name,
                      startTime: totalDuration,
                      duration: asset.duration || 5,
                      color: asset.thumbnail,
                    };
                    setTracks(prev => prev.map(t => 
                      t.id === 'video-1' 
                        ? { ...t, clips: [...t.clips, newClip] }
                        : t
                    ));
                    setTotalDuration(prev => prev + (asset.duration || 5));
                  }}
                  style={{
                    background: asset.thumbnail,
                    aspectRatio: '16/9',
                    borderRadius: '6px',
                    cursor: 'pointer',
                    position: 'relative',
                    border: '2px solid transparent',
                    transition: 'all 0.2s',
                  }}
                  onMouseOver={(e) => e.currentTarget.style.border = '2px solid #8b5cf6'}
                  onMouseOut={(e) => e.currentTarget.style.border = '2px solid transparent'}
                >
                  <div style={{
                    position: 'absolute',
                    top: '4px',
                    right: '4px',
                    background: 'rgba(0,0,0,0.7)',
                    borderRadius: '4px',
                    padding: '2px 6px',
                    fontSize: '9px',
                    color: '#fff',
                  }}>
                    +
                  </div>
                  <div style={{
                    position: 'absolute',
                    bottom: '4px',
                    left: '4px',
                    right: '4px',
                    fontSize: '10px',
                    color: '#fff',
                    textShadow: '0 1px 2px rgba(0,0,0,0.8)',
                  }}>
                    {asset.name}
                  </div>
                </div>
              ))}
            </div>
          </div>
        );
        
      case 'audio':
        return (
          <div style={{ padding: '12px' }}>
            {/* Create Audio Button */}
            <button
              onClick={() => setShowAudioWorkspace(true)}
              style={{
                width: '100%',
                padding: '12px',
                background: 'linear-gradient(135deg, #00b894 0%, #00cec9 100%)',
                border: 'none',
                borderRadius: '8px',
                color: '#fff',
                fontSize: '13px',
                fontWeight: '600',
                cursor: 'pointer',
                display: 'flex',
                alignItems: 'center',
                justifyContent: 'center',
                gap: '8px',
                marginBottom: '16px',
                boxShadow: '0 4px 12px rgba(0, 184, 148, 0.3)',
              }}
            >
              <Icons.Sparkles style={{ width: 16, height: 16 }} />
              Create AI Audio
            </button>
            
            {/* Recently Generated */}
            {generatedAudioFiles.length > 0 && (
              <div style={{ marginBottom: '16px' }}>
                <h4 style={{ fontSize: '12px', color: colors.text.secondary, marginBottom: '8px' }}>RECENTLY GENERATED</h4>
                {generatedAudioFiles.slice(0, 4).map(file => (
                  <div
                    key={file.id}
                    onClick={() => handleAddGeneratedAudioToTimeline(file)}
                    style={{
                      padding: '8px 10px',
                      background: file.type === 'music' ? 'rgba(0,184,148,0.15)' : 'rgba(243,156,18,0.15)',
                      borderRadius: '6px',
                      marginBottom: '4px',
                      cursor: 'pointer',
                      border: `1px solid ${file.type === 'music' ? 'rgba(0,184,148,0.3)' : 'rgba(243,156,18,0.3)'}`,
                      display: 'flex',
                      justifyContent: 'space-between',
                      alignItems: 'center',
                    }}
                  >
                    <div>
                      <div style={{ fontSize: '12px', color: colors.text.primary }}>{file.name}</div>
                      <div style={{ fontSize: '10px', color: colors.text.tertiary }}>
                        {file.type === 'music' ? '🎵' : '🔊'} {file.duration.toFixed(1)}s
                      </div>
                    </div>
                    <span style={{ fontSize: '16px', color: file.type === 'music' ? '#00b894' : '#f39c12' }}>+</span>
                  </div>
                ))}
              </div>
            )}
            
            <div style={{ marginBottom: '16px' }}>
              <h4 style={{ fontSize: '12px', color: colors.text.secondary, marginBottom: '8px' }}>MUSIC LIBRARY</h4>
              {musicTracks.map(track => (
                <div
                  key={track.id}
                  onClick={() => {
                    // Add music to timeline
                    const newClip = {
                      id: `music-${Date.now()}`,
                      type: 'music',
                      name: track.name,
                      startTime: 0,
                      duration: Math.min(track.duration, totalDuration || 60),
                      color: '#00b894',
                    };
                    setTracks(prev => prev.map(t => 
                      t.id === 'music-1' 
                        ? { ...t, clips: [...t.clips, newClip] }
                        : t
                    ));
                  }}
                  style={{
                    padding: '10px 12px',
                    background: colors.bg.tertiary,
                    borderRadius: '6px',
                    marginBottom: '6px',
                    cursor: 'pointer',
                    border: '2px solid transparent',
                    transition: 'all 0.2s',
                  }}
                  onMouseOver={(e) => {
                    e.currentTarget.style.border = '2px solid #00b894';
                    e.currentTarget.style.background = '#1a2d28';
                  }}
                  onMouseOut={(e) => {
                    e.currentTarget.style.border = '2px solid transparent';
                    e.currentTarget.style.background = colors.bg.tertiary;
                  }}
                >
                  <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center' }}>
                    <div style={{ fontSize: '13px', color: colors.text.primary, marginBottom: '2px' }}>{track.name}</div>
                    <span style={{ fontSize: '10px', color: '#00b894', background: 'rgba(0,184,148,0.2)', padding: '2px 6px', borderRadius: '4px' }}>+ Add</span>
                  </div>
                  <div style={{ fontSize: '11px', color: colors.text.tertiary }}>
                    {Math.floor(track.duration / 60)}:{String(track.duration % 60).padStart(2, '0')} • {track.genre} • {track.bpm} BPM
                  </div>
                </div>
              ))}
            </div>
            <div>
              <h4 style={{ fontSize: '12px', color: colors.text.secondary, marginBottom: '8px' }}>SOUND FX</h4>
              {soundFX.map(fx => (
                <div
                  key={fx.id}
                  onClick={() => {
                    // Add SFX to timeline at playhead
                    const newClip = {
                      id: `sfx-${Date.now()}`,
                      type: 'sfx',
                      name: fx.name,
                      startTime: playheadPosition,
                      duration: fx.duration,
                      color: '#f39c12',
                    };
                    setTracks(prev => prev.map(t => 
                      t.id === 'audio-original' 
                        ? { ...t, clips: [...t.clips, newClip] }
                        : t
                    ));
                  }}
                  style={{
                    padding: '8px 12px',
                    background: colors.bg.tertiary,
                    borderRadius: '6px',
                    marginBottom: '4px',
                    cursor: 'pointer',
                    display: 'flex',
                    justifyContent: 'space-between',
                    alignItems: 'center',
                    border: '2px solid transparent',
                    transition: 'all 0.2s',
                  }}
                  onMouseOver={(e) => e.currentTarget.style.border = '2px solid #f39c12'}
                  onMouseOut={(e) => e.currentTarget.style.border = '2px solid transparent'}
                >
                  <span style={{ fontSize: '12px', color: colors.text.primary }}>{fx.name}</span>
                  <span style={{ fontSize: '10px', color: colors.text.tertiary }}>{fx.duration}s</span>
                </div>
              ))}
            </div>
          </div>
        );
        
      case 'video':
        return (
          <div style={{ padding: '12px' }}>
            <h4 style={{ fontSize: '12px', color: colors.text.secondary, marginBottom: '12px' }}>VIDEO EFFECTS</h4>
            {[
              { id: 'speed', name: 'Speed Adjustment', icon: '⏩', desc: 'Change playback speed' },
              { id: 'reverse', name: 'Reverse', icon: '⏪', desc: 'Play backwards' },
              { id: 'freeze', name: 'Freeze Frame', icon: '❄️', desc: 'Hold on a frame' },
              { id: 'crop', name: 'Crop & Zoom', icon: '🔲', desc: 'Adjust framing' },
              { id: 'rotate', name: 'Rotate', icon: '🔄', desc: 'Rotate video' },
              { id: 'flip', name: 'Flip', icon: '↔️', desc: 'Mirror video' },
            ].map(effect => (
              <div
                key={effect.id}
                style={{
                  padding: '12px',
                  background: colors.bg.tertiary,
                  borderRadius: '8px',
                  marginBottom: '8px',
                  cursor: 'pointer',
                  display: 'flex',
                  alignItems: 'center',
                  gap: '12px',
                  border: '2px solid transparent',
                  transition: 'all 0.2s',
                }}
                onMouseOver={(e) => e.currentTarget.style.border = '2px solid #8b5cf6'}
                onMouseOut={(e) => e.currentTarget.style.border = '2px solid transparent'}
              >
                <span style={{ fontSize: '20px' }}>{effect.icon}</span>
                <div>
                  <div style={{ fontSize: '13px', color: colors.text.primary }}>{effect.name}</div>
                  <div style={{ fontSize: '11px', color: colors.text.tertiary }}>{effect.desc}</div>
                </div>
              </div>
            ))}
          </div>
        );
        
      case 'photo':
        return (
          <div style={{ padding: '12px' }}>
            <h4 style={{ fontSize: '12px', color: colors.text.secondary, marginBottom: '12px' }}>OVERLAYS</h4>
            <button style={{
              width: '100%',
              padding: '10px',
              background: 'linear-gradient(135deg, #8b5cf6 0%, #6366f1 100%)',
              border: 'none',
              borderRadius: '6px',
              color: '#fff',
              cursor: 'pointer',
              marginBottom: '12px',
              fontSize: '13px',
            }}>
              <Icons.Upload style={{ width: 14, height: 14, marginRight: '6px' }} />
              Import Image
            </button>
            <div style={{ display: 'grid', gridTemplateColumns: '1fr 1fr', gap: '8px' }}>
              {[
                { id: 'logo', name: 'Logo', color: '#3498db' },
                { id: 'watermark', name: 'Watermark', color: '#9b59b6' },
                { id: 'frame', name: 'Frame', color: '#e74c3c' },
                { id: 'badge', name: 'Badge', color: '#f39c12' },
              ].map(overlay => (
                <div
                  key={overlay.id}
                  style={{
                    aspectRatio: '1',
                    background: overlay.color,
                    borderRadius: '8px',
                    display: 'flex',
                    alignItems: 'center',
                    justifyContent: 'center',
                    cursor: 'pointer',
                    fontSize: '11px',
                    color: '#fff',
                    fontWeight: '500',
                  }}
                >
                  {overlay.name}
                </div>
              ))}
            </div>
          </div>
        );
      
      case 'transitions':
        return (
          <div style={{ padding: '12px' }}>
            <h4 style={{ fontSize: '12px', color: colors.text.secondary, marginBottom: '12px' }}>TRANSITIONS</h4>
            <p style={{ fontSize: '11px', color: colors.text.tertiary, marginBottom: '12px' }}>Click to apply between clips</p>
            <div style={{ display: 'grid', gridTemplateColumns: '1fr 1fr', gap: '8px' }}>
              {transitions.map(t => (
                <div
                  key={t.id}
                  style={{
                    padding: '16px',
                    background: colors.bg.tertiary,
                    borderRadius: '8px',
                    textAlign: 'center',
                    cursor: 'pointer',
                    border: '2px solid transparent',
                    transition: 'all 0.2s',
                  }}
                  onMouseOver={(e) => e.currentTarget.style.border = '2px solid #8b5cf6'}
                  onMouseOut={(e) => e.currentTarget.style.border = '2px solid transparent'}
                >
                  <div style={{ fontSize: '24px', marginBottom: '4px' }}>{t.icon}</div>
                  <div style={{ fontSize: '11px', color: colors.text.secondary }}>{t.name}</div>
                  <div style={{ fontSize: '9px', color: colors.text.tertiary }}>{t.duration}s</div>
                </div>
              ))}
            </div>
          </div>
        );
        
      case 'effect':
        return (
          <div style={{ padding: '12px' }}>
            <h4 style={{ fontSize: '12px', color: colors.text.secondary, marginBottom: '12px' }}>COLOR PRESETS</h4>
            <div style={{ display: 'grid', gridTemplateColumns: '1fr 1fr', gap: '8px', marginBottom: '16px' }}>
              {colorPresets.map(preset => (
                <div
                  key={preset.id}
                  style={{
                    padding: '8px',
                    background: colors.bg.tertiary,
                    borderRadius: '8px',
                    cursor: 'pointer',
                  }}
                >
                  <div style={{ display: 'flex', gap: '2px', marginBottom: '6px' }}>
                    {preset.colors.map((c, i) => (
                      <div key={i} style={{ flex: 1, height: '20px', background: c, borderRadius: i === 0 ? '4px 0 0 4px' : i === 2 ? '0 4px 4px 0' : '0' }} />
                    ))}
                  </div>
                  <div style={{ fontSize: '11px', color: colors.text.secondary, textAlign: 'center' }}>{preset.name}</div>
                </div>
              ))}
            </div>
            <h4 style={{ fontSize: '12px', color: colors.text.secondary, marginBottom: '8px' }}>EFFECTS</h4>
            {effects.map(effect => (
              <div
                key={effect.id}
                style={{
                  padding: '10px 12px',
                  background: colors.bg.tertiary,
                  borderRadius: '6px',
                  marginBottom: '4px',
                  cursor: 'pointer',
                  display: 'flex',
                  alignItems: 'center',
                  gap: '10px',
                }}
              >
                <span style={{ fontSize: '16px' }}>{effect.icon}</span>
                <span style={{ fontSize: '12px', color: colors.text.primary }}>{effect.name}</span>
              </div>
            ))}
          </div>
        );
        
      case 'text':
        return (
          <div style={{ padding: '12px' }}>
            <Button style={{ width: '100%', marginBottom: '12px' }}>
              <Icons.Type style={{ width: 14, height: 14, marginRight: '6px' }} />
              Add Text
            </Button>
            <div style={{ fontSize: '12px', color: colors.text.secondary, marginBottom: '8px' }}>PRESETS</div>
            {['Title', 'Subtitle', 'Lower Third', 'Caption', 'Credits'].map(preset => (
              <div
                key={preset}
                style={{
                  padding: '12px',
                  background: colors.bg.tertiary,
                  borderRadius: '6px',
                  marginBottom: '6px',
                  cursor: 'pointer',
                  fontSize: '13px',
                  color: colors.text.primary,
                }}
              >
                {preset}
              </div>
            ))}
          </div>
        );
        
      case 'adjustment':
        return (
          <div style={{ padding: '12px' }}>
            {[
              { name: 'Brightness', value: 0, min: -100, max: 100 },
              { name: 'Contrast', value: 0, min: -100, max: 100 },
              { name: 'Saturation', value: 0, min: -100, max: 100 },
              { name: 'Temperature', value: 0, min: -100, max: 100 },
              { name: 'Exposure', value: 0, min: -100, max: 100 },
              { name: 'Highlights', value: 0, min: -100, max: 100 },
              { name: 'Shadows', value: 0, min: -100, max: 100 },
            ].map(adj => (
              <div key={adj.name} style={{ marginBottom: '12px' }}>
                <div style={{ display: 'flex', justifyContent: 'space-between', marginBottom: '4px' }}>
                  <span style={{ fontSize: '12px', color: colors.text.secondary }}>{adj.name}</span>
                  <span style={{ fontSize: '12px', color: colors.text.primary }}>{adj.value}</span>
                </div>
                <input type="range" min={adj.min} max={adj.max} defaultValue={adj.value} style={{ width: '100%' }} />
              </div>
            ))}
          </div>
        );
        
      case 'sticker':
        return (
          <div style={{ padding: '12px' }}>
            <h4 style={{ fontSize: '12px', color: colors.text.secondary, marginBottom: '12px' }}>STICKERS & EMOJIS</h4>
            <div style={{ display: 'grid', gridTemplateColumns: 'repeat(4, 1fr)', gap: '8px', marginBottom: '16px' }}>
              {['😀', '😂', '🎉', '🔥', '💯', '⭐', '❤️', '👍', '🎬', '🎭', '🎪', '✨', '💥', '💫', '🌟', '⚡'].map((emoji, i) => (
                <div
                  key={i}
                  style={{
                    aspectRatio: '1',
                    background: colors.bg.tertiary,
                    borderRadius: '8px',
                    display: 'flex',
                    alignItems: 'center',
                    justifyContent: 'center',
                    fontSize: '24px',
                    cursor: 'pointer',
                    border: '2px solid transparent',
                    transition: 'all 0.2s',
                  }}
                  onMouseOver={(e) => e.currentTarget.style.border = '2px solid #8b5cf6'}
                  onMouseOut={(e) => e.currentTarget.style.border = '2px solid transparent'}
                >
                  {emoji}
                </div>
              ))}
            </div>
            <h4 style={{ fontSize: '12px', color: colors.text.secondary, marginBottom: '8px' }}>ANIMATED</h4>
            <div style={{ display: 'grid', gridTemplateColumns: '1fr 1fr', gap: '8px' }}>
              {['Subscribe', 'Like', 'Follow', 'Share'].map(label => (
                <div
                  key={label}
                  style={{
                    padding: '12px',
                    background: 'linear-gradient(135deg, #e74c3c 0%, #c0392b 100%)',
                    borderRadius: '8px',
                    textAlign: 'center',
                    cursor: 'pointer',
                    fontSize: '11px',
                    color: '#fff',
                    fontWeight: '600',
                  }}
                >
                  {label}
                </div>
              ))}
            </div>
          </div>
        );
        
      case 'settings':
        return (
          <div style={{ padding: '12px' }}>
            <h4 style={{ fontSize: '12px', color: colors.text.secondary, marginBottom: '12px' }}>PROJECT SETTINGS</h4>
            
            <div style={{ marginBottom: '16px' }}>
              <label style={{ fontSize: '11px', color: colors.text.tertiary, display: 'block', marginBottom: '6px' }}>Resolution</label>
              <select style={{
                width: '100%',
                padding: '8px 12px',
                background: colors.bg.tertiary,
                border: `1px solid ${colors.border.default}`,
                borderRadius: '6px',
                color: colors.text.primary,
                fontSize: '13px',
              }}>
                <option>1080p (1920x1080)</option>
                <option>4K (3840x2160)</option>
                <option>720p (1280x720)</option>
                <option>480p (854x480)</option>
              </select>
            </div>
            
            <div style={{ marginBottom: '16px' }}>
              <label style={{ fontSize: '11px', color: colors.text.tertiary, display: 'block', marginBottom: '6px' }}>Frame Rate</label>
              <select style={{
                width: '100%',
                padding: '8px 12px',
                background: colors.bg.tertiary,
                border: `1px solid ${colors.border.default}`,
                borderRadius: '6px',
                color: colors.text.primary,
                fontSize: '13px',
              }}>
                <option>24 fps (Cinema)</option>
                <option>30 fps</option>
                <option>60 fps</option>
              </select>
            </div>
            
            <div style={{ marginBottom: '16px' }}>
              <label style={{ fontSize: '11px', color: colors.text.tertiary, display: 'block', marginBottom: '6px' }}>Aspect Ratio</label>
              <select style={{
                width: '100%',
                padding: '8px 12px',
                background: colors.bg.tertiary,
                border: `1px solid ${colors.border.default}`,
                borderRadius: '6px',
                color: colors.text.primary,
                fontSize: '13px',
              }}>
                <option>16:9 (Widescreen)</option>
                <option>9:16 (Vertical)</option>
                <option>1:1 (Square)</option>
                <option>4:3 (Standard)</option>
                <option>21:9 (Cinematic)</option>
              </select>
            </div>
            
            <div style={{ marginBottom: '16px' }}>
              <label style={{ fontSize: '11px', color: colors.text.tertiary, display: 'block', marginBottom: '6px' }}>Background Color</label>
              <div style={{ display: 'flex', gap: '8px' }}>
                {['#000000', '#ffffff', '#1a1a1a', '#0066ff', '#00ff00'].map(color => (
                  <div
                    key={color}
                    style={{
                      width: '32px',
                      height: '32px',
                      background: color,
                      borderRadius: '6px',
                      cursor: 'pointer',
                      border: '2px solid #333',
                    }}
                  />
                ))}
              </div>
            </div>
          </div>
        );
        
      default:
        return (
          <div style={{ padding: '20px', textAlign: 'center', color: colors.text.tertiary }}>
            Select an option
          </div>
        );
    }
  };
  
  // Left sidebar panels
  const panels = [
    { id: 'media', icon: '📁', label: 'Media' },
    { id: 'video', icon: '🎬', label: 'Video' },
    { id: 'photo', icon: '📷', label: 'Photo' },
    { id: 'audio', icon: '🎵', label: 'Audio' },
    { id: 'text', icon: '𝐓', label: 'Text' },
    { id: 'transitions', icon: '⬚', label: 'Transitions' },
    { id: 'effect', icon: '✨', label: 'Effect' },
    { id: 'sticker', icon: '😀', label: 'Sticker' },
    { id: 'adjustment', icon: '◐', label: 'Adjustment' },
    { id: 'settings', icon: '⚙', label: 'Settings' },
  ];

  return (
    <div style={{ flex: 1, display: 'flex', flexDirection: 'column', overflow: 'hidden', background: '#1a1a1a' }}>
      {/* Header */}
      <div style={{
        padding: '8px 16px',
        background: '#2d2d2d',
        borderBottom: '1px solid #3d3d3d',
        display: 'flex',
        alignItems: 'center',
        justifyContent: 'space-between',
      }}>
        <div style={{ display: 'flex', alignItems: 'center', gap: '12px' }}>
          <button
            onClick={onBack}
            style={{ background: 'none', border: 'none', color: '#888', cursor: 'pointer', display: 'flex', alignItems: 'center' }}
          >
            <Icons.ChevronLeft style={{ width: 20, height: 20 }} />
          </button>
          <span style={{ fontSize: '13px', color: '#888' }}>📁 Uploaded</span>
        </div>
        
        <div style={{ display: 'flex', alignItems: 'center', gap: '8px' }}>
          <span style={{ fontSize: '14px', color: '#fff' }}>🎬 {displayEpisode?.title || 'Video Project'}</span>
          <Icons.ChevronDown style={{ width: 14, height: 14, color: '#888' }} />
        </div>
        
        <div style={{ display: 'flex', alignItems: 'center', gap: '12px' }}>
          <button 
            onClick={() => setShowPreviewModal(true)}
            style={{
              padding: '8px 16px',
              background: 'linear-gradient(135deg, #8b5cf6 0%, #a855f7 100%)',
              border: 'none',
              borderRadius: '8px',
              color: '#fff',
              fontSize: '13px',
              fontWeight: '600',
              cursor: 'pointer',
              display: 'flex',
              alignItems: 'center',
              gap: '8px',
              boxShadow: '0 4px 15px rgba(139, 92, 246, 0.4)',
              transition: 'all 0.3s ease',
            }}
            onMouseOver={(e) => {
              e.target.style.transform = 'translateY(-2px)';
              e.target.style.boxShadow = '0 6px 20px rgba(139, 92, 246, 0.6)';
            }}
            onMouseOut={(e) => {
              e.target.style.transform = 'translateY(0)';
              e.target.style.boxShadow = '0 4px 15px rgba(139, 92, 246, 0.4)';
            }}
          >
            <Icons.Play style={{ width: 16, height: 16 }} />
            Preview
          </button>
          <Button onClick={onExport}>
            Export
            <Icons.Download style={{ width: 14, height: 14, marginLeft: '6px' }} />
          </Button>
        </div>
      </div>
      
      {/* Main Content */}
      <div style={{ flex: 1, display: 'flex', overflow: 'hidden' }}>
        {/* Left Sidebar - Tool Panels */}
        <div style={{ width: '60px', background: '#252525', borderRight: '1px solid #3d3d3d', display: 'flex', flexDirection: 'column' }}>
          {panels.map(panel => (
            <button
              key={panel.id}
              onClick={() => setActivePanel(panel.id)}
              style={{
                padding: '12px 8px',
                background: activePanel === panel.id ? '#3d3d3d' : 'transparent',
                border: 'none',
                borderLeft: activePanel === panel.id ? '2px solid #8b5cf6' : '2px solid transparent',
                color: activePanel === panel.id ? '#fff' : '#888',
                cursor: 'pointer',
                display: 'flex',
                flexDirection: 'column',
                alignItems: 'center',
                gap: '4px',
              }}
            >
              <span style={{ fontSize: '18px' }}>{panel.icon}</span>
              <span style={{ fontSize: '9px' }}>{panel.label}</span>
            </button>
          ))}
        </div>
        
        {/* Panel Content */}
        <div style={{ width: '220px', background: '#2a2a2a', borderRight: '1px solid #3d3d3d', overflow: 'auto' }}>
          {renderPanelContent()}
        </div>
        
        {/* Preview Area */}
        <div style={{ flex: 1, display: 'flex', flexDirection: 'column' }}>
          {/* Video Preview - Full Width */}
          <div style={{ 
            flex: 1, 
            display: 'flex', 
            flexDirection: 'column',
            background: '#0d0d0d', 
            position: 'relative',
            minHeight: '300px',
          }}>
            {/* Video Container - Fills Space */}
            <div style={{
              flex: 1,
              display: 'flex',
              alignItems: 'center',
              justifyContent: 'center',
              padding: '16px',
            }}>
              <div style={{
                width: '100%',
                height: '100%',
                maxWidth: '1200px',
                aspectRatio: '16/9',
                background: 'linear-gradient(135deg, #1a1a1a 0%, #0d0d0d 100%)',
                borderRadius: '8px',
                display: 'flex',
                alignItems: 'center',
                justifyContent: 'center',
                position: 'relative',
                border: '1px solid #2d2d2d',
              }}>
                <Icons.Film style={{ width: 64, height: 64, color: '#333' }} />
                
                {/* Timeline position indicator */}
                <div style={{
                  position: 'absolute',
                  left: '16px',
                  top: '16px',
                  background: 'rgba(0,0,0,0.8)',
                  padding: '6px 12px',
                  borderRadius: '6px',
                  fontSize: '13px',
                  color: '#00ff00',
                  fontFamily: 'monospace',
                  fontWeight: '600',
                }}>
                  {formatTimecode(playheadPosition)}
                </div>
                
                {/* Selected clip info */}
                {selectedClip && (
                  <div style={{
                    position: 'absolute',
                    right: '16px',
                    top: '16px',
                    background: 'rgba(0,0,0,0.8)',
                    padding: '6px 12px',
                    borderRadius: '6px',
                    fontSize: '12px',
                    color: '#fff',
                  }}>
                    {selectedClip.name}
                  </div>
                )}
              </div>
            </div>
            
            {/* Playback Controls Bar - Below Video */}
            <div style={{
              padding: '12px 24px',
              background: '#1a1a1a',
              borderTop: '1px solid #2d2d2d',
              display: 'flex',
              alignItems: 'center',
              justifyContent: 'center',
              gap: '20px',
            }}>
              {/* Time Display */}
              <span style={{ 
                fontSize: '13px', 
                color: '#888', 
                fontFamily: 'monospace', 
                minWidth: '100px',
              }}>
                {formatTimecode(playheadPosition)}
              </span>
              
              {/* Control Buttons */}
              <div style={{ display: 'flex', alignItems: 'center', gap: '8px' }}>
                <button 
                  onClick={() => setPlayheadPosition(0)}
                  style={{ 
                    background: 'none', 
                    border: 'none', 
                    cursor: 'pointer', 
                    color: '#888',
                    padding: '8px',
                    borderRadius: '6px',
                    transition: 'all 0.2s',
                  }}
                  onMouseOver={(e) => e.target.style.background = '#333'}
                  onMouseOut={(e) => e.target.style.background = 'none'}
                >
                  <Icons.SkipBack style={{ width: 20, height: 20 }} />
                </button>
                
                <button 
                  onClick={() => setPlayheadPosition(Math.max(0, playheadPosition - 5))}
                  style={{ 
                    background: 'none', 
                    border: 'none', 
                    cursor: 'pointer', 
                    color: '#888',
                    padding: '8px',
                    borderRadius: '6px',
                    fontSize: '16px',
                  }}
                >
                  ⏮
                </button>
                
                <button
                  onClick={() => setIsPlaying(!isPlaying)}
                  style={{
                    width: '48px',
                    height: '48px',
                    borderRadius: '50%',
                    background: isPlaying ? '#ef4444' : '#8b5cf6',
                    border: 'none',
                    cursor: 'pointer',
                    display: 'flex',
                    alignItems: 'center',
                    justifyContent: 'center',
                    fontSize: '18px',
                    color: '#fff',
                    transition: 'all 0.2s',
                    boxShadow: isPlaying ? '0 0 20px rgba(239,68,68,0.4)' : '0 0 20px rgba(139,92,246,0.4)',
                  }}
                >
                  {isPlaying ? '⏸' : '▶'}
                </button>
                
                <button 
                  onClick={() => setPlayheadPosition(Math.min(totalDuration, playheadPosition + 5))}
                  style={{ 
                    background: 'none', 
                    border: 'none', 
                    cursor: 'pointer', 
                    color: '#888',
                    padding: '8px',
                    borderRadius: '6px',
                    fontSize: '16px',
                  }}
                >
                  ⏭
                </button>
                
                <button 
                  onClick={() => setPlayheadPosition(totalDuration)}
                  style={{ 
                    background: 'none', 
                    border: 'none', 
                    cursor: 'pointer', 
                    color: '#888',
                    padding: '8px',
                    borderRadius: '6px',
                  }}
                >
                  <Icons.SkipForward style={{ width: 20, height: 20 }} />
                </button>
              </div>
              
              {/* Duration Display */}
              <span style={{ 
                fontSize: '13px', 
                color: '#888', 
                fontFamily: 'monospace', 
                minWidth: '100px', 
                textAlign: 'right',
              }}>
                {formatTimecode(totalDuration)}
              </span>
              
              {/* Volume & Fullscreen */}
              <div style={{ display: 'flex', alignItems: 'center', gap: '12px', marginLeft: '20px' }}>
                <button style={{ 
                  background: 'none', 
                  border: 'none', 
                  cursor: 'pointer', 
                  color: '#888',
                  padding: '8px',
                }}>
                  🔊
                </button>
                <input 
                  type="range" 
                  min="0" 
                  max="100" 
                  defaultValue="100" 
                  style={{ width: '80px', accentColor: '#8b5cf6' }} 
                />
                <button style={{ 
                  background: 'none', 
                  border: 'none', 
                  cursor: 'pointer', 
                  color: '#888',
                  padding: '8px',
                  fontSize: '16px',
                }}>
                  ⛶
                </button>
              </div>
            </div>
          </div>
          
          {/* Timeline */}
          <div style={{ height: '280px', background: '#1e1e1e', borderTop: '1px solid #3d3d3d' }}>
            {/* Timeline Header / Time Ruler */}
            <div style={{
              height: '32px',
              background: '#252525',
              borderBottom: '1px solid #3d3d3d',
              display: 'flex',
              alignItems: 'center',
            }}>
              {/* Track controls spacer */}
              <div style={{ width: '180px', paddingLeft: '12px', display: 'flex', alignItems: 'center', gap: '8px' }}>
                <button style={{ background: 'none', border: 'none', color: '#888', cursor: 'pointer', fontSize: '12px' }}>
                  Layers ▾
                </button>
              </div>
              
              {/* Time ruler */}
              <div style={{ flex: 1, overflow: 'hidden', position: 'relative' }}>
                <div style={{ display: 'flex' }}>
                  {Array.from({ length: Math.ceil(totalDuration / 10) + 1 }, (_, i) => (
                    <div
                      key={i}
                      style={{
                        width: `${10 * pxPerSecond}px`,
                        fontSize: '10px',
                        color: '#666',
                        paddingLeft: '4px',
                        borderLeft: '1px solid #3d3d3d',
                      }}
                    >
                      {formatTimecode(i * 10).slice(3, -3)}
                    </div>
                  ))}
                </div>
                
                {/* Playhead */}
                <div style={{
                  position: 'absolute',
                  left: `${playheadPosition * pxPerSecond}px`,
                  top: 0,
                  bottom: '-250px',
                  width: '2px',
                  background: '#f1c40f',
                  zIndex: 100,
                }}>
                  <div style={{
                    position: 'absolute',
                    top: '-4px',
                    left: '-6px',
                    width: '14px',
                    height: '14px',
                    background: '#f1c40f',
                    borderRadius: '2px 2px 50% 50%',
                  }} />
                </div>
              </div>
            </div>
            
            {/* Tracks */}
            <div style={{ flex: 1, overflow: 'auto' }}>
              {/* Track Controls Column + Clips */}
              {tracks.map((track, trackIdx) => (
                <div
                  key={track.id}
                  style={{
                    display: 'flex',
                    height: track.type === 'video' ? '60px' : '36px',
                    borderBottom: '1px solid #2d2d2d',
                  }}
                >
                  {/* Track Controls */}
                  <div style={{
                    width: '180px',
                    background: '#252525',
                    padding: '4px 8px',
                    display: 'flex',
                    alignItems: 'center',
                    gap: '6px',
                    borderRight: '1px solid #3d3d3d',
                  }}>
                    <button style={{ background: 'none', border: 'none', color: track.locked ? '#666' : '#888', cursor: 'pointer', fontSize: '12px' }}>
                      🔒
                    </button>
                    <button style={{ background: 'none', border: 'none', color: track.muted ? '#666' : '#888', cursor: 'pointer', fontSize: '12px' }}>
                      {track.type === 'audio' || track.type === 'music' ? '🔊' : '👁'}
                    </button>
                    <button style={{ background: 'none', border: 'none', color: '#888', cursor: 'pointer', fontSize: '12px' }}>
                      👁
                    </button>
                    <span style={{
                      fontSize: '11px',
                      color: track.type === 'video' ? '#fff' : track.type === 'effect' ? '#e74c3c' : '#00b894',
                      flex: 1,
                      overflow: 'hidden',
                      textOverflow: 'ellipsis',
                      whiteSpace: 'nowrap',
                    }}>
                      {track.name}
                    </span>
                  </div>
                  
                  {/* Track Clips */}
                  <div style={{ flex: 1, position: 'relative', background: '#1a1a1a' }}>
                    {track.clips.map(clip => (
                      <div
                        key={clip.id}
                        onClick={() => setSelectedClip(clip)}
                        style={{
                          position: 'absolute',
                          left: `${clip.startTime * pxPerSecond}px`,
                          width: `${clip.duration * pxPerSecond}px`,
                          top: '2px',
                          bottom: '2px',
                          background: track.type === 'video' 
                            ? `linear-gradient(180deg, ${clip.color} 0%, ${clip.color}88 100%)`
                            : track.type === 'effect'
                            ? `linear-gradient(90deg, ${['#e74c3c', '#9b59b6', '#3498db'][trackIdx % 3]}88 0%, ${['#e74c3c', '#9b59b6', '#3498db'][trackIdx % 3]}44 100%)`
                            : 'linear-gradient(180deg, #00b89488 0%, #00b89444 100%)',
                          borderRadius: '4px',
                          cursor: 'pointer',
                          border: selectedClip?.id === clip.id ? '2px solid #f1c40f' : '1px solid rgba(255,255,255,0.1)',
                          overflow: 'hidden',
                          display: 'flex',
                          alignItems: 'center',
                          padding: '0 6px',
                        }}
                      >
                        {track.type === 'video' && (
                          <span style={{ fontSize: '10px', color: '#fff', textShadow: '0 1px 2px rgba(0,0,0,0.5)', overflow: 'hidden', textOverflow: 'ellipsis', whiteSpace: 'nowrap' }}>
                            {clip.name}
                          </span>
                        )}
                        {track.type !== 'video' && (
                          <div style={{
                            width: '100%',
                            height: '60%',
                            background: 'rgba(255,255,255,0.2)',
                            borderRadius: '2px',
                            display: 'flex',
                            alignItems: 'center',
                            overflow: 'hidden',
                          }}>
                            {/* Fake waveform */}
                            {Array.from({ length: Math.floor(clip.duration * 3) }, (_, i) => (
                              <div
                                key={i}
                                style={{
                                  width: '2px',
                                  marginRight: '1px',
                                  height: `${20 + Math.random() * 60}%`,
                                  background: 'rgba(255,255,255,0.5)',
                                  borderRadius: '1px',
                                }}
                              />
                            ))}
                          </div>
                        )}
                      </div>
                    ))}
                  </div>
                </div>
              ))}
            </div>
            
            {/* Timeline Footer / Tools */}
            <div style={{
              height: '40px',
              background: '#252525',
              borderTop: '1px solid #3d3d3d',
              display: 'flex',
              alignItems: 'center',
              justifyContent: 'space-between',
              padding: '0 12px',
            }}>
              <div style={{ display: 'flex', alignItems: 'center', gap: '4px' }}>
                <button 
                  onClick={handleUndo}
                  disabled={historyIndex <= 0}
                  title="Undo (Ctrl+Z)"
                  style={{ 
                    background: 'none', 
                    border: 'none', 
                    color: historyIndex > 0 ? '#888' : '#444', 
                    cursor: historyIndex > 0 ? 'pointer' : 'not-allowed',
                    padding: '6px 8px',
                    borderRadius: '4px',
                  }}
                >↩</button>
                <button 
                  onClick={handleRedo}
                  disabled={historyIndex >= history.length - 1}
                  title="Redo (Ctrl+Y)"
                  style={{ 
                    background: 'none', 
                    border: 'none', 
                    color: historyIndex < history.length - 1 ? '#888' : '#444', 
                    cursor: historyIndex < history.length - 1 ? 'pointer' : 'not-allowed',
                    padding: '6px 8px',
                    borderRadius: '4px',
                  }}
                >↪</button>
                <span style={{ color: '#333', margin: '0 4px' }}>|</span>
                <button 
                  onClick={handleDeleteClip}
                  disabled={!selectedClip}
                  title="Delete (Del)"
                  style={{ 
                    background: 'none', 
                    border: 'none', 
                    color: selectedClip ? '#ef4444' : '#444', 
                    cursor: selectedClip ? 'pointer' : 'not-allowed',
                    padding: '6px 8px',
                    borderRadius: '4px',
                  }}
                >🗑</button>
              </div>
              
              <div style={{ display: 'flex', alignItems: 'center', gap: '8px' }}>
                <button
                  onClick={handleSplitClip}
                  disabled={!selectedClip}
                  title="Split at Playhead (S)"
                  style={{
                    background: selectedClip ? '#2d2d2d' : 'transparent',
                    border: '1px solid #3d3d3d',
                    color: selectedClip ? '#fff' : '#555',
                    cursor: selectedClip ? 'pointer' : 'not-allowed',
                    fontSize: '11px',
                    display: 'flex',
                    alignItems: 'center',
                    gap: '4px',
                    padding: '6px 12px',
                    borderRadius: '4px',
                  }}
                >
                  ✂ Split
                </button>
                <button
                  onClick={handleDuplicateClip}
                  disabled={!selectedClip}
                  title="Duplicate (Ctrl+D)"
                  style={{
                    background: selectedClip ? '#2d2d2d' : 'transparent',
                    border: '1px solid #3d3d3d',
                    color: selectedClip ? '#fff' : '#555',
                    cursor: selectedClip ? 'pointer' : 'not-allowed',
                    fontSize: '11px',
                    display: 'flex',
                    alignItems: 'center',
                    gap: '4px',
                    padding: '6px 12px',
                    borderRadius: '4px',
                  }}
                >
                  ⧉ Duplicate
                </button>
                <button
                  onClick={handleCopyClip}
                  disabled={!selectedClip}
                  title="Copy (Ctrl+C)"
                  style={{
                    background: selectedClip ? '#2d2d2d' : 'transparent',
                    border: '1px solid #3d3d3d',
                    color: selectedClip ? '#fff' : '#555',
                    cursor: selectedClip ? 'pointer' : 'not-allowed',
                    fontSize: '11px',
                    padding: '6px 12px',
                    borderRadius: '4px',
                  }}
                >
                  📋 Copy
                </button>
                <button
                  onClick={handlePasteClip}
                  disabled={!clipboardClip}
                  title="Paste (Ctrl+V)"
                  style={{
                    background: clipboardClip ? '#2d2d2d' : 'transparent',
                    border: '1px solid #3d3d3d',
                    color: clipboardClip ? '#fff' : '#555',
                    cursor: clipboardClip ? 'pointer' : 'not-allowed',
                    fontSize: '11px',
                    padding: '6px 12px',
                    borderRadius: '4px',
                  }}
                >
                  📄 Paste
                </button>
              </div>
              
              {/* Zoom */}
              <div style={{ display: 'flex', alignItems: 'center', gap: '8px' }}>
                <button onClick={() => setZoom(Math.max(0.25, zoom - 0.25))} style={{ background: 'none', border: 'none', color: '#888', cursor: 'pointer', padding: '4px 8px' }}>−</button>
                <span style={{ fontSize: '11px', color: '#888', minWidth: '40px', textAlign: 'center' }}>{Math.round(zoom * 100)}%</span>
                <button onClick={() => setZoom(Math.min(4, zoom + 0.25))} style={{ background: 'none', border: 'none', color: '#888', cursor: 'pointer' }}>+</button>
              </div>
            </div>
          </div>
        </div>
      </div>
      
      {/* AI Analyzer Modal */}
      {showAIAnalyzer && (
        <div style={{
          position: 'fixed',
          top: 0,
          left: 0,
          right: 0,
          bottom: 0,
          background: 'rgba(0,0,0,0.8)',
          display: 'flex',
          alignItems: 'center',
          justifyContent: 'center',
          zIndex: 1000,
        }}>
          <div style={{
            width: '600px',
            maxHeight: '80vh',
            background: '#2a2a2a',
            borderRadius: '12px',
            overflow: 'hidden',
          }}>
            <div style={{
              padding: '16px 20px',
              borderBottom: '1px solid #3d3d3d',
              display: 'flex',
              alignItems: 'center',
              justifyContent: 'space-between',
            }}>
              <div style={{ display: 'flex', alignItems: 'center', gap: '10px' }}>
                <Icons.Sparkles style={{ width: 20, height: 20, color: '#8b5cf6' }} />
                <span style={{ fontSize: '16px', fontWeight: '600', color: '#fff' }}>AI Video Analyzer</span>
              </div>
              <button
                onClick={() => setShowAIAnalyzer(false)}
                style={{ background: 'none', border: 'none', color: '#888', cursor: 'pointer' }}
              >
                <Icons.X style={{ width: 20, height: 20 }} />
              </button>
            </div>
            
            <div style={{ padding: '20px', overflow: 'auto', maxHeight: 'calc(80vh - 120px)' }}>
              {isAnalyzing ? (
                <div style={{ textAlign: 'center', padding: '40px' }}>
                  <div style={{
                    width: '48px',
                    height: '48px',
                    border: '3px solid #3d3d3d',
                    borderTopColor: '#8b5cf6',
                    borderRadius: '50%',
                    margin: '0 auto 16px',
                    animation: 'spin 1s linear infinite',
                  }} />
                  <p style={{ color: '#888' }}>Analyzing your video...</p>
                  <p style={{ color: '#666', fontSize: '12px', marginTop: '8px' }}>Checking pacing, colors, audio levels, and more</p>
                </div>
              ) : analysisResults ? (
                <div style={{ display: 'flex', flexDirection: 'column', gap: '16px' }}>
                  {/* Color Grading */}
                  <div style={{ background: '#1e1e1e', borderRadius: '8px', padding: '16px' }}>
                    <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center', marginBottom: '12px' }}>
                      <span style={{ fontWeight: '600', color: '#fff' }}>🎨 Color Grading</span>
                      <span style={{ fontSize: '11px', color: '#00b894' }}>{Math.round(analysisResults.colorGrading.confidence * 100)}% confident</span>
                    </div>
                    <p style={{ fontSize: '13px', color: '#888', marginBottom: '12px' }}>{analysisResults.colorGrading.reason}</p>
                    <Button size="sm" onClick={() => applyAISuggestion('colorGrading', analysisResults.colorGrading.suggestion)}>
                      Apply "{analysisResults.colorGrading.suggestion}" preset
                    </Button>
                  </div>
                  
                  {/* Audio */}
                  <div style={{ background: '#1e1e1e', borderRadius: '8px', padding: '16px' }}>
                    <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center', marginBottom: '12px' }}>
                      <span style={{ fontWeight: '600', color: '#fff' }}>🎵 Audio</span>
                      <span style={{ fontSize: '11px', color: analysisResults.audio.missingMusic ? '#e74c3c' : '#00b894' }}>
                        {analysisResults.audio.missingMusic ? 'Music Missing' : 'Music OK'}
                      </span>
                    </div>
                    {analysisResults.audio.missingMusic && (
                      <Button size="sm" onClick={() => applyAISuggestion('audio', analysisResults.audio.suggestedTrack)}>
                        Add "{analysisResults.audio.suggestedTrack}" track
                      </Button>
                    )}
                  </div>
                  
                  {/* Transitions */}
                  <div style={{ background: '#1e1e1e', borderRadius: '8px', padding: '16px' }}>
                    <div style={{ marginBottom: '12px' }}>
                      <span style={{ fontWeight: '600', color: '#fff' }}>⬚ Transitions</span>
                    </div>
                    <p style={{ fontSize: '13px', color: '#888', marginBottom: '12px' }}>
                      Found {analysisResults.transitions.suggestions.length} suggested transitions
                    </p>
                    <Button size="sm" onClick={() => applyAISuggestion('transitions', 'all')}>
                      Apply All Suggestions
                    </Button>
                  </div>
                  
                  {/* Stabilization */}
                  <div style={{ background: '#1e1e1e', borderRadius: '8px', padding: '16px' }}>
                    <div style={{ marginBottom: '12px' }}>
                      <span style={{ fontWeight: '600', color: '#fff' }}>▣ Stabilization</span>
                    </div>
                    <p style={{ fontSize: '13px', color: '#888', marginBottom: '12px' }}>
                      {analysisResults.effects.stabilizationNeeded.length} clips need stabilization
                    </p>
                    <Button size="sm" onClick={() => applyAISuggestion('stabilize', analysisResults.effects.stabilizationNeeded)}>
                      Stabilize {analysisResults.effects.stabilizationNeeded.length} Clips
                    </Button>
                  </div>
                </div>
              ) : null}
            </div>
            
            {!isAnalyzing && analysisResults && (
              <div style={{ padding: '16px 20px', borderTop: '1px solid #3d3d3d', display: 'flex', justifyContent: 'flex-end', gap: '12px' }}>
                <Button variant="secondary" onClick={() => setShowAIAnalyzer(false)}>Close</Button>
                <Button onClick={() => {
                  // Apply all suggestions
                  setShowAIAnalyzer(false);
                }}>Apply All</Button>
              </div>
            )}
          </div>
        </div>
      )}
      
      {/* Audio Generation Workspace Modal */}
      {showAudioWorkspace && (
        <div style={{
          position: 'fixed',
          top: 0,
          left: 0,
          right: 0,
          bottom: 0,
          background: 'rgba(0,0,0,0.9)',
          display: 'flex',
          alignItems: 'center',
          justifyContent: 'center',
          zIndex: 1000,
        }}>
          <div style={{
            width: '800px',
            maxHeight: '85vh',
            background: '#1e1e1e',
            borderRadius: '16px',
            overflow: 'hidden',
            display: 'flex',
            flexDirection: 'column',
          }}>
            {/* Header */}
            <div style={{
              padding: '16px 24px',
              borderBottom: '1px solid #3d3d3d',
              display: 'flex',
              alignItems: 'center',
              justifyContent: 'space-between',
              background: 'linear-gradient(135deg, #00b894 0%, #00cec9 100%)',
            }}>
              <div style={{ display: 'flex', alignItems: 'center', gap: '12px' }}>
                <span style={{ fontSize: '24px' }}>🎵</span>
                <div>
                  <h2 style={{ fontSize: '18px', fontWeight: '600', color: '#fff', margin: 0 }}>AI Audio Generator</h2>
                  <p style={{ fontSize: '12px', color: 'rgba(255,255,255,0.8)', margin: 0 }}>Create custom music and sound effects</p>
                </div>
              </div>
              <button
                onClick={() => setShowAudioWorkspace(false)}
                style={{ background: 'rgba(255,255,255,0.2)', border: 'none', color: '#fff', cursor: 'pointer', padding: '8px', borderRadius: '8px' }}
              >
                <Icons.X style={{ width: 20, height: 20 }} />
              </button>
            </div>
            
            {/* Tabs */}
            <div style={{ display: 'flex', borderBottom: '1px solid #3d3d3d' }}>
              <button
                onClick={() => setAudioWorkspaceTab('music')}
                style={{
                  flex: 1,
                  padding: '14px',
                  background: audioWorkspaceTab === 'music' ? '#2a2a2a' : 'transparent',
                  border: 'none',
                  borderBottom: audioWorkspaceTab === 'music' ? '2px solid #00b894' : '2px solid transparent',
                  color: audioWorkspaceTab === 'music' ? '#00b894' : '#888',
                  cursor: 'pointer',
                  fontSize: '14px',
                  fontWeight: '500',
                }}
              >
                🎵 Music
              </button>
              <button
                onClick={() => setAudioWorkspaceTab('sfx')}
                style={{
                  flex: 1,
                  padding: '14px',
                  background: audioWorkspaceTab === 'sfx' ? '#2a2a2a' : 'transparent',
                  border: 'none',
                  borderBottom: audioWorkspaceTab === 'sfx' ? '2px solid #f39c12' : '2px solid transparent',
                  color: audioWorkspaceTab === 'sfx' ? '#f39c12' : '#888',
                  cursor: 'pointer',
                  fontSize: '14px',
                  fontWeight: '500',
                }}
              >
                🔊 Sound Effects
              </button>
            </div>
            
            {/* Content */}
            <div style={{ flex: 1, overflow: 'auto', padding: '24px' }}>
              {/* Prompt Input */}
              <div style={{ marginBottom: '20px' }}>
                <label style={{ display: 'block', fontSize: '13px', color: '#888', marginBottom: '8px' }}>
                  {audioWorkspaceTab === 'music' ? 'Describe the music you want to create' : 'Describe the sound effect'}
                </label>
                <textarea
                  value={audioPrompt}
                  onChange={(e) => setAudioPrompt(e.target.value)}
                  placeholder={audioWorkspaceTab === 'music' 
                    ? 'e.g., Epic orchestral battle music with heavy drums and brass, building tension...'
                    : 'e.g., Sword clash with metallic ring, echoing in a stone chamber...'}
                  style={{
                    width: '100%',
                    padding: '14px',
                    background: '#2a2a2a',
                    border: '1px solid #3d3d3d',
                    borderRadius: '8px',
                    color: '#fff',
                    fontSize: '14px',
                    minHeight: '80px',
                    resize: 'vertical',
                  }}
                />
              </div>
              
              {/* Settings - Music */}
              {audioWorkspaceTab === 'music' && (
                <div style={{ display: 'grid', gridTemplateColumns: '1fr 1fr', gap: '16px', marginBottom: '20px' }}>
                  <div>
                    <label style={{ display: 'block', fontSize: '12px', color: '#888', marginBottom: '6px' }}>Genre</label>
                    <select
                      value={audioGenSettings.genre}
                      onChange={(e) => setAudioGenSettings(prev => ({ ...prev, genre: e.target.value }))}
                      style={{
                        width: '100%',
                        padding: '10px 12px',
                        background: '#2a2a2a',
                        border: '1px solid #3d3d3d',
                        borderRadius: '6px',
                        color: '#fff',
                        fontSize: '13px',
                      }}
                    >
                      <option value="cinematic">Cinematic / Film Score</option>
                      <option value="electronic">Electronic / EDM</option>
                      <option value="ambient">Ambient / Atmospheric</option>
                      <option value="rock">Rock / Metal</option>
                      <option value="jazz">Jazz / Blues</option>
                      <option value="classical">Classical / Orchestral</option>
                      <option value="hiphop">Hip Hop / Trap</option>
                      <option value="folk">Folk / Acoustic</option>
                    </select>
                  </div>
                  <div>
                    <label style={{ display: 'block', fontSize: '12px', color: '#888', marginBottom: '6px' }}>Mood</label>
                    <select
                      value={audioGenSettings.mood}
                      onChange={(e) => setAudioGenSettings(prev => ({ ...prev, mood: e.target.value }))}
                      style={{
                        width: '100%',
                        padding: '10px 12px',
                        background: '#2a2a2a',
                        border: '1px solid #3d3d3d',
                        borderRadius: '6px',
                        color: '#fff',
                        fontSize: '13px',
                      }}
                    >
                      <option value="epic">Epic / Powerful</option>
                      <option value="calm">Calm / Peaceful</option>
                      <option value="tense">Tense / Suspenseful</option>
                      <option value="happy">Happy / Uplifting</option>
                      <option value="sad">Sad / Melancholic</option>
                      <option value="mysterious">Mysterious / Eerie</option>
                      <option value="romantic">Romantic / Emotional</option>
                      <option value="energetic">Energetic / Driving</option>
                    </select>
                  </div>
                  <div>
                    <label style={{ display: 'block', fontSize: '12px', color: '#888', marginBottom: '6px' }}>Tempo</label>
                    <select
                      value={audioGenSettings.tempo}
                      onChange={(e) => setAudioGenSettings(prev => ({ ...prev, tempo: e.target.value }))}
                      style={{
                        width: '100%',
                        padding: '10px 12px',
                        background: '#2a2a2a',
                        border: '1px solid #3d3d3d',
                        borderRadius: '6px',
                        color: '#fff',
                        fontSize: '13px',
                      }}
                    >
                      <option value="slow">Slow (60-80 BPM)</option>
                      <option value="medium">Medium (80-120 BPM)</option>
                      <option value="fast">Fast (120-160 BPM)</option>
                      <option value="very-fast">Very Fast (160+ BPM)</option>
                    </select>
                  </div>
                  <div>
                    <label style={{ display: 'block', fontSize: '12px', color: '#888', marginBottom: '6px' }}>Duration: {audioGenSettings.duration}s</label>
                    <input
                      type="range"
                      min="10"
                      max="180"
                      value={audioGenSettings.duration}
                      onChange={(e) => setAudioGenSettings(prev => ({ ...prev, duration: parseInt(e.target.value) }))}
                      style={{ width: '100%', accentColor: '#00b894' }}
                    />
                  </div>
                </div>
              )}
              
              {/* Settings - SFX */}
              {audioWorkspaceTab === 'sfx' && (
                <div style={{ display: 'grid', gridTemplateColumns: '1fr 1fr', gap: '16px', marginBottom: '20px' }}>
                  <div>
                    <label style={{ display: 'block', fontSize: '12px', color: '#888', marginBottom: '6px' }}>Category</label>
                    <select
                      style={{
                        width: '100%',
                        padding: '10px 12px',
                        background: '#2a2a2a',
                        border: '1px solid #3d3d3d',
                        borderRadius: '6px',
                        color: '#fff',
                        fontSize: '13px',
                      }}
                    >
                      <option value="impact">Impacts / Hits</option>
                      <option value="transition">Transitions / Whooshes</option>
                      <option value="ambient">Ambient / Background</option>
                      <option value="ui">UI / Interface</option>
                      <option value="nature">Nature / Weather</option>
                      <option value="mechanical">Mechanical / Industrial</option>
                      <option value="creature">Creature / Monster</option>
                      <option value="magic">Magic / Sci-Fi</option>
                    </select>
                  </div>
                  <div>
                    <label style={{ display: 'block', fontSize: '12px', color: '#888', marginBottom: '6px' }}>Intensity</label>
                    <select
                      style={{
                        width: '100%',
                        padding: '10px 12px',
                        background: '#2a2a2a',
                        border: '1px solid #3d3d3d',
                        borderRadius: '6px',
                        color: '#fff',
                        fontSize: '13px',
                      }}
                    >
                      <option value="subtle">Subtle</option>
                      <option value="medium">Medium</option>
                      <option value="intense">Intense</option>
                      <option value="extreme">Extreme</option>
                    </select>
                  </div>
                </div>
              )}
              
              {/* Generate Button */}
              <button
                onClick={handleGenerateAudio}
                disabled={isGeneratingAudio || !audioPrompt.trim()}
                style={{
                  width: '100%',
                  padding: '14px',
                  background: isGeneratingAudio 
                    ? '#3d3d3d' 
                    : audioWorkspaceTab === 'music' 
                      ? 'linear-gradient(135deg, #00b894 0%, #00cec9 100%)'
                      : 'linear-gradient(135deg, #f39c12 0%, #e74c3c 100%)',
                  border: 'none',
                  borderRadius: '8px',
                  color: '#fff',
                  fontSize: '15px',
                  fontWeight: '600',
                  cursor: isGeneratingAudio || !audioPrompt.trim() ? 'not-allowed' : 'pointer',
                  display: 'flex',
                  alignItems: 'center',
                  justifyContent: 'center',
                  gap: '10px',
                  marginBottom: '24px',
                }}
              >
                {isGeneratingAudio ? (
                  <>
                    <div style={{
                      width: '18px',
                      height: '18px',
                      border: '2px solid rgba(255,255,255,0.3)',
                      borderTopColor: '#fff',
                      borderRadius: '50%',
                      animation: 'spin 1s linear infinite',
                    }} />
                    Generating...
                  </>
                ) : (
                  <>
                    <Icons.Sparkles style={{ width: 18, height: 18 }} />
                    Generate {audioWorkspaceTab === 'music' ? 'Music' : 'Sound Effect'}
                  </>
                )}
              </button>
              
              {/* Generated Files List */}
              <div>
                <h3 style={{ fontSize: '14px', color: '#888', marginBottom: '12px' }}>
                  {audioWorkspaceTab === 'music' ? 'Generated Music' : 'Generated Sound Effects'}
                </h3>
                <div style={{ display: 'flex', flexDirection: 'column', gap: '8px' }}>
                  {generatedAudioFiles
                    .filter(f => audioWorkspaceTab === 'music' ? f.type === 'music' : f.type === 'sfx')
                    .map(file => (
                      <div
                        key={file.id}
                        style={{
                          padding: '12px 16px',
                          background: '#2a2a2a',
                          borderRadius: '8px',
                          display: 'flex',
                          alignItems: 'center',
                          justifyContent: 'space-between',
                        }}
                      >
                        <div style={{ display: 'flex', alignItems: 'center', gap: '12px' }}>
                          <div style={{
                            width: '40px',
                            height: '40px',
                            borderRadius: '8px',
                            background: file.type === 'music' 
                              ? 'linear-gradient(135deg, #00b894 0%, #00cec9 100%)'
                              : 'linear-gradient(135deg, #f39c12 0%, #e74c3c 100%)',
                            display: 'flex',
                            alignItems: 'center',
                            justifyContent: 'center',
                            fontSize: '18px',
                          }}>
                            {file.type === 'music' ? '🎵' : '🔊'}
                          </div>
                          <div>
                            <div style={{ fontSize: '13px', color: '#fff' }}>{file.name}</div>
                            <div style={{ fontSize: '11px', color: '#666' }}>
                              {file.duration.toFixed(1)}s • Generated just now
                            </div>
                          </div>
                        </div>
                        <div style={{ display: 'flex', gap: '8px' }}>
                          <button
                            style={{
                              padding: '8px 12px',
                              background: '#3d3d3d',
                              border: 'none',
                              borderRadius: '6px',
                              color: '#fff',
                              cursor: 'pointer',
                              fontSize: '12px',
                            }}
                          >
                            ▶ Preview
                          </button>
                          <button
                            onClick={() => handleAddGeneratedAudioToTimeline(file)}
                            style={{
                              padding: '8px 12px',
                              background: file.type === 'music' ? '#00b894' : '#f39c12',
                              border: 'none',
                              borderRadius: '6px',
                              color: '#fff',
                              cursor: 'pointer',
                              fontSize: '12px',
                              fontWeight: '500',
                            }}
                          >
                            + Add to Timeline
                          </button>
                        </div>
                      </div>
                    ))}
                  {generatedAudioFiles.filter(f => audioWorkspaceTab === 'music' ? f.type === 'music' : f.type === 'sfx').length === 0 && (
                    <div style={{ textAlign: 'center', padding: '30px', color: '#555' }}>
                      No {audioWorkspaceTab === 'music' ? 'music' : 'sound effects'} generated yet.<br/>
                      Enter a prompt above to create one!
                    </div>
                  )}
                </div>
              </div>
            </div>
          </div>
        </div>
      )}
      
      {/* Preview Modal */}
      {showPreviewModal && (
        <div style={{
          position: 'fixed',
          top: 0,
          left: 0,
          right: 0,
          bottom: 0,
          background: 'rgba(0,0,0,0.95)',
          display: 'flex',
          alignItems: 'center',
          justifyContent: 'center',
          zIndex: 1000,
        }}>
          <div style={{
            width: '90%',
            maxWidth: '1200px',
            background: '#1a1a1a',
            borderRadius: '16px',
            overflow: 'hidden',
          }}>
            {/* Header */}
            <div style={{
              padding: '16px 24px',
              borderBottom: '1px solid #333',
              display: 'flex',
              justifyContent: 'space-between',
              alignItems: 'center',
            }}>
              <h2 style={{ fontSize: '18px', fontWeight: '600', color: '#fff' }}>
                <Icons.Play style={{ width: 20, height: 20, marginRight: '8px', display: 'inline' }} />
                Final Preview
              </h2>
              <button
                onClick={() => setShowPreviewModal(false)}
                style={{
                  padding: '8px',
                  background: 'none',
                  border: 'none',
                  color: '#888',
                  cursor: 'pointer',
                  fontSize: '24px',
                }}
              >×</button>
            </div>
            
            {/* Preview Content */}
            <div style={{ padding: '24px' }}>
              {/* Main Preview Area */}
              <div style={{
                aspectRatio: '16/9',
                background: 'linear-gradient(135deg, #1a1a2e 0%, #16213e 100%)',
                borderRadius: '12px',
                display: 'flex',
                alignItems: 'center',
                justifyContent: 'center',
                marginBottom: '20px',
                position: 'relative',
                border: '1px solid #333',
              }}>
                <div style={{ textAlign: 'center', color: '#fff' }}>
                  <div style={{
                    width: '100px',
                    height: '100px',
                    borderRadius: '50%',
                    background: 'linear-gradient(135deg, #8b5cf6 0%, #a855f7 100%)',
                    display: 'flex',
                    alignItems: 'center',
                    justifyContent: 'center',
                    margin: '0 auto 20px',
                    cursor: 'pointer',
                    boxShadow: '0 8px 30px rgba(139, 92, 246, 0.5)',
                    transition: 'all 0.3s ease',
                  }}
                  onMouseOver={(e) => e.currentTarget.style.transform = 'scale(1.1)'}
                  onMouseOut={(e) => e.currentTarget.style.transform = 'scale(1)'}
                  >
                    <Icons.Play style={{ width: 48, height: 48 }} />
                  </div>
                  <div style={{ fontSize: '16px', fontWeight: '500', marginBottom: '8px' }}>
                    {displayEpisode?.title || 'Untitled Project'}
                  </div>
                  <div style={{ fontSize: '13px', opacity: 0.7 }}>Click to play final cut</div>
                </div>
                
                {/* Progress Bar */}
                <div style={{
                  position: 'absolute',
                  bottom: 0,
                  left: 0,
                  right: 0,
                  height: '4px',
                  background: '#333',
                }}>
                  <div style={{
                    width: `${(playheadPosition / totalDuration) * 100}%`,
                    height: '100%',
                    background: 'linear-gradient(90deg, #8b5cf6, #a855f7)',
                  }} />
                </div>
              </div>
              
              {/* Track Overview */}
              <div style={{
                background: '#252525',
                borderRadius: '8px',
                padding: '16px',
              }}>
                <div style={{ fontSize: '12px', color: '#888', marginBottom: '12px' }}>TIMELINE OVERVIEW</div>
                <div style={{ display: 'flex', flexDirection: 'column', gap: '8px' }}>
                  {tracks.slice(0, 4).map((track, idx) => (
                    <div key={track.id || idx} style={{ display: 'flex', alignItems: 'center', gap: '12px' }}>
                      <div style={{ 
                        width: '80px', 
                        fontSize: '11px', 
                        color: '#888',
                        textOverflow: 'ellipsis',
                        overflow: 'hidden',
                        whiteSpace: 'nowrap',
                      }}>
                        {track.name || `Track ${idx + 1}`}
                      </div>
                      <div style={{ 
                        flex: 1, 
                        height: '24px', 
                        background: '#333', 
                        borderRadius: '4px',
                        display: 'flex',
                        gap: '2px',
                        overflow: 'hidden',
                      }}>
                        {(track.clips || []).map((clip, clipIdx) => (
                          <div 
                            key={clip.id || clipIdx} 
                            style={{
                              width: `${(clip.duration / totalDuration) * 100}%`,
                              height: '100%',
                              background: track.type === 'audio' 
                                ? 'linear-gradient(135deg, #10b981 0%, #059669 100%)'
                                : 'linear-gradient(135deg, #8b5cf6 0%, #a855f7 100%)',
                              borderRadius: '2px',
                              marginLeft: `${(clip.startTime / totalDuration) * 100}%`,
                            }}
                          />
                        ))}
                      </div>
                    </div>
                  ))}
                  {tracks.length === 0 && (
                    <div style={{ textAlign: 'center', padding: '20px', color: '#555', fontSize: '13px' }}>
                      No tracks added yet
                    </div>
                  )}
                </div>
              </div>
            </div>
            
            {/* Footer */}
            <div style={{
              padding: '16px 24px',
              borderTop: '1px solid #333',
              display: 'flex',
              justifyContent: 'space-between',
              alignItems: 'center',
            }}>
              <div style={{ fontSize: '13px', color: '#888' }}>
                {tracks.length} tracks · {formatTime(totalDuration)} duration
              </div>
              <div style={{ display: 'flex', gap: '12px' }}>
                <Button variant="secondary" onClick={() => setShowPreviewModal(false)}>
                  Close
                </Button>
                <Button onClick={() => {
                  setShowPreviewModal(false);
                  onExport && onExport();
                }}>
                  <Icons.Download style={{ width: 14, height: 14, marginRight: '6px' }} />
                  Export Final
                </Button>
              </div>
            </div>
          </div>
        </div>
      )}
      
      <style>{`
        @keyframes spin {
          to { transform: rotate(360deg); }
        }
      `}</style>
    </div>
  );
};

// ============================================================================
// GEN SPACE VIEW - Image & Video Generation
// ============================================================================
const GenSpaceView = ({ onAddAsset, assets = [], elements = [] }) => {
  const [mode, setMode] = useState('image'); // 'image' or 'video'
  const [inputMode, setInputMode] = useState('text'); // 'text' or 'image' - determines text-to-X vs image-to-X
  const [prompt, setPrompt] = useState('');
  const [selectedGenerator, setSelectedGenerator] = useState('midjourney');
  const [referenceImage, setReferenceImage] = useState(null);
  const [referenceImages, setReferenceImages] = useState([]); // For multiple references (max 4 for image, 3 for video)
  const [startFrame, setStartFrame] = useState(null); // For video timeline control
  const [endFrame, setEndFrame] = useState(null); // For video timeline control
  const [showAdvancedPanel, setShowAdvancedPanel] = useState(true);
  const [settingsTab, setSettingsTab] = useState('camera'); // 'camera', 'lighting', 'style', 'advanced'
  const [leftPanelCollapsed, setLeftPanelCollapsed] = useState(false);
  const [rightPanelCollapsed, setRightPanelCollapsed] = useState(false);
  const [showElementsPicker, setShowElementsPicker] = useState(false);
  const [selectedElement, setSelectedElement] = useState(null);
  const [showSaveToast, setShowSaveToast] = useState(false);
  const [showHistory, setShowHistory] = useState(false);
  const [elementPickerCategory, setElementPickerCategory] = useState(null); // null = show categories, 'character' etc = show items
  const [elementSearchQuery, setElementSearchQuery] = useState('');
  const [showPromptEditor, setShowPromptEditor] = useState(false);
  const [tempPrompt, setTempPrompt] = useState(''); // Temporary prompt for modal editing
  
  // Element categories with icons and colors
  const elementCategories = [
    { id: 'character', label: 'Characters', icon: '👤', color: '#8b5cf6', desc: 'People and creatures' },
    { id: 'location', label: 'Locations', icon: '🏠', color: '#3b82f6', desc: 'Places and environments' },
    { id: 'prop', label: 'Props', icon: '📦', color: '#f59e0b', desc: 'Objects and items' },
    { id: 'vehicle', label: 'Vehicles', icon: '🚗', color: '#10b981', desc: 'Cars, bikes, ships' },
    { id: 'wardrobe', label: 'Wardrobe', icon: '👕', color: '#ec4899', desc: 'Clothing and costumes' },
    { id: 'creature', label: 'Creatures', icon: '🐉', color: '#ef4444', desc: 'Animals and beings' },
  ];
  
  // Mock elements data organized by category
  const mockElements = [
    // Characters
    { id: 'char-1', name: 'Christian Ramirez', type: 'character', emoji: '👤', prompt: 'Young Latino man, 25 years old, dark wavy hair, brown eyes, casual streetwear, warm smile' },
    { id: 'char-2', name: 'Maria Gonzalez', type: 'character', emoji: '👩', prompt: 'Latina woman, late 20s, long black hair, warm smile, elegant sundress, kind eyes' },
    { id: 'char-3', name: 'Detective Marcus Cole', type: 'character', emoji: '🕵️', prompt: 'African American man, 40s, short gray beard, weathered face, long trench coat, fedora hat' },
    { id: 'char-4', name: 'Dr. Sarah Chen', type: 'character', emoji: '👩‍🔬', prompt: 'Asian woman, mid-30s, glasses, lab coat, hair in ponytail, professional demeanor' },
    // Locations
    { id: 'loc-1', name: "Christian's Apartment", type: 'location', emoji: '🏠', prompt: 'Small studio apartment, cluttered but cozy, posters on walls, city view from window, warm lighting' },
    { id: 'loc-2', name: 'Barrio Street', type: 'location', emoji: '🏘️', prompt: 'Vibrant Latino neighborhood street, colorful murals, food vendors, warm sunlight, busy atmosphere' },
    { id: 'loc-3', name: 'Neon City Alley', type: 'location', emoji: '🌃', prompt: 'Dark cyberpunk alley, neon signs reflecting on wet pavement, steam rising, moody atmosphere' },
    { id: 'loc-4', name: 'Mountain Cabin', type: 'location', emoji: '🏔️', prompt: 'Rustic wooden cabin in snowy mountains, smoke from chimney, pine trees, cozy winter scene' },
    // Props
    { id: 'prop-1', name: 'Vintage Camera', type: 'prop', emoji: '📷', prompt: 'Old 35mm film camera, worn leather strap, chrome finish, scratched from use' },
    { id: 'prop-2', name: 'Ancient Book', type: 'prop', emoji: '📚', prompt: 'Leather-bound ancient tome, gold lettering, worn pages, mysterious symbols' },
    { id: 'prop-3', name: 'Futuristic Tablet', type: 'prop', emoji: '📱', prompt: 'Sleek holographic tablet, transparent display, glowing blue interface, sci-fi design' },
    // Vehicles
    { id: 'veh-1', name: '1967 Mustang', type: 'vehicle', emoji: '🚗', prompt: 'Classic 1967 Ford Mustang, cherry red, chrome details, muscle car, pristine condition' },
    { id: 'veh-2', name: 'Hover Bike', type: 'vehicle', emoji: '🏍️', prompt: 'Futuristic hover motorcycle, sleek black design, blue thrust glow, cyberpunk style' },
    // Wardrobe
    { id: 'ward-1', name: 'Victorian Dress', type: 'wardrobe', emoji: '👗', prompt: 'Elegant Victorian-era ball gown, deep burgundy velvet, lace details, corseted bodice' },
    { id: 'ward-2', name: 'Space Suit', type: 'wardrobe', emoji: '🧑‍🚀', prompt: 'Modern astronaut suit, white with blue accents, helmet with gold visor, NASA-style patches' },
    // Creatures
    { id: 'crea-1', name: 'Shadow Wolf', type: 'creature', emoji: '🐺', prompt: 'Mystical black wolf, glowing purple eyes, wisps of shadow emanating, ethereal presence' },
    { id: 'crea-2', name: 'Crystal Dragon', type: 'creature', emoji: '🐉', prompt: 'Majestic dragon made of translucent crystals, rainbow light refracting, elegant wings' },
  ];
  
  const availableElements = elements.length > 0 ? elements : mockElements;
  
  // Filter elements by category and search
  const getFilteredElements = () => {
    let filtered = availableElements;
    
    if (elementPickerCategory) {
      filtered = filtered.filter(el => el.type === elementPickerCategory);
    }
    
    if (elementSearchQuery.trim()) {
      const query = elementSearchQuery.toLowerCase();
      filtered = filtered.filter(el => 
        el.name.toLowerCase().includes(query) || 
        el.prompt?.toLowerCase().includes(query) ||
        el.type.toLowerCase().includes(query)
      );
    }
    
    return filtered;
  };
  
  // Get element count by category
  const getCategoryCount = (categoryId) => {
    return availableElements.filter(el => el.type === categoryId).length;
  };
  
  // Comprehensive generation settings
  const [generationSettings, setGenerationSettings] = useState({
    // === SHARED SETTINGS (Image & Video) ===
    mediaQuality: 'Pro',
    shotSize: 'medium',
    cameraAngle: 'eye_level',
    framing: 'center',
    lens: 'standard',
    lightingStyle: 'cinematic',
    lightingDirection: 45,
    colorGrade: 'teal_orange',
    aesthetic: 'cinematic',
    wardrobeStyle: '',
    timeOfDay: 'day',
    weather: 'clear',
    
    // === IMAGE SPECIFIC ===
    imageModel: 'gemini-3-pro-image-preview',
    aspectRatio: '16:9',
    imageSize: '2K',
    
    // === VIDEO SPECIFIC ===
    resolution: '1080p',
    fps: 24,
    duration: 5,
    cameraMovement: 'static',
    movementSpeed: 5,
    
    // === LEGACY/GENERAL ===
    negativePrompt: '',
    seed: '',
    guidanceScale: 7.5,
    steps: 30,
  });
  const [isGenerating, setIsGenerating] = useState(false);
  const [generatedItems, setGeneratedItems] = useState([]);
  
  // === OPTION DEFINITIONS ===
  const mediaQualityOptions = [
    { id: 'Pro', label: 'Pro', desc: 'Professional quality' },
    { id: 'Amateur', label: 'Amateur', desc: 'Casual/home video look' },
    { id: 'Selfie', label: 'Selfie', desc: 'Phone selfie aesthetic' },
  ];
  
  const shotSizeOptions = [
    { id: 'default', label: 'Default' },
    { id: 'extreme_wide', label: 'Extreme Wide' },
    { id: 'wide', label: 'Wide' },
    { id: 'medium', label: 'Medium' },
    { id: 'close_up', label: 'Close Up' },
    { id: 'selfie_arm_length', label: 'Selfie (Arm)' },
    { id: 'mirror_selfie', label: 'Mirror Selfie' },
    { id: 'body_cam', label: 'Body Cam' },
    { id: 'webcam', label: 'Webcam' },
  ];
  
  const cameraAngleOptions = [
    { id: 'eye_level', label: 'Eye Level' },
    { id: 'low_angle', label: 'Low Angle' },
    { id: 'high_angle', label: 'High Angle' },
    { id: 'birds_eye', label: "Bird's Eye" },
    { id: 'dutch', label: 'Dutch Angle' },
    { id: 'cctv', label: 'CCTV' },
  ];
  
  const framingOptions = [
    { id: 'center', label: 'Center' },
    { id: 'thirds', label: 'Rule of Thirds' },
    { id: 'messy', label: 'Messy/Candid' },
  ];
  
  const lensOptions = [
    { id: 'standard', label: 'Standard' },
    { id: 'wide_angle', label: 'Wide Angle' },
    { id: 'telephoto', label: 'Telephoto' },
    { id: 'anamorphic', label: 'Anamorphic' },
    { id: 'phone_standard', label: 'Phone Standard' },
    { id: 'phone_wide', label: 'Phone Wide' },
    { id: 'front_camera', label: 'Front Camera' },
    { id: 'action_cam', label: 'Action Cam' },
    { id: 'webcam_lens', label: 'Webcam' },
  ];
  
  const lightingStyleOptions = [
    { id: 'cinematic', label: 'Cinematic' },
    { id: 'film_noir', label: 'Film Noir' },
    { id: 'rembrandt', label: 'Rembrandt' },
    { id: 'natural', label: 'Natural' },
    { id: 'ring_light', label: 'Ring Light' },
    { id: 'flash', label: 'Flash' },
    { id: 'overhead', label: 'Overhead' },
    { id: 'screen_glow', label: 'Screen Glow' },
  ];
  
  const colorGradeOptions = [
    { id: 'teal_orange', label: 'Teal & Orange' },
    { id: 'bw', label: 'Black & White' },
    { id: 'vintage', label: 'Vintage' },
    { id: 'vibrant', label: 'Vibrant' },
    { id: 'instagram_filter', label: 'Instagram' },
    { id: 'no_filter', label: 'No Filter' },
    { id: 'cctv_green', label: 'CCTV Green' },
    { id: 'faded', label: 'Faded' },
  ];
  
  const aestheticOptions = [
    { id: 'cinematic', label: 'Cinematic' },
    { id: 'social_media', label: 'Social Media' },
    { id: 'vlog', label: 'Vlog' },
    { id: 'cctv', label: 'CCTV' },
    { id: 'editorial', label: 'Editorial' },
    { id: 'candid', label: 'Candid' },
  ];
  
  const wardrobeStyleOptions = [
    { id: '', label: 'None/Default' },
    { id: 'casual', label: 'Casual' },
    { id: 'gym', label: 'Gym/Athletic' },
    { id: 'formal', label: 'Formal' },
    { id: 'streetwear', label: 'Streetwear' },
    { id: 'sci_fi', label: 'Sci-Fi' },
    { id: 'costume', label: 'Costume' },
  ];
  
  const timeOfDayOptions = [
    { id: 'day', label: 'Day' },
    { id: 'golden_hour', label: 'Golden Hour' },
    { id: 'blue_hour', label: 'Blue Hour' },
    { id: 'night', label: 'Night' },
    { id: 'sunrise', label: 'Sunrise' },
  ];
  
  const weatherOptions = [
    { id: 'clear', label: 'Clear' },
    { id: 'cloudy', label: 'Cloudy' },
    { id: 'rain', label: 'Rain' },
    { id: 'storm', label: 'Storm' },
    { id: 'snow', label: 'Snow' },
    { id: 'indoor', label: 'Indoor' },
  ];
  
  const cameraMovementOptions = [
    { id: 'static', label: 'Static' },
    { id: 'pan', label: 'Pan' },
    { id: 'tracking', label: 'Tracking' },
    { id: 'drone', label: 'Drone' },
    { id: 'handheld_shaky', label: 'Handheld (Shaky)' },
    { id: 'handheld_selfie', label: 'Handheld (Selfie)' },
    { id: 'whip_pan', label: 'Whip Pan' },
    { id: 'gimbal', label: 'Gimbal' },
  ];
  
  const aspectRatioOptions = [
    { id: '16:9', label: '16:9', desc: 'Widescreen' },
    { id: '9:16', label: '9:16', desc: 'Portrait' },
    { id: '1:1', label: '1:1', desc: 'Square' },
    { id: '4:3', label: '4:3', desc: 'Standard' },
    { id: '21:9', label: '21:9', desc: 'Cinematic' },
  ];
  
  const imageSizeOptions = [
    { id: '1K', label: '1K' },
    { id: '2K', label: '2K' },
    { id: '4K', label: '4K' },
  ];
  
  const resolutionOptions = [
    { id: '720p', label: '720p' },
    { id: '1080p', label: '1080p' },
  ];
  
  const fpsOptions = [24, 30, 60];
  const durationOptions = [5, 10];
  
  // Image Generators from Kie AI
  const imageGenerators = [
    { 
      id: 'midjourney', 
      name: 'Midjourney', 
      apiId: 'features/mj-api',
      badge: 'ARTISTIC', 
      quality: 'Highest', 
      speed: 'Medium', 
      capabilities: { textToImage: true, imageToImage: true, imageToVideo: true },
      features: ['Artistic', 'Aesthetic', 'Stylized', 'Image input'] 
    },
    { 
      id: 'flux-2', 
      name: 'Flux 2', 
      apiId: 'flux-2/pro-image-to-image',
      quality: 'Highest', 
      speed: 'Fast', 
      capabilities: { textToImage: true, imageToImage: true },
      features: ['Photorealistic', 'High quality', 'Pro mode'] 
    },
    { 
      id: 'grok-imagine', 
      name: 'Grok Imagine', 
      apiId: 'grok-imagine/image-to-video',
      badge: 'NEW',
      quality: 'High', 
      speed: 'Fast', 
      capabilities: { textToImage: true, imageToImage: true, textToVideo: true, upscale: true },
      features: ['Multi-modal', 'Upscaling', 'Video capable'] 
    },
    { 
      id: 'nano-banana-pro', 
      name: 'Nano Banana Pro', 
      apiId: 'nano-banana-pro',
      quality: 'High', 
      speed: 'Fast', 
      capabilities: { textToImage: true, imageToImage: true },
      features: ['Fast generation', 'Versatile'] 
    },
  ];
  
  // Video Generators from Kie AI
  const videoGenerators = [
    { 
      id: 'kling-2.5', 
      name: 'Kling 2.5', 
      apiId: 'kling/v2-5-turbo-text-to-video-pro',
      badge: 'BEST', 
      quality: 'Highest', 
      speed: 'Fast', 
      maxDuration: '10s',
      capabilities: { textToVideo: true, imageToVideo: true },
      features: ['Turbo mode', 'Pro quality', 'Fast rendering'] 
    },
    { 
      id: 'gemini-veo-3.1', 
      name: 'Gemini Veo 3.1', 
      apiId: 'veo-3-1',
      badge: 'NEW',
      quality: 'Highest', 
      speed: 'Medium', 
      maxDuration: '60s',
      capabilities: { textToVideo: true, imageToVideo: true, referenceToVideo: true, upscale: true },
      features: ['Long form', 'Reference video', 'Upscaling', 'Advanced'] 
    },
    { 
      id: 'sora-2-pro', 
      name: 'Sora 2 Pro', 
      apiId: 'sora-2-pro-storyboard',
      badge: 'POPULAR',
      quality: 'Highest', 
      speed: 'Medium', 
      maxDuration: '20s',
      capabilities: { textToVideo: true, imageToVideo: true },
      features: ['Storyboard mode', 'Cinematic', 'Physics'] 
    },
    { 
      id: 'hailuo-2.3', 
      name: 'Hailuo 2.3', 
      apiId: 'hailuo-2.3',
      quality: 'High', 
      speed: 'Fast', 
      maxDuration: '6s',
      capabilities: { imageToVideo: true },
      features: ['Image-to-video', 'Fast', 'Consistent'] 
    },
    { 
      id: 'seedance-fast', 
      name: 'Seedance 1.0 Fast', 
      apiId: 'bytedance/v1-pro-fast-image-to-video',
      quality: 'High', 
      speed: 'Fastest', 
      maxDuration: '8s',
      capabilities: { imageToImage: true },
      features: ['Ultra fast', 'Image transform'] 
    },
    { 
      id: 'wan-2.5', 
      name: 'Wan 2.5', 
      apiId: 'wan-2.5',
      quality: 'High', 
      speed: 'Medium', 
      maxDuration: '10s',
      capabilities: { textToVideo: true, imageToVideo: true },
      features: ['Text & Image input', 'Versatile'] 
    },
    { 
      id: 'runway', 
      name: 'Runway', 
      apiId: 'runway',
      quality: 'Highest', 
      speed: 'Medium', 
      maxDuration: '10s',
      capabilities: { textToVideo: true, imageToVideo: true },
      features: ['Motion control', 'Camera moves', 'Professional'] 
    },
  ];
  
  const examplePrompts = mode === 'video' ? [
    { image: '🎬', prompt: 'A young man walks through a rain-soaked neon-lit alley in Tokyo, reflections glistening on wet pavement' },
    { image: '🌅', prompt: 'Drone shot flying over misty mountains at golden hour, revealing a hidden valley below' },
    { image: '🎭', prompt: 'Close-up of a woman turning to look at camera, her expression shifting from sadness to hope' },
  ] : [
    { image: '🏠', prompt: 'A small apartment building in the barrios of Los Angeles, showing its worn-down facade at sunset' },
    { image: '👤', prompt: 'Portrait of a 15-year-old Latino boy with a thoughtful expression, cinematic lighting' },
    { image: '🌃', prompt: 'Gritty alleyway at night with flickering streetlight, graffiti walls, urban atmosphere' },
  ];
  
  const generators = mode === 'image' ? imageGenerators : videoGenerators;
  const currentGenerator = generators.find(g => g.id === selectedGenerator);
  
  // Filter generators based on input mode
  const availableGenerators = generators.filter(gen => {
    if (mode === 'image') {
      return inputMode === 'text' ? gen.capabilities.textToImage : gen.capabilities.imageToImage;
    } else {
      return inputMode === 'text' ? gen.capabilities.textToVideo : gen.capabilities.imageToVideo;
    }
  });
  
  // Get current workflow type
  const getWorkflowType = () => {
    if (mode === 'image') {
      return inputMode === 'text' ? 'Text to Image' : 'Image to Image';
    } else {
      return inputMode === 'text' ? 'Text to Video' : 'Image to Video';
    }
  };
  
  // Switch generator when mode/inputMode changes if current isn't compatible
  const handleModeChange = (newMode) => {
    setMode(newMode);
    const newGenerators = newMode === 'image' ? imageGenerators : videoGenerators;
    const compatible = newGenerators.find(g => {
      if (newMode === 'image') {
        return inputMode === 'text' ? g.capabilities.textToImage : g.capabilities.imageToImage;
      } else {
        return inputMode === 'text' ? g.capabilities.textToVideo : g.capabilities.imageToVideo;
      }
    });
    if (compatible) {
      setSelectedGenerator(compatible.id);
    }
  };
  
  const handleInputModeChange = (newInputMode) => {
    setInputMode(newInputMode);
    // Check if current generator supports new input mode
    const currentGen = generators.find(g => g.id === selectedGenerator);
    const isCompatible = mode === 'image' 
      ? (newInputMode === 'text' ? currentGen?.capabilities.textToImage : currentGen?.capabilities.imageToImage)
      : (newInputMode === 'text' ? currentGen?.capabilities.textToVideo : currentGen?.capabilities.imageToVideo);
    
    if (!isCompatible) {
      // Find first compatible generator
      const compatible = generators.find(g => {
        if (mode === 'image') {
          return newInputMode === 'text' ? g.capabilities.textToImage : g.capabilities.imageToImage;
        } else {
          return newInputMode === 'text' ? g.capabilities.textToVideo : g.capabilities.imageToVideo;
        }
      });
      if (compatible) setSelectedGenerator(compatible.id);
    }
  };
  
  const handleGenerate = () => {
    if (!prompt.trim() && inputMode === 'text') return;
    if (!referenceImage && inputMode === 'image') return;
    setIsGenerating(true);
    
    // Simulate generation
    setTimeout(() => {
      const newItem = {
        id: `asset-${Date.now()}`,
        type: mode,
        workflow: getWorkflowType(),
        prompt,
        referenceImage,
        generator: selectedGenerator,
        generatorName: generators.find(g => g.id === selectedGenerator)?.name || selectedGenerator,
        settings: { ...generationSettings },
        createdAt: new Date().toISOString(),
        status: 'completed',
        // Include element info if used
        element: selectedElement ? { id: selectedElement.id, name: selectedElement.name } : null,
        // Generate a placeholder gradient for the preview
        thumbnail: `linear-gradient(135deg, hsl(${Math.random() * 360}, 50%, 35%), hsl(${Math.random() * 360}, 50%, 45%))`,
      };
      
      // Add to local state for immediate display
      setGeneratedItems(prev => [newItem, ...prev]);
      
      // Add to global assets if callback provided
      if (onAddAsset) {
        onAddAsset(newItem);
        // Show save toast
        setShowSaveToast(true);
        setTimeout(() => setShowSaveToast(false), 3000);
      }
      
      setIsGenerating(false);
    }, 3000);
  };
  
  // Handle element selection
  const handleSelectElement = (element) => {
    setSelectedElement(element);
    // Append element prompt to current prompt
    if (element.prompt) {
      setPrompt(prev => prev ? `${prev}, ${element.prompt}` : element.prompt);
    }
    // Close modal and reset state
    setShowElementsPicker(false);
    setElementPickerCategory(null);
    setElementSearchQuery('');
  };
  
  // Clear selected element
  const handleClearElement = () => {
    setSelectedElement(null);
  };
  
  // Close element picker modal
  const handleCloseElementPicker = () => {
    setShowElementsPicker(false);
    setElementPickerCategory(null);
    setElementSearchQuery('');
  };
  
  return (
    <div style={{ flex: 1, display: 'flex', flexDirection: 'column', overflow: 'hidden' }}>
      {/* Top Bar - Mode & Input Toggle */}
      <div style={{
        padding: '16px 32px',
        background: colors.bg.secondary,
        borderBottom: `1px solid ${colors.border.subtle}`,
        display: 'flex',
        alignItems: 'center',
        justifyContent: 'space-between',
      }}>
        <div style={{ display: 'flex', alignItems: 'center', gap: '16px' }}>
          {/* Output Mode: Image/Video */}
          <div style={{ display: 'flex', gap: '4px', background: colors.bg.tertiary, borderRadius: '8px', padding: '4px' }}>
            <button
              onClick={() => handleModeChange('image')}
              style={{
                display: 'flex',
                alignItems: 'center',
                gap: '8px',
                padding: '10px 20px',
                background: mode === 'image' ? colors.bg.secondary : 'transparent',
                border: 'none',
                borderRadius: '6px',
                color: mode === 'image' ? colors.text.primary : colors.text.secondary,
                fontSize: '14px',
                fontWeight: '500',
                cursor: 'pointer',
              }}
            >
              <Icons.Image />
              Image
            </button>
            <button
              onClick={() => handleModeChange('video')}
              style={{
                display: 'flex',
                alignItems: 'center',
                gap: '8px',
                padding: '10px 20px',
                background: mode === 'video' ? colors.bg.secondary : 'transparent',
                border: 'none',
                borderRadius: '6px',
                color: mode === 'video' ? colors.text.primary : colors.text.secondary,
                fontSize: '14px',
                fontWeight: '500',
                cursor: 'pointer',
              }}
            >
              <Icons.Film />
              Video
            </button>
          </div>
          
          {/* Input Mode: Text/Image */}
          <div style={{ display: 'flex', gap: '4px', background: colors.bg.tertiary, borderRadius: '8px', padding: '4px' }}>
            <button
              onClick={() => handleInputModeChange('text')}
              style={{
                display: 'flex',
                alignItems: 'center',
                gap: '6px',
                padding: '8px 14px',
                background: inputMode === 'text' ? colors.accent.primary : 'transparent',
                border: 'none',
                borderRadius: '6px',
                color: inputMode === 'text' ? 'white' : colors.text.secondary,
                fontSize: '13px',
                fontWeight: '500',
                cursor: 'pointer',
              }}
            >
              Text Input
            </button>
            <button
              onClick={() => handleInputModeChange('image')}
              style={{
                display: 'flex',
                alignItems: 'center',
                gap: '6px',
                padding: '8px 14px',
                background: inputMode === 'image' ? colors.accent.primary : 'transparent',
                border: 'none',
                borderRadius: '6px',
                color: inputMode === 'image' ? 'white' : colors.text.secondary,
                fontSize: '13px',
                fontWeight: '500',
                cursor: 'pointer',
              }}
            >
              Image Input
            </button>
          </div>
        </div>
        
        <div style={{ display: 'flex', alignItems: 'center', gap: '12px' }}>
          <span style={{ 
            padding: '6px 12px', 
            background: `${colors.accent.primary}20`, 
            borderRadius: '6px',
            fontSize: '12px', 
            color: colors.accent.primary,
            fontWeight: '500',
          }}>
            {getWorkflowType()}
          </span>
          <div style={{
            padding: '8px 16px',
            background: colors.bg.tertiary,
            borderRadius: '6px',
            fontSize: '14px',
            fontWeight: '500',
            display: 'flex',
            alignItems: 'center',
            gap: '8px',
          }}>
            {currentGenerator?.name}
            {currentGenerator?.badge && (
              <span style={{
                padding: '2px 6px',
                background: currentGenerator.badge === 'BEST' ? colors.accent.success : 
                           currentGenerator.badge === 'NEW' ? colors.accent.primary :
                           currentGenerator.badge === 'POPULAR' ? colors.accent.warning :
                           currentGenerator.badge === 'ARTISTIC' ? '#ec4899' : colors.bg.elevated,
                borderRadius: '4px',
                fontSize: '9px',
                fontWeight: '700',
                color: 'white',
              }}>
                {currentGenerator.badge}
              </span>
            )}
          </div>
        </div>
      </div>
      
      {/* Main Content */}
      <div style={{ flex: 1, display: 'flex', overflow: 'hidden' }}>
        {/* Left Panel - Generator Selection (Collapsible) */}
        <div style={{
          width: leftPanelCollapsed ? '48px' : '280px',
          borderRight: `1px solid ${colors.border.subtle}`,
          overflow: 'hidden',
          background: colors.bg.secondary,
          transition: 'width 0.3s ease',
          display: 'flex',
          flexDirection: 'column',
        }}>
          {/* Collapse Toggle */}
          <button
            onClick={() => setLeftPanelCollapsed(!leftPanelCollapsed)}
            style={{
              padding: '12px',
              background: 'transparent',
              border: 'none',
              borderBottom: `1px solid ${colors.border.subtle}`,
              cursor: 'pointer',
              display: 'flex',
              alignItems: 'center',
              justifyContent: leftPanelCollapsed ? 'center' : 'space-between',
              color: colors.text.secondary,
            }}
          >
            {!leftPanelCollapsed && (
              <span style={{ fontSize: '13px', fontWeight: '600', textTransform: 'uppercase' }}>
                Generators
              </span>
            )}
            <Icons.ChevronLeft style={{ 
              width: 18, 
              height: 18, 
              transform: leftPanelCollapsed ? 'rotate(180deg)' : 'none',
              transition: 'transform 0.3s ease',
            }} />
          </button>
          
          {/* Panel Content */}
          <div style={{ 
            flex: 1, 
            overflow: 'auto', 
            padding: leftPanelCollapsed ? '8px' : '20px',
            opacity: leftPanelCollapsed ? 0 : 1,
            visibility: leftPanelCollapsed ? 'hidden' : 'visible',
            transition: 'opacity 0.2s ease',
          }}>
            <h3 style={{ fontSize: '12px', fontWeight: '600', color: colors.text.tertiary, marginBottom: '12px' }}>
              {getWorkflowType()}
            </h3>
            <div style={{ display: 'flex', flexDirection: 'column', gap: '8px' }}>
            {availableGenerators.map((gen) => (
              <button
                key={gen.id}
                onClick={() => setSelectedGenerator(gen.id)}
                style={{
                  display: 'flex',
                  flexDirection: 'column',
                  alignItems: 'flex-start',
                  padding: '12px',
                  background: selectedGenerator === gen.id ? `${colors.accent.primary}15` : colors.bg.tertiary,
                  border: `1px solid ${selectedGenerator === gen.id ? colors.accent.primary : colors.border.subtle}`,
                  borderRadius: '8px',
                  cursor: 'pointer',
                  textAlign: 'left',
                  transition: 'all 0.2s ease',
                }}
              >
                <div style={{ display: 'flex', alignItems: 'center', gap: '8px', width: '100%' }}>
                  <span style={{ fontSize: '14px', fontWeight: '600', color: colors.text.primary }}>{gen.name}</span>
                  {gen.badge && (
                    <span style={{
                      padding: '2px 6px',
                      background: gen.badge === 'BEST' ? colors.accent.success : 
                                 gen.badge === 'NEW' ? colors.accent.primary :
                                 gen.badge === 'POPULAR' ? colors.accent.warning :
                                 gen.badge === 'ARTISTIC' ? '#ec4899' : colors.bg.elevated,
                      borderRadius: '4px',
                      fontSize: '9px',
                      fontWeight: '700',
                      color: 'white',
                      marginLeft: 'auto',
                    }}>
                      {gen.badge}
                    </span>
                  )}
                </div>
                <div style={{ display: 'flex', gap: '12px', marginTop: '8px', fontSize: '11px' }}>
                  <span style={{ color: colors.text.secondary }}>
                    <span style={{ color: colors.text.tertiary }}>Quality:</span> {gen.quality}
                  </span>
                  <span style={{ color: colors.text.secondary }}>
                    <span style={{ color: colors.text.tertiary }}>Speed:</span> {gen.speed}
                  </span>
                </div>
                {/* Capability badges */}
                <div style={{ display: 'flex', gap: '4px', marginTop: '8px', flexWrap: 'wrap' }}>
                  {gen.capabilities.textToImage && <span style={{ padding: '2px 6px', background: colors.bg.secondary, borderRadius: '4px', fontSize: '9px', color: colors.text.tertiary }}>T→I</span>}
                  {gen.capabilities.imageToImage && <span style={{ padding: '2px 6px', background: colors.bg.secondary, borderRadius: '4px', fontSize: '9px', color: colors.text.tertiary }}>I→I</span>}
                  {gen.capabilities.textToVideo && <span style={{ padding: '2px 6px', background: colors.bg.secondary, borderRadius: '4px', fontSize: '9px', color: colors.text.tertiary }}>T→V</span>}
                  {gen.capabilities.imageToVideo && <span style={{ padding: '2px 6px', background: colors.bg.secondary, borderRadius: '4px', fontSize: '9px', color: colors.text.tertiary }}>I→V</span>}
                  {gen.capabilities.upscale && <span style={{ padding: '2px 6px', background: colors.bg.secondary, borderRadius: '4px', fontSize: '9px', color: colors.text.tertiary }}>Upscale</span>}
                </div>
              </button>
            ))}
          </div>
          
          {availableGenerators.length === 0 && (
            <div style={{ padding: '20px', textAlign: 'center', color: colors.text.tertiary }}>
              No generators available for {getWorkflowType()}
            </div>
          )}
          </div>
        </div>
        
        {/* Center - Generation Area */}
        <div style={{ flex: 1, display: 'flex', flexDirection: 'column', overflow: 'hidden' }}>
          {/* Examples / Generated Content */}
          <div style={{ flex: 1, overflow: 'auto', padding: '32px', display: 'flex', flexDirection: 'column', alignItems: 'center', justifyContent: 'center' }}>
            {generatedItems.length === 0 ? (
              <div style={{ textAlign: 'center', maxWidth: '800px' }}>
                <h2 style={{ fontSize: '28px', fontWeight: '600', marginBottom: '8px' }}>
                  {getWorkflowType()}
                </h2>
                <p style={{ color: colors.text.secondary, marginBottom: '32px' }}>
                  {inputMode === 'text' 
                    ? 'Describe what you want to create' 
                    : 'Upload a reference image to transform'}
                </p>
                
                {inputMode === 'text' && (
                  <div style={{ display: 'flex', gap: '16px', justifyContent: 'center' }}>
                    {examplePrompts.map((example, i) => (
                      <div
                        key={i}
                        onClick={() => setPrompt(example.prompt)}
                        style={{
                          width: '260px',
                          height: '180px',
                          borderRadius: '12px',
                          background: `linear-gradient(135deg, hsl(${i * 60 + 180}, 40%, 25%), hsl(${i * 60 + 180}, 40%, 35%))`,
                          cursor: 'pointer',
                          position: 'relative',
                          overflow: 'hidden',
                          transition: 'transform 0.2s ease',
                        }}
                        onMouseEnter={(e) => e.currentTarget.style.transform = 'scale(1.02)'}
                        onMouseLeave={(e) => e.currentTarget.style.transform = 'scale(1)'}
                      >
                        <div style={{
                          position: 'absolute',
                          bottom: 0,
                          left: 0,
                          right: 0,
                          padding: '16px',
                          background: 'linear-gradient(transparent, rgba(0,0,0,0.8))',
                        }}>
                          <p style={{ fontSize: '12px', color: 'white', lineHeight: '1.4' }}>
                            {example.prompt.slice(0, 80)}...
                          </p>
                        </div>
                      </div>
                    ))}
                  </div>
                )}
                
                {inputMode === 'image' && !referenceImage && (
                  <div
                    onClick={() => setReferenceImage('uploaded-reference.jpg')}
                    style={{
                      width: '300px',
                      height: '200px',
                      margin: '0 auto',
                      borderRadius: '16px',
                      border: `2px dashed ${colors.border.default}`,
                      display: 'flex',
                      flexDirection: 'column',
                      alignItems: 'center',
                      justifyContent: 'center',
                      gap: '12px',
                      cursor: 'pointer',
                      transition: 'all 0.2s ease',
                    }}
                  >
                    <Icons.Upload style={{ width: 32, height: 32, color: colors.text.tertiary }} />
                    <span style={{ color: colors.text.secondary }}>Upload reference image</span>
                    <span style={{ fontSize: '12px', color: colors.text.tertiary }}>or drag and drop</span>
                  </div>
                )}
                
                {inputMode === 'image' && referenceImage && (
                  <div style={{ position: 'relative', display: 'inline-block' }}>
                    <div style={{
                      width: '300px',
                      height: '200px',
                      borderRadius: '16px',
                      background: `linear-gradient(135deg, ${colors.accent.primary}40, ${colors.accent.secondary}40)`,
                      display: 'flex',
                      alignItems: 'center',
                      justifyContent: 'center',
                    }}>
                      <Icons.Image style={{ width: 48, height: 48, color: colors.text.tertiary }} />
                    </div>
                    <button
                      onClick={() => setReferenceImage(null)}
                      style={{
                        position: 'absolute',
                        top: '8px',
                        right: '8px',
                        width: '28px',
                        height: '28px',
                        borderRadius: '50%',
                        background: 'rgba(0,0,0,0.6)',
                        border: 'none',
                        color: 'white',
                        cursor: 'pointer',
                        display: 'flex',
                        alignItems: 'center',
                        justifyContent: 'center',
                      }}
                    >
                      <Icons.X style={{ width: 14, height: 14 }} />
                    </button>
                  </div>
                )}
              </div>
            ) : (
              <div style={{ width: '100%' }}>
                <h3 style={{ fontSize: '16px', fontWeight: '600', marginBottom: '16px' }}>Generated Content</h3>
                <div style={{ display: 'grid', gridTemplateColumns: 'repeat(auto-fill, minmax(300px, 1fr))', gap: '16px' }}>
                  {generatedItems.map((item) => (
                    <div
                      key={item.id}
                      style={{
                        background: colors.bg.secondary,
                        borderRadius: '12px',
                        overflow: 'hidden',
                        border: `1px solid ${colors.border.subtle}`,
                      }}
                    >
                      <div style={{
                        height: '200px',
                        background: `linear-gradient(135deg, hsl(${parseInt(item.id) % 360}, 40%, 25%), hsl(${parseInt(item.id) % 360}, 40%, 35%))`,
                        display: 'flex',
                        alignItems: 'center',
                        justifyContent: 'center',
                      }}>
                        {item.type === 'video' ? <Icons.Film /> : <Icons.Image />}
                      </div>
                      <div style={{ padding: '16px' }}>
                        <div style={{ display: 'flex', alignItems: 'center', gap: '8px', marginBottom: '8px' }}>
                          <span style={{ 
                            padding: '2px 8px', 
                            background: colors.bg.tertiary, 
                            borderRadius: '4px', 
                            fontSize: '10px', 
                            color: colors.text.secondary 
                          }}>
                            {item.workflow}
                          </span>
                        </div>
                        <p style={{ fontSize: '13px', color: colors.text.secondary, marginBottom: '8px', lineHeight: '1.4' }}>
                          {item.prompt ? item.prompt.slice(0, 100) + '...' : 'Image reference'}
                        </p>
                        <div style={{ display: 'flex', alignItems: 'center', justifyContent: 'space-between' }}>
                          <span style={{ fontSize: '11px', color: colors.text.tertiary }}>{generators.find(g => g.id === item.generator)?.name}</span>
                          <div style={{ display: 'flex', gap: '8px' }}>
                            <Button variant="ghost" size="sm">Edit</Button>
                            <Button variant="ghost" size="sm">Add to Scene</Button>
                          </div>
                        </div>
                      </div>
                    </div>
                  ))}
                </div>
              </div>
            )}
          </div>
          
          {/* Bottom - Prompt Input */}
          <div style={{
            padding: '20px 32px',
            borderTop: `1px solid ${colors.border.subtle}`,
            background: colors.bg.secondary,
          }}>
            {/* Selected Element Badge */}
            {selectedElement && (
              <div style={{
                display: 'flex',
                alignItems: 'center',
                gap: '8px',
                marginBottom: '12px',
                padding: '8px 12px',
                background: `${colors.accent.primary}15`,
                borderRadius: '8px',
                border: `1px solid ${colors.accent.primary}30`,
              }}>
                <span style={{ fontSize: '16px' }}>{selectedElement.emoji}</span>
                <span style={{ fontSize: '13px', color: colors.text.primary, fontWeight: '500' }}>
                  Using: {selectedElement.name}
                </span>
                <span style={{ fontSize: '11px', color: colors.text.tertiary, textTransform: 'capitalize' }}>
                  ({selectedElement.type})
                </span>
                <button
                  onClick={handleClearElement}
                  style={{
                    marginLeft: 'auto',
                    padding: '4px 8px',
                    background: 'transparent',
                    border: 'none',
                    color: colors.text.tertiary,
                    cursor: 'pointer',
                    fontSize: '12px',
                  }}
                >
                  ✕ Clear
                </button>
              </div>
            )}
            
            <div style={{
              display: 'flex',
              gap: '12px',
              alignItems: 'flex-end',
            }}>
              {/* Reference Image Upload/Preview */}
              <div style={{
                display: 'flex',
                flexDirection: 'column',
                gap: '4px',
              }}>
                <button
                  onClick={() => referenceImage ? setReferenceImage(null) : setReferenceImage('uploaded.jpg')}
                  style={{
                    width: '48px',
                    height: '48px',
                    borderRadius: '8px',
                    border: `1px solid ${referenceImage ? colors.accent.primary : colors.border.default}`,
                    background: referenceImage ? `${colors.accent.primary}20` : colors.bg.tertiary,
                    color: referenceImage ? colors.accent.primary : colors.text.tertiary,
                    cursor: 'pointer',
                    display: 'flex',
                    alignItems: 'center',
                    justifyContent: 'center',
                  }}
                  title={referenceImage ? "Remove reference image" : "Add reference image"}
                >
                  {referenceImage ? <Icons.Check /> : <Icons.Plus />}
                </button>
              </div>
              
              {/* Elements Picker Button */}
              <div style={{
                display: 'flex',
                flexDirection: 'column',
                gap: '4px',
              }}>
                <button
                  onClick={() => setShowElementsPicker(true)}
                  style={{
                    width: '48px',
                    height: '48px',
                    borderRadius: '8px',
                    border: `1px solid ${selectedElement ? colors.accent.success : colors.border.default}`,
                    background: selectedElement ? `${colors.accent.success}20` : colors.bg.tertiary,
                    color: selectedElement ? colors.accent.success : colors.text.tertiary,
                    cursor: 'pointer',
                    display: 'flex',
                    alignItems: 'center',
                    justifyContent: 'center',
                  }}
                  title="Use Element"
                >
                  <Icons.Users style={{ width: 20, height: 20 }} />
                </button>
              </div>
              
              {/* Prompt Input */}
              <div style={{ flex: 1 }}>
                <div style={{
                  display: 'flex',
                  alignItems: 'center',
                  background: colors.bg.tertiary,
                  border: `1px solid ${colors.border.subtle}`,
                  borderRadius: '12px',
                  padding: '4px',
                }}>
                  <div
                    onClick={() => {
                      setTempPrompt(prompt);
                      setShowPromptEditor(true);
                    }}
                    style={{
                      flex: 1,
                      padding: '12px 16px',
                      background: 'transparent',
                      color: prompt ? colors.text.primary : colors.text.tertiary,
                      fontSize: '14px',
                      cursor: 'text',
                      minHeight: '24px',
                      display: 'flex',
                      alignItems: 'center',
                      overflow: 'hidden',
                      textOverflow: 'ellipsis',
                      whiteSpace: 'nowrap',
                    }}
                  >
                    {prompt ? (
                      <span style={{ overflow: 'hidden', textOverflow: 'ellipsis' }}>
                        {prompt.length > 80 ? `${prompt.slice(0, 80)}...` : prompt}
                      </span>
                    ) : (
                      <span style={{ display: 'flex', alignItems: 'center', gap: '8px' }}>
                        {inputMode === 'text' 
                          ? (mode === 'image' ? 'Click to write your prompt...' : 'Click to describe the video scene...')
                          : 'Click to add a prompt (optional)...'}
                        <Icons.Edit style={{ width: 14, height: 14, opacity: 0.5 }} />
                      </span>
                    )}
                  </div>
                  {prompt && (
                    <button
                      onClick={() => setPrompt('')}
                      style={{
                        padding: '8px',
                        background: 'transparent',
                        border: 'none',
                        color: colors.text.tertiary,
                        cursor: 'pointer',
                        display: 'flex',
                        alignItems: 'center',
                        justifyContent: 'center',
                      }}
                      title="Clear prompt"
                    >
                      <Icons.X style={{ width: 16, height: 16 }} />
                    </button>
                  )}
                  <button
                    onClick={handleGenerate}
                    disabled={isGenerating || (inputMode === 'text' && !prompt.trim()) || (inputMode === 'image' && !referenceImage)}
                    style={{
                      padding: '12px 24px',
                      background: isGenerating ? colors.bg.elevated : colors.accent.primary,
                      border: 'none',
                      borderRadius: '8px',
                      color: 'white',
                      fontSize: '14px',
                      fontWeight: '500',
                      cursor: isGenerating ? 'not-allowed' : 'pointer',
                      display: 'flex',
                      alignItems: 'center',
                      gap: '8px',
                      opacity: (inputMode === 'text' && !prompt.trim()) || (inputMode === 'image' && !referenceImage) ? 0.5 : 1,
                    }}
                  >
                    {isGenerating ? (
                      <>Generating...</>
                    ) : (
                      <>
                        <Icons.Sparkles />
                        Generate
                      </>
                    )}
                  </button>
                </div>
              </div>
            </div>
            
            {/* Settings Bar */}
            <div style={{
              display: 'flex',
              alignItems: 'center',
              gap: '16px',
              marginTop: '12px',
              flexWrap: 'wrap',
            }}>
              {/* Model Selection */}
              <div style={{ display: 'flex', alignItems: 'center', gap: '8px' }}>
                <Icons.Sparkles style={{ width: '14px', height: '14px', color: colors.text.tertiary }} />
                <select
                  value={selectedGenerator}
                  onChange={(e) => setSelectedGenerator(e.target.value)}
                  style={{
                    padding: '6px 12px',
                    background: colors.bg.tertiary,
                    border: `1px solid ${colors.border.subtle}`,
                    borderRadius: '6px',
                    color: colors.text.primary,
                    fontSize: '13px',
                    cursor: 'pointer',
                  }}
                >
                  {availableGenerators.map((gen) => (
                    <option key={gen.id} value={gen.id}>{gen.name}</option>
                  ))}
                </select>
              </div>
              
              {/* Aspect Ratio */}
              <div style={{ display: 'flex', gap: '4px' }}>
                {aspectRatioOptions.slice(0, 3).map((ratio) => (
                  <button
                    key={ratio.id}
                    onClick={() => setGenerationSettings(prev => ({ ...prev, aspectRatio: ratio.id }))}
                    style={{
                      padding: '6px 12px',
                      background: generationSettings.aspectRatio === ratio.id ? colors.accent.primary : colors.bg.tertiary,
                      border: 'none',
                      borderRadius: '6px',
                      color: generationSettings.aspectRatio === ratio.id ? 'white' : colors.text.secondary,
                      fontSize: '12px',
                      cursor: 'pointer',
                    }}
                  >
                    {ratio.label}
                  </button>
                ))}
              </div>
              
              {/* Image Size / Resolution */}
              {mode === 'image' ? (
                <div style={{ display: 'flex', alignItems: 'center', gap: '4px' }}>
                  <Icons.Camera style={{ width: '14px', height: '14px', color: colors.text.tertiary }} />
                  <select
                    value={generationSettings.imageSize}
                    onChange={(e) => setGenerationSettings(prev => ({ ...prev, imageSize: e.target.value }))}
                    style={{
                      padding: '6px 10px',
                      background: colors.bg.tertiary,
                      border: `1px solid ${colors.border.subtle}`,
                      borderRadius: '6px',
                      color: colors.text.primary,
                      fontSize: '12px',
                      cursor: 'pointer',
                    }}
                  >
                    {imageSizeOptions.map((size) => (
                      <option key={size.id} value={size.id}>{size.label}</option>
                    ))}
                  </select>
                </div>
              ) : (
                <div style={{ display: 'flex', alignItems: 'center', gap: '4px' }}>
                  <Icons.Camera style={{ width: '14px', height: '14px', color: colors.text.tertiary }} />
                  <select
                    value={generationSettings.resolution}
                    onChange={(e) => setGenerationSettings(prev => ({ ...prev, resolution: e.target.value }))}
                    style={{
                      padding: '6px 10px',
                      background: colors.bg.tertiary,
                      border: `1px solid ${colors.border.subtle}`,
                      borderRadius: '6px',
                      color: colors.text.primary,
                      fontSize: '12px',
                      cursor: 'pointer',
                    }}
                  >
                    {resolutionOptions.map((res) => (
                      <option key={res.id} value={res.id}>{res.label}</option>
                    ))}
                  </select>
                </div>
              )}
              
              {/* Video-specific: Duration */}
              {mode === 'video' && (
                <div style={{ display: 'flex', alignItems: 'center', gap: '8px' }}>
                  <span style={{ fontSize: '12px', color: colors.text.tertiary }}>Duration:</span>
                  <div style={{ display: 'flex', gap: '2px' }}>
                    {durationOptions.map((d) => (
                      <button
                        key={d}
                        onClick={() => setGenerationSettings(prev => ({ ...prev, duration: d }))}
                        style={{
                          padding: '6px 10px',
                          background: generationSettings.duration === d ? colors.accent.primary : colors.bg.tertiary,
                          border: 'none',
                          borderRadius: '4px',
                          color: generationSettings.duration === d ? 'white' : colors.text.secondary,
                          fontSize: '12px',
                          cursor: 'pointer',
                        }}
                      >
                        {d}s
                      </button>
                    ))}
                  </div>
                </div>
              )}
              
              {/* Number of outputs */}
              <div style={{ display: 'flex', alignItems: 'center', gap: '8px', marginLeft: 'auto' }}>
                <span style={{ fontSize: '12px', color: colors.text.tertiary }}>Outputs:</span>
                <div style={{ display: 'flex', gap: '2px' }}>
                  {[1, 2, 4].map((num) => (
                    <button
                      key={num}
                      style={{
                        padding: '6px 10px',
                        background: num === 1 ? colors.accent.primary : colors.bg.tertiary,
                        border: 'none',
                        borderRadius: '4px',
                        color: num === 1 ? 'white' : colors.text.secondary,
                        fontSize: '12px',
                        cursor: 'pointer',
                      }}
                    >
                      {num}
                    </button>
                  ))}
                </div>
              </div>
            </div>
          </div>
        </div>
        
        {/* Right Panel - Advanced Settings (Collapsible) */}
        <div style={{
          width: rightPanelCollapsed ? '48px' : '320px',
          borderLeft: `1px solid ${colors.border.subtle}`,
          overflow: 'hidden',
          background: colors.bg.secondary,
          display: 'flex',
          flexDirection: 'column',
          transition: 'width 0.3s ease',
        }}>
          {/* Collapse Toggle */}
          <button
            onClick={() => setRightPanelCollapsed(!rightPanelCollapsed)}
            style={{
              padding: '12px',
              background: 'transparent',
              border: 'none',
              borderBottom: `1px solid ${colors.border.subtle}`,
              cursor: 'pointer',
              display: 'flex',
              alignItems: 'center',
              justifyContent: rightPanelCollapsed ? 'center' : 'space-between',
              color: colors.text.secondary,
            }}
          >
            <Icons.ChevronRight style={{ 
              width: 18, 
              height: 18, 
              transform: rightPanelCollapsed ? 'rotate(180deg)' : 'none',
              transition: 'transform 0.3s ease',
            }} />
            {!rightPanelCollapsed && (
              <span style={{ fontSize: '13px', fontWeight: '600', textTransform: 'uppercase' }}>
                Settings
              </span>
            )}
          </button>
          
          {/* Panel Content */}
          <div style={{
            flex: 1,
            overflow: 'hidden',
            display: 'flex',
            flexDirection: 'column',
            opacity: rightPanelCollapsed ? 0 : 1,
            visibility: rightPanelCollapsed ? 'hidden' : 'visible',
            transition: 'opacity 0.2s ease',
          }}>
          {/* Settings Tabs */}
          <div style={{ 
            display: 'flex', 
            borderBottom: `1px solid ${colors.border.subtle}`,
            padding: '0 12px',
          }}>
            {[
              { id: 'camera', label: 'Camera' },
              { id: 'lighting', label: 'Lighting' },
              { id: 'style', label: 'Style' },
              { id: 'advanced', label: 'Advanced' },
            ].map(tab => (
              <button
                key={tab.id}
                onClick={() => setSettingsTab(tab.id)}
                style={{
                  padding: '12px 14px',
                  background: 'transparent',
                  border: 'none',
                  borderBottom: `2px solid ${settingsTab === tab.id ? colors.accent.primary : 'transparent'}`,
                  color: settingsTab === tab.id ? colors.text.primary : colors.text.tertiary,
                  fontSize: '12px',
                  fontWeight: '500',
                  cursor: 'pointer',
                  transition: 'all 0.2s ease',
                }}
              >
                {tab.label}
              </button>
            ))}
          </div>
          
          <div style={{ flex: 1, overflow: 'auto', padding: '16px' }}>
            {/* CAMERA TAB */}
            {settingsTab === 'camera' && (
              <>
                {/* Media Quality */}
                <div style={{ marginBottom: '20px' }}>
                  <label style={{ fontSize: '11px', color: colors.text.tertiary, display: 'block', marginBottom: '6px', textTransform: 'uppercase' }}>Media Quality</label>
                  <div style={{ display: 'flex', gap: '6px' }}>
                    {mediaQualityOptions.map(opt => (
                      <button
                        key={opt.id}
                        onClick={() => setGenerationSettings(prev => ({ ...prev, mediaQuality: opt.id }))}
                        style={{
                          flex: 1,
                          padding: '8px 4px',
                          background: generationSettings.mediaQuality === opt.id ? colors.accent.primary : colors.bg.tertiary,
                          border: 'none',
                          borderRadius: '6px',
                          color: generationSettings.mediaQuality === opt.id ? 'white' : colors.text.secondary,
                          fontSize: '11px',
                          fontWeight: '500',
                          cursor: 'pointer',
                        }}
                      >
                        {opt.label}
                      </button>
                    ))}
                  </div>
                </div>
                
                {/* Shot Size */}
                <div style={{ marginBottom: '20px' }}>
                  <label style={{ fontSize: '11px', color: colors.text.tertiary, display: 'block', marginBottom: '6px', textTransform: 'uppercase' }}>Shot Size</label>
                  <select
                    value={generationSettings.shotSize}
                    onChange={(e) => setGenerationSettings(prev => ({ ...prev, shotSize: e.target.value }))}
                    style={{
                      width: '100%',
                      padding: '8px 12px',
                      background: colors.bg.tertiary,
                      border: `1px solid ${colors.border.subtle}`,
                      borderRadius: '6px',
                      color: colors.text.primary,
                      fontSize: '13px',
                    }}
                  >
                    {shotSizeOptions.map(opt => (
                      <option key={opt.id} value={opt.id}>{opt.label}</option>
                    ))}
                  </select>
                </div>
                
                {/* Camera Angle */}
                <div style={{ marginBottom: '20px' }}>
                  <label style={{ fontSize: '11px', color: colors.text.tertiary, display: 'block', marginBottom: '6px', textTransform: 'uppercase' }}>Camera Angle</label>
                  <div style={{ display: 'grid', gridTemplateColumns: 'repeat(3, 1fr)', gap: '6px' }}>
                    {cameraAngleOptions.map(opt => (
                      <button
                        key={opt.id}
                        onClick={() => setGenerationSettings(prev => ({ ...prev, cameraAngle: opt.id }))}
                        style={{
                          padding: '8px 4px',
                          background: generationSettings.cameraAngle === opt.id ? colors.accent.primary : colors.bg.tertiary,
                          border: 'none',
                          borderRadius: '6px',
                          color: generationSettings.cameraAngle === opt.id ? 'white' : colors.text.secondary,
                          fontSize: '10px',
                          fontWeight: '500',
                          cursor: 'pointer',
                        }}
                      >
                        {opt.label}
                      </button>
                    ))}
                  </div>
                </div>
                
                {/* Framing */}
                <div style={{ marginBottom: '20px' }}>
                  <label style={{ fontSize: '11px', color: colors.text.tertiary, display: 'block', marginBottom: '6px', textTransform: 'uppercase' }}>Framing</label>
                  <div style={{ display: 'flex', gap: '6px' }}>
                    {framingOptions.map(opt => (
                      <button
                        key={opt.id}
                        onClick={() => setGenerationSettings(prev => ({ ...prev, framing: opt.id }))}
                        style={{
                          flex: 1,
                          padding: '8px 4px',
                          background: generationSettings.framing === opt.id ? colors.accent.primary : colors.bg.tertiary,
                          border: 'none',
                          borderRadius: '6px',
                          color: generationSettings.framing === opt.id ? 'white' : colors.text.secondary,
                          fontSize: '11px',
                          fontWeight: '500',
                          cursor: 'pointer',
                        }}
                      >
                        {opt.label}
                      </button>
                    ))}
                  </div>
                </div>
                
                {/* Lens */}
                <div style={{ marginBottom: '20px' }}>
                  <label style={{ fontSize: '11px', color: colors.text.tertiary, display: 'block', marginBottom: '6px', textTransform: 'uppercase' }}>Lens</label>
                  <select
                    value={generationSettings.lens}
                    onChange={(e) => setGenerationSettings(prev => ({ ...prev, lens: e.target.value }))}
                    style={{
                      width: '100%',
                      padding: '8px 12px',
                      background: colors.bg.tertiary,
                      border: `1px solid ${colors.border.subtle}`,
                      borderRadius: '6px',
                      color: colors.text.primary,
                      fontSize: '13px',
                    }}
                  >
                    {lensOptions.map(opt => (
                      <option key={opt.id} value={opt.id}>{opt.label}</option>
                    ))}
                  </select>
                </div>
                
                {/* Video-only: Camera Movement */}
                {mode === 'video' && (
                  <>
                    <div style={{ marginBottom: '20px' }}>
                      <label style={{ fontSize: '11px', color: colors.text.tertiary, display: 'block', marginBottom: '6px', textTransform: 'uppercase' }}>Camera Movement</label>
                      <select
                        value={generationSettings.cameraMovement}
                        onChange={(e) => setGenerationSettings(prev => ({ ...prev, cameraMovement: e.target.value }))}
                        style={{
                          width: '100%',
                          padding: '8px 12px',
                          background: colors.bg.tertiary,
                          border: `1px solid ${colors.border.subtle}`,
                          borderRadius: '6px',
                          color: colors.text.primary,
                          fontSize: '13px',
                        }}
                      >
                        {cameraMovementOptions.map(opt => (
                          <option key={opt.id} value={opt.id}>{opt.label}</option>
                        ))}
                      </select>
                    </div>
                    
                    {/* Movement Speed */}
                    <div style={{ marginBottom: '20px' }}>
                      <div style={{ display: 'flex', justifyContent: 'space-between', marginBottom: '6px' }}>
                        <label style={{ fontSize: '11px', color: colors.text.tertiary, textTransform: 'uppercase' }}>Movement Speed</label>
                        <span style={{ fontSize: '12px', fontFamily: 'monospace', color: colors.text.secondary }}>{generationSettings.movementSpeed}</span>
                      </div>
                      <input
                        type="range"
                        min="1"
                        max="10"
                        value={generationSettings.movementSpeed}
                        onChange={(e) => setGenerationSettings(prev => ({ ...prev, movementSpeed: parseInt(e.target.value) }))}
                        style={{ width: '100%', accentColor: colors.accent.primary }}
                      />
                    </div>
                  </>
                )}
              </>
            )}
            
            {/* LIGHTING TAB */}
            {settingsTab === 'lighting' && (
              <>
                {/* Lighting Style */}
                <div style={{ marginBottom: '20px' }}>
                  <label style={{ fontSize: '11px', color: colors.text.tertiary, display: 'block', marginBottom: '6px', textTransform: 'uppercase' }}>Lighting Style</label>
                  <div style={{ display: 'grid', gridTemplateColumns: 'repeat(2, 1fr)', gap: '6px' }}>
                    {lightingStyleOptions.map(opt => (
                      <button
                        key={opt.id}
                        onClick={() => setGenerationSettings(prev => ({ ...prev, lightingStyle: opt.id }))}
                        style={{
                          padding: '10px 8px',
                          background: generationSettings.lightingStyle === opt.id ? colors.accent.primary : colors.bg.tertiary,
                          border: 'none',
                          borderRadius: '6px',
                          color: generationSettings.lightingStyle === opt.id ? 'white' : colors.text.secondary,
                          fontSize: '11px',
                          fontWeight: '500',
                          cursor: 'pointer',
                        }}
                      >
                        {opt.label}
                      </button>
                    ))}
                  </div>
                </div>
                
                {/* Lighting Direction */}
                <div style={{ marginBottom: '20px' }}>
                  <div style={{ display: 'flex', justifyContent: 'space-between', marginBottom: '6px' }}>
                    <label style={{ fontSize: '11px', color: colors.text.tertiary, textTransform: 'uppercase' }}>Light Direction</label>
                    <span style={{ fontSize: '12px', fontFamily: 'monospace', color: colors.text.secondary }}>{generationSettings.lightingDirection}°</span>
                  </div>
                  <input
                    type="range"
                    min="0"
                    max="360"
                    value={generationSettings.lightingDirection}
                    onChange={(e) => setGenerationSettings(prev => ({ ...prev, lightingDirection: parseInt(e.target.value) }))}
                    style={{ width: '100%', accentColor: colors.accent.primary }}
                  />
                  <div style={{ display: 'flex', justifyContent: 'space-between', fontSize: '9px', color: colors.text.tertiary, marginTop: '4px' }}>
                    <span>Front</span>
                    <span>Right</span>
                    <span>Back</span>
                    <span>Left</span>
                    <span>Front</span>
                  </div>
                </div>
                
                {/* Time of Day */}
                <div style={{ marginBottom: '20px' }}>
                  <label style={{ fontSize: '11px', color: colors.text.tertiary, display: 'block', marginBottom: '6px', textTransform: 'uppercase' }}>Time of Day</label>
                  <div style={{ display: 'flex', gap: '6px', flexWrap: 'wrap' }}>
                    {timeOfDayOptions.map(opt => (
                      <button
                        key={opt.id}
                        onClick={() => setGenerationSettings(prev => ({ ...prev, timeOfDay: opt.id }))}
                        style={{
                          padding: '8px 12px',
                          background: generationSettings.timeOfDay === opt.id ? colors.accent.primary : colors.bg.tertiary,
                          border: 'none',
                          borderRadius: '6px',
                          color: generationSettings.timeOfDay === opt.id ? 'white' : colors.text.secondary,
                          fontSize: '11px',
                          fontWeight: '500',
                          cursor: 'pointer',
                        }}
                      >
                        {opt.label}
                      </button>
                    ))}
                  </div>
                </div>
                
                {/* Weather */}
                <div style={{ marginBottom: '20px' }}>
                  <label style={{ fontSize: '11px', color: colors.text.tertiary, display: 'block', marginBottom: '6px', textTransform: 'uppercase' }}>Weather / Environment</label>
                  <div style={{ display: 'grid', gridTemplateColumns: 'repeat(3, 1fr)', gap: '6px' }}>
                    {weatherOptions.map(opt => (
                      <button
                        key={opt.id}
                        onClick={() => setGenerationSettings(prev => ({ ...prev, weather: opt.id }))}
                        style={{
                          padding: '8px 4px',
                          background: generationSettings.weather === opt.id ? colors.accent.primary : colors.bg.tertiary,
                          border: 'none',
                          borderRadius: '6px',
                          color: generationSettings.weather === opt.id ? 'white' : colors.text.secondary,
                          fontSize: '10px',
                          fontWeight: '500',
                          cursor: 'pointer',
                        }}
                      >
                        {opt.label}
                      </button>
                    ))}
                  </div>
                </div>
              </>
            )}
            
            {/* STYLE TAB */}
            {settingsTab === 'style' && (
              <>
                {/* Color Grade */}
                <div style={{ marginBottom: '20px' }}>
                  <label style={{ fontSize: '11px', color: colors.text.tertiary, display: 'block', marginBottom: '6px', textTransform: 'uppercase' }}>Color Grade</label>
                  <div style={{ display: 'grid', gridTemplateColumns: 'repeat(2, 1fr)', gap: '6px' }}>
                    {colorGradeOptions.map(opt => (
                      <button
                        key={opt.id}
                        onClick={() => setGenerationSettings(prev => ({ ...prev, colorGrade: opt.id }))}
                        style={{
                          padding: '10px 8px',
                          background: generationSettings.colorGrade === opt.id ? colors.accent.primary : colors.bg.tertiary,
                          border: 'none',
                          borderRadius: '6px',
                          color: generationSettings.colorGrade === opt.id ? 'white' : colors.text.secondary,
                          fontSize: '11px',
                          fontWeight: '500',
                          cursor: 'pointer',
                        }}
                      >
                        {opt.label}
                      </button>
                    ))}
                  </div>
                </div>
                
                {/* Aesthetic */}
                <div style={{ marginBottom: '20px' }}>
                  <label style={{ fontSize: '11px', color: colors.text.tertiary, display: 'block', marginBottom: '6px', textTransform: 'uppercase' }}>Aesthetic</label>
                  <div style={{ display: 'grid', gridTemplateColumns: 'repeat(2, 1fr)', gap: '6px' }}>
                    {aestheticOptions.map(opt => (
                      <button
                        key={opt.id}
                        onClick={() => setGenerationSettings(prev => ({ ...prev, aesthetic: opt.id }))}
                        style={{
                          padding: '10px 8px',
                          background: generationSettings.aesthetic === opt.id ? colors.accent.primary : colors.bg.tertiary,
                          border: 'none',
                          borderRadius: '6px',
                          color: generationSettings.aesthetic === opt.id ? 'white' : colors.text.secondary,
                          fontSize: '11px',
                          fontWeight: '500',
                          cursor: 'pointer',
                        }}
                      >
                        {opt.label}
                      </button>
                    ))}
                  </div>
                </div>
                
                {/* Wardrobe Style */}
                <div style={{ marginBottom: '20px' }}>
                  <label style={{ fontSize: '11px', color: colors.text.tertiary, display: 'block', marginBottom: '6px', textTransform: 'uppercase' }}>Wardrobe Style</label>
                  <select
                    value={generationSettings.wardrobeStyle}
                    onChange={(e) => setGenerationSettings(prev => ({ ...prev, wardrobeStyle: e.target.value }))}
                    style={{
                      width: '100%',
                      padding: '8px 12px',
                      background: colors.bg.tertiary,
                      border: `1px solid ${colors.border.subtle}`,
                      borderRadius: '6px',
                      color: colors.text.primary,
                      fontSize: '13px',
                    }}
                  >
                    {wardrobeStyleOptions.map(opt => (
                      <option key={opt.id} value={opt.id}>{opt.label}</option>
                    ))}
                  </select>
                </div>
                
                {/* Negative Prompt */}
                <div style={{ marginBottom: '20px' }}>
                  <label style={{ fontSize: '11px', color: colors.text.tertiary, display: 'block', marginBottom: '6px', textTransform: 'uppercase' }}>Negative Prompt</label>
                  <textarea
                    placeholder="Things to avoid..."
                    value={generationSettings.negativePrompt}
                    onChange={(e) => setGenerationSettings(prev => ({ ...prev, negativePrompt: e.target.value }))}
                    style={{
                      width: '100%',
                      padding: '10px 12px',
                      background: colors.bg.tertiary,
                      border: `1px solid ${colors.border.subtle}`,
                      borderRadius: '6px',
                      color: colors.text.primary,
                      fontSize: '12px',
                      resize: 'vertical',
                      minHeight: '60px',
                    }}
                  />
                </div>
              </>
            )}
            
            {/* ADVANCED TAB */}
            {settingsTab === 'advanced' && (
              <>
                {/* Aspect Ratio */}
                <div style={{ marginBottom: '20px' }}>
                  <label style={{ fontSize: '11px', color: colors.text.tertiary, display: 'block', marginBottom: '6px', textTransform: 'uppercase' }}>Aspect Ratio</label>
                  <div style={{ display: 'flex', gap: '6px' }}>
                    {aspectRatioOptions.map(opt => (
                      <button
                        key={opt.id}
                        onClick={() => setGenerationSettings(prev => ({ ...prev, aspectRatio: opt.id }))}
                        style={{
                          flex: 1,
                          padding: '8px 4px',
                          background: generationSettings.aspectRatio === opt.id ? colors.accent.primary : colors.bg.tertiary,
                          border: 'none',
                          borderRadius: '6px',
                          color: generationSettings.aspectRatio === opt.id ? 'white' : colors.text.secondary,
                          fontSize: '11px',
                          fontWeight: '500',
                          cursor: 'pointer',
                        }}
                      >
                        {opt.label}
                      </button>
                    ))}
                  </div>
                </div>
                
                {/* Image-specific settings */}
                {mode === 'image' && (
                  <div style={{ marginBottom: '20px' }}>
                    <label style={{ fontSize: '11px', color: colors.text.tertiary, display: 'block', marginBottom: '6px', textTransform: 'uppercase' }}>Image Size</label>
                    <div style={{ display: 'flex', gap: '6px' }}>
                      {imageSizeOptions.map(opt => (
                        <button
                          key={opt.id}
                          onClick={() => setGenerationSettings(prev => ({ ...prev, imageSize: opt.id }))}
                          style={{
                            flex: 1,
                            padding: '8px 4px',
                            background: generationSettings.imageSize === opt.id ? colors.accent.primary : colors.bg.tertiary,
                            border: 'none',
                            borderRadius: '6px',
                            color: generationSettings.imageSize === opt.id ? 'white' : colors.text.secondary,
                            fontSize: '11px',
                            fontWeight: '500',
                            cursor: 'pointer',
                          }}
                        >
                          {opt.label}
                        </button>
                      ))}
                    </div>
                  </div>
                )}
                
                {/* Video-specific settings */}
                {mode === 'video' && (
                  <>
                    <div style={{ marginBottom: '20px' }}>
                      <label style={{ fontSize: '11px', color: colors.text.tertiary, display: 'block', marginBottom: '6px', textTransform: 'uppercase' }}>Resolution</label>
                      <div style={{ display: 'flex', gap: '6px' }}>
                        {resolutionOptions.map(opt => (
                          <button
                            key={opt.id}
                            onClick={() => setGenerationSettings(prev => ({ ...prev, resolution: opt.id }))}
                            style={{
                              flex: 1,
                              padding: '8px 4px',
                              background: generationSettings.resolution === opt.id ? colors.accent.primary : colors.bg.tertiary,
                              border: 'none',
                              borderRadius: '6px',
                              color: generationSettings.resolution === opt.id ? 'white' : colors.text.secondary,
                              fontSize: '11px',
                              fontWeight: '500',
                              cursor: 'pointer',
                            }}
                          >
                            {opt.label}
                          </button>
                        ))}
                      </div>
                    </div>
                    
                    <div style={{ marginBottom: '20px' }}>
                      <label style={{ fontSize: '11px', color: colors.text.tertiary, display: 'block', marginBottom: '6px', textTransform: 'uppercase' }}>Frame Rate</label>
                      <div style={{ display: 'flex', gap: '6px' }}>
                        {fpsOptions.map(fps => (
                          <button
                            key={fps}
                            onClick={() => setGenerationSettings(prev => ({ ...prev, fps }))}
                            style={{
                              flex: 1,
                              padding: '8px 4px',
                              background: generationSettings.fps === fps ? colors.accent.primary : colors.bg.tertiary,
                              border: 'none',
                              borderRadius: '6px',
                              color: generationSettings.fps === fps ? 'white' : colors.text.secondary,
                              fontSize: '11px',
                              fontWeight: '500',
                              cursor: 'pointer',
                            }}
                          >
                            {fps} fps
                          </button>
                        ))}
                      </div>
                    </div>
                    
                    <div style={{ marginBottom: '20px' }}>
                      <label style={{ fontSize: '11px', color: colors.text.tertiary, display: 'block', marginBottom: '6px', textTransform: 'uppercase' }}>Duration</label>
                      <div style={{ display: 'flex', gap: '6px' }}>
                        {durationOptions.map(dur => (
                          <button
                            key={dur}
                            onClick={() => setGenerationSettings(prev => ({ ...prev, duration: dur }))}
                            style={{
                              flex: 1,
                              padding: '8px 4px',
                              background: generationSettings.duration === dur ? colors.accent.primary : colors.bg.tertiary,
                              border: 'none',
                              borderRadius: '6px',
                              color: generationSettings.duration === dur ? 'white' : colors.text.secondary,
                              fontSize: '11px',
                              fontWeight: '500',
                              cursor: 'pointer',
                            }}
                          >
                            {dur}s
                          </button>
                        ))}
                      </div>
                    </div>
                    
                    {/* Start/End Frame for timeline control */}
                    <div style={{ marginBottom: '20px' }}>
                      <label style={{ fontSize: '11px', color: colors.text.tertiary, display: 'block', marginBottom: '6px', textTransform: 'uppercase' }}>Timeline Control</label>
                      <div style={{ display: 'flex', gap: '8px' }}>
                        <div 
                          onClick={() => setStartFrame(startFrame ? null : 'start-frame.jpg')}
                          style={{
                            flex: 1,
                            height: '60px',
                            borderRadius: '8px',
                            border: `2px dashed ${startFrame ? colors.accent.primary : colors.border.default}`,
                            background: startFrame ? `${colors.accent.primary}20` : colors.bg.tertiary,
                            display: 'flex',
                            flexDirection: 'column',
                            alignItems: 'center',
                            justifyContent: 'center',
                            cursor: 'pointer',
                          }}
                        >
                          {startFrame ? <Icons.Check style={{ width: 16, height: 16, color: colors.accent.primary }} /> : <Icons.Plus style={{ width: 14, height: 14, color: colors.text.tertiary }} />}
                          <span style={{ fontSize: '9px', color: colors.text.tertiary, marginTop: '4px' }}>Start Frame</span>
                        </div>
                        <div 
                          onClick={() => setEndFrame(endFrame ? null : 'end-frame.jpg')}
                          style={{
                            flex: 1,
                            height: '60px',
                            borderRadius: '8px',
                            border: `2px dashed ${endFrame ? colors.accent.primary : colors.border.default}`,
                            background: endFrame ? `${colors.accent.primary}20` : colors.bg.tertiary,
                            display: 'flex',
                            flexDirection: 'column',
                            alignItems: 'center',
                            justifyContent: 'center',
                            cursor: 'pointer',
                          }}
                        >
                          {endFrame ? <Icons.Check style={{ width: 16, height: 16, color: colors.accent.primary }} /> : <Icons.Plus style={{ width: 14, height: 14, color: colors.text.tertiary }} />}
                          <span style={{ fontSize: '9px', color: colors.text.tertiary, marginTop: '4px' }}>End Frame</span>
                        </div>
                      </div>
                    </div>
                  </>
                )}
                
                {/* Guidance Scale */}
                <div style={{ marginBottom: '20px' }}>
                  <div style={{ display: 'flex', justifyContent: 'space-between', marginBottom: '6px' }}>
                    <label style={{ fontSize: '11px', color: colors.text.tertiary, textTransform: 'uppercase' }}>Guidance Scale</label>
                    <span style={{ fontSize: '12px', fontFamily: 'monospace', color: colors.text.secondary }}>{generationSettings.guidanceScale}</span>
                  </div>
                  <input
                    type="range"
                    min="1"
                    max="20"
                    step="0.5"
                    value={generationSettings.guidanceScale}
                    onChange={(e) => setGenerationSettings(prev => ({ ...prev, guidanceScale: parseFloat(e.target.value) }))}
                    style={{ width: '100%', accentColor: colors.accent.primary }}
                  />
                </div>
                
                {/* Seed */}
                <div style={{ marginBottom: '20px' }}>
                  <label style={{ fontSize: '11px', color: colors.text.tertiary, display: 'block', marginBottom: '6px', textTransform: 'uppercase' }}>Seed (optional)</label>
                  <input
                    type="text"
                    placeholder="Random"
                    value={generationSettings.seed}
                    onChange={(e) => setGenerationSettings(prev => ({ ...prev, seed: e.target.value }))}
                    style={{
                      width: '100%',
                      padding: '8px 12px',
                      background: colors.bg.tertiary,
                      border: `1px solid ${colors.border.subtle}`,
                      borderRadius: '6px',
                      color: colors.text.primary,
                      fontSize: '12px',
                    }}
                  />
                </div>
                
                {/* Reference Images */}
                <div style={{ marginBottom: '20px' }}>
                  <label style={{ fontSize: '11px', color: colors.text.tertiary, display: 'block', marginBottom: '6px', textTransform: 'uppercase' }}>
                    Reference Images ({referenceImages.length}/{mode === 'image' ? 4 : 3})
                  </label>
                  <div style={{ display: 'grid', gridTemplateColumns: 'repeat(4, 1fr)', gap: '6px' }}>
                    {[0, 1, 2, 3].slice(0, mode === 'image' ? 4 : 3).map(i => (
                      <div
                        key={i}
                        onClick={() => {
                          if (referenceImages[i]) {
                            setReferenceImages(prev => prev.filter((_, idx) => idx !== i));
                          } else if (referenceImages.length < (mode === 'image' ? 4 : 3)) {
                            setReferenceImages(prev => [...prev, `ref-${i}.jpg`]);
                          }
                        }}
                        style={{
                          aspectRatio: '1',
                          borderRadius: '6px',
                          border: `2px dashed ${referenceImages[i] ? colors.accent.primary : colors.border.default}`,
                          background: referenceImages[i] ? `${colors.accent.primary}20` : colors.bg.tertiary,
                          display: 'flex',
                          alignItems: 'center',
                          justifyContent: 'center',
                          cursor: 'pointer',
                        }}
                      >
                        {referenceImages[i] ? (
                          <Icons.Check style={{ width: 14, height: 14, color: colors.accent.primary }} />
                        ) : (
                          <Icons.Plus style={{ width: 12, height: 12, color: colors.text.tertiary }} />
                        )}
                      </div>
                    ))}
                  </div>
                </div>
              </>
            )}
            
            {/* Generator Info */}
            {currentGenerator && (
              <div style={{
                padding: '12px',
                background: colors.bg.tertiary,
                borderRadius: '8px',
                marginTop: '12px',
              }}>
                <div style={{ fontSize: '11px', color: colors.text.tertiary, marginBottom: '6px' }}>
                  {currentGenerator.name}
                </div>
                <div style={{ display: 'flex', flexWrap: 'wrap', gap: '4px' }}>
                  {currentGenerator.features.map((feature) => (
                    <span
                      key={feature}
                      style={{
                        padding: '3px 6px',
                        background: colors.bg.secondary,
                        borderRadius: '4px',
                        fontSize: '10px',
                        color: colors.text.secondary,
                      }}
                    >
                      {feature}
                    </span>
                  ))}
                </div>
                {currentGenerator.apiId && (
                  <div style={{ fontSize: '9px', color: colors.text.tertiary, marginTop: '8px', fontFamily: 'monospace' }}>
                    {currentGenerator.apiId}
                  </div>
                )}
              </div>
            )}
          </div>
          </div>
        </div>
      </div>
      
      {/* Prompt Editor Modal */}
      {showPromptEditor && (
        <div style={{
          position: 'fixed',
          top: 0,
          left: 0,
          right: 0,
          bottom: 0,
          background: 'rgba(0,0,0,0.7)',
          display: 'flex',
          alignItems: 'center',
          justifyContent: 'center',
          zIndex: 1000,
        }}
        onClick={() => setShowPromptEditor(false)}
        >
          <div 
            style={{
              width: '700px',
              maxHeight: '80vh',
              background: colors.bg.primary,
              borderRadius: '16px',
              overflow: 'hidden',
              boxShadow: '0 20px 60px rgba(0,0,0,0.5)',
              display: 'flex',
              flexDirection: 'column',
            }}
            onClick={(e) => e.stopPropagation()}
          >
            {/* Modal Header */}
            <div style={{
              padding: '20px 24px',
              borderBottom: `1px solid ${colors.border.subtle}`,
              display: 'flex',
              justifyContent: 'space-between',
              alignItems: 'center',
              background: colors.bg.secondary,
            }}>
              <div>
                <h2 style={{ fontSize: '18px', fontWeight: '600', margin: 0, marginBottom: '4px' }}>
                  {mode === 'image' ? 'Image Prompt' : 'Video Prompt'}
                </h2>
                <p style={{ fontSize: '13px', color: colors.text.tertiary, margin: 0 }}>
                  Describe what you want to generate in detail
                </p>
              </div>
              <button
                onClick={() => setShowPromptEditor(false)}
                style={{
                  width: '32px',
                  height: '32px',
                  borderRadius: '8px',
                  background: colors.bg.tertiary,
                  border: 'none',
                  color: colors.text.secondary,
                  cursor: 'pointer',
                  display: 'flex',
                  alignItems: 'center',
                  justifyContent: 'center',
                }}
              >
                <Icons.X style={{ width: 18, height: 18 }} />
              </button>
            </div>
            
            {/* Prompt Textarea */}
            <div style={{ padding: '24px', flex: 1 }}>
              <textarea
                value={tempPrompt}
                onChange={(e) => setTempPrompt(e.target.value)}
                placeholder={mode === 'image' 
                  ? "Describe the image you want to create...\n\nExample: A young woman with long dark hair standing in a sunlit forest, golden hour lighting, cinematic composition, wearing a flowing white dress, surrounded by fireflies, magical atmosphere, 8K quality, photorealistic"
                  : "Describe the video scene you want to generate...\n\nExample: A slow tracking shot through a neon-lit cyberpunk alley, rain falling, steam rising from vents, a hooded figure walking away from camera, moody atmosphere, cinematic lighting"}
                autoFocus
                style={{
                  width: '100%',
                  minHeight: '250px',
                  padding: '16px',
                  background: colors.bg.tertiary,
                  border: `1px solid ${colors.border.default}`,
                  borderRadius: '12px',
                  color: colors.text.primary,
                  fontSize: '15px',
                  lineHeight: '1.6',
                  resize: 'vertical',
                  outline: 'none',
                  fontFamily: 'inherit',
                }}
              />
              
              {/* Character Count */}
              <div style={{
                display: 'flex',
                justifyContent: 'space-between',
                alignItems: 'center',
                marginTop: '12px',
              }}>
                <span style={{ fontSize: '12px', color: colors.text.tertiary }}>
                  {tempPrompt.length} characters
                </span>
                <div style={{ display: 'flex', gap: '8px' }}>
                  <button
                    onClick={() => setTempPrompt('')}
                    style={{
                      padding: '6px 12px',
                      background: 'transparent',
                      border: `1px solid ${colors.border.default}`,
                      borderRadius: '6px',
                      color: colors.text.secondary,
                      fontSize: '12px',
                      cursor: 'pointer',
                    }}
                  >
                    Clear
                  </button>
                </div>
              </div>
              
              {/* Prompt Tips */}
              <div style={{
                marginTop: '20px',
                padding: '16px',
                background: `${colors.accent.primary}10`,
                borderRadius: '10px',
                border: `1px solid ${colors.accent.primary}20`,
              }}>
                <div style={{ 
                  fontSize: '13px', 
                  fontWeight: '600', 
                  color: colors.accent.primary,
                  marginBottom: '10px',
                  display: 'flex',
                  alignItems: 'center',
                  gap: '6px',
                }}>
                  <Icons.Sparkles style={{ width: 14, height: 14 }} />
                  Prompt Tips
                </div>
                <ul style={{ 
                  margin: 0, 
                  paddingLeft: '20px', 
                  fontSize: '12px', 
                  color: colors.text.secondary,
                  lineHeight: '1.8',
                }}>
                  <li>Be specific about subject, action, setting, and mood</li>
                  <li>Include lighting details (golden hour, dramatic shadows, soft light)</li>
                  <li>Specify camera angle and composition (close-up, wide shot, rule of thirds)</li>
                  <li>Add style references (cinematic, photorealistic, anime, oil painting)</li>
                  <li>Use quality keywords (8K, highly detailed, professional photography)</li>
                </ul>
              </div>
              
              {/* Quick Add Elements Button */}
              <button
                onClick={() => {
                  setShowPromptEditor(false);
                  setPrompt(tempPrompt);
                  setTimeout(() => setShowElementsPicker(true), 100);
                }}
                style={{
                  width: '100%',
                  marginTop: '16px',
                  padding: '12px',
                  background: colors.bg.secondary,
                  border: `1px dashed ${colors.border.default}`,
                  borderRadius: '10px',
                  color: colors.text.secondary,
                  fontSize: '13px',
                  cursor: 'pointer',
                  display: 'flex',
                  alignItems: 'center',
                  justifyContent: 'center',
                  gap: '8px',
                }}
              >
                <Icons.Users style={{ width: 16, height: 16 }} />
                Add Element to Prompt
              </button>
            </div>
            
            {/* Modal Footer */}
            <div style={{
              padding: '16px 24px',
              borderTop: `1px solid ${colors.border.subtle}`,
              background: colors.bg.secondary,
              display: 'flex',
              justifyContent: 'flex-end',
              gap: '12px',
            }}>
              <button
                onClick={() => setShowPromptEditor(false)}
                style={{
                  padding: '10px 20px',
                  background: colors.bg.tertiary,
                  border: `1px solid ${colors.border.default}`,
                  borderRadius: '8px',
                  color: colors.text.secondary,
                  fontSize: '14px',
                  cursor: 'pointer',
                }}
              >
                Cancel
              </button>
              <button
                onClick={() => {
                  setPrompt(tempPrompt);
                  setShowPromptEditor(false);
                }}
                style={{
                  padding: '10px 24px',
                  background: colors.accent.primary,
                  border: 'none',
                  borderRadius: '8px',
                  color: 'white',
                  fontSize: '14px',
                  fontWeight: '600',
                  cursor: 'pointer',
                  display: 'flex',
                  alignItems: 'center',
                  gap: '8px',
                }}
              >
                <Icons.Check style={{ width: 16, height: 16 }} />
                Apply Prompt
              </button>
            </div>
          </div>
        </div>
      )}
      
      {/* Elements Picker Modal */}
      {showElementsPicker && (
        <div style={{
          position: 'fixed',
          top: 0,
          left: 0,
          right: 0,
          bottom: 0,
          background: 'rgba(0,0,0,0.7)',
          display: 'flex',
          alignItems: 'center',
          justifyContent: 'center',
          zIndex: 1000,
        }}
        onClick={handleCloseElementPicker}
        >
          <div 
            style={{
              width: '600px',
              maxHeight: '80vh',
              background: colors.bg.primary,
              borderRadius: '16px',
              overflow: 'hidden',
              boxShadow: '0 20px 60px rgba(0,0,0,0.5)',
            }}
            onClick={(e) => e.stopPropagation()}
          >
            {/* Modal Header */}
            <div style={{
              padding: '20px 24px',
              borderBottom: `1px solid ${colors.border.subtle}`,
              display: 'flex',
              justifyContent: 'space-between',
              alignItems: 'center',
              background: colors.bg.secondary,
            }}>
              <div style={{ display: 'flex', alignItems: 'center', gap: '12px' }}>
                {elementPickerCategory && (
                  <button
                    onClick={() => {
                      setElementPickerCategory(null);
                      setElementSearchQuery('');
                    }}
                    style={{
                      padding: '6px 10px',
                      background: colors.bg.tertiary,
                      border: 'none',
                      borderRadius: '6px',
                      color: colors.text.secondary,
                      cursor: 'pointer',
                      display: 'flex',
                      alignItems: 'center',
                      gap: '4px',
                      fontSize: '13px',
                    }}
                  >
                    <Icons.ChevronLeft style={{ width: 14, height: 14 }} />
                    Back
                  </button>
                )}
                <h2 style={{ fontSize: '18px', fontWeight: '600', margin: 0 }}>
                  {elementPickerCategory 
                    ? elementCategories.find(c => c.id === elementPickerCategory)?.label || 'Elements'
                    : 'Select Element'}
                </h2>
              </div>
              <button
                onClick={handleCloseElementPicker}
                style={{
                  width: '32px',
                  height: '32px',
                  borderRadius: '8px',
                  background: colors.bg.tertiary,
                  border: 'none',
                  color: colors.text.secondary,
                  cursor: 'pointer',
                  display: 'flex',
                  alignItems: 'center',
                  justifyContent: 'center',
                }}
              >
                <Icons.X style={{ width: 18, height: 18 }} />
              </button>
            </div>
            
            {/* Search Bar */}
            <div style={{
              padding: '16px 24px',
              borderBottom: `1px solid ${colors.border.subtle}`,
            }}>
              <div style={{
                position: 'relative',
              }}>
                <Icons.Search style={{
                  position: 'absolute',
                  left: '14px',
                  top: '50%',
                  transform: 'translateY(-50%)',
                  width: 18,
                  height: 18,
                  color: colors.text.tertiary,
                }} />
                <input
                  type="text"
                  placeholder="Search elements..."
                  value={elementSearchQuery}
                  onChange={(e) => setElementSearchQuery(e.target.value)}
                  style={{
                    width: '100%',
                    padding: '12px 14px 12px 44px',
                    background: colors.bg.tertiary,
                    border: `1px solid ${colors.border.default}`,
                    borderRadius: '10px',
                    color: colors.text.primary,
                    fontSize: '14px',
                    outline: 'none',
                  }}
                />
                {elementSearchQuery && (
                  <button
                    onClick={() => setElementSearchQuery('')}
                    style={{
                      position: 'absolute',
                      right: '12px',
                      top: '50%',
                      transform: 'translateY(-50%)',
                      background: 'none',
                      border: 'none',
                      color: colors.text.tertiary,
                      cursor: 'pointer',
                      fontSize: '18px',
                    }}
                  >
                    ×
                  </button>
                )}
              </div>
            </div>
            
            {/* Modal Content */}
            <div style={{
              maxHeight: '50vh',
              overflow: 'auto',
              padding: '16px 24px',
            }}>
              {/* Show search results if searching */}
              {elementSearchQuery ? (
                <div>
                  <div style={{ fontSize: '12px', color: colors.text.tertiary, marginBottom: '12px' }}>
                    {getFilteredElements().length} results for "{elementSearchQuery}"
                  </div>
                  <div style={{ display: 'flex', flexDirection: 'column', gap: '8px' }}>
                    {getFilteredElements().map((el) => (
                      <button
                        key={el.id}
                        onClick={() => handleSelectElement(el)}
                        style={{
                          padding: '14px 16px',
                          background: colors.bg.secondary,
                          border: `1px solid ${colors.border.subtle}`,
                          borderRadius: '10px',
                          cursor: 'pointer',
                          display: 'flex',
                          alignItems: 'flex-start',
                          gap: '14px',
                          textAlign: 'left',
                          transition: 'all 0.15s ease',
                        }}
                        onMouseEnter={(e) => {
                          e.currentTarget.style.borderColor = colors.accent.primary;
                          e.currentTarget.style.background = `${colors.accent.primary}10`;
                        }}
                        onMouseLeave={(e) => {
                          e.currentTarget.style.borderColor = colors.border.subtle;
                          e.currentTarget.style.background = colors.bg.secondary;
                        }}
                      >
                        <span style={{ fontSize: '28px' }}>{el.emoji}</span>
                        <div style={{ flex: 1 }}>
                          <div style={{ fontSize: '14px', fontWeight: '600', color: colors.text.primary, marginBottom: '4px' }}>
                            {el.name}
                          </div>
                          <div style={{ fontSize: '11px', color: colors.text.tertiary, textTransform: 'capitalize', marginBottom: '6px' }}>
                            {el.type}
                          </div>
                          <div style={{ fontSize: '12px', color: colors.text.secondary, lineHeight: '1.4' }}>
                            {el.prompt?.slice(0, 80)}...
                          </div>
                        </div>
                        <span style={{ 
                          padding: '4px 8px', 
                          background: colors.accent.primary, 
                          borderRadius: '4px',
                          fontSize: '11px',
                          fontWeight: '600',
                          color: 'white',
                        }}>
                          Use
                        </span>
                      </button>
                    ))}
                  </div>
                </div>
              ) : !elementPickerCategory ? (
                /* Category Grid */
                <div style={{
                  display: 'grid',
                  gridTemplateColumns: 'repeat(2, 1fr)',
                  gap: '12px',
                }}>
                  {elementCategories.map((cat) => {
                    const count = getCategoryCount(cat.id);
                    return (
                      <button
                        key={cat.id}
                        onClick={() => count > 0 && setElementPickerCategory(cat.id)}
                        disabled={count === 0}
                        style={{
                          padding: '20px',
                          background: colors.bg.secondary,
                          border: `1px solid ${colors.border.subtle}`,
                          borderRadius: '12px',
                          cursor: count > 0 ? 'pointer' : 'not-allowed',
                          opacity: count === 0 ? 0.5 : 1,
                          textAlign: 'left',
                          transition: 'all 0.15s ease',
                        }}
                        onMouseEnter={(e) => {
                          if (count > 0) {
                            e.currentTarget.style.borderColor = cat.color;
                            e.currentTarget.style.background = `${cat.color}10`;
                          }
                        }}
                        onMouseLeave={(e) => {
                          e.currentTarget.style.borderColor = colors.border.subtle;
                          e.currentTarget.style.background = colors.bg.secondary;
                        }}
                      >
                        <div style={{ display: 'flex', alignItems: 'center', gap: '12px', marginBottom: '8px' }}>
                          <span style={{ 
                            fontSize: '28px',
                            width: '48px',
                            height: '48px',
                            background: `${cat.color}20`,
                            borderRadius: '12px',
                            display: 'flex',
                            alignItems: 'center',
                            justifyContent: 'center',
                          }}>
                            {cat.icon}
                          </span>
                          <div>
                            <div style={{ fontSize: '15px', fontWeight: '600', color: colors.text.primary }}>
                              {cat.label}
                            </div>
                            <div style={{ fontSize: '12px', color: colors.text.tertiary }}>
                              {count} element{count !== 1 ? 's' : ''}
                            </div>
                          </div>
                        </div>
                        <div style={{ fontSize: '12px', color: colors.text.secondary }}>
                          {cat.desc}
                        </div>
                      </button>
                    );
                  })}
                </div>
              ) : (
                /* Elements List for Selected Category */
                <div style={{ display: 'flex', flexDirection: 'column', gap: '8px' }}>
                  {getFilteredElements().length === 0 ? (
                    <div style={{ textAlign: 'center', padding: '40px', color: colors.text.tertiary }}>
                      No elements in this category
                    </div>
                  ) : (
                    getFilteredElements().map((el) => (
                      <button
                        key={el.id}
                        onClick={() => handleSelectElement(el)}
                        style={{
                          padding: '14px 16px',
                          background: colors.bg.secondary,
                          border: `1px solid ${colors.border.subtle}`,
                          borderRadius: '10px',
                          cursor: 'pointer',
                          display: 'flex',
                          alignItems: 'flex-start',
                          gap: '14px',
                          textAlign: 'left',
                          transition: 'all 0.15s ease',
                        }}
                        onMouseEnter={(e) => {
                          e.currentTarget.style.borderColor = colors.accent.primary;
                          e.currentTarget.style.background = `${colors.accent.primary}10`;
                        }}
                        onMouseLeave={(e) => {
                          e.currentTarget.style.borderColor = colors.border.subtle;
                          e.currentTarget.style.background = colors.bg.secondary;
                        }}
                      >
                        <span style={{ fontSize: '28px' }}>{el.emoji}</span>
                        <div style={{ flex: 1 }}>
                          <div style={{ fontSize: '14px', fontWeight: '600', color: colors.text.primary, marginBottom: '4px' }}>
                            {el.name}
                          </div>
                          <div style={{ fontSize: '12px', color: colors.text.secondary, lineHeight: '1.4' }}>
                            {el.prompt?.slice(0, 100)}...
                          </div>
                        </div>
                        <span style={{ 
                          padding: '4px 8px', 
                          background: colors.accent.primary, 
                          borderRadius: '4px',
                          fontSize: '11px',
                          fontWeight: '600',
                          color: 'white',
                        }}>
                          Use
                        </span>
                      </button>
                    ))
                  )}
                </div>
              )}
            </div>
            
            {/* Modal Footer */}
            <div style={{
              padding: '16px 24px',
              borderTop: `1px solid ${colors.border.subtle}`,
              background: colors.bg.secondary,
              display: 'flex',
              justifyContent: 'space-between',
              alignItems: 'center',
            }}>
              <span style={{ fontSize: '12px', color: colors.text.tertiary }}>
                {availableElements.length} total elements
              </span>
              <button
                onClick={handleCloseElementPicker}
                style={{
                  padding: '8px 16px',
                  background: colors.bg.tertiary,
                  border: `1px solid ${colors.border.default}`,
                  borderRadius: '6px',
                  color: colors.text.secondary,
                  fontSize: '13px',
                  cursor: 'pointer',
                }}
              >
                Cancel
              </button>
            </div>
          </div>
        </div>
      )}
      
      {/* Save to Assets Toast */}
      {showSaveToast && (
        <div style={{
          position: 'fixed',
          bottom: '100px',
          left: '50%',
          transform: 'translateX(-50%)',
          padding: '12px 24px',
          background: colors.accent.success,
          borderRadius: '8px',
          boxShadow: '0 4px 20px rgba(0,0,0,0.3)',
          display: 'flex',
          alignItems: 'center',
          gap: '10px',
          zIndex: 1000,
          animation: 'slideUp 0.3s ease',
        }}>
          <Icons.Check style={{ width: 18, height: 18, color: 'white' }} />
          <span style={{ color: 'white', fontWeight: '500', fontSize: '14px' }}>
            Saved to My Assets
          </span>
        </div>
      )}
      
      {/* Generation History Panel (Floating) */}
      {generatedItems.length > 0 && assets.length > 0 && (
        <div style={{
          position: 'fixed',
          bottom: '100px',
          right: '24px',
          zIndex: 50,
        }}>
          <button
            onClick={() => setShowHistory(!showHistory)}
            style={{
              padding: '12px 16px',
              background: colors.bg.secondary,
              border: `1px solid ${colors.border.default}`,
              borderRadius: '10px',
              boxShadow: '0 4px 20px rgba(0,0,0,0.2)',
              cursor: 'pointer',
              display: 'flex',
              alignItems: 'center',
              gap: '8px',
              color: colors.text.primary,
              fontSize: '13px',
              fontWeight: '500',
            }}
          >
            <Icons.Clock style={{ width: 16, height: 16 }} />
            History ({assets.length})
            <Icons.ChevronUp style={{ 
              width: 14, 
              height: 14,
              transform: showHistory ? 'rotate(180deg)' : 'none',
              transition: 'transform 0.2s ease',
            }} />
          </button>
          
          {showHistory && (
            <div style={{
              position: 'absolute',
              bottom: '52px',
              right: '0',
              width: '300px',
              maxHeight: '400px',
              background: colors.bg.secondary,
              border: `1px solid ${colors.border.default}`,
              borderRadius: '12px',
              boxShadow: '0 8px 32px rgba(0,0,0,0.3)',
              overflow: 'hidden',
            }}>
              <div style={{
                padding: '12px 16px',
                borderBottom: `1px solid ${colors.border.subtle}`,
                display: 'flex',
                justifyContent: 'space-between',
                alignItems: 'center',
              }}>
                <span style={{ fontSize: '13px', fontWeight: '600' }}>Recent Generations</span>
                <span style={{ fontSize: '11px', color: colors.text.tertiary }}>{assets.length} total</span>
              </div>
              <div style={{ maxHeight: '340px', overflow: 'auto' }}>
                {assets.slice(0, 10).map((asset) => (
                  <div
                    key={asset.id}
                    style={{
                      padding: '10px 16px',
                      borderBottom: `1px solid ${colors.border.subtle}`,
                      display: 'flex',
                      alignItems: 'center',
                      gap: '12px',
                      cursor: 'pointer',
                    }}
                    onMouseEnter={(e) => e.currentTarget.style.background = colors.bg.tertiary}
                    onMouseLeave={(e) => e.currentTarget.style.background = 'transparent'}
                  >
                    <div style={{
                      width: '40px',
                      height: '40px',
                      borderRadius: '6px',
                      background: asset.thumbnail || `linear-gradient(135deg, ${colors.accent.primary}40, ${colors.accent.secondary}40)`,
                      display: 'flex',
                      alignItems: 'center',
                      justifyContent: 'center',
                      flexShrink: 0,
                    }}>
                      {asset.type === 'video' ? 
                        <Icons.Film style={{ width: 16, height: 16, color: 'white' }} /> : 
                        <Icons.Image style={{ width: 16, height: 16, color: 'white' }} />
                      }
                    </div>
                    <div style={{ flex: 1, minWidth: 0 }}>
                      <div style={{ 
                        fontSize: '12px', 
                        fontWeight: '500', 
                        color: colors.text.primary,
                        whiteSpace: 'nowrap',
                        overflow: 'hidden',
                        textOverflow: 'ellipsis',
                      }}>
                        {asset.prompt?.slice(0, 30) || 'Untitled'}...
                      </div>
                      <div style={{ fontSize: '10px', color: colors.text.tertiary }}>
                        {asset.generatorName} · {asset.type}
                      </div>
                    </div>
                  </div>
                ))}
              </div>
            </div>
          )}
        </div>
      )}
      
      <style>{`
        @keyframes slideUp {
          from { transform: translateX(-50%) translateY(20px); opacity: 0; }
          to { transform: translateX(-50%) translateY(0); opacity: 1; }
        }
      `}</style>
    </div>
  );
};


// ============================================================================
// PROMO STUDIO VIEW - Unified Promo Content Creation
// ============================================================================
const PromoStudioView = ({ setCurrentView }) => {
  const [selectedCategory, setSelectedCategory] = useState(null);
  
  const promoCategories = [
    {
      id: 'intros',
      title: 'Intros & Outros',
      description: 'Professional intro and outro sequences with your logo and branding',
      icon: '🎬',
      gradient: 'linear-gradient(135deg, #667eea 0%, #764ba2 100%)',
      templates: 12,
      features: ['Logo Animation', 'Custom Music', 'Brand Colors', 'Multiple Styles'],
    },
    {
      id: 'trailers',
      title: 'Trailers',
      description: 'AI-powered trailer generation that analyzes your episodes for key moments',
      icon: '🎞️',
      gradient: 'linear-gradient(135deg, #f093fb 0%, #f5576c 100%)',
      templates: 8,
      features: ['Auto Scene Selection', 'Music Sync', 'Text Overlays', 'Voice Over'],
    },
    {
      id: 'social',
      title: 'Social Clips',
      description: 'Platform-optimized clips for TikTok, Instagram, YouTube Shorts and more',
      icon: '📱',
      gradient: 'linear-gradient(135deg, #4facfe 0%, #00f2fe 100%)',
      templates: 24,
      features: ['Platform Presets', 'Auto Captions', 'Trending Formats', 'Quick Export'],
    },
    {
      id: 'character',
      title: 'Character Promos',
      description: 'Promotional content featuring your characters with custom scripts and tones',
      icon: '👤',
      gradient: 'linear-gradient(135deg, #fa709a 0%, #fee140 100%)',
      templates: 16,
      features: ['Interview Style', '4th Wall Break', 'Blooper Reel', 'Behind the Scenes'],
    },
  ];
  
  const recentPromos = [
    { id: 1, type: 'intro', name: 'Episode 1 Intro', date: '2 hours ago', thumbnail: 'linear-gradient(135deg, #667eea, #764ba2)' },
    { id: 2, type: 'trailer', name: 'Season 1 Trailer', date: '1 day ago', thumbnail: 'linear-gradient(135deg, #f093fb, #f5576c)' },
    { id: 3, type: 'social', name: 'TikTok Clip #3', date: '3 days ago', thumbnail: 'linear-gradient(135deg, #4facfe, #00f2fe)' },
  ];
  
  return (
    <div style={{ flex: 1, overflow: 'auto', padding: '32px 40px' }}>
      {/* Header */}
      <div style={{ marginBottom: '40px' }}>
        <h1 style={{ fontSize: '28px', fontWeight: '700', marginBottom: '8px' }}>Promo Studio</h1>
        <p style={{ fontSize: '14px', color: colors.text.secondary }}>
          Create promotional content for your series — intros, trailers, social clips, and more
        </p>
      </div>
      
      {/* Category Cards */}
      <div style={{ marginBottom: '48px' }}>
        <h2 style={{ fontSize: '18px', fontWeight: '600', marginBottom: '20px' }}>Create New</h2>
        <div style={{ 
          display: 'grid', 
          gridTemplateColumns: 'repeat(auto-fit, minmax(280px, 1fr))', 
          gap: '20px' 
        }}>
          {promoCategories.map((category) => (
            <div
              key={category.id}
              onClick={() => setSelectedCategory(category.id)}
              style={{
                background: colors.bg.secondary,
                border: `1px solid ${selectedCategory === category.id ? colors.accent.primary : colors.border.subtle}`,
                borderRadius: '16px',
                overflow: 'hidden',
                cursor: 'pointer',
                transition: 'all 0.3s ease',
              }}
              onMouseEnter={(e) => {
                e.currentTarget.style.transform = 'translateY(-4px)';
                e.currentTarget.style.boxShadow = '0 12px 40px rgba(0,0,0,0.3)';
              }}
              onMouseLeave={(e) => {
                e.currentTarget.style.transform = 'translateY(0)';
                e.currentTarget.style.boxShadow = 'none';
              }}
            >
              {/* Card Header with Gradient */}
              <div style={{
                height: '120px',
                background: category.gradient,
                display: 'flex',
                alignItems: 'center',
                justifyContent: 'center',
                position: 'relative',
              }}>
                <span style={{ fontSize: '48px' }}>{category.icon}</span>
                <div style={{
                  position: 'absolute',
                  top: '12px',
                  right: '12px',
                  padding: '4px 10px',
                  background: 'rgba(0,0,0,0.3)',
                  borderRadius: '100px',
                  fontSize: '11px',
                  color: 'white',
                  fontWeight: '500',
                }}>
                  {category.templates} templates
                </div>
              </div>
              
              {/* Card Content */}
              <div style={{ padding: '20px' }}>
                <h3 style={{ fontSize: '18px', fontWeight: '600', marginBottom: '8px' }}>
                  {category.title}
                </h3>
                <p style={{ 
                  fontSize: '13px', 
                  color: colors.text.secondary, 
                  lineHeight: '1.5',
                  marginBottom: '16px',
                }}>
                  {category.description}
                </p>
                
                {/* Features */}
                <div style={{ display: 'flex', flexWrap: 'wrap', gap: '6px' }}>
                  {category.features.map((feature) => (
                    <span
                      key={feature}
                      style={{
                        padding: '4px 10px',
                        background: colors.bg.tertiary,
                        borderRadius: '100px',
                        fontSize: '11px',
                        color: colors.text.tertiary,
                      }}
                    >
                      {feature}
                    </span>
                  ))}
                </div>
              </div>
              
              {/* Card Footer */}
              <div style={{
                padding: '16px 20px',
                borderTop: `1px solid ${colors.border.subtle}`,
                display: 'flex',
                justifyContent: 'space-between',
                alignItems: 'center',
              }}>
                <span style={{ fontSize: '13px', color: colors.text.tertiary }}>
                  Click to start
                </span>
                <div style={{
                  width: '32px',
                  height: '32px',
                  borderRadius: '50%',
                  background: colors.bg.tertiary,
                  display: 'flex',
                  alignItems: 'center',
                  justifyContent: 'center',
                }}>
                  <Icons.ChevronRight style={{ width: 16, height: 16, color: colors.text.secondary }} />
                </div>
              </div>
            </div>
          ))}
        </div>
      </div>
      
      {/* Recent Promos */}
      <div>
        <div style={{ 
          display: 'flex', 
          justifyContent: 'space-between', 
          alignItems: 'center',
          marginBottom: '20px',
        }}>
          <h2 style={{ fontSize: '18px', fontWeight: '600' }}>Recent Promos</h2>
          <button style={{
            padding: '8px 16px',
            background: 'transparent',
            border: `1px solid ${colors.border.default}`,
            borderRadius: '8px',
            color: colors.text.secondary,
            fontSize: '13px',
            cursor: 'pointer',
          }}>
            View All
          </button>
        </div>
        
        {recentPromos.length > 0 ? (
          <div style={{ 
            display: 'grid', 
            gridTemplateColumns: 'repeat(auto-fill, minmax(240px, 1fr))', 
            gap: '16px' 
          }}>
            {recentPromos.map((promo) => (
              <div
                key={promo.id}
                style={{
                  background: colors.bg.secondary,
                  border: `1px solid ${colors.border.subtle}`,
                  borderRadius: '12px',
                  overflow: 'hidden',
                  cursor: 'pointer',
                  transition: 'all 0.2s ease',
                }}
                onMouseEnter={(e) => {
                  e.currentTarget.style.borderColor = colors.accent.primary;
                }}
                onMouseLeave={(e) => {
                  e.currentTarget.style.borderColor = colors.border.subtle;
                }}
              >
                <div style={{
                  height: '100px',
                  background: promo.thumbnail,
                  display: 'flex',
                  alignItems: 'center',
                  justifyContent: 'center',
                }}>
                  <div style={{
                    width: '40px',
                    height: '40px',
                    borderRadius: '50%',
                    background: 'rgba(0,0,0,0.4)',
                    display: 'flex',
                    alignItems: 'center',
                    justifyContent: 'center',
                  }}>
                    <Icons.Play style={{ width: 16, height: 16, color: 'white' }} />
                  </div>
                </div>
                <div style={{ padding: '14px' }}>
                  <div style={{ fontSize: '14px', fontWeight: '500', marginBottom: '4px' }}>
                    {promo.name}
                  </div>
                  <div style={{ fontSize: '12px', color: colors.text.tertiary }}>
                    {promo.date}
                  </div>
                </div>
              </div>
            ))}
          </div>
        ) : (
          <div style={{
            textAlign: 'center',
            padding: '60px 40px',
            background: colors.bg.secondary,
            borderRadius: '12px',
            border: `1px solid ${colors.border.subtle}`,
          }}>
            <Icons.Film style={{ width: 48, height: 48, color: colors.text.tertiary, marginBottom: '16px' }} />
            <h3 style={{ fontSize: '16px', fontWeight: '500', marginBottom: '8px', color: colors.text.secondary }}>
              No promos yet
            </h3>
            <p style={{ fontSize: '14px', color: colors.text.tertiary }}>
              Create your first promo by selecting a category above
            </p>
          </div>
        )}
      </div>
      
      {/* Quick Tips */}
      <div style={{
        marginTop: '48px',
        padding: '24px',
        background: `linear-gradient(135deg, ${colors.bg.secondary}, ${colors.bg.tertiary})`,
        borderRadius: '12px',
        border: `1px solid ${colors.border.subtle}`,
      }}>
        <h3 style={{ fontSize: '14px', fontWeight: '600', marginBottom: '16px', display: 'flex', alignItems: 'center', gap: '8px' }}>
          <Icons.Sparkles style={{ width: 16, height: 16, color: colors.accent.primary }} />
          Quick Tips
        </h3>
        <div style={{ display: 'grid', gridTemplateColumns: 'repeat(auto-fit, minmax(200px, 1fr))', gap: '16px' }}>
          {[
            { tip: 'Use consistent branding across all your promos for recognition' },
            { tip: 'Social clips perform best when under 60 seconds' },
            { tip: 'Character promos build audience connection before the show' },
          ].map((item, i) => (
            <div key={i} style={{ display: 'flex', gap: '12px', alignItems: 'flex-start' }}>
              <div style={{
                width: '20px',
                height: '20px',
                borderRadius: '50%',
                background: colors.bg.tertiary,
                display: 'flex',
                alignItems: 'center',
                justifyContent: 'center',
                fontSize: '11px',
                color: colors.text.tertiary,
                flexShrink: 0,
              }}>
                {i + 1}
              </div>
              <p style={{ fontSize: '13px', color: colors.text.secondary, lineHeight: '1.5' }}>
                {item.tip}
              </p>
            </div>
          ))}
        </div>
      </div>
    </div>
  );
};

// ELEMENTS MANAGEMENT VIEW
// ============================================================================
const ElementsView = ({ onNavigateToGenSpace }) => {
  // View state
  const [currentView, setCurrentView] = useState('dashboard'); // 'dashboard', 'group', 'profile'
  const [selectedGroup, setSelectedGroup] = useState(null);
  const [selectedElement, setSelectedElement] = useState(null);
  const [searchQuery, setSearchQuery] = useState('');
  const [sortBy, setSortBy] = useState('recent');
  const [showCreateModal, setShowCreateModal] = useState(false);
  const [showEditModal, setShowEditModal] = useState(false);
  const [showNewGroupModal, setShowNewGroupModal] = useState(false);
  const [showDeleteConfirm, setShowDeleteConfirm] = useState(false);
  const [isAnalyzing, setIsAnalyzing] = useState(false);
  const [showBulkImportModal, setShowBulkImportModal] = useState(false);
  const [bulkImportFiles, setBulkImportFiles] = useState([]);
  const [bulkImportGroup, setBulkImportGroup] = useState('characters');
  
  // Consistent Image Generator state
  const [showConsistentImageModal, setShowConsistentImageModal] = useState(false);
  const [consistentImageGenerator, setConsistentImageGenerator] = useState('midjourney');
  const [consistentImageElement, setConsistentImageElement] = useState(null);
  const [consistentImages, setConsistentImages] = useState({
    masterTurnaround: { image: null, status: 'pending', prompt: '' },
    frontFull: { image: null, status: 'pending', prompt: '' },
    backFull: { image: null, status: 'pending', prompt: '' },
    leftFull: { image: null, status: 'pending', prompt: '' },
    rightFull: { image: null, status: 'pending', prompt: '' },
    frontHead: { image: null, status: 'pending', prompt: '' },
    backHead: { image: null, status: 'pending', prompt: '' },
    leftHead: { image: null, status: 'pending', prompt: '' },
    rightHead: { image: null, status: 'pending', prompt: '' },
  });
  const [showPromptEditModal, setShowPromptEditModal] = useState(false);
  const [editingPromptType, setEditingPromptType] = useState(null);
  const [tempEditPrompt, setTempEditPrompt] = useState('');
  const [isGenerating, setIsGenerating] = useState(null); // which slot is currently generating
  
  // New element form state
  const [newElement, setNewElement] = useState({
    name: '',
    group: 'characters',
    subgroup: '',
    prompt: '',
    referenceImage: null,
    tags: [],
  });
  
  // Edit element form state
  const [editElement, setEditElement] = useState({
    id: '',
    name: '',
    group: 'characters',
    subgroup: '',
    prompt: '',
    referenceImage: null,
    tags: [],
  });
  
  // New group form
  const [newGroup, setNewGroup] = useState({ name: '', icon: '📁' });
  
  // Elements data store
  const [elements, setElements] = useState([
    // Characters
    { id: 'chr-1', group: 'characters', name: 'Christian Ramirez', prompt: 'Latino male, early 20s, athletic build, short black hair, brown eyes, clean-shaven, confident expression', referenceImage: null, generatedImages: ['linear-gradient(135deg, #667eea 0%, #764ba2 100%)'], tags: ['protagonist', 'main-cast'], lastUsed: new Date('2024-01-15'), usedInVideos: ['vid-1', 'vid-2'], createdAt: new Date('2024-01-01') },
    { id: 'chr-2', group: 'characters', name: 'Maria Gonzalez', prompt: 'Latina female, early 20s, slim build, long dark wavy hair, warm brown eyes, gentle smile', referenceImage: null, generatedImages: ['linear-gradient(135deg, #f093fb 0%, #f5576c 100%)'], tags: ['love-interest', 'main-cast'], lastUsed: new Date('2024-01-14'), usedInVideos: ['vid-1'], createdAt: new Date('2024-01-01') },
    { id: 'chr-3', group: 'characters', name: 'Detective Santos', prompt: 'Latino male, mid 40s, stocky build, graying temples, weathered face, stern expression, slight stubble', referenceImage: null, generatedImages: ['linear-gradient(135deg, #4facfe 0%, #00f2fe 100%)'], tags: ['antagonist'], lastUsed: new Date('2024-01-10'), usedInVideos: ['vid-2'], createdAt: new Date('2024-01-02') },
    { id: 'chr-4', group: 'characters', name: 'Abuela Rosa', prompt: 'Latina elderly female, late 70s, petite, silver hair in bun, kind wrinkled face, warm eyes', referenceImage: null, generatedImages: ['linear-gradient(135deg, #43e97b 0%, #38f9d7 100%)'], tags: ['supporting'], lastUsed: new Date('2024-01-08'), usedInVideos: [], createdAt: new Date('2024-01-02') },
    // Locations
    { id: 'loc-1', group: 'locations', subgroup: 'residential', name: "Christian's Apartment", prompt: 'Small urban apartment, modest furnishings, movie posters on walls, cluttered but clean, warm lighting', referenceImage: null, generatedImages: ['linear-gradient(135deg, #a18cd1 0%, #fbc2eb 100%)'], tags: ['interior', 'recurring'], lastUsed: new Date('2024-01-15'), usedInVideos: ['vid-1', 'vid-2'], createdAt: new Date('2024-01-03') },
    { id: 'loc-2', group: 'locations', subgroup: 'exterior', name: 'Barrio Street', prompt: 'Urban street in East LA, colorful murals on walls, small shops, palm trees, vibrant atmosphere', referenceImage: null, generatedImages: ['linear-gradient(135deg, #fa709a 0%, #fee140 100%)'], tags: ['exterior', 'recurring'], lastUsed: new Date('2024-01-14'), usedInVideos: ['vid-1'], createdAt: new Date('2024-01-03') },
    { id: 'loc-3', group: 'locations', subgroup: 'commercial', name: 'Corner Bodega', prompt: 'Small neighborhood convenience store, cramped aisles, fluorescent lighting, colorful product displays', referenceImage: null, generatedImages: ['linear-gradient(135deg, #30cfd0 0%, #330867 100%)'], tags: ['interior'], lastUsed: new Date('2024-01-12'), usedInVideos: ['vid-2'], createdAt: new Date('2024-01-04') },
    // Props
    { id: 'prop-1', group: 'props', subgroup: 'personal', name: "Christian's Phone", prompt: 'Older iPhone model, cracked screen in corner, worn black case, scratches on back', referenceImage: null, generatedImages: ['linear-gradient(135deg, #667eea 0%, #764ba2 100%)'], tags: ['technology'], lastUsed: new Date('2024-01-15'), usedInVideos: ['vid-1'], createdAt: new Date('2024-01-05') },
    { id: 'prop-2', group: 'props', subgroup: 'jewelry', name: 'Gold Chain Necklace', prompt: 'Thick gold rope chain, 24 inch length, slightly tarnished, masculine style, religious pendant', referenceImage: null, generatedImages: ['linear-gradient(135deg, #f6d365 0%, #fda085 100%)'], tags: ['jewelry'], lastUsed: new Date('2024-01-14'), usedInVideos: ['vid-1', 'vid-2'], createdAt: new Date('2024-01-05') },
    // Wardrobe
    { id: 'ward-1', group: 'wardrobe', name: 'Christian Casual', prompt: 'White tank top, baggy dark jeans, white Air Jordan sneakers, casual streetwear style', referenceImage: null, generatedImages: ['linear-gradient(135deg, #a1c4fd 0%, #c2e9fb 100%)'], tags: ['casual'], lastUsed: new Date('2024-01-15'), usedInVideos: ['vid-1'], createdAt: new Date('2024-01-07') },
    { id: 'ward-2', group: 'wardrobe', name: 'Maria Sundress', prompt: 'Yellow floral sundress, knee length, thin straps, light flowing fabric, summer style', referenceImage: null, generatedImages: ['linear-gradient(135deg, #ffecd2 0%, #fcb69f 100%)'], tags: ['feminine'], lastUsed: new Date('2024-01-14'), usedInVideos: ['vid-1'], createdAt: new Date('2024-01-07') },
    // Vehicles
    { id: 'veh-1', group: 'vehicles', name: "Christian's Civic", prompt: '1995 Honda Civic, lowered suspension, dark blue paint, aftermarket rims, tinted windows', referenceImage: null, generatedImages: ['linear-gradient(135deg, #0c3483 0%, #a2b6df 100%)'], tags: ['car'], lastUsed: new Date('2024-01-12'), usedInVideos: ['vid-1'], createdAt: new Date('2024-01-08') },
    { id: 'veh-2', group: 'vehicles', name: 'Unmarked Police Car', prompt: 'Black Ford Crown Victoria, police spotlight, plain hubcaps, tinted windows', referenceImage: null, generatedImages: ['linear-gradient(135deg, #1e3c72 0%, #2a5298 100%)'], tags: ['police'], lastUsed: new Date('2024-01-10'), usedInVideos: ['vid-2'], createdAt: new Date('2024-01-08') },
  ]);
  
  // Groups configuration
  const [groups, setGroups] = useState([
    { id: 'characters', name: 'Characters', icon: '👤', subgroups: [] },
    { id: 'locations', name: 'Locations', icon: '📍', subgroups: ['residential', 'exterior', 'commercial', 'institutional'] },
    { id: 'props', name: 'Props', icon: '📦', subgroups: ['personal', 'jewelry', 'electronics', 'documents', 'police'] },
    { id: 'wardrobe', name: 'Wardrobe', icon: '👕', subgroups: [] },
    { id: 'vehicles', name: 'Vehicles', icon: '🚗', subgroups: [] },
  ]);
  
  // ============================================================================
  // CONSISTENT IMAGE PROMPT TEMPLATES
  // ============================================================================
  const consistentImagePromptTemplates = {
    masterTurnaround: {
      label: 'Master Turnaround',
      description: 'One wide image containing all views (Front, Side, Back, Headshot)',
      template: `(character reference sheet:1.3), full body character turnaround, [SUBJECT_DESCRIPTION], [ART_STYLE], consisting of front view, side view, back view, and close-up headshot, orthographic view, neutral expression, A-pose, simple white background, flat lighting, high resolution, 4k, concept art style`,
      negativePrompt: `shadows, complex background, perspective, dynamic pose, action shot, asymmetry, noise, watermark, text, blurry, distorted face, extra limbs, different clothing, accessories changing`,
      aspectRatio: '3:2',
    },
    frontFull: {
      label: 'Full Body - Front',
      description: 'Full frontal body view',
      template: `full body shot, front view, [SUBJECT_DESCRIPTION], [ART_STYLE], standing straight, A-pose, neutral expression, looking at viewer, orthographic, simple white background`,
      negativePrompt: `shadows, complex background, perspective, dynamic pose, asymmetry, noise, watermark, text, blurry`,
      aspectRatio: '2:3',
    },
    backFull: {
      label: 'Full Body - Back',
      description: 'Full back body view',
      template: `full body shot, back view, from behind, [SUBJECT_DESCRIPTION], [ART_STYLE], standing straight, A-pose, simple white background, no face visible`,
      negativePrompt: `shadows, complex background, perspective, dynamic pose, asymmetry, noise, watermark, text, blurry, face visible`,
      aspectRatio: '2:3',
    },
    leftFull: {
      label: 'Full Body - Left Side',
      description: 'Full left side profile view',
      template: `full body shot, left side view, profile view, [SUBJECT_DESCRIPTION], [ART_STYLE], standing straight, looking left, simple white background`,
      negativePrompt: `shadows, complex background, perspective, dynamic pose, asymmetry, noise, watermark, text, blurry`,
      aspectRatio: '2:3',
    },
    rightFull: {
      label: 'Full Body - Right Side',
      description: 'Full right side profile view',
      template: `full body shot, right side view, profile view, [SUBJECT_DESCRIPTION], [ART_STYLE], standing straight, looking right, simple white background`,
      negativePrompt: `shadows, complex background, perspective, dynamic pose, asymmetry, noise, watermark, text, blurry`,
      aspectRatio: '2:3',
    },
    frontHead: {
      label: 'Headshot - Front',
      description: 'Front facing headshot',
      template: `extreme close-up, headshot, front view, [SUBJECT_DESCRIPTION], [ART_STYLE], neutral expression, detailed eyes, detailed skin texture, simple white background, passport photo style`,
      negativePrompt: `body, shoulders cropped, complex background, noise, watermark, text, blurry, distorted face`,
      aspectRatio: '1:1',
    },
    backHead: {
      label: 'Headshot - Back',
      description: 'Back of head view',
      template: `extreme close-up, headshot, back view, back of head, [SUBJECT_DESCRIPTION], [ART_STYLE], showing hair details, simple white background`,
      negativePrompt: `face visible, complex background, noise, watermark, text, blurry`,
      aspectRatio: '1:1',
    },
    leftHead: {
      label: 'Headshot - Left Side',
      description: 'Left side profile headshot',
      template: `extreme close-up, headshot, left side profile, [SUBJECT_DESCRIPTION], [ART_STYLE], neutral expression, detailed features, simple white background`,
      negativePrompt: `front view, complex background, noise, watermark, text, blurry, distorted face`,
      aspectRatio: '1:1',
    },
    rightHead: {
      label: 'Headshot - Right Side',
      description: 'Right side profile headshot',
      template: `extreme close-up, headshot, right side profile, [SUBJECT_DESCRIPTION], [ART_STYLE], neutral expression, detailed features, simple white background`,
      negativePrompt: `front view, complex background, noise, watermark, text, blurry, distorted face`,
      aspectRatio: '1:1',
    },
  };
  
  // Available generators for consistent images
  const consistentImageGenerators = [
    { id: 'midjourney', name: 'Midjourney', quality: 'Highest', speed: 'Medium' },
    { id: 'flux-2', name: 'Flux 2', quality: 'High', speed: 'Fast' },
    { id: 'nano-banana-pro', name: 'Nano Banana Pro', quality: 'High', speed: 'Fast' },
    { id: 'grok-imagine', name: 'Grok Imagine', quality: 'High', speed: 'Medium' },
  ];
  
  // Build prompt from template
  const buildConsistentPrompt = (templateKey, element) => {
    const template = consistentImagePromptTemplates[templateKey];
    if (!template || !element) return '';
    
    let prompt = template.template;
    
    // Replace placeholders
    prompt = prompt.replace('[SUBJECT_DESCRIPTION]', element.prompt || '');
    prompt = prompt.replace('[ART_STYLE]', 'photorealistic, cinematic lighting, 8k');
    
    return prompt;
  };
  
  // Open consistent image modal
  const openConsistentImageModal = (element) => {
    setConsistentImageElement(element);
    
    // Initialize prompts for all slots
    const initialImages = {};
    Object.keys(consistentImagePromptTemplates).forEach(key => {
      initialImages[key] = {
        image: null,
        status: 'pending',
        prompt: buildConsistentPrompt(key, element),
        negativePrompt: consistentImagePromptTemplates[key].negativePrompt,
      };
    });
    setConsistentImages(initialImages);
    setShowConsistentImageModal(true);
  };
  
  // Update a specific prompt
  const updateConsistentPrompt = (key, newPrompt) => {
    setConsistentImages(prev => ({
      ...prev,
      [key]: { ...prev[key], prompt: newPrompt },
    }));
  };
  
  // Open prompt edit modal
  const openPromptEditor = (key) => {
    setEditingPromptType(key);
    setTempEditPrompt(consistentImages[key].prompt);
    setShowPromptEditModal(true);
  };
  
  // Save edited prompt
  const saveEditedPrompt = () => {
    if (editingPromptType) {
      updateConsistentPrompt(editingPromptType, tempEditPrompt);
    }
    setShowPromptEditModal(false);
    setEditingPromptType(null);
  };
  
  // Simulate image generation
  const generateConsistentImage = async (key) => {
    setIsGenerating(key);
    setConsistentImages(prev => ({
      ...prev,
      [key]: { ...prev[key], status: 'generating' },
    }));
    
    // Simulate API call
    await new Promise(resolve => setTimeout(resolve, 3000));
    
    // Generate a mock gradient as placeholder
    const hue = Math.floor(Math.random() * 360);
    const mockImage = `linear-gradient(135deg, hsl(${hue}, 60%, 50%) 0%, hsl(${hue + 30}, 60%, 40%) 100%)`;
    
    setConsistentImages(prev => ({
      ...prev,
      [key]: { ...prev[key], status: 'completed', image: mockImage },
    }));
    setIsGenerating(null);
  };
  
  // Save consistent images to element
  const saveConsistentImagesToElement = () => {
    if (!consistentImageElement) return;
    
    const completedImages = Object.entries(consistentImages)
      .filter(([_, data]) => data.status === 'completed' && data.image)
      .map(([key, data]) => ({
        type: key,
        image: data.image,
        prompt: data.prompt,
      }));
    
    setElements(prev => prev.map(el => {
      if (el.id === consistentImageElement.id) {
        return {
          ...el,
          consistentImages: completedImages,
          updatedAt: new Date(),
        };
      }
      return el;
    }));
    
    setShowConsistentImageModal(false);
    alert(`Saved ${completedImages.length} consistent reference images to ${consistentImageElement.name}`);
  };
  
  // ============================================================================
  // END CONSISTENT IMAGE FUNCTIONS
  // ============================================================================
  
  // Get recently used elements (last 5)
  const recentlyUsed = [...elements].sort((a, b) => new Date(b.lastUsed) - new Date(a.lastUsed)).slice(0, 5);
  
  // Get elements for a group
  const getGroupElements = (groupId) => elements.filter(el => el.group === groupId);
  
  // Search elements
  const searchElements = (query) => {
    if (!query) return [];
    const q = query.toLowerCase();
    return elements.filter(el => 
      el.name.toLowerCase().includes(q) ||
      el.prompt?.toLowerCase().includes(q) ||
      el.tags?.some(t => t.toLowerCase().includes(q))
    );
  };
  
  // AI Image Analyzer (simulated)
  const analyzeImage = async () => {
    setIsAnalyzing(true);
    await new Promise(resolve => setTimeout(resolve, 2000));
    
    let analysis = '';
    if (newElement.group === 'characters') {
      analysis = 'Adult male, mid 20s, medium athletic build, approximately 5\'10", dark brown short hair styled casually, brown eyes, oval face shape, clean-shaven, light olive skin tone';
    } else if (newElement.group === 'locations') {
      analysis = 'Interior residential space, modern apartment style, neutral color palette with warm accents, hardwood flooring, natural light from windows, minimalist furniture';
    } else if (newElement.group === 'props') {
      analysis = 'Handheld electronic device, smartphone form factor, black color, glossy finish, visible screen damage in upper corner, protective case with wear marks';
    } else if (newElement.group === 'vehicles') {
      analysis = 'Compact sedan, Japanese make likely Honda/Toyota, 1990s model year, dark blue metallic paint, lowered suspension, aftermarket alloy wheels';
    } else if (newElement.group === 'wardrobe') {
      analysis = 'Casual menswear outfit, white cotton tank top, relaxed fit dark denim jeans, athletic sneakers in white colorway, streetwear aesthetic';
    }
    
    setNewElement(prev => ({ ...prev, prompt: analysis }));
    setIsAnalyzing(false);
  };
  
  // Save new element
  const saveElement = () => {
    const element = {
      id: `el-${Date.now()}`,
      group: newElement.group,
      subgroup: newElement.subgroup || null,
      name: newElement.name,
      prompt: newElement.prompt,
      referenceImage: newElement.referenceImage,
      generatedImages: [],
      tags: newElement.tags,
      lastUsed: new Date(),
      usedInVideos: [],
      createdAt: new Date(),
    };
    
    setElements(prev => [element, ...prev]);
    setShowCreateModal(false);
    setNewElement({ name: '', group: 'characters', subgroup: '', prompt: '', referenceImage: null, tags: [] });
  };
  
  // Add new group
  const addGroup = () => {
    const group = {
      id: newGroup.name.toLowerCase().replace(/\s+/g, '-'),
      name: newGroup.name,
      icon: newGroup.icon,
      subgroups: [],
    };
    setGroups(prev => [...prev, group]);
    setShowNewGroupModal(false);
    setNewGroup({ name: '', icon: '📁' });
  };
  
  // Open edit modal with element data
  const openEditModal = (element) => {
    setEditElement({
      id: element.id,
      name: element.name,
      group: element.group,
      subgroup: element.subgroup || '',
      prompt: element.prompt,
      referenceImage: element.referenceImage,
      tags: element.tags || [],
    });
    setShowEditModal(true);
  };
  
  // Update existing element
  const updateElement = () => {
    setElements(prev => prev.map(el => {
      if (el.id === editElement.id) {
        return {
          ...el,
          name: editElement.name,
          group: editElement.group,
          subgroup: editElement.subgroup || null,
          prompt: editElement.prompt,
          referenceImage: editElement.referenceImage,
          tags: editElement.tags,
        };
      }
      return el;
    }));
    
    // Update selectedElement if it's the one being edited
    if (selectedElement?.id === editElement.id) {
      setSelectedElement(prev => ({
        ...prev,
        name: editElement.name,
        group: editElement.group,
        subgroup: editElement.subgroup || null,
        prompt: editElement.prompt,
        referenceImage: editElement.referenceImage,
        tags: editElement.tags,
      }));
    }
    
    setShowEditModal(false);
    setEditElement({ id: '', name: '', group: 'characters', subgroup: '', prompt: '', referenceImage: null, tags: [] });
  };
  
  // Delete element
  const deleteElement = (elementId) => {
    setElements(prev => prev.filter(el => el.id !== elementId));
    setShowDeleteConfirm(false);
    setSelectedElement(null);
    setCurrentView(selectedGroup ? 'group' : 'dashboard');
  };
  
  // Analyze image for edit modal
  const analyzeImageForEdit = async () => {
    setIsAnalyzing(true);
    await new Promise(resolve => setTimeout(resolve, 2000));
    
    let analysis = '';
    if (editElement.group === 'characters') {
      analysis = 'Adult male, mid 20s, medium athletic build, approximately 5\'10", dark brown short hair styled casually, brown eyes, oval face shape, clean-shaven, light olive skin tone';
    } else if (editElement.group === 'locations') {
      analysis = 'Interior residential space, modern apartment style, neutral color palette with warm accents, hardwood flooring, natural light from windows, minimalist furniture';
    } else if (editElement.group === 'props') {
      analysis = 'Handheld electronic device, smartphone form factor, black color, glossy finish, visible screen damage in upper corner, protective case with wear marks';
    } else if (editElement.group === 'vehicles') {
      analysis = 'Compact sedan, Japanese make likely Honda/Toyota, 1990s model year, dark blue metallic paint, lowered suspension, aftermarket alloy wheels';
    } else if (editElement.group === 'wardrobe') {
      analysis = 'Casual menswear outfit, white cotton tank top, relaxed fit dark denim jeans, athletic sneakers in white colorway, streetwear aesthetic';
    }
    
    setEditElement(prev => ({ ...prev, prompt: analysis }));
    setIsAnalyzing(false);
  };
  
  // Handle bulk import
  const handleBulkImport = () => {
    if (bulkImportFiles.length === 0) return;
    
    const newElements = bulkImportFiles.map((file, index) => ({
      id: `el-${Date.now()}-${index}`,
      group: bulkImportGroup,
      subgroup: null,
      name: file.name.replace(/\.[^/.]+$/, '').replace(/_/g, ' ').replace(/-/g, ' '),
      prompt: '',
      referenceImage: file.preview,
      generatedImages: [file.preview],
      tags: [],
      lastUsed: new Date(),
      usedInVideos: [],
      createdAt: new Date(),
    }));
    
    setElements(prev => [...newElements, ...prev]);
    setShowBulkImportModal(false);
    setBulkImportFiles([]);
  };
  
  // Simulate file selection for bulk import
  const handleBulkFileSelect = () => {
    // Simulate selecting multiple files
    const mockFiles = [
      { name: 'character_01.jpg', preview: 'linear-gradient(135deg, #667eea 0%, #764ba2 100%)' },
      { name: 'character_02.jpg', preview: 'linear-gradient(135deg, #f093fb 0%, #f5576c 100%)' },
      { name: 'character_03.jpg', preview: 'linear-gradient(135deg, #4facfe 0%, #00f2fe 100%)' },
    ];
    setBulkImportFiles(mockFiles);
  };
  
  // Use element in Gen Space
  const handleUseInGenSpace = (element) => {
    if (onNavigateToGenSpace) {
      onNavigateToGenSpace(element);
    } else {
      alert(`Use in Gen Space:\n\nElement: ${element.name}\nPrompt: ${element.prompt}\n\n(Navigation callback not provided)`);
    }
  };
  
  // ============================================================================
  // DASHBOARD VIEW
  // ============================================================================
  const renderDashboard = () => (
    <div style={{ flex: 1, overflow: 'auto', padding: '32px 40px' }}>
      {/* Header */}
      <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'flex-start', marginBottom: '32px' }}>
        <div>
          <h1 style={{ fontSize: '28px', fontWeight: '700', marginBottom: '8px' }}>Elements</h1>
          <p style={{ fontSize: '14px', color: colors.text.secondary }}>Manage your characters, locations, props, and more</p>
        </div>
        <div style={{ display: 'flex', gap: '12px' }}>
          <Button 
            variant="secondary"
            onClick={() => setShowBulkImportModal(true)}
          >
            <Icons.Upload style={{ width: 16, height: 16, marginRight: '8px' }} />
            Bulk Import
          </Button>
          <Button 
            onClick={() => setShowCreateModal(true)}
            style={{ background: 'linear-gradient(135deg, #8b5cf6 0%, #a855f7 100%)', boxShadow: '0 4px 15px rgba(139, 92, 246, 0.4)' }}
          >
            <Icons.Plus style={{ width: 16, height: 16, marginRight: '8px' }} />
            New Element
          </Button>
        </div>
      </div>
      
      {/* Recently Used */}
      {recentlyUsed.length > 0 && (
        <div style={{ marginBottom: '40px' }}>
          <h2 style={{ fontSize: '16px', fontWeight: '600', marginBottom: '16px', color: colors.text.secondary }}>Recently Used</h2>
          <div style={{ display: 'flex', gap: '20px' }}>
            {recentlyUsed.map(el => (
              <div
                key={el.id}
                onClick={() => { setSelectedElement(el); setCurrentView('profile'); }}
                style={{ display: 'flex', flexDirection: 'column', alignItems: 'center', gap: '10px', cursor: 'pointer', transition: 'transform 0.2s ease' }}
                onMouseEnter={(e) => e.currentTarget.style.transform = 'translateY(-4px)'}
                onMouseLeave={(e) => e.currentTarget.style.transform = 'translateY(0)'}
              >
                <div style={{
                  width: '80px', height: '80px', borderRadius: '50%',
                  background: el.generatedImages?.[0] || colors.bg.tertiary,
                  border: `3px solid ${colors.border.subtle}`,
                  display: 'flex', alignItems: 'center', justifyContent: 'center',
                  fontSize: '28px', color: '#fff', fontWeight: '600',
                  boxShadow: '0 4px 12px rgba(0,0,0,0.15)',
                }}>
                  {!el.generatedImages?.[0] && el.name.charAt(0)}
                </div>
                <div style={{ fontSize: '13px', fontWeight: '500', textAlign: 'center', maxWidth: '90px', overflow: 'hidden', textOverflow: 'ellipsis', whiteSpace: 'nowrap' }}>{el.name}</div>
                <div style={{ fontSize: '11px', color: colors.text.tertiary, textTransform: 'capitalize' }}>{el.group}</div>
              </div>
            ))}
          </div>
        </div>
      )}
      
      {/* Search & Filters */}
      <div style={{ display: 'flex', gap: '12px', marginBottom: '24px', alignItems: 'center' }}>
        <div style={{ flex: 1, maxWidth: '400px', display: 'flex', alignItems: 'center', gap: '10px', padding: '10px 16px', background: colors.bg.secondary, border: `1px solid ${colors.border.default}`, borderRadius: '10px' }}>
          <Icons.Search style={{ width: 18, height: 18, color: colors.text.tertiary }} />
          <input
            type="text"
            placeholder="Search elements..."
            value={searchQuery}
            onChange={(e) => setSearchQuery(e.target.value)}
            style={{ flex: 1, background: 'none', border: 'none', color: colors.text.primary, fontSize: '14px', outline: 'none' }}
          />
        </div>
        <select value={sortBy} onChange={(e) => setSortBy(e.target.value)} style={{ padding: '10px 16px', background: colors.bg.secondary, border: `1px solid ${colors.border.default}`, borderRadius: '10px', color: colors.text.primary, fontSize: '14px' }}>
          <option value="recent">Recently Used</option>
          <option value="name">Name A-Z</option>
          <option value="created">Date Created</option>
        </select>
      </div>
      
      {/* Search Results or Groups */}
      {searchQuery ? (
        <div>
          <h3 style={{ fontSize: '14px', color: colors.text.secondary, marginBottom: '16px' }}>Search Results ({searchElements(searchQuery).length})</h3>
          <div style={{ display: 'grid', gridTemplateColumns: 'repeat(auto-fill, minmax(200px, 1fr))', gap: '16px' }}>
            {searchElements(searchQuery).map(el => (
              <div
                key={el.id}
                onClick={() => { setSelectedElement(el); setCurrentView('profile'); }}
                style={{ background: colors.bg.secondary, border: `1px solid ${colors.border.subtle}`, borderRadius: '12px', overflow: 'hidden', cursor: 'pointer', transition: 'all 0.2s ease' }}
                onMouseEnter={(e) => { e.currentTarget.style.borderColor = colors.accent.primary; e.currentTarget.style.transform = 'translateY(-2px)'; }}
                onMouseLeave={(e) => { e.currentTarget.style.borderColor = colors.border.subtle; e.currentTarget.style.transform = 'translateY(0)'; }}
              >
                <div style={{ height: '100px', background: el.generatedImages?.[0] || colors.bg.tertiary, display: 'flex', alignItems: 'center', justifyContent: 'center' }}>
                  {!el.generatedImages?.[0] && <span style={{ fontSize: '32px', opacity: 0.5 }}>{groups.find(g => g.id === el.group)?.icon || '📁'}</span>}
                </div>
                <div style={{ padding: '12px' }}>
                  <div style={{ fontSize: '14px', fontWeight: '600', marginBottom: '4px' }}>{el.name}</div>
                  <div style={{ fontSize: '12px', color: colors.text.tertiary, textTransform: 'capitalize' }}>{el.group}</div>
                </div>
              </div>
            ))}
          </div>
        </div>
      ) : (
        <>
          <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center', marginBottom: '16px' }}>
            <h2 style={{ fontSize: '16px', fontWeight: '600', color: colors.text.secondary }}>Groups</h2>
          </div>
          <div style={{ display: 'grid', gridTemplateColumns: 'repeat(auto-fill, minmax(180px, 1fr))', gap: '16px' }}>
            {groups.map(group => (
              <div
                key={group.id}
                onClick={() => { setSelectedGroup(group); setCurrentView('group'); }}
                style={{ background: colors.bg.secondary, border: `1px solid ${colors.border.subtle}`, borderRadius: '16px', padding: '24px', cursor: 'pointer', transition: 'all 0.2s ease' }}
                onMouseEnter={(e) => { e.currentTarget.style.borderColor = colors.accent.primary; e.currentTarget.style.transform = 'translateY(-4px)'; e.currentTarget.style.boxShadow = '0 8px 25px rgba(0,0,0,0.15)'; }}
                onMouseLeave={(e) => { e.currentTarget.style.borderColor = colors.border.subtle; e.currentTarget.style.transform = 'translateY(0)'; e.currentTarget.style.boxShadow = 'none'; }}
              >
                <div style={{ fontSize: '40px', marginBottom: '16px' }}>{group.icon}</div>
                <div style={{ fontSize: '16px', fontWeight: '600', marginBottom: '4px' }}>{group.name}</div>
                <div style={{ fontSize: '13px', color: colors.text.tertiary }}>{getGroupElements(group.id).length} elements</div>
              </div>
            ))}
            <div
              onClick={() => setShowNewGroupModal(true)}
              style={{ background: colors.bg.tertiary, border: `2px dashed ${colors.border.default}`, borderRadius: '16px', padding: '24px', cursor: 'pointer', display: 'flex', flexDirection: 'column', alignItems: 'center', justifyContent: 'center', transition: 'all 0.2s ease' }}
              onMouseEnter={(e) => e.currentTarget.style.borderColor = colors.accent.primary}
              onMouseLeave={(e) => e.currentTarget.style.borderColor = colors.border.default}
            >
              <div style={{ width: '48px', height: '48px', borderRadius: '50%', background: colors.bg.elevated, display: 'flex', alignItems: 'center', justifyContent: 'center', marginBottom: '12px', color: colors.text.tertiary }}><Icons.Plus /></div>
              <div style={{ fontSize: '14px', color: colors.text.tertiary }}>New Group</div>
            </div>
          </div>
        </>
      )}
    </div>
  );
  
  // ============================================================================
  // GROUP VIEW
  // ============================================================================
  const renderGroupView = () => {
    if (!selectedGroup) return null;
    const groupElements = getGroupElements(selectedGroup.id);
    const subgroups = selectedGroup.subgroups || [];
    
    return (
      <div style={{ flex: 1, overflow: 'auto', padding: '32px 40px' }}>
        <div style={{ display: 'flex', alignItems: 'center', gap: '16px', marginBottom: '32px' }}>
          <button onClick={() => setCurrentView('dashboard')} style={{ background: 'none', border: 'none', color: colors.text.secondary, cursor: 'pointer', display: 'flex', alignItems: 'center', gap: '8px', fontSize: '14px' }}>
            <Icons.ChevronLeft style={{ width: 20, height: 20 }} />Back
          </button>
          <div style={{ height: '24px', width: '1px', background: colors.border.subtle }} />
          <div>
            <div style={{ display: 'flex', alignItems: 'center', gap: '12px' }}>
              <span style={{ fontSize: '32px' }}>{selectedGroup.icon}</span>
              <h1 style={{ fontSize: '24px', fontWeight: '700' }}>{selectedGroup.name}</h1>
            </div>
            <p style={{ fontSize: '14px', color: colors.text.secondary, marginTop: '4px' }}>{groupElements.length} elements</p>
          </div>
          <div style={{ marginLeft: 'auto' }}>
            <Button onClick={() => { setNewElement(prev => ({ ...prev, group: selectedGroup.id })); setShowCreateModal(true); }}>
              <Icons.Plus style={{ width: 16, height: 16, marginRight: '8px' }} />Add {selectedGroup.name.slice(0, -1)}
            </Button>
          </div>
        </div>
        
        <div style={{ display: 'flex', gap: '12px', marginBottom: '24px' }}>
          <div style={{ flex: 1, maxWidth: '300px', display: 'flex', alignItems: 'center', gap: '10px', padding: '10px 16px', background: colors.bg.secondary, border: `1px solid ${colors.border.default}`, borderRadius: '10px' }}>
            <Icons.Search style={{ width: 16, height: 16, color: colors.text.tertiary }} />
            <input type="text" placeholder={`Search ${selectedGroup.name.toLowerCase()}...`} value={searchQuery} onChange={(e) => setSearchQuery(e.target.value)} style={{ flex: 1, background: 'none', border: 'none', color: colors.text.primary, fontSize: '14px', outline: 'none' }} />
          </div>
          {subgroups.length > 0 && (
            <select style={{ padding: '10px 16px', background: colors.bg.secondary, border: `1px solid ${colors.border.default}`, borderRadius: '10px', color: colors.text.primary, fontSize: '14px', textTransform: 'capitalize' }}>
              <option value="">All Subgroups</option>
              {subgroups.map(sg => <option key={sg} value={sg}>{sg}</option>)}
            </select>
          )}
        </div>
        
        <div style={{ display: 'grid', gridTemplateColumns: 'repeat(auto-fill, minmax(220px, 1fr))', gap: '20px' }}>
          {groupElements.map(el => (
            <div
              key={el.id}
              onClick={() => { setSelectedElement(el); setCurrentView('profile'); }}
              style={{ background: colors.bg.secondary, border: `1px solid ${colors.border.subtle}`, borderRadius: '12px', overflow: 'hidden', cursor: 'pointer', transition: 'all 0.2s ease' }}
              onMouseEnter={(e) => { e.currentTarget.style.borderColor = colors.accent.primary; e.currentTarget.style.transform = 'translateY(-4px)'; e.currentTarget.style.boxShadow = '0 8px 25px rgba(0,0,0,0.15)'; }}
              onMouseLeave={(e) => { e.currentTarget.style.borderColor = colors.border.subtle; e.currentTarget.style.transform = 'translateY(0)'; e.currentTarget.style.boxShadow = 'none'; }}
            >
              <div style={{ height: '140px', background: el.generatedImages?.[0] || colors.bg.tertiary, display: 'flex', alignItems: 'center', justifyContent: 'center', position: 'relative' }}>
                {!el.generatedImages?.[0] && <div style={{ width: '64px', height: '64px', borderRadius: '50%', background: colors.bg.elevated, display: 'flex', alignItems: 'center', justifyContent: 'center', fontSize: '24px', fontWeight: '600', color: colors.text.secondary }}>{el.name.charAt(0)}</div>}
                {el.subgroup && <div style={{ position: 'absolute', top: '10px', left: '10px', padding: '4px 10px', background: 'rgba(0,0,0,0.6)', borderRadius: '6px', fontSize: '11px', color: '#fff', textTransform: 'capitalize' }}>{el.subgroup}</div>}
              </div>
              <div style={{ padding: '16px' }}>
                <div style={{ fontSize: '15px', fontWeight: '600', marginBottom: '6px' }}>{el.name}</div>
                <div style={{ fontSize: '12px', color: colors.text.tertiary, overflow: 'hidden', textOverflow: 'ellipsis', whiteSpace: 'nowrap' }}>{el.prompt?.slice(0, 50)}...</div>
                {el.usedInVideos?.length > 0 && <div style={{ marginTop: '10px', fontSize: '11px', color: colors.accent.primary }}>Used in {el.usedInVideos.length} video{el.usedInVideos.length !== 1 ? 's' : ''}</div>}
              </div>
            </div>
          ))}
        </div>
      </div>
    );
  };
  
  // ============================================================================
  // PROFILE VIEW (IG-style)
  // ============================================================================
  const renderProfileView = () => {
    const el = selectedElement;
    if (!el) return null;
    const group = groups.find(g => g.id === el.group);
    
    return (
      <div style={{ flex: 1, overflow: 'auto', background: colors.bg.primary }}>
        <div style={{ padding: '20px 40px', borderBottom: `1px solid ${colors.border.subtle}` }}>
          <button onClick={() => { if (selectedGroup) { setCurrentView('group'); } else { setCurrentView('dashboard'); }}} style={{ background: 'none', border: 'none', color: colors.text.secondary, cursor: 'pointer', display: 'flex', alignItems: 'center', gap: '8px', fontSize: '14px' }}>
            <Icons.ChevronLeft style={{ width: 20, height: 20 }} />Back to {selectedGroup ? selectedGroup.name : 'Elements'}
          </button>
        </div>
        
        <div style={{ display: 'flex', padding: '40px' }}>
          {/* Left Column - Profile Info */}
          <div style={{ width: '320px', paddingRight: '40px', borderRight: `1px solid ${colors.border.subtle}` }}>
            <div style={{ width: '200px', height: '200px', borderRadius: '50%', background: el.generatedImages?.[0] || colors.bg.tertiary, margin: '0 auto 24px', display: 'flex', alignItems: 'center', justifyContent: 'center', border: `4px solid ${colors.border.default}`, boxShadow: '0 8px 32px rgba(0,0,0,0.2)' }}>
              {!el.generatedImages?.[0] && <span style={{ fontSize: '64px', fontWeight: '600', color: colors.text.secondary }}>{el.name.charAt(0)}</span>}
            </div>
            
            <div style={{ textAlign: 'center', marginBottom: '24px' }}>
              <h1 style={{ fontSize: '24px', fontWeight: '700', marginBottom: '4px' }}>{el.name}</h1>
              <div style={{ display: 'inline-flex', alignItems: 'center', gap: '6px', fontSize: '14px', color: colors.text.secondary }}>
                <span>{group?.icon}</span>
                <span style={{ textTransform: 'capitalize' }}>{el.group}</span>
                {el.subgroup && <><span>›</span><span style={{ textTransform: 'capitalize' }}>{el.subgroup}</span></>}
              </div>
            </div>
            
            <Button 
              style={{ width: '100%', marginBottom: '12px', background: 'linear-gradient(135deg, #10b981 0%, #059669 100%)' }} 
              onClick={() => handleUseInGenSpace(el)}
            >
              <Icons.Camera style={{ width: 16, height: 16, marginRight: '8px' }} />
              Use in Gen Space
            </Button>
            
            {/* Create Consistent Character Button - Only for Characters */}
            {el.group === 'characters' && (
              <Button 
                style={{ width: '100%', marginBottom: '12px', background: 'linear-gradient(135deg, #8b5cf6 0%, #6d28d9 100%)' }} 
                onClick={() => openConsistentImageModal(el)}
              >
                <Icons.Layers style={{ width: 16, height: 16, marginRight: '8px' }} />
                Create Consistent Character
              </Button>
            )}
            
            {/* Create Reference Images Button - For non-characters */}
            {el.group !== 'characters' && (
              <Button 
                variant="secondary"
                style={{ width: '100%', marginBottom: '12px' }} 
                onClick={() => openConsistentImageModal(el)}
              >
                <Icons.Layers style={{ width: 16, height: 16, marginRight: '8px' }} />
                Create Reference Images
              </Button>
            )}
            
            {/* Edit and Delete buttons */}
            <div style={{ display: 'flex', gap: '8px', marginBottom: '24px' }}>
              <Button 
                variant="secondary" 
                style={{ flex: 1 }} 
                onClick={() => openEditModal(el)}
              >
                Edit Element
              </Button>
              <button
                onClick={() => setShowDeleteConfirm(true)}
                style={{
                  padding: '10px 16px',
                  background: 'transparent',
                  border: `1px solid ${colors.accent.error}`,
                  borderRadius: '8px',
                  color: colors.accent.error,
                  fontSize: '14px',
                  cursor: 'pointer',
                }}
              >
                Delete
              </button>
            </div>
            
            <div style={{ display: 'flex', justifyContent: 'center', gap: '32px', marginBottom: '24px', paddingBottom: '24px', borderBottom: `1px solid ${colors.border.subtle}` }}>
              <div style={{ textAlign: 'center' }}><div style={{ fontSize: '20px', fontWeight: '700' }}>{el.generatedImages?.length || 0}</div><div style={{ fontSize: '12px', color: colors.text.tertiary }}>Images</div></div>
              <div style={{ textAlign: 'center' }}><div style={{ fontSize: '20px', fontWeight: '700' }}>{el.usedInVideos?.length || 0}</div><div style={{ fontSize: '12px', color: colors.text.tertiary }}>Videos</div></div>
            </div>
            
            <div style={{ marginBottom: '20px' }}>
              <div style={{ fontSize: '12px', fontWeight: '600', color: colors.text.tertiary, marginBottom: '8px' }}>PROMPT</div>
              <p style={{ fontSize: '14px', color: colors.text.secondary, lineHeight: '1.5' }}>{el.prompt}</p>
            </div>
            
            {el.tags?.length > 0 && (
              <div style={{ marginBottom: '20px' }}>
                <div style={{ fontSize: '12px', fontWeight: '600', color: colors.text.tertiary, marginBottom: '8px' }}>TAGS</div>
                <div style={{ display: 'flex', flexWrap: 'wrap', gap: '6px' }}>
                  {el.tags.map(tag => <span key={tag} style={{ padding: '4px 10px', background: colors.bg.tertiary, borderRadius: '12px', fontSize: '12px', color: colors.text.secondary }}>#{tag}</span>)}
                </div>
              </div>
            )}
            
            <div style={{ fontSize: '12px', color: colors.text.tertiary }}>Created {new Date(el.createdAt).toLocaleDateString()}</div>
          </div>
          
          {/* Right Column - Content */}
          <div style={{ flex: 1, paddingLeft: '40px' }}>
            {el.usedInVideos?.length > 0 && (
              <div style={{ marginBottom: '40px' }}>
                <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center', marginBottom: '16px' }}>
                  <h2 style={{ fontSize: '18px', fontWeight: '600' }}>Featured In</h2>
                </div>
                <div style={{ display: 'flex', gap: '12px', overflowX: 'auto', paddingBottom: '8px' }}>
                  {el.usedInVideos.map((vid, i) => (
                    <div key={vid} style={{ minWidth: '140px', height: '80px', borderRadius: '12px', background: `linear-gradient(135deg, hsl(${i * 60}, 60%, 40%), hsl(${i * 60 + 30}, 60%, 50%))`, display: 'flex', alignItems: 'center', justifyContent: 'center', cursor: 'pointer' }}>
                      <Icons.Play style={{ width: 24, height: 24, color: '#fff' }} />
                    </div>
                  ))}
                </div>
              </div>
            )}
            
            <div>
              <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center', marginBottom: '16px' }}>
                <h2 style={{ fontSize: '18px', fontWeight: '600' }}>Images</h2>
                <select style={{ padding: '6px 12px', background: colors.bg.secondary, border: `1px solid ${colors.border.default}`, borderRadius: '6px', color: colors.text.primary, fontSize: '13px' }}>
                  <option>All Time</option>
                  <option>This Month</option>
                  <option>This Week</option>
                </select>
              </div>
              
              {el.generatedImages?.length > 0 ? (
                <div style={{ display: 'grid', gridTemplateColumns: 'repeat(3, 1fr)', gap: '16px' }}>
                  {el.generatedImages.map((img, i) => (
                    <div key={i} style={{ aspectRatio: '1', borderRadius: '12px', background: img, cursor: 'pointer', transition: 'transform 0.2s ease' }} onMouseEnter={(e) => e.currentTarget.style.transform = 'scale(1.02)'} onMouseLeave={(e) => e.currentTarget.style.transform = 'scale(1)'} />
                  ))}
                  {[1, 2, 3, 4, 5].map(i => (
                    <div key={`placeholder-${i}`} style={{ aspectRatio: '1', borderRadius: '12px', background: colors.bg.tertiary, display: 'flex', alignItems: 'center', justifyContent: 'center', border: `2px dashed ${colors.border.default}` }}>
                      <Icons.Image style={{ width: 24, height: 24, color: colors.text.tertiary, opacity: 0.5 }} />
                    </div>
                  ))}
                </div>
              ) : (
                <div style={{ padding: '60px', background: colors.bg.secondary, borderRadius: '16px', textAlign: 'center' }}>
                  <Icons.Image style={{ width: 48, height: 48, color: colors.text.tertiary, marginBottom: '16px' }} />
                  <h3 style={{ fontSize: '16px', fontWeight: '500', marginBottom: '8px' }}>No images yet</h3>
                  <p style={{ fontSize: '14px', color: colors.text.tertiary, marginBottom: '20px' }}>Generate images for this element using GenSpace</p>
                  <Button>Generate First Image</Button>
                </div>
              )}
            </div>
          </div>
        </div>
      </div>
    );
  };
  
  // ============================================================================
  // CREATE ELEMENT MODAL
  // ============================================================================
  const renderCreateModal = () => (
    <div style={{ position: 'fixed', top: 0, left: 0, right: 0, bottom: 0, background: 'rgba(0,0,0,0.85)', display: 'flex', alignItems: 'center', justifyContent: 'center', zIndex: 1000 }}>
      <div style={{ width: '700px', maxHeight: '90vh', background: colors.bg.secondary, borderRadius: '16px', overflow: 'hidden', display: 'flex', flexDirection: 'column' }}>
        <div style={{ padding: '20px 24px', borderBottom: `1px solid ${colors.border.default}`, display: 'flex', justifyContent: 'space-between', alignItems: 'center' }}>
          <h2 style={{ fontSize: '20px', fontWeight: '600' }}>Create New Element</h2>
          <button onClick={() => setShowCreateModal(false)} style={{ background: 'none', border: 'none', color: colors.text.tertiary, cursor: 'pointer', fontSize: '24px' }}>×</button>
        </div>
        
        <div style={{ flex: 1, overflow: 'auto', padding: '24px' }}>
          {/* Group Selection */}
          <div style={{ marginBottom: '20px' }}>
            <label style={{ display: 'block', fontSize: '13px', fontWeight: '600', color: colors.text.secondary, marginBottom: '8px' }}>Group</label>
            <div style={{ display: 'flex', gap: '8px', flexWrap: 'wrap' }}>
              {groups.map(g => (
                <button key={g.id} onClick={() => setNewElement(prev => ({ ...prev, group: g.id }))} style={{ padding: '10px 16px', background: newElement.group === g.id ? colors.accent.primary : colors.bg.tertiary, border: `1px solid ${newElement.group === g.id ? colors.accent.primary : colors.border.default}`, borderRadius: '8px', color: newElement.group === g.id ? '#fff' : colors.text.primary, fontSize: '13px', cursor: 'pointer', display: 'flex', alignItems: 'center', gap: '8px' }}>
                  <span>{g.icon}</span>{g.name}
                </button>
              ))}
            </div>
          </div>
          
          {/* Subgroup */}
          {groups.find(g => g.id === newElement.group)?.subgroups?.length > 0 && (
            <div style={{ marginBottom: '20px' }}>
              <label style={{ display: 'block', fontSize: '13px', fontWeight: '600', color: colors.text.secondary, marginBottom: '8px' }}>Subgroup (optional)</label>
              <select value={newElement.subgroup} onChange={(e) => setNewElement(prev => ({ ...prev, subgroup: e.target.value }))} style={{ width: '100%', padding: '12px 16px', background: colors.bg.tertiary, border: `1px solid ${colors.border.default}`, borderRadius: '8px', color: colors.text.primary, fontSize: '14px', textTransform: 'capitalize' }}>
                <option value="">Select subgroup...</option>
                {groups.find(g => g.id === newElement.group)?.subgroups?.map(sg => <option key={sg} value={sg}>{sg}</option>)}
              </select>
            </div>
          )}
          
          {/* Name */}
          <div style={{ marginBottom: '20px' }}>
            <label style={{ display: 'block', fontSize: '13px', fontWeight: '600', color: colors.text.secondary, marginBottom: '8px' }}>Name</label>
            <input type="text" placeholder="Enter element name..." value={newElement.name} onChange={(e) => setNewElement(prev => ({ ...prev, name: e.target.value }))} style={{ width: '100%', padding: '12px 16px', background: colors.bg.tertiary, border: `1px solid ${colors.border.default}`, borderRadius: '8px', color: colors.text.primary, fontSize: '14px' }} />
          </div>
          
          {/* Reference Image */}
          <div style={{ marginBottom: '20px' }}>
            <label style={{ display: 'block', fontSize: '13px', fontWeight: '600', color: colors.text.secondary, marginBottom: '8px' }}>Reference Image (optional)</label>
            <div style={{ border: `2px dashed ${colors.border.default}`, borderRadius: '12px', padding: '32px', textAlign: 'center', cursor: 'pointer' }}>
              {newElement.referenceImage ? (
                <div>
                  <div style={{ marginBottom: '12px', color: colors.accent.success }}>✓ Image uploaded</div>
                  <Button variant="secondary" size="sm" onClick={() => setNewElement(prev => ({ ...prev, referenceImage: null }))}>Remove</Button>
                </div>
              ) : (
                <>
                  <Icons.Upload style={{ width: 32, height: 32, color: colors.text.tertiary, marginBottom: '12px' }} />
                  <div style={{ fontSize: '14px', color: colors.text.secondary, marginBottom: '8px' }}>Drop an image here or click to upload</div>
                  <Button variant="secondary" size="sm" onClick={() => setNewElement(prev => ({ ...prev, referenceImage: 'uploaded-image.jpg' }))}>Choose File</Button>
                </>
              )}
            </div>
          </div>
          
          {/* AI Analyze */}
          {newElement.referenceImage && (
            <div style={{ marginBottom: '20px' }}>
              <Button variant="secondary" onClick={analyzeImage} disabled={isAnalyzing} style={{ width: '100%' }}>
                {isAnalyzing ? (
                  <><div style={{ width: '16px', height: '16px', border: '2px solid currentColor', borderTopColor: 'transparent', borderRadius: '50%', animation: 'spin 1s linear infinite', marginRight: '8px' }} />Analyzing Image...</>
                ) : (
                  <><Icons.Sparkles style={{ width: 16, height: 16, marginRight: '8px' }} />Analyze Image with AI</>
                )}
              </Button>
            </div>
          )}
          
          {/* Prompt */}
          <div style={{ marginBottom: '20px' }}>
            <label style={{ display: 'block', fontSize: '13px', fontWeight: '600', color: colors.text.secondary, marginBottom: '8px' }}>Element Description / Prompt</label>
            <textarea placeholder="Describe the element in detail..." value={newElement.prompt} onChange={(e) => setNewElement(prev => ({ ...prev, prompt: e.target.value }))} rows={4} style={{ width: '100%', padding: '12px 16px', background: colors.bg.tertiary, border: `1px solid ${colors.border.default}`, borderRadius: '8px', color: colors.text.primary, fontSize: '14px', resize: 'vertical', fontFamily: 'inherit' }} />
            <div style={{ fontSize: '12px', color: colors.text.tertiary, marginTop: '6px' }}>Be specific about physical characteristics. Lighting and camera angles come from shot/scene settings.</div>
          </div>
          
          {/* Tags */}
          <div style={{ marginBottom: '20px' }}>
            <label style={{ display: 'block', fontSize: '13px', fontWeight: '600', color: colors.text.secondary, marginBottom: '8px' }}>Tags (for search)</label>
            <input type="text" placeholder="Add tags separated by commas..." onKeyDown={(e) => { if (e.key === 'Enter' || e.key === ',') { e.preventDefault(); const tag = e.target.value.trim().replace(',', ''); if (tag && !newElement.tags.includes(tag)) { setNewElement(prev => ({ ...prev, tags: [...prev.tags, tag] })); e.target.value = ''; }}}} style={{ width: '100%', padding: '12px 16px', background: colors.bg.tertiary, border: `1px solid ${colors.border.default}`, borderRadius: '8px', color: colors.text.primary, fontSize: '14px' }} />
            {newElement.tags.length > 0 && (
              <div style={{ display: 'flex', flexWrap: 'wrap', gap: '6px', marginTop: '10px' }}>
                {newElement.tags.map(tag => (
                  <span key={tag} style={{ padding: '4px 10px', background: colors.bg.elevated, borderRadius: '12px', fontSize: '12px', color: colors.text.secondary, display: 'flex', alignItems: 'center', gap: '6px' }}>
                    #{tag}<button onClick={() => setNewElement(prev => ({ ...prev, tags: prev.tags.filter(t => t !== tag) }))} style={{ background: 'none', border: 'none', color: colors.text.tertiary, cursor: 'pointer', fontSize: '14px' }}>×</button>
                  </span>
                ))}
              </div>
            )}
          </div>
        </div>
        
        <div style={{ padding: '16px 24px', borderTop: `1px solid ${colors.border.default}`, display: 'flex', justifyContent: 'flex-end', gap: '12px' }}>
          <Button variant="secondary" onClick={() => setShowCreateModal(false)}>Cancel</Button>
          <Button onClick={saveElement} disabled={!newElement.name || !newElement.prompt}>Create Element</Button>
        </div>
      </div>
      <style>{`@keyframes spin { to { transform: rotate(360deg); } }`}</style>
    </div>
  );
  
  // ============================================================================
  // NEW GROUP MODAL
  // ============================================================================
  const renderNewGroupModal = () => (
    <div style={{ position: 'fixed', top: 0, left: 0, right: 0, bottom: 0, background: 'rgba(0,0,0,0.85)', display: 'flex', alignItems: 'center', justifyContent: 'center', zIndex: 1000 }}>
      <div style={{ width: '400px', background: colors.bg.secondary, borderRadius: '16px', overflow: 'hidden' }}>
        <div style={{ padding: '20px 24px', borderBottom: `1px solid ${colors.border.default}`, display: 'flex', justifyContent: 'space-between', alignItems: 'center' }}>
          <h2 style={{ fontSize: '18px', fontWeight: '600' }}>Create New Group</h2>
          <button onClick={() => setShowNewGroupModal(false)} style={{ background: 'none', border: 'none', color: colors.text.tertiary, cursor: 'pointer', fontSize: '24px' }}>×</button>
        </div>
        <div style={{ padding: '24px' }}>
          <div style={{ marginBottom: '20px' }}>
            <label style={{ display: 'block', fontSize: '13px', fontWeight: '600', color: colors.text.secondary, marginBottom: '8px' }}>Group Name</label>
            <input type="text" placeholder="Enter group name..." value={newGroup.name} onChange={(e) => setNewGroup(prev => ({ ...prev, name: e.target.value }))} style={{ width: '100%', padding: '12px 16px', background: colors.bg.tertiary, border: `1px solid ${colors.border.default}`, borderRadius: '8px', color: colors.text.primary, fontSize: '14px' }} />
          </div>
          <div style={{ marginBottom: '20px' }}>
            <label style={{ display: 'block', fontSize: '13px', fontWeight: '600', color: colors.text.secondary, marginBottom: '8px' }}>Icon</label>
            <div style={{ display: 'flex', gap: '8px', flexWrap: 'wrap' }}>
              {['📁', '🎭', '🏠', '🎨', '📷', '🎬', '🎵', '💼', '🔧', '⚡'].map(icon => (
                <button key={icon} onClick={() => setNewGroup(prev => ({ ...prev, icon }))} style={{ width: '44px', height: '44px', borderRadius: '8px', background: newGroup.icon === icon ? colors.accent.primary : colors.bg.tertiary, border: `1px solid ${newGroup.icon === icon ? colors.accent.primary : colors.border.default}`, fontSize: '20px', cursor: 'pointer' }}>{icon}</button>
              ))}
            </div>
          </div>
        </div>
        <div style={{ padding: '16px 24px', borderTop: `1px solid ${colors.border.default}`, display: 'flex', justifyContent: 'flex-end', gap: '12px' }}>
          <Button variant="secondary" onClick={() => setShowNewGroupModal(false)}>Cancel</Button>
          <Button onClick={addGroup} disabled={!newGroup.name}>Create Group</Button>
        </div>
      </div>
    </div>
  );
  
  // ============================================================================
  // MAIN RENDER
  // ============================================================================
  return (
    <div style={{ flex: 1, display: 'flex', flexDirection: 'column', overflow: 'hidden', background: colors.bg.primary }}>
      {currentView === 'dashboard' && renderDashboard()}
      {currentView === 'group' && renderGroupView()}
      {currentView === 'profile' && renderProfileView()}
      {showCreateModal && renderCreateModal()}
      {showNewGroupModal && renderNewGroupModal()}
      
      {/* Edit Element Modal */}
      {showEditModal && (
        <div style={{ position: 'fixed', top: 0, left: 0, right: 0, bottom: 0, background: 'rgba(0,0,0,0.85)', display: 'flex', alignItems: 'center', justifyContent: 'center', zIndex: 1000 }}>
          <div style={{ width: '700px', maxHeight: '90vh', background: colors.bg.secondary, borderRadius: '16px', overflow: 'hidden', display: 'flex', flexDirection: 'column' }}>
            <div style={{ padding: '20px 24px', borderBottom: `1px solid ${colors.border.default}`, display: 'flex', justifyContent: 'space-between', alignItems: 'center' }}>
              <h2 style={{ fontSize: '20px', fontWeight: '600' }}>Edit Element</h2>
              <button onClick={() => setShowEditModal(false)} style={{ background: 'none', border: 'none', color: colors.text.tertiary, cursor: 'pointer', fontSize: '24px' }}>×</button>
            </div>
            
            <div style={{ flex: 1, overflow: 'auto', padding: '24px' }}>
              {/* Group Selection */}
              <div style={{ marginBottom: '20px' }}>
                <label style={{ fontSize: '13px', fontWeight: '600', color: colors.text.secondary, display: 'block', marginBottom: '8px' }}>Group</label>
                <div style={{ display: 'flex', flexWrap: 'wrap', gap: '8px' }}>
                  {groups.map(g => (
                    <button
                      key={g.id}
                      onClick={() => setEditElement(prev => ({ ...prev, group: g.id, subgroup: '' }))}
                      style={{
                        padding: '8px 16px',
                        borderRadius: '8px',
                        border: `1px solid ${editElement.group === g.id ? colors.accent.primary : colors.border.default}`,
                        background: editElement.group === g.id ? colors.accent.primary : colors.bg.tertiary,
                        color: editElement.group === g.id ? 'white' : colors.text.primary,
                        fontSize: '13px',
                        cursor: 'pointer',
                        display: 'flex',
                        alignItems: 'center',
                        gap: '6px',
                      }}
                    >
                      <span>{g.icon}</span>
                      <span>{g.name}</span>
                    </button>
                  ))}
                </div>
              </div>
              
              {/* Subgroup */}
              {groups.find(g => g.id === editElement.group)?.subgroups?.length > 0 && (
                <div style={{ marginBottom: '20px' }}>
                  <label style={{ fontSize: '13px', fontWeight: '600', color: colors.text.secondary, display: 'block', marginBottom: '8px' }}>Subgroup (optional)</label>
                  <select
                    value={editElement.subgroup}
                    onChange={(e) => setEditElement(prev => ({ ...prev, subgroup: e.target.value }))}
                    style={{ width: '100%', padding: '12px 16px', background: colors.bg.tertiary, border: `1px solid ${colors.border.default}`, borderRadius: '8px', color: colors.text.primary, fontSize: '14px' }}
                  >
                    <option value="">Select subgroup...</option>
                    {groups.find(g => g.id === editElement.group)?.subgroups.map(sg => (
                      <option key={sg} value={sg} style={{ textTransform: 'capitalize' }}>{sg}</option>
                    ))}
                  </select>
                </div>
              )}
              
              {/* Name */}
              <div style={{ marginBottom: '20px' }}>
                <label style={{ fontSize: '13px', fontWeight: '600', color: colors.text.secondary, display: 'block', marginBottom: '8px' }}>Name</label>
                <input
                  type="text"
                  value={editElement.name}
                  onChange={(e) => setEditElement(prev => ({ ...prev, name: e.target.value }))}
                  style={{ width: '100%', padding: '12px 16px', background: colors.bg.tertiary, border: `1px solid ${colors.border.default}`, borderRadius: '8px', color: colors.text.primary, fontSize: '14px' }}
                />
              </div>
              
              {/* Reference Image */}
              <div style={{ marginBottom: '20px' }}>
                <label style={{ fontSize: '13px', fontWeight: '600', color: colors.text.secondary, display: 'block', marginBottom: '8px' }}>Reference Image</label>
                <div style={{ display: 'flex', alignItems: 'center', gap: '16px', padding: '16px', background: colors.bg.tertiary, border: `2px dashed ${colors.border.default}`, borderRadius: '12px' }}>
                  {editElement.referenceImage ? (
                    <>
                      <div style={{ width: '80px', height: '80px', borderRadius: '8px', background: `linear-gradient(135deg, ${colors.accent.primary}40, ${colors.accent.secondary}40)`, display: 'flex', alignItems: 'center', justifyContent: 'center' }}>
                        <Icons.Image style={{ width: 24, height: 24, color: colors.text.tertiary }} />
                      </div>
                      <div style={{ flex: 1 }}>
                        <div style={{ fontSize: '14px', color: colors.text.primary, marginBottom: '4px' }}>✓ Image uploaded</div>
                        <div style={{ fontSize: '12px', color: colors.text.tertiary }}>{editElement.referenceImage}</div>
                      </div>
                      <div style={{ display: 'flex', gap: '8px' }}>
                        <Button variant="secondary" size="sm" onClick={() => setEditElement(prev => ({ ...prev, referenceImage: 'new-uploaded-image.jpg' }))}>Replace</Button>
                        <Button variant="secondary" size="sm" onClick={() => setEditElement(prev => ({ ...prev, referenceImage: null }))}>Remove</Button>
                      </div>
                    </>
                  ) : (
                    <div style={{ flex: 1, textAlign: 'center' }}>
                      <Icons.Upload style={{ width: 32, height: 32, color: colors.text.tertiary, marginBottom: '8px' }} />
                      <div style={{ fontSize: '14px', color: colors.text.secondary, marginBottom: '8px' }}>Drag and drop an image, or</div>
                      <Button variant="secondary" size="sm" onClick={() => setEditElement(prev => ({ ...prev, referenceImage: 'uploaded-image.jpg' }))}>Choose File</Button>
                    </div>
                  )}
                </div>
              </div>
              
              {/* AI Analyze Button */}
              {editElement.referenceImage && (
                <div style={{ marginBottom: '20px' }}>
                  <button
                    onClick={analyzeImageForEdit}
                    disabled={isAnalyzing}
                    style={{
                      width: '100%',
                      padding: '12px 16px',
                      background: colors.bg.tertiary,
                      border: `1px solid ${colors.border.default}`,
                      borderRadius: '8px',
                      color: colors.text.primary,
                      fontSize: '14px',
                      cursor: isAnalyzing ? 'not-allowed' : 'pointer',
                      display: 'flex',
                      alignItems: 'center',
                      justifyContent: 'center',
                      gap: '8px',
                    }}
                  >
                    {isAnalyzing ? (
                      <><span style={{ display: 'inline-block', width: 16, height: 16, border: '2px solid transparent', borderTopColor: colors.accent.primary, borderRadius: '50%', animation: 'spin 1s linear infinite' }} />Analyzing Image...</>
                    ) : (
                      <><Icons.Sparkles style={{ width: 16, height: 16 }} />Analyze Image with AI</>
                    )}
                  </button>
                </div>
              )}
              
              {/* Prompt */}
              <div style={{ marginBottom: '20px' }}>
                <label style={{ fontSize: '13px', fontWeight: '600', color: colors.text.secondary, display: 'block', marginBottom: '8px' }}>Element Description / Prompt</label>
                <textarea
                  value={editElement.prompt}
                  onChange={(e) => setEditElement(prev => ({ ...prev, prompt: e.target.value }))}
                  rows={4}
                  style={{ width: '100%', padding: '12px 16px', background: colors.bg.tertiary, border: `1px solid ${colors.border.default}`, borderRadius: '8px', color: colors.text.primary, fontSize: '14px', resize: 'vertical' }}
                />
                <p style={{ fontSize: '12px', color: colors.text.tertiary, marginTop: '6px' }}>Be specific about physical characteristics. Lighting and camera angles come from shot/scene settings.</p>
              </div>
              
              {/* Tags */}
              <div style={{ marginBottom: '20px' }}>
                <label style={{ fontSize: '13px', fontWeight: '600', color: colors.text.secondary, display: 'block', marginBottom: '8px' }}>Tags (for search)</label>
                <div style={{ display: 'flex', flexWrap: 'wrap', gap: '6px', marginBottom: '8px' }}>
                  {editElement.tags.map(tag => (
                    <span key={tag} style={{ padding: '4px 10px', background: colors.bg.elevated, borderRadius: '12px', fontSize: '12px', color: colors.text.secondary, display: 'flex', alignItems: 'center', gap: '6px' }}>
                      #{tag}
                      <button
                        onClick={() => setEditElement(prev => ({ ...prev, tags: prev.tags.filter(t => t !== tag) }))}
                        style={{ background: 'none', border: 'none', color: colors.text.tertiary, cursor: 'pointer', padding: 0, fontSize: '14px' }}
                      >×</button>
                    </span>
                  ))}
                </div>
                <input
                  type="text"
                  placeholder="Add tag and press Enter..."
                  onKeyDown={(e) => {
                    if ((e.key === 'Enter' || e.key === ',') && e.target.value.trim()) {
                      e.preventDefault();
                      const tag = e.target.value.trim().replace(',', '');
                      if (tag && !editElement.tags.includes(tag)) {
                        setEditElement(prev => ({ ...prev, tags: [...prev.tags, tag] }));
                      }
                      e.target.value = '';
                    }
                  }}
                  style={{ width: '100%', padding: '10px 14px', background: colors.bg.tertiary, border: `1px solid ${colors.border.default}`, borderRadius: '8px', color: colors.text.primary, fontSize: '13px' }}
                />
              </div>
            </div>
            
            <div style={{ padding: '16px 24px', borderTop: `1px solid ${colors.border.default}`, display: 'flex', justifyContent: 'flex-end', gap: '12px' }}>
              <Button variant="secondary" onClick={() => setShowEditModal(false)}>Cancel</Button>
              <Button onClick={updateElement} disabled={!editElement.name || !editElement.prompt}>Save Changes</Button>
            </div>
          </div>
        </div>
      )}
      
      {/* Delete Confirmation Modal */}
      {showDeleteConfirm && selectedElement && (
        <div style={{ position: 'fixed', top: 0, left: 0, right: 0, bottom: 0, background: 'rgba(0,0,0,0.85)', display: 'flex', alignItems: 'center', justifyContent: 'center', zIndex: 1000 }}>
          <div style={{ width: '400px', background: colors.bg.secondary, borderRadius: '16px', overflow: 'hidden' }}>
            <div style={{ padding: '24px' }}>
              <div style={{ width: '48px', height: '48px', borderRadius: '50%', background: `${colors.accent.error}20`, display: 'flex', alignItems: 'center', justifyContent: 'center', margin: '0 auto 16px' }}>
                <Icons.AlertCircle style={{ width: 24, height: 24, color: colors.accent.error }} />
              </div>
              <h3 style={{ fontSize: '18px', fontWeight: '600', textAlign: 'center', marginBottom: '8px' }}>Delete Element?</h3>
              <p style={{ fontSize: '14px', color: colors.text.secondary, textAlign: 'center', marginBottom: '24px' }}>
                Are you sure you want to delete "<strong>{selectedElement.name}</strong>"? This action cannot be undone.
              </p>
              <div style={{ display: 'flex', gap: '12px' }}>
                <Button variant="secondary" style={{ flex: 1 }} onClick={() => setShowDeleteConfirm(false)}>Cancel</Button>
                <button
                  onClick={() => deleteElement(selectedElement.id)}
                  style={{
                    flex: 1,
                    padding: '12px 20px',
                    background: colors.accent.error,
                    border: 'none',
                    borderRadius: '8px',
                    color: 'white',
                    fontSize: '14px',
                    fontWeight: '500',
                    cursor: 'pointer',
                  }}
                >
                  Delete
                </button>
              </div>
            </div>
          </div>
        </div>
      )}
      
      {/* Bulk Import Modal */}
      {showBulkImportModal && (
        <div style={{ position: 'fixed', top: 0, left: 0, right: 0, bottom: 0, background: 'rgba(0,0,0,0.85)', display: 'flex', alignItems: 'center', justifyContent: 'center', zIndex: 1000 }}>
          <div style={{ width: '600px', maxHeight: '80vh', background: colors.bg.secondary, borderRadius: '16px', overflow: 'hidden', display: 'flex', flexDirection: 'column' }}>
            {/* Header */}
            <div style={{ padding: '20px 24px', borderBottom: `1px solid ${colors.border.subtle}`, display: 'flex', justifyContent: 'space-between', alignItems: 'center' }}>
              <div>
                <h2 style={{ fontSize: '18px', fontWeight: '600', marginBottom: '4px' }}>Bulk Import</h2>
                <p style={{ fontSize: '13px', color: colors.text.tertiary }}>Import multiple reference images at once</p>
              </div>
              <button onClick={() => { setShowBulkImportModal(false); setBulkImportFiles([]); }} style={{ background: 'none', border: 'none', color: colors.text.tertiary, cursor: 'pointer', fontSize: '20px' }}>×</button>
            </div>
            
            {/* Content */}
            <div style={{ flex: 1, overflow: 'auto', padding: '24px' }}>
              {/* Group Selection */}
              <div style={{ marginBottom: '20px' }}>
                <label style={{ display: 'block', fontSize: '13px', fontWeight: '500', marginBottom: '8px' }}>Import to Group</label>
                <select
                  value={bulkImportGroup}
                  onChange={(e) => setBulkImportGroup(e.target.value)}
                  style={{ width: '100%', padding: '12px 14px', background: colors.bg.tertiary, border: `1px solid ${colors.border.default}`, borderRadius: '8px', color: colors.text.primary, fontSize: '14px' }}
                >
                  {groups.map(g => (
                    <option key={g.id} value={g.id}>{g.icon} {g.name}</option>
                  ))}
                </select>
              </div>
              
              {/* Upload Area */}
              {bulkImportFiles.length === 0 ? (
                <div
                  onClick={handleBulkFileSelect}
                  style={{
                    border: `2px dashed ${colors.border.default}`,
                    borderRadius: '12px',
                    padding: '48px',
                    textAlign: 'center',
                    cursor: 'pointer',
                    transition: 'all 0.2s ease',
                  }}
                  onMouseEnter={(e) => { e.currentTarget.style.borderColor = colors.accent.primary; e.currentTarget.style.background = `${colors.accent.primary}10`; }}
                  onMouseLeave={(e) => { e.currentTarget.style.borderColor = colors.border.default; e.currentTarget.style.background = 'transparent'; }}
                >
                  <Icons.Upload style={{ width: 40, height: 40, color: colors.text.tertiary, margin: '0 auto 16px' }} />
                  <h3 style={{ fontSize: '16px', fontWeight: '600', marginBottom: '8px' }}>Drop files here or click to upload</h3>
                  <p style={{ fontSize: '13px', color: colors.text.tertiary }}>Supports JPG, PNG, WebP (max 10 files)</p>
                </div>
              ) : (
                <div>
                  <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center', marginBottom: '16px' }}>
                    <span style={{ fontSize: '14px', fontWeight: '500' }}>{bulkImportFiles.length} files selected</span>
                    <button
                      onClick={() => setBulkImportFiles([])}
                      style={{ background: 'none', border: 'none', color: colors.accent.error, fontSize: '13px', cursor: 'pointer' }}
                    >
                      Clear All
                    </button>
                  </div>
                  <div style={{ display: 'grid', gridTemplateColumns: 'repeat(3, 1fr)', gap: '12px' }}>
                    {bulkImportFiles.map((file, index) => (
                      <div key={index} style={{ position: 'relative' }}>
                        <div style={{
                          height: '100px',
                          background: file.preview,
                          borderRadius: '8px',
                          display: 'flex',
                          alignItems: 'center',
                          justifyContent: 'center',
                        }}>
                          <Icons.Image style={{ width: 24, height: 24, color: 'white', opacity: 0.7 }} />
                        </div>
                        <button
                          onClick={() => setBulkImportFiles(prev => prev.filter((_, i) => i !== index))}
                          style={{
                            position: 'absolute',
                            top: '4px',
                            right: '4px',
                            width: '20px',
                            height: '20px',
                            borderRadius: '50%',
                            background: 'rgba(0,0,0,0.6)',
                            border: 'none',
                            color: 'white',
                            cursor: 'pointer',
                            display: 'flex',
                            alignItems: 'center',
                            justifyContent: 'center',
                            fontSize: '12px',
                          }}
                        >
                          ×
                        </button>
                        <div style={{ fontSize: '11px', color: colors.text.secondary, marginTop: '6px', overflow: 'hidden', textOverflow: 'ellipsis', whiteSpace: 'nowrap' }}>
                          {file.name}
                        </div>
                      </div>
                    ))}
                    {/* Add More Button */}
                    <div
                      onClick={handleBulkFileSelect}
                      style={{
                        height: '100px',
                        border: `2px dashed ${colors.border.default}`,
                        borderRadius: '8px',
                        display: 'flex',
                        alignItems: 'center',
                        justifyContent: 'center',
                        cursor: 'pointer',
                      }}
                    >
                      <Icons.Plus style={{ width: 24, height: 24, color: colors.text.tertiary }} />
                    </div>
                  </div>
                </div>
              )}
              
              {/* Info Box */}
              <div style={{
                marginTop: '20px',
                padding: '14px',
                background: `${colors.accent.primary}10`,
                borderRadius: '8px',
                border: `1px solid ${colors.accent.primary}20`,
              }}>
                <div style={{ fontSize: '13px', fontWeight: '500', color: colors.accent.primary, marginBottom: '6px' }}>
                  💡 How it works
                </div>
                <ul style={{ margin: 0, paddingLeft: '20px', fontSize: '12px', color: colors.text.secondary, lineHeight: '1.6' }}>
                  <li>Each image will create a new element</li>
                  <li>Element names are derived from file names</li>
                  <li>Use AI Analyzer later to generate prompts</li>
                </ul>
              </div>
            </div>
            
            {/* Footer */}
            <div style={{ padding: '16px 24px', borderTop: `1px solid ${colors.border.subtle}`, display: 'flex', justifyContent: 'flex-end', gap: '12px' }}>
              <Button variant="secondary" onClick={() => { setShowBulkImportModal(false); setBulkImportFiles([]); }}>Cancel</Button>
              <Button 
                onClick={handleBulkImport} 
                disabled={bulkImportFiles.length === 0}
                style={{ opacity: bulkImportFiles.length === 0 ? 0.5 : 1 }}
              >
                Import {bulkImportFiles.length} Element{bulkImportFiles.length !== 1 ? 's' : ''}
              </Button>
            </div>
          </div>
        </div>
      )}
      
      {/* ================================================================== */}
      {/* CONSISTENT IMAGE GENERATOR MODAL */}
      {/* ================================================================== */}
      {showConsistentImageModal && consistentImageElement && (
        <div style={{
          position: 'fixed',
          top: 0,
          left: 0,
          right: 0,
          bottom: 0,
          background: 'rgba(0,0,0,0.8)',
          display: 'flex',
          alignItems: 'center',
          justifyContent: 'center',
          zIndex: 1000,
          padding: '20px',
        }}>
          <div style={{
            width: '100%',
            maxWidth: '1000px',
            maxHeight: '90vh',
            background: colors.bg.secondary,
            borderRadius: '16px',
            overflow: 'hidden',
            display: 'flex',
            flexDirection: 'column',
          }}>
            {/* Modal Header */}
            <div style={{
              padding: '20px 24px',
              borderBottom: `1px solid ${colors.border.subtle}`,
              display: 'flex',
              justifyContent: 'space-between',
              alignItems: 'center',
            }}>
              <div>
                <h2 style={{ fontSize: '20px', fontWeight: '600', marginBottom: '4px' }}>
                  {consistentImageElement.group === 'characters' ? 'Create Consistent Character' : 'Create Reference Images'}
                </h2>
                <p style={{ fontSize: '13px', color: colors.text.secondary }}>
                  Generate multi-angle reference images for {consistentImageElement.name}
                </p>
              </div>
              <button
                onClick={() => setShowConsistentImageModal(false)}
                style={{
                  background: 'none',
                  border: 'none',
                  color: colors.text.secondary,
                  cursor: 'pointer',
                  padding: '8px',
                }}
              >
                <Icons.X style={{ width: 20, height: 20 }} />
              </button>
            </div>
            
            {/* Reference & Settings Row */}
            <div style={{
              padding: '20px 24px',
              borderBottom: `1px solid ${colors.border.subtle}`,
              display: 'flex',
              gap: '24px',
              alignItems: 'flex-start',
            }}>
              {/* Reference Image */}
              <div style={{ flex: '0 0 120px' }}>
                <div style={{ fontSize: '12px', fontWeight: '600', color: colors.text.tertiary, marginBottom: '8px' }}>
                  REFERENCE
                </div>
                <div style={{
                  width: '120px',
                  height: '120px',
                  borderRadius: '12px',
                  background: consistentImageElement.generatedImages?.[0] || colors.bg.tertiary,
                  display: 'flex',
                  alignItems: 'center',
                  justifyContent: 'center',
                  border: `2px solid ${colors.border.default}`,
                }}>
                  {!consistentImageElement.generatedImages?.[0] && (
                    <span style={{ fontSize: '40px', color: colors.text.tertiary }}>{consistentImageElement.name.charAt(0)}</span>
                  )}
                </div>
              </div>
              
              {/* Base Prompt */}
              <div style={{ flex: 1 }}>
                <div style={{ fontSize: '12px', fontWeight: '600', color: colors.text.tertiary, marginBottom: '8px' }}>
                  BASE PROMPT
                </div>
                <div style={{
                  padding: '12px',
                  background: colors.bg.tertiary,
                  borderRadius: '8px',
                  fontSize: '13px',
                  color: colors.text.secondary,
                  lineHeight: '1.5',
                  maxHeight: '80px',
                  overflow: 'auto',
                }}>
                  {consistentImageElement.prompt || 'No prompt defined'}
                </div>
              </div>
              
              {/* Generator Selection */}
              <div style={{ flex: '0 0 200px' }}>
                <div style={{ fontSize: '12px', fontWeight: '600', color: colors.text.tertiary, marginBottom: '8px' }}>
                  IMAGE GENERATOR
                </div>
                <select
                  value={consistentImageGenerator}
                  onChange={(e) => setConsistentImageGenerator(e.target.value)}
                  style={{
                    width: '100%',
                    padding: '10px 12px',
                    background: colors.bg.tertiary,
                    border: `1px solid ${colors.border.default}`,
                    borderRadius: '8px',
                    color: colors.text.primary,
                    fontSize: '14px',
                  }}
                >
                  {consistentImageGenerators.map(gen => (
                    <option key={gen.id} value={gen.id}>{gen.name} ({gen.quality})</option>
                  ))}
                </select>
              </div>
            </div>
            
            {/* Image Generation Grid */}
            <div style={{ flex: 1, overflow: 'auto', padding: '24px' }}>
              {/* Master Turnaround */}
              <div style={{ marginBottom: '32px' }}>
                <div style={{ fontSize: '14px', fontWeight: '600', marginBottom: '12px', display: 'flex', alignItems: 'center', gap: '8px' }}>
                  <span style={{ width: '24px', height: '24px', background: colors.accent.primary, borderRadius: '6px', display: 'flex', alignItems: 'center', justifyContent: 'center', fontSize: '12px', fontWeight: '700' }}>1</span>
                  Master Turnaround Sheet
                  <span style={{ fontSize: '12px', fontWeight: '400', color: colors.text.tertiary }}>(All angles in one image)</span>
                </div>
                
                <div style={{
                  display: 'flex',
                  gap: '16px',
                  alignItems: 'flex-start',
                  padding: '16px',
                  background: colors.bg.tertiary,
                  borderRadius: '12px',
                }}>
                  {/* Image Preview */}
                  <div style={{
                    width: '200px',
                    height: '133px',
                    borderRadius: '8px',
                    background: consistentImages.masterTurnaround?.image || colors.bg.primary,
                    border: `2px dashed ${consistentImages.masterTurnaround?.image ? 'transparent' : colors.border.default}`,
                    display: 'flex',
                    alignItems: 'center',
                    justifyContent: 'center',
                    flexShrink: 0,
                  }}>
                    {consistentImages.masterTurnaround?.status === 'generating' ? (
                      <div style={{ textAlign: 'center' }}>
                        <div style={{ fontSize: '24px', marginBottom: '4px' }}>⏳</div>
                        <div style={{ fontSize: '11px', color: colors.text.tertiary }}>Generating...</div>
                      </div>
                    ) : !consistentImages.masterTurnaround?.image && (
                      <Icons.Image style={{ width: 32, height: 32, color: colors.text.tertiary, opacity: 0.5 }} />
                    )}
                  </div>
                  
                  {/* Prompt & Actions */}
                  <div style={{ flex: 1 }}>
                    <div style={{
                      padding: '10px 12px',
                      background: colors.bg.primary,
                      borderRadius: '8px',
                      fontSize: '12px',
                      color: colors.text.secondary,
                      lineHeight: '1.4',
                      maxHeight: '60px',
                      overflow: 'auto',
                      marginBottom: '12px',
                    }}>
                      {consistentImages.masterTurnaround?.prompt?.substring(0, 200)}...
                    </div>
                    <div style={{ display: 'flex', gap: '8px' }}>
                      <button
                        onClick={() => openPromptEditor('masterTurnaround')}
                        style={{
                          padding: '8px 12px',
                          background: colors.bg.primary,
                          border: `1px solid ${colors.border.default}`,
                          borderRadius: '6px',
                          color: colors.text.secondary,
                          fontSize: '12px',
                          cursor: 'pointer',
                          display: 'flex',
                          alignItems: 'center',
                          gap: '4px',
                        }}
                      >
                        <Icons.Edit style={{ width: 12, height: 12 }} />
                        Edit Prompt
                      </button>
                      <button
                        onClick={() => generateConsistentImage('masterTurnaround')}
                        disabled={isGenerating !== null}
                        style={{
                          padding: '8px 16px',
                          background: consistentImages.masterTurnaround?.status === 'completed' ? colors.bg.primary : 'linear-gradient(135deg, #8b5cf6 0%, #6d28d9 100%)',
                          border: consistentImages.masterTurnaround?.status === 'completed' ? `1px solid ${colors.border.default}` : 'none',
                          borderRadius: '6px',
                          color: 'white',
                          fontSize: '12px',
                          fontWeight: '500',
                          cursor: isGenerating !== null ? 'not-allowed' : 'pointer',
                          opacity: isGenerating !== null && isGenerating !== 'masterTurnaround' ? 0.5 : 1,
                        }}
                      >
                        {consistentImages.masterTurnaround?.status === 'completed' ? '↻ Regenerate' : 'Generate'}
                      </button>
                    </div>
                  </div>
                </div>
              </div>
              
              {/* Full Body Angles */}
              <div style={{ marginBottom: '32px' }}>
                <div style={{ fontSize: '14px', fontWeight: '600', marginBottom: '12px', display: 'flex', alignItems: 'center', gap: '8px' }}>
                  <span style={{ width: '24px', height: '24px', background: colors.accent.primary, borderRadius: '6px', display: 'flex', alignItems: 'center', justifyContent: 'center', fontSize: '12px', fontWeight: '700' }}>2</span>
                  Full Body Angles
                </div>
                
                <div style={{ display: 'grid', gridTemplateColumns: 'repeat(4, 1fr)', gap: '16px' }}>
                  {['frontFull', 'backFull', 'leftFull', 'rightFull'].map((key) => (
                    <div key={key} style={{
                      padding: '12px',
                      background: colors.bg.tertiary,
                      borderRadius: '12px',
                    }}>
                      <div style={{ fontSize: '12px', fontWeight: '500', marginBottom: '8px', textAlign: 'center' }}>
                        {consistentImagePromptTemplates[key].label}
                      </div>
                      <div style={{
                        aspectRatio: '2/3',
                        borderRadius: '8px',
                        background: consistentImages[key]?.image || colors.bg.primary,
                        border: `2px dashed ${consistentImages[key]?.image ? 'transparent' : colors.border.default}`,
                        display: 'flex',
                        alignItems: 'center',
                        justifyContent: 'center',
                        marginBottom: '8px',
                      }}>
                        {consistentImages[key]?.status === 'generating' ? (
                          <div style={{ fontSize: '20px' }}>⏳</div>
                        ) : !consistentImages[key]?.image && (
                          <Icons.Image style={{ width: 24, height: 24, color: colors.text.tertiary, opacity: 0.5 }} />
                        )}
                      </div>
                      <div style={{ display: 'flex', gap: '4px' }}>
                        <button
                          onClick={() => openPromptEditor(key)}
                          style={{
                            flex: 1,
                            padding: '6px',
                            background: colors.bg.primary,
                            border: `1px solid ${colors.border.default}`,
                            borderRadius: '4px',
                            color: colors.text.tertiary,
                            fontSize: '10px',
                            cursor: 'pointer',
                          }}
                        >
                          Edit
                        </button>
                        <button
                          onClick={() => generateConsistentImage(key)}
                          disabled={isGenerating !== null}
                          style={{
                            flex: 2,
                            padding: '6px',
                            background: consistentImages[key]?.status === 'completed' ? colors.bg.primary : colors.accent.primary,
                            border: consistentImages[key]?.status === 'completed' ? `1px solid ${colors.border.default}` : 'none',
                            borderRadius: '4px',
                            color: 'white',
                            fontSize: '10px',
                            cursor: isGenerating !== null ? 'not-allowed' : 'pointer',
                            opacity: isGenerating !== null && isGenerating !== key ? 0.5 : 1,
                          }}
                        >
                          {consistentImages[key]?.status === 'completed' ? '↻' : 'Generate'}
                        </button>
                      </div>
                    </div>
                  ))}
                </div>
              </div>
              
              {/* Headshot Angles - Only for Characters */}
              {consistentImageElement.group === 'characters' && (
                <div>
                  <div style={{ fontSize: '14px', fontWeight: '600', marginBottom: '12px', display: 'flex', alignItems: 'center', gap: '8px' }}>
                    <span style={{ width: '24px', height: '24px', background: colors.accent.primary, borderRadius: '6px', display: 'flex', alignItems: 'center', justifyContent: 'center', fontSize: '12px', fontWeight: '700' }}>3</span>
                    Headshot Angles
                    <span style={{ fontSize: '12px', fontWeight: '400', color: colors.text.tertiary }}>(Character only)</span>
                  </div>
                  
                  <div style={{ display: 'grid', gridTemplateColumns: 'repeat(4, 1fr)', gap: '16px' }}>
                    {['frontHead', 'backHead', 'leftHead', 'rightHead'].map((key) => (
                      <div key={key} style={{
                        padding: '12px',
                        background: colors.bg.tertiary,
                        borderRadius: '12px',
                      }}>
                        <div style={{ fontSize: '12px', fontWeight: '500', marginBottom: '8px', textAlign: 'center' }}>
                          {consistentImagePromptTemplates[key].label}
                        </div>
                        <div style={{
                          aspectRatio: '1/1',
                          borderRadius: '8px',
                          background: consistentImages[key]?.image || colors.bg.primary,
                          border: `2px dashed ${consistentImages[key]?.image ? 'transparent' : colors.border.default}`,
                          display: 'flex',
                          alignItems: 'center',
                          justifyContent: 'center',
                          marginBottom: '8px',
                        }}>
                          {consistentImages[key]?.status === 'generating' ? (
                            <div style={{ fontSize: '20px' }}>⏳</div>
                          ) : !consistentImages[key]?.image && (
                            <Icons.User style={{ width: 24, height: 24, color: colors.text.tertiary, opacity: 0.5 }} />
                          )}
                        </div>
                        <div style={{ display: 'flex', gap: '4px' }}>
                          <button
                            onClick={() => openPromptEditor(key)}
                            style={{
                              flex: 1,
                              padding: '6px',
                              background: colors.bg.primary,
                              border: `1px solid ${colors.border.default}`,
                              borderRadius: '4px',
                              color: colors.text.tertiary,
                              fontSize: '10px',
                              cursor: 'pointer',
                            }}
                          >
                            Edit
                          </button>
                          <button
                            onClick={() => generateConsistentImage(key)}
                            disabled={isGenerating !== null}
                            style={{
                              flex: 2,
                              padding: '6px',
                              background: consistentImages[key]?.status === 'completed' ? colors.bg.primary : colors.accent.primary,
                              border: consistentImages[key]?.status === 'completed' ? `1px solid ${colors.border.default}` : 'none',
                              borderRadius: '4px',
                              color: 'white',
                              fontSize: '10px',
                              cursor: isGenerating !== null ? 'not-allowed' : 'pointer',
                              opacity: isGenerating !== null && isGenerating !== key ? 0.5 : 1,
                            }}
                          >
                            {consistentImages[key]?.status === 'completed' ? '↻' : 'Generate'}
                          </button>
                        </div>
                      </div>
                    ))}
                  </div>
                </div>
              )}
            </div>
            
            {/* Modal Footer */}
            <div style={{
              padding: '16px 24px',
              borderTop: `1px solid ${colors.border.subtle}`,
              display: 'flex',
              justifyContent: 'space-between',
              alignItems: 'center',
            }}>
              <div style={{ fontSize: '13px', color: colors.text.tertiary }}>
                {Object.values(consistentImages).filter(img => img.status === 'completed').length} of {consistentImageElement.group === 'characters' ? 9 : 5} images generated
              </div>
              <div style={{ display: 'flex', gap: '12px' }}>
                <Button variant="secondary" onClick={() => setShowConsistentImageModal(false)}>
                  Cancel
                </Button>
                <Button 
                  onClick={saveConsistentImagesToElement}
                  disabled={Object.values(consistentImages).filter(img => img.status === 'completed').length === 0}
                  style={{ 
                    opacity: Object.values(consistentImages).filter(img => img.status === 'completed').length === 0 ? 0.5 : 1,
                    background: 'linear-gradient(135deg, #10b981 0%, #059669 100%)',
                  }}
                >
                  Save to Element
                </Button>
              </div>
            </div>
          </div>
        </div>
      )}
      
      {/* Prompt Edit Modal */}
      {showPromptEditModal && editingPromptType && (
        <div style={{
          position: 'fixed',
          top: 0,
          left: 0,
          right: 0,
          bottom: 0,
          background: 'rgba(0,0,0,0.8)',
          display: 'flex',
          alignItems: 'center',
          justifyContent: 'center',
          zIndex: 1001,
        }}>
          <div style={{
            width: '600px',
            background: colors.bg.secondary,
            borderRadius: '16px',
            overflow: 'hidden',
          }}>
            <div style={{
              padding: '20px 24px',
              borderBottom: `1px solid ${colors.border.subtle}`,
              display: 'flex',
              justifyContent: 'space-between',
              alignItems: 'center',
            }}>
              <h3 style={{ fontSize: '18px', fontWeight: '600' }}>
                Edit Prompt: {consistentImagePromptTemplates[editingPromptType]?.label}
              </h3>
              <button
                onClick={() => setShowPromptEditModal(false)}
                style={{ background: 'none', border: 'none', color: colors.text.secondary, cursor: 'pointer' }}
              >
                <Icons.X style={{ width: 20, height: 20 }} />
              </button>
            </div>
            
            <div style={{ padding: '24px' }}>
              <div style={{ marginBottom: '16px' }}>
                <div style={{ fontSize: '12px', fontWeight: '600', color: colors.text.tertiary, marginBottom: '8px' }}>
                  PROMPT TEMPLATE
                </div>
                <div style={{
                  padding: '12px',
                  background: colors.bg.tertiary,
                  borderRadius: '8px',
                  fontSize: '12px',
                  color: colors.text.tertiary,
                  marginBottom: '8px',
                }}>
                  <strong>Template:</strong> {consistentImagePromptTemplates[editingPromptType]?.description}
                </div>
              </div>
              
              <div style={{ marginBottom: '16px' }}>
                <div style={{ fontSize: '12px', fontWeight: '600', color: colors.text.tertiary, marginBottom: '8px' }}>
                  FULL PROMPT
                </div>
                <textarea
                  value={tempEditPrompt}
                  onChange={(e) => setTempEditPrompt(e.target.value)}
                  style={{
                    width: '100%',
                    height: '150px',
                    padding: '12px',
                    background: colors.bg.tertiary,
                    border: `1px solid ${colors.border.default}`,
                    borderRadius: '8px',
                    color: colors.text.primary,
                    fontSize: '13px',
                    lineHeight: '1.5',
                    resize: 'vertical',
                  }}
                />
              </div>
              
              <div style={{ marginBottom: '16px' }}>
                <div style={{ fontSize: '12px', fontWeight: '600', color: colors.text.tertiary, marginBottom: '8px' }}>
                  NEGATIVE PROMPT
                </div>
                <div style={{
                  padding: '12px',
                  background: colors.bg.tertiary,
                  borderRadius: '8px',
                  fontSize: '12px',
                  color: colors.text.secondary,
                  lineHeight: '1.4',
                }}>
                  {consistentImagePromptTemplates[editingPromptType]?.negativePrompt}
                </div>
              </div>
              
              <div style={{
                padding: '12px',
                background: `${colors.accent.primary}15`,
                borderRadius: '8px',
                border: `1px solid ${colors.accent.primary}30`,
              }}>
                <div style={{ fontSize: '12px', fontWeight: '600', color: colors.accent.primary, marginBottom: '4px' }}>
                  💡 Tips
                </div>
                <ul style={{ fontSize: '12px', color: colors.text.secondary, margin: 0, paddingLeft: '16px', lineHeight: '1.6' }}>
                  <li>Keep "orthographic" for flat, consistent angles</li>
                  <li>Use "A-pose" or "T-pose" to show outfit details</li>
                  <li>"Simple white background" makes cropping easier</li>
                  <li>Be specific about distinctive features (scars, jewelry, tattoos)</li>
                </ul>
              </div>
            </div>
            
            <div style={{
              padding: '16px 24px',
              borderTop: `1px solid ${colors.border.subtle}`,
              display: 'flex',
              justifyContent: 'flex-end',
              gap: '12px',
            }}>
              <Button variant="secondary" onClick={() => setShowPromptEditModal(false)}>
                Cancel
              </Button>
              <Button onClick={saveEditedPrompt}>
                Apply Changes
              </Button>
            </div>
          </div>
        </div>
      )}
    </div>
  );
};

// ============================================================================
// MY ASSETS VIEW
// ============================================================================
const MyAssetsView = ({ assets = [], onDeleteAsset, onNavigateToGenSpace }) => {
  const [filter, setFilter] = useState('all'); // 'all', 'images', 'videos'
  const [sortBy, setSortBy] = useState('newest'); // 'newest', 'oldest', 'name'
  const [searchQuery, setSearchQuery] = useState('');
  const [selectedAsset, setSelectedAsset] = useState(null);
  const [viewMode, setViewMode] = useState('grid'); // 'grid', 'list'
  
  // Filter and sort assets
  const filteredAssets = assets
    .filter(asset => {
      if (filter === 'images' && asset.type !== 'image') return false;
      if (filter === 'videos' && asset.type !== 'video') return false;
      if (searchQuery) {
        const query = searchQuery.toLowerCase();
        return (
          asset.prompt?.toLowerCase().includes(query) ||
          asset.generatorName?.toLowerCase().includes(query) ||
          asset.workflow?.toLowerCase().includes(query)
        );
      }
      return true;
    })
    .sort((a, b) => {
      if (sortBy === 'newest') return new Date(b.createdAt) - new Date(a.createdAt);
      if (sortBy === 'oldest') return new Date(a.createdAt) - new Date(b.createdAt);
      if (sortBy === 'name') return (a.prompt || '').localeCompare(b.prompt || '');
      return 0;
    });
  
  const imageCount = assets.filter(a => a.type === 'image').length;
  const videoCount = assets.filter(a => a.type === 'video').length;
  
  const formatDate = (dateString) => {
    const date = new Date(dateString);
    return date.toLocaleDateString('en-US', { month: 'short', day: 'numeric', year: 'numeric' });
  };
  
  return (
    <div style={{ flex: 1, display: 'flex', flexDirection: 'column', overflow: 'hidden' }}>
      {/* Header */}
      <div style={{ 
        padding: '24px 32px', 
        borderBottom: `1px solid ${colors.border.subtle}`,
        background: colors.bg.secondary,
      }}>
        <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'flex-start', marginBottom: '20px' }}>
          <div>
            <h1 style={{ fontSize: '28px', fontWeight: '700', marginBottom: '8px' }}>My Assets</h1>
            <p style={{ color: colors.text.secondary, fontSize: '14px' }}>
              {assets.length} total assets • {imageCount} images • {videoCount} videos
            </p>
          </div>
          <button
            onClick={onNavigateToGenSpace}
            style={{
              display: 'flex',
              alignItems: 'center',
              gap: '8px',
              padding: '12px 20px',
              background: `linear-gradient(135deg, ${colors.accent.primary}, ${colors.accent.secondary})`,
              border: 'none',
              borderRadius: '10px',
              color: 'white',
              fontSize: '14px',
              fontWeight: '600',
              cursor: 'pointer',
              boxShadow: `0 4px 15px ${colors.accent.primary}40`,
            }}
          >
            <Icons.Sparkles style={{ width: 16, height: 16 }} />
            Generate New
          </button>
        </div>
        
        {/* Filters & Search */}
        <div style={{ display: 'flex', gap: '16px', alignItems: 'center', flexWrap: 'wrap' }}>
          {/* Type Filter */}
          <div style={{ display: 'flex', gap: '4px', background: colors.bg.tertiary, borderRadius: '8px', padding: '4px' }}>
            {[
              { id: 'all', label: 'All' },
              { id: 'images', label: 'Images' },
              { id: 'videos', label: 'Videos' },
            ].map(opt => (
              <button
                key={opt.id}
                onClick={() => setFilter(opt.id)}
                style={{
                  padding: '8px 16px',
                  background: filter === opt.id ? colors.bg.secondary : 'transparent',
                  border: 'none',
                  borderRadius: '6px',
                  color: filter === opt.id ? colors.text.primary : colors.text.secondary,
                  fontSize: '13px',
                  fontWeight: '500',
                  cursor: 'pointer',
                }}
              >
                {opt.label}
              </button>
            ))}
          </div>
          
          {/* Search */}
          <div style={{ 
            flex: 1, 
            maxWidth: '300px', 
            display: 'flex', 
            alignItems: 'center', 
            gap: '10px', 
            padding: '8px 14px', 
            background: colors.bg.tertiary, 
            border: `1px solid ${colors.border.subtle}`, 
            borderRadius: '8px' 
          }}>
            <Icons.Search style={{ width: 16, height: 16, color: colors.text.tertiary }} />
            <input
              type="text"
              placeholder="Search assets..."
              value={searchQuery}
              onChange={(e) => setSearchQuery(e.target.value)}
              style={{ 
                flex: 1, 
                background: 'none', 
                border: 'none', 
                color: colors.text.primary, 
                fontSize: '13px', 
                outline: 'none' 
              }}
            />
          </div>
          
          {/* Sort */}
          <select
            value={sortBy}
            onChange={(e) => setSortBy(e.target.value)}
            style={{
              padding: '8px 14px',
              background: colors.bg.tertiary,
              border: `1px solid ${colors.border.subtle}`,
              borderRadius: '8px',
              color: colors.text.primary,
              fontSize: '13px',
              cursor: 'pointer',
            }}
          >
            <option value="newest">Newest First</option>
            <option value="oldest">Oldest First</option>
            <option value="name">By Prompt</option>
          </select>
          
          {/* View Mode */}
          <div style={{ display: 'flex', gap: '4px', marginLeft: 'auto' }}>
            <button
              onClick={() => setViewMode('grid')}
              style={{
                padding: '8px 12px',
                background: viewMode === 'grid' ? colors.accent.primary : colors.bg.tertiary,
                border: 'none',
                borderRadius: '6px',
                color: viewMode === 'grid' ? 'white' : colors.text.secondary,
                cursor: 'pointer',
              }}
            >
              <Icons.Layout style={{ width: 16, height: 16 }} />
            </button>
            <button
              onClick={() => setViewMode('list')}
              style={{
                padding: '8px 12px',
                background: viewMode === 'list' ? colors.accent.primary : colors.bg.tertiary,
                border: 'none',
                borderRadius: '6px',
                color: viewMode === 'list' ? 'white' : colors.text.secondary,
                cursor: 'pointer',
              }}
            >
              <Icons.Menu style={{ width: 16, height: 16 }} />
            </button>
          </div>
        </div>
      </div>
      
      {/* Content */}
      <div style={{ flex: 1, overflow: 'auto', padding: '24px 32px' }}>
        {filteredAssets.length === 0 ? (
          <div style={{ 
            display: 'flex', 
            flexDirection: 'column', 
            alignItems: 'center', 
            justifyContent: 'center', 
            height: '100%',
            textAlign: 'center',
          }}>
            <div style={{
              width: '80px',
              height: '80px',
              borderRadius: '20px',
              background: colors.bg.tertiary,
              display: 'flex',
              alignItems: 'center',
              justifyContent: 'center',
              marginBottom: '20px',
            }}>
              <Icons.Image style={{ width: 32, height: 32, color: colors.text.tertiary }} />
            </div>
            <h3 style={{ fontSize: '18px', fontWeight: '600', marginBottom: '8px' }}>
              {searchQuery ? 'No assets found' : 'No assets yet'}
            </h3>
            <p style={{ color: colors.text.tertiary, marginBottom: '20px', maxWidth: '300px' }}>
              {searchQuery 
                ? 'Try adjusting your search or filters' 
                : 'Generate images and videos in GenSpace to see them here'}
            </p>
            {!searchQuery && (
              <button
                onClick={onNavigateToGenSpace}
                style={{
                  padding: '10px 20px',
                  background: colors.accent.primary,
                  border: 'none',
                  borderRadius: '8px',
                  color: 'white',
                  fontSize: '14px',
                  fontWeight: '500',
                  cursor: 'pointer',
                }}
              >
                Go to GenSpace
              </button>
            )}
          </div>
        ) : viewMode === 'grid' ? (
          <div style={{ 
            display: 'grid', 
            gridTemplateColumns: 'repeat(auto-fill, minmax(280px, 1fr))', 
            gap: '20px' 
          }}>
            {filteredAssets.map(asset => (
              <div
                key={asset.id}
                style={{
                  background: colors.bg.secondary,
                  borderRadius: '12px',
                  overflow: 'hidden',
                  border: `1px solid ${colors.border.subtle}`,
                  cursor: 'pointer',
                  transition: 'all 0.2s ease',
                }}
                onClick={() => setSelectedAsset(asset)}
                onMouseEnter={(e) => {
                  e.currentTarget.style.borderColor = colors.accent.primary;
                  e.currentTarget.style.transform = 'translateY(-2px)';
                }}
                onMouseLeave={(e) => {
                  e.currentTarget.style.borderColor = colors.border.subtle;
                  e.currentTarget.style.transform = 'translateY(0)';
                }}
              >
                {/* Thumbnail */}
                <div style={{
                  height: '180px',
                  background: asset.thumbnail || `linear-gradient(135deg, hsl(${parseInt(asset.id.split('-')[1]) % 360}, 50%, 35%), hsl(${(parseInt(asset.id.split('-')[1]) + 40) % 360}, 50%, 45%))`,
                  display: 'flex',
                  alignItems: 'center',
                  justifyContent: 'center',
                  position: 'relative',
                }}>
                  {asset.type === 'video' ? (
                    <Icons.Film style={{ width: 40, height: 40, color: 'rgba(255,255,255,0.8)' }} />
                  ) : (
                    <Icons.Image style={{ width: 40, height: 40, color: 'rgba(255,255,255,0.8)' }} />
                  )}
                  {/* Type Badge */}
                  <span style={{
                    position: 'absolute',
                    top: '10px',
                    left: '10px',
                    padding: '4px 8px',
                    background: 'rgba(0,0,0,0.6)',
                    borderRadius: '4px',
                    fontSize: '10px',
                    fontWeight: '600',
                    color: 'white',
                    textTransform: 'uppercase',
                  }}>
                    {asset.type}
                  </span>
                  {/* Workflow Badge */}
                  <span style={{
                    position: 'absolute',
                    top: '10px',
                    right: '10px',
                    padding: '4px 8px',
                    background: `${colors.accent.primary}cc`,
                    borderRadius: '4px',
                    fontSize: '10px',
                    fontWeight: '500',
                    color: 'white',
                  }}>
                    {asset.workflow}
                  </span>
                </div>
                
                {/* Info */}
                <div style={{ padding: '14px' }}>
                  <p style={{ 
                    fontSize: '13px', 
                    color: colors.text.primary, 
                    marginBottom: '8px',
                    overflow: 'hidden',
                    textOverflow: 'ellipsis',
                    display: '-webkit-box',
                    WebkitLineClamp: 2,
                    WebkitBoxOrient: 'vertical',
                    lineHeight: '1.4',
                  }}>
                    {asset.prompt || 'Image reference'}
                  </p>
                  <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center' }}>
                    <span style={{ fontSize: '11px', color: colors.text.tertiary }}>
                      {asset.generatorName}
                    </span>
                    <span style={{ fontSize: '11px', color: colors.text.tertiary }}>
                      {formatDate(asset.createdAt)}
                    </span>
                  </div>
                </div>
              </div>
            ))}
          </div>
        ) : (
          // List View
          <div style={{ display: 'flex', flexDirection: 'column', gap: '8px' }}>
            {filteredAssets.map(asset => (
              <div
                key={asset.id}
                onClick={() => setSelectedAsset(asset)}
                style={{
                  display: 'flex',
                  alignItems: 'center',
                  gap: '16px',
                  padding: '12px 16px',
                  background: colors.bg.secondary,
                  borderRadius: '10px',
                  border: `1px solid ${colors.border.subtle}`,
                  cursor: 'pointer',
                  transition: 'all 0.2s ease',
                }}
                onMouseEnter={(e) => e.currentTarget.style.borderColor = colors.accent.primary}
                onMouseLeave={(e) => e.currentTarget.style.borderColor = colors.border.subtle}
              >
                {/* Thumbnail */}
                <div style={{
                  width: '60px',
                  height: '60px',
                  borderRadius: '8px',
                  background: asset.thumbnail || `linear-gradient(135deg, hsl(${parseInt(asset.id.split('-')[1]) % 360}, 50%, 35%), hsl(${(parseInt(asset.id.split('-')[1]) + 40) % 360}, 50%, 45%))`,
                  display: 'flex',
                  alignItems: 'center',
                  justifyContent: 'center',
                  flexShrink: 0,
                }}>
                  {asset.type === 'video' ? (
                    <Icons.Film style={{ width: 20, height: 20, color: 'rgba(255,255,255,0.8)' }} />
                  ) : (
                    <Icons.Image style={{ width: 20, height: 20, color: 'rgba(255,255,255,0.8)' }} />
                  )}
                </div>
                
                {/* Info */}
                <div style={{ flex: 1, minWidth: 0 }}>
                  <p style={{ 
                    fontSize: '14px', 
                    color: colors.text.primary,
                    overflow: 'hidden',
                    textOverflow: 'ellipsis',
                    whiteSpace: 'nowrap',
                    marginBottom: '4px',
                  }}>
                    {asset.prompt || 'Image reference'}
                  </p>
                  <div style={{ display: 'flex', gap: '12px', fontSize: '12px', color: colors.text.tertiary }}>
                    <span>{asset.workflow}</span>
                    <span>•</span>
                    <span>{asset.generatorName}</span>
                  </div>
                </div>
                
                {/* Meta */}
                <div style={{ textAlign: 'right', flexShrink: 0 }}>
                  <span style={{ 
                    display: 'inline-block',
                    padding: '4px 8px',
                    background: asset.type === 'video' ? colors.accent.secondary : colors.accent.primary,
                    borderRadius: '4px',
                    fontSize: '10px',
                    fontWeight: '600',
                    color: 'white',
                    textTransform: 'uppercase',
                    marginBottom: '4px',
                  }}>
                    {asset.type}
                  </span>
                  <div style={{ fontSize: '11px', color: colors.text.tertiary }}>
                    {formatDate(asset.createdAt)}
                  </div>
                </div>
              </div>
            ))}
          </div>
        )}
      </div>
      
      {/* Asset Detail Modal */}
      {selectedAsset && (
        <div 
          style={{
            position: 'fixed',
            top: 0,
            left: 0,
            right: 0,
            bottom: 0,
            background: 'rgba(0,0,0,0.85)',
            display: 'flex',
            alignItems: 'center',
            justifyContent: 'center',
            zIndex: 1000,
          }}
          onClick={() => setSelectedAsset(null)}
        >
          <div 
            style={{
              width: '800px',
              maxHeight: '90vh',
              background: colors.bg.secondary,
              borderRadius: '16px',
              overflow: 'hidden',
              display: 'flex',
              flexDirection: 'column',
            }}
            onClick={(e) => e.stopPropagation()}
          >
            {/* Preview */}
            <div style={{
              height: '400px',
              background: selectedAsset.thumbnail || `linear-gradient(135deg, hsl(${parseInt(selectedAsset.id.split('-')[1]) % 360}, 50%, 35%), hsl(${(parseInt(selectedAsset.id.split('-')[1]) + 40) % 360}, 50%, 45%))`,
              display: 'flex',
              alignItems: 'center',
              justifyContent: 'center',
              position: 'relative',
            }}>
              {selectedAsset.type === 'video' ? (
                <Icons.Film style={{ width: 64, height: 64, color: 'rgba(255,255,255,0.8)' }} />
              ) : (
                <Icons.Image style={{ width: 64, height: 64, color: 'rgba(255,255,255,0.8)' }} />
              )}
              <button
                onClick={() => setSelectedAsset(null)}
                style={{
                  position: 'absolute',
                  top: '16px',
                  right: '16px',
                  width: '36px',
                  height: '36px',
                  borderRadius: '50%',
                  background: 'rgba(0,0,0,0.5)',
                  border: 'none',
                  color: 'white',
                  cursor: 'pointer',
                  display: 'flex',
                  alignItems: 'center',
                  justifyContent: 'center',
                }}
              >
                <Icons.X style={{ width: 18, height: 18 }} />
              </button>
            </div>
            
            {/* Details */}
            <div style={{ padding: '24px', overflow: 'auto' }}>
              <div style={{ display: 'flex', gap: '8px', marginBottom: '16px' }}>
                <span style={{
                  padding: '4px 10px',
                  background: selectedAsset.type === 'video' ? colors.accent.secondary : colors.accent.primary,
                  borderRadius: '4px',
                  fontSize: '11px',
                  fontWeight: '600',
                  color: 'white',
                  textTransform: 'uppercase',
                }}>
                  {selectedAsset.type}
                </span>
                <span style={{
                  padding: '4px 10px',
                  background: colors.bg.tertiary,
                  borderRadius: '4px',
                  fontSize: '11px',
                  color: colors.text.secondary,
                }}>
                  {selectedAsset.workflow}
                </span>
              </div>
              
              <h3 style={{ fontSize: '16px', fontWeight: '600', marginBottom: '8px' }}>Prompt</h3>
              <p style={{ fontSize: '14px', color: colors.text.secondary, lineHeight: '1.5', marginBottom: '20px' }}>
                {selectedAsset.prompt || 'No prompt (image reference used)'}
              </p>
              
              <div style={{ display: 'grid', gridTemplateColumns: 'repeat(3, 1fr)', gap: '16px', marginBottom: '20px' }}>
                <div>
                  <div style={{ fontSize: '11px', color: colors.text.tertiary, marginBottom: '4px', textTransform: 'uppercase' }}>Generator</div>
                  <div style={{ fontSize: '14px', color: colors.text.primary }}>{selectedAsset.generatorName}</div>
                </div>
                <div>
                  <div style={{ fontSize: '11px', color: colors.text.tertiary, marginBottom: '4px', textTransform: 'uppercase' }}>Created</div>
                  <div style={{ fontSize: '14px', color: colors.text.primary }}>{formatDate(selectedAsset.createdAt)}</div>
                </div>
                <div>
                  <div style={{ fontSize: '11px', color: colors.text.tertiary, marginBottom: '4px', textTransform: 'uppercase' }}>Aspect Ratio</div>
                  <div style={{ fontSize: '14px', color: colors.text.primary }}>{selectedAsset.settings?.aspectRatio || '16:9'}</div>
                </div>
              </div>
              
              {/* Settings Summary */}
              {selectedAsset.settings && (
                <div style={{ 
                  padding: '16px', 
                  background: colors.bg.tertiary, 
                  borderRadius: '10px',
                  marginBottom: '20px',
                }}>
                  <div style={{ fontSize: '12px', color: colors.text.tertiary, marginBottom: '10px', textTransform: 'uppercase' }}>Generation Settings</div>
                  <div style={{ display: 'flex', flexWrap: 'wrap', gap: '8px' }}>
                    {selectedAsset.settings.shotSize && <span style={{ padding: '4px 8px', background: colors.bg.secondary, borderRadius: '4px', fontSize: '11px', color: colors.text.secondary }}>Shot: {selectedAsset.settings.shotSize}</span>}
                    {selectedAsset.settings.cameraAngle && <span style={{ padding: '4px 8px', background: colors.bg.secondary, borderRadius: '4px', fontSize: '11px', color: colors.text.secondary }}>Angle: {selectedAsset.settings.cameraAngle}</span>}
                    {selectedAsset.settings.lightingStyle && <span style={{ padding: '4px 8px', background: colors.bg.secondary, borderRadius: '4px', fontSize: '11px', color: colors.text.secondary }}>Light: {selectedAsset.settings.lightingStyle}</span>}
                    {selectedAsset.settings.colorGrade && <span style={{ padding: '4px 8px', background: colors.bg.secondary, borderRadius: '4px', fontSize: '11px', color: colors.text.secondary }}>Grade: {selectedAsset.settings.colorGrade}</span>}
                    {selectedAsset.settings.aesthetic && <span style={{ padding: '4px 8px', background: colors.bg.secondary, borderRadius: '4px', fontSize: '11px', color: colors.text.secondary }}>Style: {selectedAsset.settings.aesthetic}</span>}
                  </div>
                </div>
              )}
              
              {/* Actions */}
              <div style={{ display: 'flex', gap: '12px' }}>
                <Button variant="primary" style={{ flex: 1 }}>
                  <Icons.Download style={{ width: 14, height: 14, marginRight: '6px' }} />
                  Download
                </Button>
                <Button variant="secondary" style={{ flex: 1 }}>
                  Add to Storyboard
                </Button>
                <button
                  onClick={() => {
                    if (onDeleteAsset) {
                      onDeleteAsset(selectedAsset.id);
                      setSelectedAsset(null);
                    }
                  }}
                  style={{
                    padding: '10px 16px',
                    background: 'transparent',
                    border: `1px solid ${colors.accent.error}`,
                    borderRadius: '8px',
                    color: colors.accent.error,
                    fontSize: '14px',
                    cursor: 'pointer',
                  }}
                >
                  Delete
                </button>
              </div>
            </div>
          </div>
        </div>
      )}
    </div>
  );
};

// ============================================================================
// PLACEHOLDER VIEWS
// ============================================================================
const PlaceholderView = ({ title, description, icon }) => (
  <div style={{ flex: 1, overflow: 'auto', padding: '32px 40px' }}>
    {/* Header */}
    <div style={{ marginBottom: '40px' }}>
      <h1 style={{ fontSize: '28px', fontWeight: '700', marginBottom: '8px' }}>{title}</h1>
      <p style={{ fontSize: '14px', color: colors.text.secondary }}>{description}</p>
    </div>
    
    {/* Placeholder Content */}
    <div style={{
      display: 'flex',
      alignItems: 'center',
      justifyContent: 'center',
      flexDirection: 'column',
      padding: '80px 40px',
      background: colors.bg.secondary,
      borderRadius: '16px',
      border: `1px solid ${colors.border.subtle}`,
    }}>
      <div style={{
        width: '80px',
        height: '80px',
        borderRadius: '20px',
        background: colors.bg.tertiary,
        display: 'flex',
        alignItems: 'center',
        justifyContent: 'center',
        marginBottom: '24px',
        color: colors.text.tertiary,
      }}>
        {icon}
      </div>
      <p style={{ fontSize: '16px', color: colors.text.tertiary, textAlign: 'center', maxWidth: '400px' }}>
        Coming soon
      </p>
    </div>
  </div>
);

// ============================================================================
// MAIN APP
// ============================================================================
export default function App() {
  const [showLanding, setShowLanding] = useState(true); // Show landing page first
  const [currentView, setCurrentView] = useState('home');
  const [currentProject, setCurrentProject] = useState(null);
  const [currentEpisode, setCurrentEpisode] = useState(null);
  const [editingProjectSetup, setEditingProjectSetup] = useState(false); // For editing existing project setup
  
  // Load projects from localStorage on mount
  const [projects, setProjects] = useState(() => {
    try {
      const saved = localStorage.getItem('basement-projects');
      return saved ? JSON.parse(saved) : [];
    } catch (e) {
      console.error('Failed to load projects from localStorage:', e);
      return [];
    }
  });
  
  // Global generated assets state with localStorage persistence
  const [generatedAssets, setGeneratedAssets] = useState(() => {
    try {
      const saved = localStorage.getItem('basement-assets');
      return saved ? JSON.parse(saved) : [];
    } catch (e) {
      console.error('Failed to load assets from localStorage:', e);
      return [];
    }
  });
  
  // Save projects to localStorage whenever they change
  React.useEffect(() => {
    try {
      localStorage.setItem('basement-projects', JSON.stringify(projects));
      console.log('Projects saved to localStorage:', projects.length, 'projects');
    } catch (e) {
      console.error('Failed to save projects to localStorage:', e);
    }
  }, [projects]);
  
  // Save generated assets to localStorage whenever they change
  React.useEffect(() => {
    try {
      localStorage.setItem('basement-assets', JSON.stringify(generatedAssets));
      console.log('Assets saved to localStorage:', generatedAssets.length, 'assets');
    } catch (e) {
      console.error('Failed to save assets to localStorage:', e);
    }
  }, [generatedAssets]);
  
  // Function to add new generated asset
  const addGeneratedAsset = (asset) => {
    setGeneratedAssets(prev => [asset, ...prev]);
  };
  
  // Function to delete asset
  const deleteAsset = (assetId) => {
    setGeneratedAssets(prev => prev.filter(a => a.id !== assetId));
  };
  
  // Also save currentProject when it changes
  React.useEffect(() => {
    if (currentProject) {
      setProjects((prev) => prev.map(p => p.id === currentProject.id ? currentProject : p));
    }
  }, [currentProject]);
  
  const handleProjectComplete = (project) => {
    console.log('Project created:', project);
    setProjects((prev) => [project, ...prev]);
    setCurrentProject(project);
    console.log('Navigating to episode-setup');
    setCurrentView('episode-setup');
  };
  
  const handleUpdateProject = (updatedProject) => {
    setCurrentProject(updatedProject);
    setProjects((prev) => prev.map(p => p.id === updatedProject.id ? updatedProject : p));
  };
  
  const handleDeleteProject = (projectId) => {
    setProjects((prev) => prev.filter(p => p.id !== projectId));
    if (currentProject?.id === projectId) {
      setCurrentProject(null);
      setCurrentView('home');
    }
  };
  
  const handleNavigateToStoryboard = (episode) => {
    setCurrentEpisode(episode);
    setCurrentView('storyboard');
  };
  
  const renderContent = () => {
    switch (currentView) {
      case 'home':
        return (
          <HomeView
            setCurrentView={setCurrentView}
            projects={projects}
            setCurrentProject={setCurrentProject}
            generatedAssets={generatedAssets}
          />
        );
      case 'templates':
        return (
          <TemplatesView
            setCurrentView={setCurrentView}
          />
        );
      case 'projects':
        return (
          <ProjectsView
            projects={projects}
            setCurrentProject={setCurrentProject}
            setCurrentView={setCurrentView}
            onDeleteProject={handleDeleteProject}
          />
        );
      case 'new-project':
        return (
          <NewProjectWizard
            onComplete={handleProjectComplete}
            onCancel={() => setCurrentView('home')}
          />
        );
      case 'episode-setup':
        return (
          <EpisodeSetupView
            project={currentProject}
            onUpdateProject={handleUpdateProject}
            onNavigateToStoryboard={(episode) => {
              setCurrentEpisode(episode);
              setCurrentView('storyboard');
            }}
            onEditProjectSetup={() => {
              setEditingProjectSetup(true);
              setCurrentView('edit-project-setup');
            }}
          />
        );
      case 'edit-project-setup':
        return (
          <EditProjectWizard
            project={currentProject}
            onSave={(updatedProject) => {
              setCurrentProject(updatedProject);
              setProjects(prev => prev.map(p => p.id === updatedProject.id ? updatedProject : p));
              setEditingProjectSetup(false);
              setCurrentView('episode-setup');
            }}
            onCancel={() => {
              setEditingProjectSetup(false);
              setCurrentView('episode-setup');
            }}
          />
        );
      case 'gen-space':
        return <GenSpaceView onAddAsset={addGeneratedAsset} assets={generatedAssets} />;
      case 'storyboard':
        return (
          <StoryboardView
            project={currentProject}
            episode={currentEpisode}
            onUpdateProject={handleUpdateProject}
            onBack={() => setCurrentView('episode-setup')}
            onNavigateToRoughCut={(ep) => {
              setCurrentEpisode(ep);
              setCurrentView('rough-cut');
            }}
          />
        );
      case 'rough-cut':
        return (
          <RoughCutView
            project={currentProject}
            episode={currentEpisode}
            onBack={() => setCurrentView('storyboard')}
            onNavigateToPost={(ep) => {
              setCurrentEpisode(ep);
              setCurrentView('post');
            }}
          />
        );
      case 'post':
        return (
          <PostProductionView
            project={currentProject}
            episode={currentEpisode}
            onBack={() => setCurrentView('rough-cut')}
            onExport={() => alert('Export functionality coming soon!')}
          />
        );
      case 'promo-studio':
        return <PromoStudioView setCurrentView={setCurrentView} />;
      case 'elements':
        return <ElementsView onNavigateToGenSpace={(element) => {
          // Store element for Gen Space to use
          setCurrentView('gen-space');
          // In a real app, you'd pass this via context or state management
        }} />;
      case 'assets':
        return <MyAssetsView assets={generatedAssets} onDeleteAsset={deleteAsset} onNavigateToGenSpace={() => setCurrentView('gen-space')} />;
      case 'settings':
        return <PlaceholderView title="Settings" description="Configure your project settings" icon={<Icons.Settings />} />;
      default:
        return <HomeView setCurrentView={setCurrentView} projects={projects} setCurrentProject={setCurrentProject} generatedAssets={generatedAssets} />;
    }
  };
  
  return (
    <>
      <style>{globalStyles}</style>
      {showLanding ? (
        <LandingPage onEnter={() => setShowLanding(false)} />
      ) : (
        <div style={{
          display: 'flex',
          height: '100vh',
          background: colors.bg.primary,
        }}>
          <Sidebar
            currentView={currentView}
            setCurrentView={setCurrentView}
            currentProject={currentProject}
          />
          <div style={{
            flex: 1,
            display: 'flex',
            flexDirection: 'column',
            overflow: 'hidden',
          }}>
            {renderContent()}
          </div>
        </div>
      )}
    </>
  );
}
