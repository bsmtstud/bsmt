// ============================================================================
// THE BASEMENT - TypeScript Types
// ============================================================================

// ============================================================================
// ENUMS
// ============================================================================

export type ProjectType = 'short' | 'film' | 'series';

export type ProjectPhase = 
  | 'development' 
  | 'pre-production' 
  | 'production' 
  | 'post-production' 
  | 'complete';

export type FilmStyle = 'cinematic' | 'documentary' | 'animated' | 'experimental';

export type VideoStyle = 
  | 'photorealistic' 
  | 'cinematic-color' 
  | 'noir' 
  | 'vintage' 
  | 'neon-noir' 
  | 'pastel';

export type GenerationStatus = 'pending' | 'processing' | 'completed' | 'failed';

export type ShotType = 
  | 'wide' 
  | 'medium' 
  | 'close-up' 
  | 'extreme-close-up' 
  | 'over-shoulder' 
  | 'pov' 
  | 'aerial' 
  | 'tracking';

export type CameraMovement = 
  | 'static' 
  | 'pan' 
  | 'tilt' 
  | 'dolly' 
  | 'crane' 
  | 'handheld' 
  | 'steadicam' 
  | 'drone';

export type CollaboratorRole = 'owner' | 'editor' | 'viewer' | 'commenter';

export type ElementCategory = 
  | 'prop' 
  | 'location' 
  | 'vehicle' 
  | 'creature' 
  | 'effect' 
  | 'other';

export type ImageGenerator = 
  | 'flux-pro' 
  | 'nano-banana' 
  | 'midjourney' 
  | 'grok-imagine';

export type VideoGenerator = 
  | 'sora-2' 
  | 'runway-gen3' 
  | 'kling-1.6' 
  | 'veo-2' 
  | 'minimax' 
  | 'luma-ray2';

// ============================================================================
// DATABASE TYPES
// ============================================================================

export interface Profile {
  id: string;
  email: string | null;
  full_name: string | null;
  avatar_url: string | null;
  subscription_tier: string;
  generation_credits: number;
  created_at: string;
  updated_at: string;
}

export interface Project {
  id: string;
  user_id: string;
  title: string;
  project_type: ProjectType;
  phase: ProjectPhase;
  logline: string | null;
  theme: string | null;
  genre: string | null;
  subgenres: string[] | null;
  tones: string[] | null;
  film_style: FilmStyle | null;
  video_style: VideoStyle | null;
  seasons: number | null;
  episodes_per_season: number | null;
  episode_length: number | null;
  runtime: number | null;
  primary_image_generator: ImageGenerator | null;
  primary_video_generator: VideoGenerator | null;
  reference_studios: string | null;
  reference_films: string | null;
  style_ref_visual: string | null;
  style_ref_camera: string | null;
  style_ref_tone: string | null;
  style_ref_lighting: string | null;
  thumbnail_url: string | null;
  created_at: string;
  updated_at: string;
  last_accessed_at: string;
}

export interface Episode {
  id: string;
  project_id: string;
  season_number: number;
  episode_number: number;
  title: string | null;
  synopsis: string | null;
  script_content: string | null;
  script_version: number;
  target_duration: number | null;
  status: string;
  created_at: string;
  updated_at: string;
}

export interface Scene {
  id: string;
  project_id: string;
  episode_id: string | null;
  scene_number: number;
  title: string | null;
  description: string | null;
  location: string | null;
  time_of_day: string | null;
  mood: string | null;
  script_content: string | null;
  estimated_duration: number | null;
  thumbnail_url: string | null;
  sort_order: number;
  created_at: string;
  updated_at: string;
}

export interface Shot {
  id: string;
  scene_id: string;
  project_id: string;
  shot_number: number;
  shot_type: ShotType;
  camera_movement: CameraMovement;
  description: string | null;
  visual_prompt: string | null;
  duration: number;
  dialogue: string | null;
  action_description: string | null;
  camera_notes: string | null;
  lighting_notes: string | null;
  audio_notes: string | null;
  selected_image_id: string | null;
  selected_video_id: string | null;
  sort_order: number;
  created_at: string;
  updated_at: string;
}

export interface Character {
  id: string;
  project_id: string;
  name: string;
  role: string | null;
  age: string | null;
  gender: string | null;
  physical_description: string | null;
  personality: string | null;
  backstory: string | null;
  motivations: string | null;
  reference_prompt: string | null;
  primary_image_url: string | null;
  created_at: string;
  updated_at: string;
}

export interface CharacterImage {
  id: string;
  character_id: string;
  angle: string;
  image_url: string;
  prompt_used: string | null;
  generator_used: string | null;
  generation_params: Record<string, any> | null;
  is_approved: boolean;
  created_at: string;
}

export interface Element {
  id: string;
  project_id: string;
  name: string;
  category: ElementCategory;
  description: string | null;
  reference_prompt: string | null;
  primary_image_url: string | null;
  tags: string[] | null;
  created_at: string;
  updated_at: string;
}

export interface GeneratedImage {
  id: string;
  project_id: string;
  shot_id: string | null;
  character_id: string | null;
  element_id: string | null;
  prompt: string;
  negative_prompt: string | null;
  generator: ImageGenerator;
  params: Record<string, any> | null;
  image_url: string | null;
  thumbnail_url: string | null;
  status: GenerationStatus;
  error_message: string | null;
  generation_time_ms: number | null;
  cost_credits: number;
  is_favorite: boolean;
  rating: number | null;
  created_at: string;
  completed_at: string | null;
}

export interface GeneratedVideo {
  id: string;
  project_id: string;
  shot_id: string | null;
  source_image_id: string | null;
  source_image_url: string | null;
  prompt: string;
  generator: VideoGenerator;
  params: Record<string, any> | null;
  target_duration: number | null;
  video_url: string | null;
  thumbnail_url: string | null;
  status: GenerationStatus;
  error_message: string | null;
  actual_duration: number | null;
  resolution: string | null;
  fps: number | null;
  generation_time_ms: number | null;
  cost_credits: number;
  is_favorite: boolean;
  rating: number | null;
  created_at: string;
  completed_at: string | null;
}

export interface GenerationQueueItem {
  id: string;
  user_id: string;
  project_id: string;
  generation_type: 'image' | 'video' | 'script' | 'scene-breakdown';
  result_table: string;
  result_id: string;
  status: GenerationStatus;
  priority: number;
  attempts: number;
  max_attempts: number;
  last_error: string | null;
  created_at: string;
  started_at: string | null;
  completed_at: string | null;
  webhook_id: string | null;
  webhook_response: Record<string, any> | null;
}

export interface ProjectCollaborator {
  id: string;
  project_id: string;
  user_id: string;
  role: CollaboratorRole;
  invited_by: string | null;
  invited_at: string;
  accepted_at: string | null;
}

export interface Comment {
  id: string;
  project_id: string;
  user_id: string;
  episode_id: string | null;
  scene_id: string | null;
  shot_id: string | null;
  parent_id: string | null;
  content: string;
  is_resolved: boolean;
  resolved_by: string | null;
  resolved_at: string | null;
  created_at: string;
  updated_at: string;
}

export interface VersionHistory {
  id: string;
  project_id: string;
  user_id: string;
  version_number: string;
  description: string | null;
  changes: Record<string, any> | null;
  created_at: string;
}

export interface ShareLink {
  id: string;
  project_id: string;
  created_by: string;
  token: string;
  permission: CollaboratorRole;
  password_hash: string | null;
  expires_at: string | null;
  max_uses: number | null;
  use_count: number;
  is_active: boolean;
  created_at: string;
}

export interface Template {
  id: string;
  name: string;
  description: string | null;
  category: string | null;
  template_data: Record<string, any>;
  is_public: boolean;
  created_by: string | null;
  use_count: number;
  created_at: string;
  updated_at: string;
}

export interface UserSettings {
  id: string;
  default_image_generator: ImageGenerator;
  default_video_generator: VideoGenerator;
  sidebar_collapsed: boolean;
  theme: string;
  email_notifications: boolean;
  generation_complete_notify: boolean;
  collaboration_notify: boolean;
  default_project_type: ProjectType;
  default_film_style: FilmStyle;
  updated_at: string;
}

// ============================================================================
// API REQUEST/RESPONSE TYPES
// ============================================================================

export interface CreateProjectRequest {
  title: string;
  project_type: ProjectType;
  logline?: string;
  theme?: string;
  genre?: string;
  subgenres?: string[];
  tones?: string[];
  film_style?: FilmStyle;
  video_style?: VideoStyle;
  seasons?: number;
  episodes_per_season?: number;
  episode_length?: number;
  runtime?: number;
  primary_image_generator?: ImageGenerator;
  primary_video_generator?: VideoGenerator;
  reference_studios?: string;
  reference_films?: string;
}

export interface UpdateProjectRequest extends Partial<CreateProjectRequest> {
  phase?: ProjectPhase;
}

export interface GenerateImageRequest {
  project_id: string;
  shot_id?: string;
  character_id?: string;
  element_id?: string;
  prompt: string;
  negative_prompt?: string;
  generator: ImageGenerator;
  params?: {
    width?: number;
    height?: number;
    seed?: number;
    steps?: number;
  };
}

export interface GenerateVideoRequest {
  project_id: string;
  shot_id?: string;
  source_image_id?: string;
  source_image_url?: string;
  prompt: string;
  generator: VideoGenerator;
  params?: {
    duration?: number;
    fps?: number;
    motion_amount?: number;
  };
}

export interface GenerateScriptRequest {
  project_id: string;
  episode_id?: string;
  prompt: string;
  include_characters?: boolean;
  style_guidance?: string;
}

export interface BreakdownSceneRequest {
  project_id: string;
  scene_id: string;
  script_content: string;
  max_shot_duration?: number;
}

export interface ProjectStats {
  total_episodes: number;
  total_scenes: number;
  total_shots: number;
  total_characters: number;
  total_elements: number;
  total_images: number;
  total_videos: number;
  pending_generations: number;
  total_duration_seconds: number;
}

// ============================================================================
// SUPABASE CLIENT TYPES
// ============================================================================

export interface Database {
  public: {
    Tables: {
      profiles: {
        Row: Profile;
        Insert: Omit<Profile, 'created_at' | 'updated_at'>;
        Update: Partial<Omit<Profile, 'id' | 'created_at'>>;
      };
      projects: {
        Row: Project;
        Insert: Omit<Project, 'id' | 'created_at' | 'updated_at' | 'last_accessed_at'>;
        Update: Partial<Omit<Project, 'id' | 'created_at'>>;
      };
      episodes: {
        Row: Episode;
        Insert: Omit<Episode, 'id' | 'created_at' | 'updated_at'>;
        Update: Partial<Omit<Episode, 'id' | 'created_at'>>;
      };
      scenes: {
        Row: Scene;
        Insert: Omit<Scene, 'id' | 'created_at' | 'updated_at'>;
        Update: Partial<Omit<Scene, 'id' | 'created_at'>>;
      };
      shots: {
        Row: Shot;
        Insert: Omit<Shot, 'id' | 'created_at' | 'updated_at'>;
        Update: Partial<Omit<Shot, 'id' | 'created_at'>>;
      };
      characters: {
        Row: Character;
        Insert: Omit<Character, 'id' | 'created_at' | 'updated_at'>;
        Update: Partial<Omit<Character, 'id' | 'created_at'>>;
      };
      character_images: {
        Row: CharacterImage;
        Insert: Omit<CharacterImage, 'id' | 'created_at'>;
        Update: Partial<Omit<CharacterImage, 'id' | 'created_at'>>;
      };
      elements: {
        Row: Element;
        Insert: Omit<Element, 'id' | 'created_at' | 'updated_at'>;
        Update: Partial<Omit<Element, 'id' | 'created_at'>>;
      };
      generated_images: {
        Row: GeneratedImage;
        Insert: Omit<GeneratedImage, 'id' | 'created_at'>;
        Update: Partial<Omit<GeneratedImage, 'id' | 'created_at'>>;
      };
      generated_videos: {
        Row: GeneratedVideo;
        Insert: Omit<GeneratedVideo, 'id' | 'created_at'>;
        Update: Partial<Omit<GeneratedVideo, 'id' | 'created_at'>>;
      };
      generation_queue: {
        Row: GenerationQueueItem;
        Insert: Omit<GenerationQueueItem, 'id' | 'created_at'>;
        Update: Partial<Omit<GenerationQueueItem, 'id' | 'created_at'>>;
      };
      project_collaborators: {
        Row: ProjectCollaborator;
        Insert: Omit<ProjectCollaborator, 'id'>;
        Update: Partial<Omit<ProjectCollaborator, 'id'>>;
      };
      comments: {
        Row: Comment;
        Insert: Omit<Comment, 'id' | 'created_at' | 'updated_at'>;
        Update: Partial<Omit<Comment, 'id' | 'created_at'>>;
      };
      version_history: {
        Row: VersionHistory;
        Insert: Omit<VersionHistory, 'id' | 'created_at'>;
        Update: never;
      };
      share_links: {
        Row: ShareLink;
        Insert: Omit<ShareLink, 'id' | 'created_at' | 'token' | 'use_count'>;
        Update: Partial<Omit<ShareLink, 'id' | 'created_at' | 'token'>>;
      };
      templates: {
        Row: Template;
        Insert: Omit<Template, 'id' | 'created_at' | 'updated_at' | 'use_count'>;
        Update: Partial<Omit<Template, 'id' | 'created_at'>>;
      };
      user_settings: {
        Row: UserSettings;
        Insert: Omit<UserSettings, 'updated_at'>;
        Update: Partial<Omit<UserSettings, 'id'>>;
      };
    };
    Functions: {
      get_next_queue_item: {
        Args: Record<string, never>;
        Returns: GenerationQueueItem | null;
      };
      complete_queue_item: {
        Args: { queue_id: string; success: boolean; error_msg?: string };
        Returns: void;
      };
      get_project_stats: {
        Args: { project_uuid: string };
        Returns: ProjectStats;
      };
      validate_share_link: {
        Args: { link_token: string; password_attempt?: string };
        Returns: { valid: boolean; project_id: string | null; permission: CollaboratorRole | null; error_message: string | null };
      };
      deduct_generation_credits: {
        Args: { user_uuid: string; credits: number };
        Returns: boolean;
      };
      create_version_snapshot: {
        Args: { project_uuid: string; user_uuid: string; version_num: string; change_description: string };
        Returns: string;
      };
      duplicate_project: {
        Args: { source_project_id: string; new_title?: string };
        Returns: string;
      };
    };
  };
}
