# N8N Setup Guide for The Basement

## Overview

N8N handles all AI generation workflows as a queue system. This keeps the main application responsive while AI tasks process in the background.

## Architecture

```
┌─────────────────┐     ┌─────────────────┐     ┌─────────────────┐
│   React App     │────>│    Supabase     │<────│      N8N        │
│  (Frontend)     │     │   (Database)    │     │  (Workflows)    │
└─────────────────┘     └─────────────────┘     └─────────────────┘
        │                       │                       │
        │                       │                       │
        ▼                       ▼                       ▼
   User triggers          Queue tables            API calls to
   generation            store requests          AI services
```

## Workflow Descriptions

### 1. Image Generation Queue (`image-generation-queue`)

**Purpose**: Processes image generation requests from the queue

**Flow**:
1. Polls Supabase every 10 seconds for pending image jobs
2. Routes to appropriate API based on generator selection
3. Calls external API (Flux, Midjourney, etc.)
4. Updates `generated_images` table with result
5. Marks queue item as complete

**Supported Generators**:
- Flux Pro (Black Forest Labs)
- Nano Banana Pro (Banan)
- Midjourney v6 (via Replicate or direct)
- Grok Imagine (xAI)

### 2. Video Generation Queue (`video-generation-queue`)

**Purpose**: Processes video generation requests

**Flow**:
1. Polls every 30 seconds (videos take longer)
2. Routes to appropriate video API
3. Handles async completion (most video APIs are async)
4. Updates `generated_videos` table

**Supported Generators**:
- Sora 2 (OpenAI) - 20s max
- Runway Gen-3 - 10s max
- Kling 1.6 - 10s max
- Veo 2 (Google) - 60s max
- Minimax - 6s max
- Luma Ray 2 - 9s max

### 3. Script Generation (`script-generation`)

**Purpose**: Generates scripts using Claude

**Flow**:
1. Webhook trigger from app
2. Fetches project context and characters
3. Builds system prompt with project details
4. Calls Claude API
5. Updates episode with generated script

### 4. Scene Breakdown (`scene-breakdown`)

**Purpose**: AI-assisted breakdown of scripts into shots

**Flow**:
1. Webhook trigger with script content
2. Claude analyzes and suggests shot breakdown
3. Returns structured JSON with shot details
4. Creates shots in database

## Installation Steps

### 1. Install N8N

```bash
# Docker (recommended)
docker run -d --name n8n \
  -p 5678:5678 \
  -e N8N_BASIC_AUTH_ACTIVE=true \
  -e N8N_BASIC_AUTH_USER=admin \
  -e N8N_BASIC_AUTH_PASSWORD=your-password \
  -v n8n_data:/home/node/.n8n \
  n8nio/n8n

# Or npm
npm install n8n -g
n8n start
```

### 2. Configure Credentials

In N8N, go to **Settings > Credentials** and create:

#### Supabase
- Type: Supabase API
- Host: `https://your-project.supabase.co`
- Service Role Key: (from Supabase dashboard)

#### Anthropic (Claude)
- Type: HTTP Header Auth
- Name: `x-api-key`
- Value: Your Anthropic API key

#### Black Forest Labs (Flux)
- Type: HTTP Header Auth
- Name: `X-Key`
- Value: Your BFL API key

#### Runway
- Type: HTTP Header Auth
- Name: `Authorization`
- Value: `Bearer your-runway-key`

### 3. Import Workflows

1. Open N8N at `http://localhost:5678`
2. Go to **Workflows > Import**
3. Import the workflows from `n8n-workflows.json`
4. Update each workflow with your credentials
5. Activate the workflows

### 4. Set Environment Variables

```bash
# In N8N environment or .env file
SUPABASE_URL=https://your-project.supabase.co
SUPABASE_SERVICE_KEY=your-service-role-key
ANTHROPIC_API_KEY=sk-ant-xxx
BFL_API_KEY=xxx
RUNWAY_API_KEY=xxx
REPLICATE_API_TOKEN=xxx
```

## API Endpoint Reference

### Image Generation APIs

#### Flux Pro (Black Forest Labs)
```
POST https://api.bfl.ml/v1/flux-pro-1.1
Headers: X-Key: {api_key}
Body: {
  "prompt": "...",
  "width": 1024,
  "height": 1024,
  "seed": optional
}
```

#### Runway Gen-3 Alpha
```
POST https://api.runwayml.com/v1/image_to_video
Headers: Authorization: Bearer {api_key}
Body: {
  "promptImage": "base64 or url",
  "promptText": "motion description",
  "duration": 5
}
```

### Video Generation Flow

Most video APIs are asynchronous:

1. **Submit job** → Get job ID
2. **Poll status** → Check every 5-10 seconds
3. **Get result** → Download when complete

Example polling logic in N8N:
```javascript
// In Code node
const maxAttempts = 60;
const pollInterval = 5000;

for (let i = 0; i < maxAttempts; i++) {
  const status = await checkStatus(jobId);
  if (status.complete) {
    return status.result;
  }
  await sleep(pollInterval);
}
throw new Error('Generation timed out');
```

## Webhook Endpoints

Configure these in your app to trigger N8N:

```javascript
// Generate script
POST https://your-n8n.com/webhook/generate-script
Body: {
  project_id: "uuid",
  episode_id: "uuid",
  prompt: "Additional instructions..."
}

// Break down scene
POST https://your-n8n.com/webhook/breakdown-scene
Body: {
  project_id: "uuid",
  scene_id: "uuid",
  script_content: "Scene script text..."
}
```

## Error Handling

The queue system handles errors gracefully:

1. **Retry Logic**: Failed jobs retry up to 3 times
2. **Error Logging**: Errors stored in `last_error` column
3. **Status Updates**: Real-time status via Supabase Realtime
4. **Credit Refunds**: On failure, credits are refunded

## Monitoring

### Supabase Dashboard
- Monitor `generation_queue` table for pending/failed jobs
- Check `generated_images` and `generated_videos` for results

### N8N Dashboard
- View execution history
- Check for failed workflows
- Monitor API rate limits

## Scaling Considerations

1. **Parallel Processing**: Run multiple N8N instances
2. **Priority Queue**: Lower priority number = higher priority
3. **Rate Limiting**: Implement per-API rate limits
4. **Cost Control**: Track credits in `profiles.generation_credits`

## Testing

1. Create a test project in The Basement
2. Trigger an image generation
3. Watch N8N execution logs
4. Verify image appears in app

## Troubleshooting

### Queue items stuck in "pending"
- Check N8N is running
- Verify Supabase credentials
- Check `get_next_queue_item()` function

### API errors
- Verify API keys are valid
- Check rate limits
- Review error in `last_error` column

### Images not appearing
- Check Supabase Storage bucket permissions
- Verify image URLs are public or signed
