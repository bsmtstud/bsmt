-- ============================================================================
-- THE BASEMENT - Supabase Row Level Security (RLS) Policies
-- ============================================================================
-- Run this AFTER supabase-schema.sql
-- ============================================================================

-- Enable RLS on all tables
ALTER TABLE public.profiles ENABLE ROW LEVEL SECURITY;
ALTER TABLE public.projects ENABLE ROW LEVEL SECURITY;
ALTER TABLE public.episodes ENABLE ROW LEVEL SECURITY;
ALTER TABLE public.scenes ENABLE ROW LEVEL SECURITY;
ALTER TABLE public.shots ENABLE ROW LEVEL SECURITY;
ALTER TABLE public.characters ENABLE ROW LEVEL SECURITY;
ALTER TABLE public.character_images ENABLE ROW LEVEL SECURITY;
ALTER TABLE public.elements ENABLE ROW LEVEL SECURITY;
ALTER TABLE public.generated_images ENABLE ROW LEVEL SECURITY;
ALTER TABLE public.generated_videos ENABLE ROW LEVEL SECURITY;
ALTER TABLE public.generation_queue ENABLE ROW LEVEL SECURITY;
ALTER TABLE public.project_collaborators ENABLE ROW LEVEL SECURITY;
ALTER TABLE public.comments ENABLE ROW LEVEL SECURITY;
ALTER TABLE public.version_history ENABLE ROW LEVEL SECURITY;
ALTER TABLE public.share_links ENABLE ROW LEVEL SECURITY;
ALTER TABLE public.templates ENABLE ROW LEVEL SECURITY;
ALTER TABLE public.user_settings ENABLE ROW LEVEL SECURITY;

-- ============================================================================
-- HELPER FUNCTIONS
-- ============================================================================

-- Check if user owns a project
CREATE OR REPLACE FUNCTION public.user_owns_project(project_uuid UUID)
RETURNS BOOLEAN AS $$
BEGIN
    RETURN EXISTS (
        SELECT 1 FROM public.projects 
        WHERE id = project_uuid AND user_id = auth.uid()
    );
END;
$$ LANGUAGE plpgsql SECURITY DEFINER;

-- Check if user can access a project (owner or collaborator)
CREATE OR REPLACE FUNCTION public.user_can_access_project(project_uuid UUID)
RETURNS BOOLEAN AS $$
BEGIN
    RETURN EXISTS (
        SELECT 1 FROM public.projects 
        WHERE id = project_uuid AND user_id = auth.uid()
    ) OR EXISTS (
        SELECT 1 FROM public.project_collaborators
        WHERE project_id = project_uuid AND user_id = auth.uid()
    );
END;
$$ LANGUAGE plpgsql SECURITY DEFINER;

-- Check if user can edit a project (owner or editor)
CREATE OR REPLACE FUNCTION public.user_can_edit_project(project_uuid UUID)
RETURNS BOOLEAN AS $$
BEGIN
    RETURN EXISTS (
        SELECT 1 FROM public.projects 
        WHERE id = project_uuid AND user_id = auth.uid()
    ) OR EXISTS (
        SELECT 1 FROM public.project_collaborators
        WHERE project_id = project_uuid 
        AND user_id = auth.uid()
        AND role IN ('owner', 'editor')
    );
END;
$$ LANGUAGE plpgsql SECURITY DEFINER;

-- ============================================================================
-- PROFILES POLICIES
-- ============================================================================

CREATE POLICY "Users can view their own profile"
    ON public.profiles FOR SELECT
    USING (id = auth.uid());

CREATE POLICY "Users can update their own profile"
    ON public.profiles FOR UPDATE
    USING (id = auth.uid());

CREATE POLICY "Users can insert their own profile"
    ON public.profiles FOR INSERT
    WITH CHECK (id = auth.uid());

-- ============================================================================
-- PROJECTS POLICIES
-- ============================================================================

CREATE POLICY "Users can view their own projects"
    ON public.projects FOR SELECT
    USING (user_id = auth.uid());

CREATE POLICY "Users can view projects they collaborate on"
    ON public.projects FOR SELECT
    USING (
        EXISTS (
            SELECT 1 FROM public.project_collaborators
            WHERE project_id = id AND user_id = auth.uid()
        )
    );

CREATE POLICY "Users can create projects"
    ON public.projects FOR INSERT
    WITH CHECK (user_id = auth.uid());

CREATE POLICY "Users can update their own projects"
    ON public.projects FOR UPDATE
    USING (user_id = auth.uid());

CREATE POLICY "Editors can update projects"
    ON public.projects FOR UPDATE
    USING (public.user_can_edit_project(id));

CREATE POLICY "Users can delete their own projects"
    ON public.projects FOR DELETE
    USING (user_id = auth.uid());

-- ============================================================================
-- EPISODES POLICIES
-- ============================================================================

CREATE POLICY "Users can view episodes of accessible projects"
    ON public.episodes FOR SELECT
    USING (public.user_can_access_project(project_id));

CREATE POLICY "Users can create episodes in their projects"
    ON public.episodes FOR INSERT
    WITH CHECK (public.user_can_edit_project(project_id));

CREATE POLICY "Users can update episodes in editable projects"
    ON public.episodes FOR UPDATE
    USING (public.user_can_edit_project(project_id));

CREATE POLICY "Users can delete episodes in their projects"
    ON public.episodes FOR DELETE
    USING (public.user_owns_project(project_id));

-- ============================================================================
-- SCENES POLICIES
-- ============================================================================

CREATE POLICY "Users can view scenes of accessible projects"
    ON public.scenes FOR SELECT
    USING (public.user_can_access_project(project_id));

CREATE POLICY "Users can create scenes in editable projects"
    ON public.scenes FOR INSERT
    WITH CHECK (public.user_can_edit_project(project_id));

CREATE POLICY "Users can update scenes in editable projects"
    ON public.scenes FOR UPDATE
    USING (public.user_can_edit_project(project_id));

CREATE POLICY "Users can delete scenes in their projects"
    ON public.scenes FOR DELETE
    USING (public.user_owns_project(project_id));

-- ============================================================================
-- SHOTS POLICIES
-- ============================================================================

CREATE POLICY "Users can view shots of accessible projects"
    ON public.shots FOR SELECT
    USING (public.user_can_access_project(project_id));

CREATE POLICY "Users can create shots in editable projects"
    ON public.shots FOR INSERT
    WITH CHECK (public.user_can_edit_project(project_id));

CREATE POLICY "Users can update shots in editable projects"
    ON public.shots FOR UPDATE
    USING (public.user_can_edit_project(project_id));

CREATE POLICY "Users can delete shots in their projects"
    ON public.shots FOR DELETE
    USING (public.user_owns_project(project_id));

-- ============================================================================
-- CHARACTERS POLICIES
-- ============================================================================

CREATE POLICY "Users can view characters of accessible projects"
    ON public.characters FOR SELECT
    USING (public.user_can_access_project(project_id));

CREATE POLICY "Users can manage characters in editable projects"
    ON public.characters FOR ALL
    USING (public.user_can_edit_project(project_id));

-- ============================================================================
-- CHARACTER IMAGES POLICIES
-- ============================================================================

CREATE POLICY "Users can view character images of accessible projects"
    ON public.character_images FOR SELECT
    USING (
        EXISTS (
            SELECT 1 FROM public.characters c
            WHERE c.id = character_id
            AND public.user_can_access_project(c.project_id)
        )
    );

CREATE POLICY "Users can manage character images in editable projects"
    ON public.character_images FOR ALL
    USING (
        EXISTS (
            SELECT 1 FROM public.characters c
            WHERE c.id = character_id
            AND public.user_can_edit_project(c.project_id)
        )
    );

-- ============================================================================
-- ELEMENTS POLICIES
-- ============================================================================

CREATE POLICY "Users can view elements of accessible projects"
    ON public.elements FOR SELECT
    USING (public.user_can_access_project(project_id));

CREATE POLICY "Users can manage elements in editable projects"
    ON public.elements FOR ALL
    USING (public.user_can_edit_project(project_id));

-- ============================================================================
-- GENERATED IMAGES POLICIES
-- ============================================================================

CREATE POLICY "Users can view generated images of accessible projects"
    ON public.generated_images FOR SELECT
    USING (public.user_can_access_project(project_id));

CREATE POLICY "Users can create generated images in editable projects"
    ON public.generated_images FOR INSERT
    WITH CHECK (public.user_can_edit_project(project_id));

CREATE POLICY "Users can update generated images in editable projects"
    ON public.generated_images FOR UPDATE
    USING (public.user_can_edit_project(project_id));

CREATE POLICY "Users can delete generated images in their projects"
    ON public.generated_images FOR DELETE
    USING (public.user_owns_project(project_id));

-- ============================================================================
-- GENERATED VIDEOS POLICIES
-- ============================================================================

CREATE POLICY "Users can view generated videos of accessible projects"
    ON public.generated_videos FOR SELECT
    USING (public.user_can_access_project(project_id));

CREATE POLICY "Users can create generated videos in editable projects"
    ON public.generated_videos FOR INSERT
    WITH CHECK (public.user_can_edit_project(project_id));

CREATE POLICY "Users can update generated videos in editable projects"
    ON public.generated_videos FOR UPDATE
    USING (public.user_can_edit_project(project_id));

CREATE POLICY "Users can delete generated videos in their projects"
    ON public.generated_videos FOR DELETE
    USING (public.user_owns_project(project_id));

-- ============================================================================
-- GENERATION QUEUE POLICIES
-- ============================================================================

CREATE POLICY "Users can view their own queue items"
    ON public.generation_queue FOR SELECT
    USING (user_id = auth.uid());

CREATE POLICY "Users can create queue items for their projects"
    ON public.generation_queue FOR INSERT
    WITH CHECK (user_id = auth.uid() AND public.user_can_edit_project(project_id));

CREATE POLICY "Users can update their own queue items"
    ON public.generation_queue FOR UPDATE
    USING (user_id = auth.uid());

-- ============================================================================
-- COLLABORATION POLICIES
-- ============================================================================

CREATE POLICY "Users can view collaborators of accessible projects"
    ON public.project_collaborators FOR SELECT
    USING (public.user_can_access_project(project_id));

CREATE POLICY "Project owners can manage collaborators"
    ON public.project_collaborators FOR ALL
    USING (public.user_owns_project(project_id));

-- ============================================================================
-- COMMENTS POLICIES
-- ============================================================================

CREATE POLICY "Users can view comments of accessible projects"
    ON public.comments FOR SELECT
    USING (public.user_can_access_project(project_id));

CREATE POLICY "Users can create comments on accessible projects"
    ON public.comments FOR INSERT
    WITH CHECK (
        user_id = auth.uid() 
        AND public.user_can_access_project(project_id)
    );

CREATE POLICY "Users can update their own comments"
    ON public.comments FOR UPDATE
    USING (user_id = auth.uid());

CREATE POLICY "Users can delete their own comments"
    ON public.comments FOR DELETE
    USING (user_id = auth.uid());

CREATE POLICY "Project owners can delete any comment"
    ON public.comments FOR DELETE
    USING (public.user_owns_project(project_id));

-- ============================================================================
-- VERSION HISTORY POLICIES
-- ============================================================================

CREATE POLICY "Users can view version history of accessible projects"
    ON public.version_history FOR SELECT
    USING (public.user_can_access_project(project_id));

CREATE POLICY "Users can create version history in editable projects"
    ON public.version_history FOR INSERT
    WITH CHECK (
        user_id = auth.uid()
        AND public.user_can_edit_project(project_id)
    );

-- ============================================================================
-- SHARE LINKS POLICIES
-- ============================================================================

CREATE POLICY "Users can view share links they created"
    ON public.share_links FOR SELECT
    USING (created_by = auth.uid());

CREATE POLICY "Project owners can view all share links"
    ON public.share_links FOR SELECT
    USING (public.user_owns_project(project_id));

CREATE POLICY "Project owners can manage share links"
    ON public.share_links FOR ALL
    USING (public.user_owns_project(project_id));

-- ============================================================================
-- TEMPLATES POLICIES
-- ============================================================================

CREATE POLICY "Users can view public templates"
    ON public.templates FOR SELECT
    USING (is_public = TRUE);

CREATE POLICY "Users can view their own templates"
    ON public.templates FOR SELECT
    USING (created_by = auth.uid());

CREATE POLICY "Users can create templates"
    ON public.templates FOR INSERT
    WITH CHECK (created_by = auth.uid());

CREATE POLICY "Users can update their own templates"
    ON public.templates FOR UPDATE
    USING (created_by = auth.uid());

CREATE POLICY "Users can delete their own templates"
    ON public.templates FOR DELETE
    USING (created_by = auth.uid());

-- ============================================================================
-- USER SETTINGS POLICIES
-- ============================================================================

CREATE POLICY "Users can view their own settings"
    ON public.user_settings FOR SELECT
    USING (id = auth.uid());

CREATE POLICY "Users can update their own settings"
    ON public.user_settings FOR UPDATE
    USING (id = auth.uid());

CREATE POLICY "Users can insert their own settings"
    ON public.user_settings FOR INSERT
    WITH CHECK (id = auth.uid());
