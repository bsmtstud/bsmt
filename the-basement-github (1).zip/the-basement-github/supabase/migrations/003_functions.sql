-- ============================================================================
-- THE BASEMENT - Supabase Functions & Triggers
-- ============================================================================
-- Run this AFTER supabase-schema.sql and supabase-rls.sql
-- ============================================================================

-- ============================================================================
-- AUTO-UPDATE TIMESTAMPS
-- ============================================================================

CREATE OR REPLACE FUNCTION public.update_updated_at()
RETURNS TRIGGER AS $$
BEGIN
    NEW.updated_at = NOW();
    RETURN NEW;
END;
$$ LANGUAGE plpgsql;

-- Apply to all tables with updated_at
CREATE TRIGGER update_profiles_updated_at BEFORE UPDATE ON public.profiles
    FOR EACH ROW EXECUTE FUNCTION public.update_updated_at();

CREATE TRIGGER update_projects_updated_at BEFORE UPDATE ON public.projects
    FOR EACH ROW EXECUTE FUNCTION public.update_updated_at();

CREATE TRIGGER update_episodes_updated_at BEFORE UPDATE ON public.episodes
    FOR EACH ROW EXECUTE FUNCTION public.update_updated_at();

CREATE TRIGGER update_scenes_updated_at BEFORE UPDATE ON public.scenes
    FOR EACH ROW EXECUTE FUNCTION public.update_updated_at();

CREATE TRIGGER update_shots_updated_at BEFORE UPDATE ON public.shots
    FOR EACH ROW EXECUTE FUNCTION public.update_updated_at();

CREATE TRIGGER update_characters_updated_at BEFORE UPDATE ON public.characters
    FOR EACH ROW EXECUTE FUNCTION public.update_updated_at();

CREATE TRIGGER update_elements_updated_at BEFORE UPDATE ON public.elements
    FOR EACH ROW EXECUTE FUNCTION public.update_updated_at();

CREATE TRIGGER update_comments_updated_at BEFORE UPDATE ON public.comments
    FOR EACH ROW EXECUTE FUNCTION public.update_updated_at();

CREATE TRIGGER update_templates_updated_at BEFORE UPDATE ON public.templates
    FOR EACH ROW EXECUTE FUNCTION public.update_updated_at();

CREATE TRIGGER update_user_settings_updated_at BEFORE UPDATE ON public.user_settings
    FOR EACH ROW EXECUTE FUNCTION public.update_updated_at();

-- ============================================================================
-- AUTO-CREATE USER PROFILE & SETTINGS
-- ============================================================================

CREATE OR REPLACE FUNCTION public.handle_new_user()
RETURNS TRIGGER AS $$
BEGIN
    -- Create profile
    INSERT INTO public.profiles (id, email, full_name, avatar_url)
    VALUES (
        NEW.id,
        NEW.email,
        COALESCE(NEW.raw_user_meta_data->>'full_name', NEW.email),
        NEW.raw_user_meta_data->>'avatar_url'
    );
    
    -- Create default settings
    INSERT INTO public.user_settings (id)
    VALUES (NEW.id);
    
    RETURN NEW;
END;
$$ LANGUAGE plpgsql SECURITY DEFINER;

CREATE TRIGGER on_auth_user_created
    AFTER INSERT ON auth.users
    FOR EACH ROW EXECUTE FUNCTION public.handle_new_user();

-- ============================================================================
-- AUTO-CREATE EPISODES FOR SERIES
-- ============================================================================

CREATE OR REPLACE FUNCTION public.create_series_episodes()
RETURNS TRIGGER AS $$
DECLARE
    s INTEGER;
    e INTEGER;
BEGIN
    IF NEW.project_type = 'series' THEN
        FOR s IN 1..NEW.seasons LOOP
            FOR e IN 1..NEW.episodes_per_season LOOP
                INSERT INTO public.episodes (
                    project_id,
                    season_number,
                    episode_number,
                    title,
                    target_duration
                ) VALUES (
                    NEW.id,
                    s,
                    e,
                    'Episode ' || e,
                    NEW.episode_length
                );
            END LOOP;
        END LOOP;
    END IF;
    RETURN NEW;
END;
$$ LANGUAGE plpgsql;

CREATE TRIGGER create_episodes_on_project_create
    AFTER INSERT ON public.projects
    FOR EACH ROW EXECUTE FUNCTION public.create_series_episodes();

-- ============================================================================
-- AUTO-UPDATE PROJECT LAST_ACCESSED
-- ============================================================================

CREATE OR REPLACE FUNCTION public.update_project_last_accessed()
RETURNS TRIGGER AS $$
BEGIN
    UPDATE public.projects
    SET last_accessed_at = NOW()
    WHERE id = NEW.project_id;
    RETURN NEW;
END;
$$ LANGUAGE plpgsql;

-- Trigger on various child tables
CREATE TRIGGER update_project_accessed_on_scene
    AFTER INSERT OR UPDATE ON public.scenes
    FOR EACH ROW EXECUTE FUNCTION public.update_project_last_accessed();

CREATE TRIGGER update_project_accessed_on_shot
    AFTER INSERT OR UPDATE ON public.shots
    FOR EACH ROW EXECUTE FUNCTION public.update_project_last_accessed();

CREATE TRIGGER update_project_accessed_on_image
    AFTER INSERT ON public.generated_images
    FOR EACH ROW EXECUTE FUNCTION public.update_project_last_accessed();

-- ============================================================================
-- GENERATION CREDIT MANAGEMENT
-- ============================================================================

CREATE OR REPLACE FUNCTION public.deduct_generation_credits(
    user_uuid UUID,
    credits INTEGER
)
RETURNS BOOLEAN AS $$
DECLARE
    current_credits INTEGER;
BEGIN
    SELECT generation_credits INTO current_credits
    FROM public.profiles
    WHERE id = user_uuid;
    
    IF current_credits >= credits THEN
        UPDATE public.profiles
        SET generation_credits = generation_credits - credits
        WHERE id = user_uuid;
        RETURN TRUE;
    ELSE
        RETURN FALSE;
    END IF;
END;
$$ LANGUAGE plpgsql SECURITY DEFINER;

CREATE OR REPLACE FUNCTION public.add_generation_credits(
    user_uuid UUID,
    credits INTEGER
)
RETURNS VOID AS $$
BEGIN
    UPDATE public.profiles
    SET generation_credits = generation_credits + credits
    WHERE id = user_uuid;
END;
$$ LANGUAGE plpgsql SECURITY DEFINER;

-- ============================================================================
-- QUEUE MANAGEMENT FUNCTIONS
-- ============================================================================

-- Get next item from queue for processing
CREATE OR REPLACE FUNCTION public.get_next_queue_item()
RETURNS TABLE (
    id UUID,
    user_id UUID,
    project_id UUID,
    generation_type TEXT,
    result_table TEXT,
    result_id UUID
) AS $$
DECLARE
    queue_item RECORD;
BEGIN
    -- Get and lock the next pending item
    SELECT q.* INTO queue_item
    FROM public.generation_queue q
    WHERE q.status = 'pending'
    AND q.attempts < q.max_attempts
    ORDER BY q.priority ASC, q.created_at ASC
    LIMIT 1
    FOR UPDATE SKIP LOCKED;
    
    IF queue_item.id IS NOT NULL THEN
        -- Mark as processing
        UPDATE public.generation_queue
        SET status = 'processing',
            started_at = NOW(),
            attempts = attempts + 1
        WHERE generation_queue.id = queue_item.id;
        
        RETURN QUERY SELECT 
            queue_item.id,
            queue_item.user_id,
            queue_item.project_id,
            queue_item.generation_type,
            queue_item.result_table,
            queue_item.result_id;
    END IF;
END;
$$ LANGUAGE plpgsql;

-- Mark queue item as completed
CREATE OR REPLACE FUNCTION public.complete_queue_item(
    queue_id UUID,
    success BOOLEAN,
    error_msg TEXT DEFAULT NULL
)
RETURNS VOID AS $$
BEGIN
    UPDATE public.generation_queue
    SET 
        status = CASE WHEN success THEN 'completed' ELSE 'failed' END,
        completed_at = NOW(),
        last_error = error_msg
    WHERE id = queue_id;
END;
$$ LANGUAGE plpgsql;

-- ============================================================================
-- SCENE/SHOT ORDERING FUNCTIONS
-- ============================================================================

-- Reorder scenes within a project/episode
CREATE OR REPLACE FUNCTION public.reorder_scenes(
    scene_ids UUID[]
)
RETURNS VOID AS $$
DECLARE
    i INTEGER;
BEGIN
    FOR i IN 1..array_length(scene_ids, 1) LOOP
        UPDATE public.scenes
        SET sort_order = i
        WHERE id = scene_ids[i];
    END LOOP;
END;
$$ LANGUAGE plpgsql;

-- Reorder shots within a scene
CREATE OR REPLACE FUNCTION public.reorder_shots(
    shot_ids UUID[]
)
RETURNS VOID AS $$
DECLARE
    i INTEGER;
BEGIN
    FOR i IN 1..array_length(shot_ids, 1) LOOP
        UPDATE public.shots
        SET sort_order = i
        WHERE id = shot_ids[i];
    END LOOP;
END;
$$ LANGUAGE plpgsql;

-- ============================================================================
-- PROJECT STATISTICS
-- ============================================================================

CREATE OR REPLACE FUNCTION public.get_project_stats(project_uuid UUID)
RETURNS TABLE (
    total_episodes BIGINT,
    total_scenes BIGINT,
    total_shots BIGINT,
    total_characters BIGINT,
    total_elements BIGINT,
    total_images BIGINT,
    total_videos BIGINT,
    pending_generations BIGINT,
    total_duration_seconds BIGINT
) AS $$
BEGIN
    RETURN QUERY
    SELECT
        (SELECT COUNT(*) FROM public.episodes WHERE project_id = project_uuid),
        (SELECT COUNT(*) FROM public.scenes WHERE project_id = project_uuid),
        (SELECT COUNT(*) FROM public.shots WHERE project_id = project_uuid),
        (SELECT COUNT(*) FROM public.characters WHERE project_id = project_uuid),
        (SELECT COUNT(*) FROM public.elements WHERE project_id = project_uuid),
        (SELECT COUNT(*) FROM public.generated_images WHERE project_id = project_uuid AND status = 'completed'),
        (SELECT COUNT(*) FROM public.generated_videos WHERE project_id = project_uuid AND status = 'completed'),
        (SELECT COUNT(*) FROM public.generation_queue WHERE project_id = project_uuid AND status IN ('pending', 'processing')),
        (SELECT COALESCE(SUM(duration), 0) FROM public.shots WHERE project_id = project_uuid);
END;
$$ LANGUAGE plpgsql;

-- ============================================================================
-- SHARE LINK VALIDATION
-- ============================================================================

CREATE OR REPLACE FUNCTION public.validate_share_link(
    link_token TEXT,
    password_attempt TEXT DEFAULT NULL
)
RETURNS TABLE (
    valid BOOLEAN,
    project_id UUID,
    permission collaborator_role,
    error_message TEXT
) AS $$
DECLARE
    link RECORD;
BEGIN
    SELECT * INTO link
    FROM public.share_links
    WHERE token = link_token;
    
    IF link IS NULL THEN
        RETURN QUERY SELECT FALSE, NULL::UUID, NULL::collaborator_role, 'Link not found';
        RETURN;
    END IF;
    
    IF NOT link.is_active THEN
        RETURN QUERY SELECT FALSE, NULL::UUID, NULL::collaborator_role, 'Link is inactive';
        RETURN;
    END IF;
    
    IF link.expires_at IS NOT NULL AND link.expires_at < NOW() THEN
        RETURN QUERY SELECT FALSE, NULL::UUID, NULL::collaborator_role, 'Link has expired';
        RETURN;
    END IF;
    
    IF link.max_uses IS NOT NULL AND link.use_count >= link.max_uses THEN
        RETURN QUERY SELECT FALSE, NULL::UUID, NULL::collaborator_role, 'Link has reached maximum uses';
        RETURN;
    END IF;
    
    IF link.password_hash IS NOT NULL THEN
        IF password_attempt IS NULL OR crypt(password_attempt, link.password_hash) != link.password_hash THEN
            RETURN QUERY SELECT FALSE, NULL::UUID, NULL::collaborator_role, 'Invalid password';
            RETURN;
        END IF;
    END IF;
    
    -- Increment use count
    UPDATE public.share_links
    SET use_count = use_count + 1
    WHERE token = link_token;
    
    RETURN QUERY SELECT TRUE, link.project_id, link.permission, NULL::TEXT;
END;
$$ LANGUAGE plpgsql SECURITY DEFINER;

-- ============================================================================
-- VERSION HISTORY HELPER
-- ============================================================================

CREATE OR REPLACE FUNCTION public.create_version_snapshot(
    project_uuid UUID,
    user_uuid UUID,
    version_num TEXT,
    change_description TEXT
)
RETURNS UUID AS $$
DECLARE
    snapshot JSONB;
    version_id UUID;
BEGIN
    -- Create snapshot of current project state
    SELECT jsonb_build_object(
        'project', (SELECT row_to_json(p.*) FROM public.projects p WHERE p.id = project_uuid),
        'episodes', (SELECT json_agg(row_to_json(e.*)) FROM public.episodes e WHERE e.project_id = project_uuid),
        'scenes', (SELECT json_agg(row_to_json(s.*)) FROM public.scenes s WHERE s.project_id = project_uuid),
        'shots', (SELECT json_agg(row_to_json(sh.*)) FROM public.shots sh WHERE sh.project_id = project_uuid),
        'characters', (SELECT json_agg(row_to_json(c.*)) FROM public.characters c WHERE c.project_id = project_uuid)
    ) INTO snapshot;
    
    INSERT INTO public.version_history (
        project_id,
        user_id,
        version_number,
        description,
        changes
    ) VALUES (
        project_uuid,
        user_uuid,
        version_num,
        change_description,
        snapshot
    )
    RETURNING id INTO version_id;
    
    RETURN version_id;
END;
$$ LANGUAGE plpgsql;

-- ============================================================================
-- DUPLICATE PROJECT
-- ============================================================================

CREATE OR REPLACE FUNCTION public.duplicate_project(
    source_project_id UUID,
    new_title TEXT DEFAULT NULL
)
RETURNS UUID AS $$
DECLARE
    new_project_id UUID;
    source_project RECORD;
BEGIN
    -- Get source project
    SELECT * INTO source_project
    FROM public.projects
    WHERE id = source_project_id;
    
    -- Create new project
    INSERT INTO public.projects (
        user_id, title, project_type, logline, theme, genre, subgenres, tones,
        film_style, video_style, seasons, episodes_per_season, episode_length,
        runtime, primary_image_generator, primary_video_generator,
        reference_studios, reference_films
    )
    SELECT
        user_id,
        COALESCE(new_title, title || ' (Copy)'),
        project_type, logline, theme, genre, subgenres, tones,
        film_style, video_style, seasons, episodes_per_season, episode_length,
        runtime, primary_image_generator, primary_video_generator,
        reference_studios, reference_films
    FROM public.projects
    WHERE id = source_project_id
    RETURNING id INTO new_project_id;
    
    -- Copy characters
    INSERT INTO public.characters (
        project_id, name, role, age, gender, physical_description,
        personality, backstory, motivations, reference_prompt
    )
    SELECT
        new_project_id, name, role, age, gender, physical_description,
        personality, backstory, motivations, reference_prompt
    FROM public.characters
    WHERE project_id = source_project_id;
    
    -- Copy elements
    INSERT INTO public.elements (
        project_id, name, category, description, reference_prompt, tags
    )
    SELECT
        new_project_id, name, category, description, reference_prompt, tags
    FROM public.elements
    WHERE project_id = source_project_id;
    
    -- Note: Episodes are auto-created by trigger for series
    -- Scenes and shots would need more complex logic to maintain relationships
    
    RETURN new_project_id;
END;
$$ LANGUAGE plpgsql;
