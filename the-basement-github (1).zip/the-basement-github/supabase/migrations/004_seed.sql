-- ============================================================================
-- THE BASEMENT - Sample Seed Data
-- ============================================================================
-- Run this AFTER all schema files for testing
-- This creates a sample project with episodes, scenes, shots, and characters
-- ============================================================================

-- Note: Replace these UUIDs with actual user IDs from your auth system
-- For testing, you can use a fixed UUID

-- Create a test user profile (if not using auth)
INSERT INTO public.profiles (id, email, full_name, generation_credits)
VALUES (
    '00000000-0000-0000-0000-000000000001',
    'test@example.com',
    'Test User',
    500
) ON CONFLICT (id) DO NOTHING;

-- Create user settings
INSERT INTO public.user_settings (id)
VALUES ('00000000-0000-0000-0000-000000000001')
ON CONFLICT (id) DO NOTHING;

-- ============================================================================
-- SAMPLE PROJECT: Sci-Fi Series
-- ============================================================================

INSERT INTO public.projects (
    id, user_id, title, project_type, phase,
    logline, theme, genre, subgenres, tones,
    film_style, video_style,
    seasons, episodes_per_season, episode_length,
    primary_image_generator, primary_video_generator,
    reference_studios, reference_films
) VALUES (
    '11111111-1111-1111-1111-111111111111',
    '00000000-0000-0000-0000-000000000001',
    'Neon Horizons',
    'series',
    'development',
    'In a sprawling megacity of 2087, a disgraced detective must navigate corporate conspiracies and underground resistance movements to solve a murder that threatens to expose the truth about humanity''s synthetic evolution.',
    'Identity and humanity in a post-human world',
    'sci-fi',
    ARRAY['cyberpunk', 'noir', 'thriller'],
    ARRAY['dark', 'suspenseful', 'gritty'],
    'cinematic',
    'neon-noir',
    2,
    8,
    45,
    'flux-pro',
    'runway-gen3',
    'A24, HBO, Blade Runner Productions',
    'Blade Runner 2049, Altered Carbon, True Detective'
);

-- Episodes will be auto-created by trigger, but let's update Episode 1
UPDATE public.episodes
SET 
    title = 'Ghost in the Machine',
    synopsis = 'Detective Kira Chen is called to investigate a murder at NeoSyn Corporation, but nothing is as it seems. The victim appears to have died twice.',
    script_content = 'FADE IN:

EXT. MEGACITY - NIGHT

Rain pours over the neon-lit streets of New Shanghai. Holographic advertisements flicker between towering skyscrapers.

KIRA (V.O.)
They say the city never sleeps. That''s because the dreams here turned to nightmares long ago.

A police spinner descends through the rain.

INT. SPINNER - CONTINUOUS

DETECTIVE KIRA CHEN (35, weathered, cybernetic left eye) stares out at the city below. Her partner, MARCUS (40s, fully organic, rare these days), pilots.

MARCUS
NeoSyn''s board is already breathing down the Captain''s neck. This needs to be clean.

KIRA
Since when is any murder clean?

She taps her temple, her cybernetic eye flickering as data scrolls across her vision.

KIRA (CONT''D)
Victim is Dr. Elena Voss. Lead researcher in their Synthetic Consciousness division.

MARCUS
The mind upload people?

KIRA
(nodding)
They''re saying she was found dead in her lab. Except...

MARCUS
Except what?

KIRA
She was also found dead in her apartment. Same time. Same cause of death.

Marcus nearly loses control of the spinner.

MARCUS
That''s impossible.

KIRA
(bitter smile)
Welcome to New Shanghai.'
WHERE project_id = '11111111-1111-1111-1111-111111111111'
AND season_number = 1
AND episode_number = 1;

-- ============================================================================
-- SAMPLE SCENES
-- ============================================================================

INSERT INTO public.scenes (id, project_id, episode_id, scene_number, title, description, location, time_of_day, mood, sort_order)
SELECT 
    '22222222-2222-2222-2222-222222222201',
    '11111111-1111-1111-1111-111111111111',
    e.id,
    1,
    'City Establishing',
    'Opening shot establishing the megacity atmosphere',
    'Megacity Skyline',
    'night',
    'foreboding',
    1
FROM public.episodes e 
WHERE e.project_id = '11111111-1111-1111-1111-111111111111' 
AND e.season_number = 1 AND e.episode_number = 1;

INSERT INTO public.scenes (id, project_id, episode_id, scene_number, title, description, location, time_of_day, mood, sort_order)
SELECT 
    '22222222-2222-2222-2222-222222222202',
    '11111111-1111-1111-1111-111111111111',
    e.id,
    2,
    'Spinner Descent',
    'Kira and Marcus discuss the case while descending to the crime scene',
    'Police Spinner Interior',
    'night',
    'tense',
    2
FROM public.episodes e 
WHERE e.project_id = '11111111-1111-1111-1111-111111111111' 
AND e.season_number = 1 AND e.episode_number = 1;

-- ============================================================================
-- SAMPLE SHOTS
-- ============================================================================

INSERT INTO public.shots (id, scene_id, project_id, shot_number, shot_type, camera_movement, description, visual_prompt, duration, dialogue, sort_order)
VALUES 
(
    '33333333-3333-3333-3333-333333333301',
    '22222222-2222-2222-2222-222222222201',
    '11111111-1111-1111-1111-111111111111',
    1,
    'aerial',
    'drone',
    'Establishing shot of the megacity',
    'Aerial view of a futuristic cyberpunk megacity at night, rain falling, neon signs and holographic advertisements everywhere, flying vehicles between massive skyscrapers, cinematic lighting, blade runner style, 8k',
    8,
    NULL,
    1
),
(
    '33333333-3333-3333-3333-333333333302',
    '22222222-2222-2222-2222-222222222201',
    '11111111-1111-1111-1111-111111111111',
    2,
    'wide',
    'tilt',
    'Camera tilts down following rain to street level',
    'Rain falling through neon lights onto a dark cyberpunk street, steam rising from vents, silhouettes of pedestrians with umbrellas, holographic signs reflecting in puddles, cinematic film grain',
    5,
    NULL,
    2
),
(
    '33333333-3333-3333-3333-333333333303',
    '22222222-2222-2222-2222-222222222202',
    '11111111-1111-1111-1111-111111111111',
    1,
    'medium',
    'static',
    'Interior of police spinner, Kira looking out window',
    'Interior of futuristic police vehicle, female detective with short dark hair and glowing cybernetic left eye looking out rain-streaked window, blue holographic displays, moody lighting',
    4,
    'They say the city never sleeps.',
    1
),
(
    '33333333-3333-3333-3333-333333333304',
    '22222222-2222-2222-2222-222222222202',
    '11111111-1111-1111-1111-111111111111',
    2,
    'over-shoulder',
    'static',
    'Over Kira shoulder to Marcus piloting',
    'Over shoulder shot of female detective, male pilot in 40s at controls of futuristic vehicle, holographic dashboard, rain on windshield, city lights beyond',
    3,
    'NeoSyn''s board is already breathing down the Captain''s neck.',
    2
);

-- ============================================================================
-- SAMPLE CHARACTERS
-- ============================================================================

INSERT INTO public.characters (id, project_id, name, role, age, gender, physical_description, personality, backstory, reference_prompt)
VALUES 
(
    '44444444-4444-4444-4444-444444444401',
    '11111111-1111-1111-1111-111111111111',
    'Kira Chen',
    'protagonist',
    '35',
    'female',
    'Asian woman, short black hair with subtle blue highlights, cybernetic left eye that glows soft blue, sharp features, often wears a weathered leather jacket',
    'Cynical but principled, haunted by past failures, brilliant detective instincts, struggles with the line between human and synthetic',
    'Former corporate security investigator who left after discovering corruption. Now a city detective trying to make a difference in a system she knows is broken.',
    'Asian woman detective, 35 years old, short black hair with blue highlights, cybernetic glowing blue left eye, weathered leather jacket, cyberpunk noir style, detailed portrait'
),
(
    '44444444-4444-4444-4444-444444444402',
    '11111111-1111-1111-1111-111111111111',
    'Marcus Webb',
    'supporting',
    '45',
    'male',
    'African American man, mid-40s, fully organic (no cybernetics), greying temples, kind eyes, always impeccably dressed even on rough nights',
    'Warm, grounded, the moral compass of the partnership, protective of Kira, believes in old-fashioned detective work',
    'Twenty-year veteran of the force, one of the few who refused synthetic enhancements. Partnered with Kira to keep her grounded after her transfer.',
    'African American male detective, mid 40s, greying temples, warm expression, no cybernetics, wearing neat suit and coat, cyberpunk setting, portrait'
),
(
    '44444444-4444-4444-4444-444444444403',
    '11111111-1111-1111-1111-111111111111',
    'Dr. Elena Voss',
    'supporting',
    '42',
    'female',
    'Caucasian woman, early 40s, silver-white hair, pale complexion, elegant, minimal visible cybernetics but heavily enhanced internally',
    'Brilliant, secretive, driven by scientific curiosity that borders on obsession, complicated morality',
    'Lead researcher at NeoSyn''s Synthetic Consciousness division. Pioneer in mind uploading technology. The murder victim with an impossible death.',
    'Elegant scientist woman, early 40s, silver white hair, pale skin, wearing white lab coat, futuristic laboratory setting, mysterious expression'
);

-- ============================================================================
-- SAMPLE ELEMENTS
-- ============================================================================

INSERT INTO public.elements (id, project_id, name, category, description, reference_prompt, tags)
VALUES 
(
    '55555555-5555-5555-5555-555555555501',
    '11111111-1111-1111-1111-111111111111',
    'Police Spinner',
    'vehicle',
    'Flying police vehicle used by NSPD detectives',
    'Futuristic flying police car, blade runner style, black and white with blue lights, rain slicked, hovering over city, cyberpunk aesthetic',
    ARRAY['vehicle', 'police', 'flying', 'cyberpunk']
),
(
    '55555555-5555-5555-5555-555555555502',
    '11111111-1111-1111-1111-111111111111',
    'NeoSyn Tower',
    'location',
    'Corporate headquarters of NeoSyn Corporation, a massive skyscraper in the city center',
    'Massive corporate skyscraper, futuristic architecture, glowing logo at top, surrounded by smaller buildings, night scene, cyberpunk megacity',
    ARRAY['location', 'corporate', 'skyscraper', 'neosyn']
),
(
    '55555555-5555-5555-5555-555555555503',
    '11111111-1111-1111-1111-111111111111',
    'Kira''s Badge',
    'prop',
    'NSPD detective badge with holographic ID',
    'Futuristic police badge, holographic elements, metallic with blue glow, detective insignia, cyberpunk prop design',
    ARRAY['prop', 'police', 'badge', 'holographic']
);

-- ============================================================================
-- SAMPLE FILM PROJECT
-- ============================================================================

INSERT INTO public.projects (
    id, user_id, title, project_type, phase,
    logline, theme, genre, subgenres, tones,
    film_style, video_style,
    runtime,
    primary_image_generator, primary_video_generator
) VALUES (
    '66666666-6666-6666-6666-666666666666',
    '00000000-0000-0000-0000-000000000001',
    'The Last Garden',
    'short',
    'pre-production',
    'In a world where all plant life has died, an elderly botanist tends to Earth''s last garden in a sealed dome, until a young refugee arrives seeking shelter.',
    'Hope persists even in the darkest times',
    'drama',
    ARRAY['post-apocalyptic', 'character-study'],
    ARRAY['heartfelt', 'melancholic', 'hopeful'],
    'cinematic',
    'cinematic-color',
    18,
    'flux-pro',
    'veo-2'
);

-- ============================================================================
-- SAMPLE TEMPLATES
-- ============================================================================

INSERT INTO public.templates (name, description, category, template_data, is_public, created_by)
VALUES 
(
    'Three-Act Structure',
    'Classic three-act story structure with setup, confrontation, and resolution',
    'project',
    '{
        "acts": [
            {"name": "Act 1 - Setup", "percentage": 25, "scenes": ["Opening Image", "Theme Stated", "Setup", "Catalyst", "Debate"]},
            {"name": "Act 2 - Confrontation", "percentage": 50, "scenes": ["Break into Two", "B Story", "Fun and Games", "Midpoint", "Bad Guys Close In", "All Is Lost", "Dark Night of Soul"]},
            {"name": "Act 3 - Resolution", "percentage": 25, "scenes": ["Break into Three", "Finale", "Final Image"]}
        ]
    }',
    true,
    '00000000-0000-0000-0000-000000000001'
),
(
    'Interview Setup',
    'Standard two-camera interview shot setup',
    'scene',
    '{
        "shots": [
            {"type": "medium", "movement": "static", "description": "Main camera A - subject", "duration": 0},
            {"type": "medium", "movement": "static", "description": "Camera B - interviewer", "duration": 0},
            {"type": "close-up", "movement": "static", "description": "Insert - hands/details", "duration": 3},
            {"type": "wide", "movement": "static", "description": "Establishing - both in frame", "duration": 5}
        ]
    }',
    true,
    '00000000-0000-0000-0000-000000000001'
);

-- ============================================================================
-- VERIFICATION QUERIES
-- ============================================================================

-- Run these to verify the seed data was created correctly:

-- SELECT * FROM public.profiles;
-- SELECT * FROM public.projects;
-- SELECT * FROM public.episodes WHERE project_id = '11111111-1111-1111-1111-111111111111';
-- SELECT * FROM public.scenes WHERE project_id = '11111111-1111-1111-1111-111111111111';
-- SELECT * FROM public.shots WHERE project_id = '11111111-1111-1111-1111-111111111111';
-- SELECT * FROM public.characters WHERE project_id = '11111111-1111-1111-1111-111111111111';
-- SELECT * FROM public.elements WHERE project_id = '11111111-1111-1111-1111-111111111111';
-- SELECT * FROM public.templates;
