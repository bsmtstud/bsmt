-- ============================================================================
-- THE BASEMENT - Supabase Database Schema
-- ============================================================================
-- Run this file first to create all tables
-- ============================================================================

-- Enable necessary extensions
CREATE EXTENSION IF NOT EXISTS "uuid-ossp";
CREATE EXTENSION IF NOT EXISTS "pgcrypto";

-- ============================================================================
-- ENUMS
-- ============================================================================

CREATE TYPE project_type AS ENUM ('short', 'film', 'series');
CREATE TYPE project_phase AS ENUM ('development', 'pre-production', 'production', 'post-production', 'complete');
CREATE TYPE film_style AS ENUM ('cinematic', 'documentary', 'animated', 'experimental');
CREATE TYPE video_style AS ENUM ('photorealistic', 'cinematic-color', 'noir', 'vintage', 'neon-noir', 'pastel');
CREATE TYPE generation_status AS ENUM ('pending', 'processing', 'completed', 'failed');
CREATE TYPE shot_type AS ENUM ('wide', 'medium', 'close-up', 'extreme-close-up', 'over-shoulder', 'pov', 'aerial', 'tracking');
CREATE TYPE camera_movement AS ENUM ('static', 'pan', 'tilt', 'dolly', 'crane', 'handheld', 'steadicam', 'drone');
CREATE TYPE collaborator_role AS ENUM ('owner', 'editor', 'viewer', 'commenter');

-- ============================================================================
-- USERS (extends Supabase auth.users)
-- ============================================================================

CREATE TABLE public.profiles (
    id UUID PRIMARY KEY REFERENCES auth.users(id) ON DELETE CASCADE,
    email TEXT,
    full_name TEXT,
    avatar_url TEXT,
    subscription_tier TEXT DEFAULT 'free', -- free, pro, studio
    generation_credits INTEGER DEFAULT 100,
    created_at TIMESTAMPTZ DEFAULT NOW(),
    updated_at TIMESTAMPTZ DEFAULT NOW()
);

-- ============================================================================
-- PROJECTS
-- ============================================================================

CREATE TABLE public.projects (
    id UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
    user_id UUID NOT NULL REFERENCES public.profiles(id) ON DELETE CASCADE,
    
    -- Basic Info
    title TEXT NOT NULL,
    project_type project_type NOT NULL DEFAULT 'film',
    phase project_phase NOT NULL DEFAULT 'development',
    
    -- Creative Info
    logline TEXT,
    theme TEXT,
    genre TEXT,
    subgenres TEXT[], -- Array of subgenre strings
    tones TEXT[], -- Array of tone strings
    
    -- Style Settings
    film_style film_style DEFAULT 'cinematic',
    video_style video_style DEFAULT 'cinematic-color',
    
    -- Structure (for series)
    seasons INTEGER DEFAULT 1,
    episodes_per_season INTEGER DEFAULT 10,
    episode_length INTEGER DEFAULT 45, -- minutes
    
    -- Structure (for films)
    runtime INTEGER DEFAULT 90, -- minutes
    
    -- AI Generator Preferences
    primary_image_generator TEXT DEFAULT 'flux-pro',
    primary_video_generator TEXT DEFAULT 'sora-2',
    
    -- Reference Info
    reference_studios TEXT,
    reference_films TEXT,
    
    -- Style Reference Images (Supabase Storage paths)
    style_ref_visual TEXT,
    style_ref_camera TEXT,
    style_ref_tone TEXT,
    style_ref_lighting TEXT,
    
    -- Metadata
    thumbnail_url TEXT,
    created_at TIMESTAMPTZ DEFAULT NOW(),
    updated_at TIMESTAMPTZ DEFAULT NOW(),
    last_accessed_at TIMESTAMPTZ DEFAULT NOW()
);

-- ============================================================================
-- EPISODES (for series projects)
-- ============================================================================

CREATE TABLE public.episodes (
    id UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
    project_id UUID NOT NULL REFERENCES public.projects(id) ON DELETE CASCADE,
    
    season_number INTEGER NOT NULL DEFAULT 1,
    episode_number INTEGER NOT NULL,
    title TEXT,
    synopsis TEXT,
    
    -- Episode-specific script
    script_content TEXT,
    script_version INTEGER DEFAULT 1,
    
    -- Duration
    target_duration INTEGER, -- minutes
    
    -- Status
    status TEXT DEFAULT 'draft', -- draft, in-progress, review, complete
    
    created_at TIMESTAMPTZ DEFAULT NOW(),
    updated_at TIMESTAMPTZ DEFAULT NOW(),
    
    UNIQUE(project_id, season_number, episode_number)
);

-- ============================================================================
-- SCENES
-- ============================================================================

CREATE TABLE public.scenes (
    id UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
    project_id UUID NOT NULL REFERENCES public.projects(id) ON DELETE CASCADE,
    episode_id UUID REFERENCES public.episodes(id) ON DELETE CASCADE, -- NULL for films
    
    scene_number INTEGER NOT NULL,
    title TEXT,
    description TEXT,
    
    -- Scene Details
    location TEXT,
    time_of_day TEXT, -- day, night, dawn, dusk, etc.
    mood TEXT,
    
    -- Script content for this scene
    script_content TEXT,
    
    -- Estimated duration in seconds
    estimated_duration INTEGER,
    
    -- Scene thumbnail (first shot or custom)
    thumbnail_url TEXT,
    
    -- Ordering
    sort_order INTEGER NOT NULL DEFAULT 0,
    
    created_at TIMESTAMPTZ DEFAULT NOW(),
    updated_at TIMESTAMPTZ DEFAULT NOW()
);

-- ============================================================================
-- SHOTS
-- ============================================================================

CREATE TABLE public.shots (
    id UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
    scene_id UUID NOT NULL REFERENCES public.scenes(id) ON DELETE CASCADE,
    project_id UUID NOT NULL REFERENCES public.projects(id) ON DELETE CASCADE,
    
    shot_number INTEGER NOT NULL,
    
    -- Shot Details
    shot_type shot_type DEFAULT 'medium',
    camera_movement camera_movement DEFAULT 'static',
    
    -- Description & Prompt
    description TEXT,
    visual_prompt TEXT, -- AI generation prompt
    
    -- Duration
    duration INTEGER DEFAULT 5, -- seconds
    
    -- Dialogue/Action
    dialogue TEXT,
    action_description TEXT,
    
    -- Technical Notes
    camera_notes TEXT,
    lighting_notes TEXT,
    audio_notes TEXT,
    
    -- Generated Content References
    selected_image_id UUID, -- Reference to selected generated image
    selected_video_id UUID, -- Reference to selected generated video
    
    -- Ordering
    sort_order INTEGER NOT NULL DEFAULT 0,
    
    created_at TIMESTAMPTZ DEFAULT NOW(),
    updated_at TIMESTAMPTZ DEFAULT NOW()
);

-- ============================================================================
-- CHARACTERS
-- ============================================================================

CREATE TABLE public.characters (
    id UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
    project_id UUID NOT NULL REFERENCES public.projects(id) ON DELETE CASCADE,
    
    name TEXT NOT NULL,
    role TEXT, -- protagonist, antagonist, supporting, etc.
    
    -- Physical Description
    age TEXT,
    gender TEXT,
    physical_description TEXT,
    
    -- Character Details
    personality TEXT,
    backstory TEXT,
    motivations TEXT,
    
    -- Visual Reference
    reference_prompt TEXT, -- Base prompt for generating this character
    primary_image_url TEXT, -- Main character reference image
    
    created_at TIMESTAMPTZ DEFAULT NOW(),
    updated_at TIMESTAMPTZ DEFAULT NOW()
);

-- ============================================================================
-- CHARACTER IMAGES (9-angle reference system)
-- ============================================================================

CREATE TABLE public.character_images (
    id UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
    character_id UUID NOT NULL REFERENCES public.characters(id) ON DELETE CASCADE,
    
    angle TEXT NOT NULL, -- front, front-left, left, back-left, back, back-right, right, front-right, above
    image_url TEXT NOT NULL,
    
    -- Generation info
    prompt_used TEXT,
    generator_used TEXT,
    generation_params JSONB,
    
    is_approved BOOLEAN DEFAULT FALSE,
    
    created_at TIMESTAMPTZ DEFAULT NOW()
);

-- ============================================================================
-- ELEMENTS (Props, Locations, Vehicles, etc.)
-- ============================================================================

CREATE TABLE public.elements (
    id UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
    project_id UUID NOT NULL REFERENCES public.projects(id) ON DELETE CASCADE,
    
    name TEXT NOT NULL,
    category TEXT NOT NULL, -- prop, location, vehicle, creature, effect, other
    description TEXT,
    
    -- Visual Reference
    reference_prompt TEXT,
    primary_image_url TEXT,
    
    -- Tags for searching
    tags TEXT[],
    
    created_at TIMESTAMPTZ DEFAULT NOW(),
    updated_at TIMESTAMPTZ DEFAULT NOW()
);

-- ============================================================================
-- GENERATED IMAGES
-- ============================================================================

CREATE TABLE public.generated_images (
    id UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
    project_id UUID NOT NULL REFERENCES public.projects(id) ON DELETE CASCADE,
    shot_id UUID REFERENCES public.shots(id) ON DELETE SET NULL,
    character_id UUID REFERENCES public.characters(id) ON DELETE SET NULL,
    element_id UUID REFERENCES public.elements(id) ON DELETE SET NULL,
    
    -- Generation Details
    prompt TEXT NOT NULL,
    negative_prompt TEXT,
    generator TEXT NOT NULL, -- flux-pro, nano-banana, midjourney, grok-imagine
    
    -- Generation Parameters
    params JSONB, -- width, height, seed, steps, etc.
    
    -- Result
    image_url TEXT,
    thumbnail_url TEXT,
    status generation_status DEFAULT 'pending',
    error_message TEXT,
    
    -- Metadata
    generation_time_ms INTEGER,
    cost_credits INTEGER DEFAULT 1,
    
    -- User feedback
    is_favorite BOOLEAN DEFAULT FALSE,
    rating INTEGER, -- 1-5
    
    created_at TIMESTAMPTZ DEFAULT NOW(),
    completed_at TIMESTAMPTZ
);

-- ============================================================================
-- GENERATED VIDEOS
-- ============================================================================

CREATE TABLE public.generated_videos (
    id UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
    project_id UUID NOT NULL REFERENCES public.projects(id) ON DELETE CASCADE,
    shot_id UUID REFERENCES public.shots(id) ON DELETE SET NULL,
    
    -- Source image (for img2vid)
    source_image_id UUID REFERENCES public.generated_images(id) ON DELETE SET NULL,
    source_image_url TEXT,
    
    -- Generation Details
    prompt TEXT NOT NULL,
    generator TEXT NOT NULL, -- sora-2, runway-gen3, kling-1.6, veo-2, minimax, luma-ray2
    
    -- Generation Parameters
    params JSONB, -- duration, fps, motion_amount, etc.
    target_duration INTEGER, -- seconds
    
    -- Result
    video_url TEXT,
    thumbnail_url TEXT,
    status generation_status DEFAULT 'pending',
    error_message TEXT,
    
    -- Actual result info
    actual_duration FLOAT,
    resolution TEXT,
    fps INTEGER,
    
    -- Metadata
    generation_time_ms INTEGER,
    cost_credits INTEGER DEFAULT 5,
    
    -- User feedback
    is_favorite BOOLEAN DEFAULT FALSE,
    rating INTEGER,
    
    created_at TIMESTAMPTZ DEFAULT NOW(),
    completed_at TIMESTAMPTZ
);

-- ============================================================================
-- GENERATION QUEUE (for N8N processing)
-- ============================================================================

CREATE TABLE public.generation_queue (
    id UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
    user_id UUID NOT NULL REFERENCES public.profiles(id) ON DELETE CASCADE,
    project_id UUID NOT NULL REFERENCES public.projects(id) ON DELETE CASCADE,
    
    -- What to generate
    generation_type TEXT NOT NULL, -- image, video, script, scene-breakdown
    
    -- Reference to the result table row
    result_table TEXT NOT NULL, -- generated_images, generated_videos
    result_id UUID NOT NULL,
    
    -- Processing
    status generation_status DEFAULT 'pending',
    priority INTEGER DEFAULT 5, -- 1-10, lower = higher priority
    
    -- Retry logic
    attempts INTEGER DEFAULT 0,
    max_attempts INTEGER DEFAULT 3,
    last_error TEXT,
    
    -- Timing
    created_at TIMESTAMPTZ DEFAULT NOW(),
    started_at TIMESTAMPTZ,
    completed_at TIMESTAMPTZ,
    
    -- N8N webhook info
    webhook_id TEXT,
    webhook_response JSONB
);

-- ============================================================================
-- COLLABORATION
-- ============================================================================

CREATE TABLE public.project_collaborators (
    id UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
    project_id UUID NOT NULL REFERENCES public.projects(id) ON DELETE CASCADE,
    user_id UUID NOT NULL REFERENCES public.profiles(id) ON DELETE CASCADE,
    
    role collaborator_role NOT NULL DEFAULT 'viewer',
    
    invited_by UUID REFERENCES public.profiles(id),
    invited_at TIMESTAMPTZ DEFAULT NOW(),
    accepted_at TIMESTAMPTZ,
    
    UNIQUE(project_id, user_id)
);

-- ============================================================================
-- COMMENTS
-- ============================================================================

CREATE TABLE public.comments (
    id UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
    project_id UUID NOT NULL REFERENCES public.projects(id) ON DELETE CASCADE,
    user_id UUID NOT NULL REFERENCES public.profiles(id) ON DELETE CASCADE,
    
    -- What the comment is on
    episode_id UUID REFERENCES public.episodes(id) ON DELETE CASCADE,
    scene_id UUID REFERENCES public.scenes(id) ON DELETE CASCADE,
    shot_id UUID REFERENCES public.shots(id) ON DELETE CASCADE,
    
    -- Reply threading
    parent_id UUID REFERENCES public.comments(id) ON DELETE CASCADE,
    
    content TEXT NOT NULL,
    
    -- Status
    is_resolved BOOLEAN DEFAULT FALSE,
    resolved_by UUID REFERENCES public.profiles(id),
    resolved_at TIMESTAMPTZ,
    
    created_at TIMESTAMPTZ DEFAULT NOW(),
    updated_at TIMESTAMPTZ DEFAULT NOW()
);

-- ============================================================================
-- VERSION HISTORY
-- ============================================================================

CREATE TABLE public.version_history (
    id UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
    project_id UUID NOT NULL REFERENCES public.projects(id) ON DELETE CASCADE,
    user_id UUID NOT NULL REFERENCES public.profiles(id) ON DELETE CASCADE,
    
    version_number TEXT NOT NULL,
    description TEXT,
    
    -- Snapshot of changes (could be JSON diff or full snapshot)
    changes JSONB,
    
    created_at TIMESTAMPTZ DEFAULT NOW()
);

-- ============================================================================
-- SHARE LINKS
-- ============================================================================

CREATE TABLE public.share_links (
    id UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
    project_id UUID NOT NULL REFERENCES public.projects(id) ON DELETE CASCADE,
    created_by UUID NOT NULL REFERENCES public.profiles(id) ON DELETE CASCADE,
    
    -- Link settings
    token TEXT UNIQUE NOT NULL DEFAULT encode(gen_random_bytes(32), 'hex'),
    
    permission collaborator_role DEFAULT 'viewer',
    password_hash TEXT, -- Optional password protection
    
    -- Expiration
    expires_at TIMESTAMPTZ,
    max_uses INTEGER,
    use_count INTEGER DEFAULT 0,
    
    -- Status
    is_active BOOLEAN DEFAULT TRUE,
    
    created_at TIMESTAMPTZ DEFAULT NOW()
);

-- ============================================================================
-- TEMPLATES
-- ============================================================================

CREATE TABLE public.templates (
    id UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
    
    -- Template info
    name TEXT NOT NULL,
    description TEXT,
    category TEXT, -- workflow, scene, shot, project
    
    -- Template content
    template_data JSONB NOT NULL,
    
    -- Visibility
    is_public BOOLEAN DEFAULT FALSE,
    created_by UUID REFERENCES public.profiles(id),
    
    -- Usage stats
    use_count INTEGER DEFAULT 0,
    
    created_at TIMESTAMPTZ DEFAULT NOW(),
    updated_at TIMESTAMPTZ DEFAULT NOW()
);

-- ============================================================================
-- USER SETTINGS
-- ============================================================================

CREATE TABLE public.user_settings (
    id UUID PRIMARY KEY REFERENCES public.profiles(id) ON DELETE CASCADE,
    
    -- Default AI preferences
    default_image_generator TEXT DEFAULT 'flux-pro',
    default_video_generator TEXT DEFAULT 'sora-2',
    
    -- UI preferences
    sidebar_collapsed BOOLEAN DEFAULT TRUE,
    theme TEXT DEFAULT 'dark',
    
    -- Notification preferences
    email_notifications BOOLEAN DEFAULT TRUE,
    generation_complete_notify BOOLEAN DEFAULT TRUE,
    collaboration_notify BOOLEAN DEFAULT TRUE,
    
    -- Default project settings
    default_project_type project_type DEFAULT 'film',
    default_film_style film_style DEFAULT 'cinematic',
    
    updated_at TIMESTAMPTZ DEFAULT NOW()
);

-- ============================================================================
-- INDEXES
-- ============================================================================

-- Projects
CREATE INDEX idx_projects_user_id ON public.projects(user_id);
CREATE INDEX idx_projects_phase ON public.projects(phase);
CREATE INDEX idx_projects_updated_at ON public.projects(updated_at DESC);

-- Episodes
CREATE INDEX idx_episodes_project_id ON public.episodes(project_id);
CREATE INDEX idx_episodes_season_episode ON public.episodes(project_id, season_number, episode_number);

-- Scenes
CREATE INDEX idx_scenes_project_id ON public.scenes(project_id);
CREATE INDEX idx_scenes_episode_id ON public.scenes(episode_id);
CREATE INDEX idx_scenes_sort_order ON public.scenes(project_id, sort_order);

-- Shots
CREATE INDEX idx_shots_scene_id ON public.shots(scene_id);
CREATE INDEX idx_shots_project_id ON public.shots(project_id);
CREATE INDEX idx_shots_sort_order ON public.shots(scene_id, sort_order);

-- Characters
CREATE INDEX idx_characters_project_id ON public.characters(project_id);

-- Elements
CREATE INDEX idx_elements_project_id ON public.elements(project_id);
CREATE INDEX idx_elements_category ON public.elements(project_id, category);

-- Generated content
CREATE INDEX idx_generated_images_project_id ON public.generated_images(project_id);
CREATE INDEX idx_generated_images_shot_id ON public.generated_images(shot_id);
CREATE INDEX idx_generated_images_status ON public.generated_images(status);
CREATE INDEX idx_generated_videos_project_id ON public.generated_videos(project_id);
CREATE INDEX idx_generated_videos_shot_id ON public.generated_videos(shot_id);
CREATE INDEX idx_generated_videos_status ON public.generated_videos(status);

-- Queue
CREATE INDEX idx_generation_queue_status ON public.generation_queue(status);
CREATE INDEX idx_generation_queue_user_id ON public.generation_queue(user_id);
CREATE INDEX idx_generation_queue_priority ON public.generation_queue(priority, created_at);

-- Collaboration
CREATE INDEX idx_collaborators_project_id ON public.project_collaborators(project_id);
CREATE INDEX idx_collaborators_user_id ON public.project_collaborators(user_id);
CREATE INDEX idx_comments_project_id ON public.comments(project_id);
CREATE INDEX idx_comments_scene_id ON public.comments(scene_id);

-- Share links
CREATE INDEX idx_share_links_token ON public.share_links(token);
CREATE INDEX idx_share_links_project_id ON public.share_links(project_id);
