# AI Generator Integration Guide

## Image Generators

### 1. Flux Pro (Black Forest Labs)
**Recommended for**: Photorealistic images, text rendering

```javascript
// API Endpoint
POST https://api.bfl.ml/v1/flux-pro-1.1

// Headers
X-Key: {BFL_API_KEY}
Content-Type: application/json

// Request Body
{
  "prompt": "A cinematic wide shot of a detective in a noir alley, rain falling, neon signs reflecting",
  "width": 1024,
  "height": 768,
  "seed": 12345, // optional, for reproducibility
  "guidance_scale": 7.5 // optional
}

// Response (sync)
{
  "id": "generation-id",
  "sample": "https://cdn.bfl.ml/images/xxx.png"
}
```

**Pricing**: ~$0.04 per image
**Max Resolution**: 2048x2048
**Best for**: Hero shots, establishing shots, detailed scenes

---

### 2. Nano Banana Pro (Banan)
**Recommended for**: Scene compositions with separate layers

```javascript
// API Endpoint
POST https://api.banan.ai/v1/generate

// Headers
Authorization: Bearer {BANAN_API_KEY}

// Request Body
{
  "prompt": "...",
  "mode": "scene", // Enables layer separation
  "output_layers": true,
  "width": 1024,
  "height": 576
}

// Response includes
{
  "composite": "url",
  "layers": {
    "background": "url",
    "midground": "url", 
    "foreground": "url",
    "lighting": "url"
  }
}
```

**Pricing**: ~$0.05 per image
**Unique Feature**: Separate background/lighting layers for compositing

---

### 3. Midjourney v6
**Access via**: Replicate or third-party API

```javascript
// Via Replicate
POST https://api.replicate.com/v1/predictions

// Headers
Authorization: Token {REPLICATE_API_TOKEN}

// Request Body
{
  "version": "midjourney-v6-model-id",
  "input": {
    "prompt": "...",
    "aspect_ratio": "16:9",
    "stylize": 100
  }
}

// Response (async)
{
  "id": "prediction-id",
  "status": "starting",
  "urls": {
    "get": "https://api.replicate.com/v1/predictions/{id}",
    "cancel": "..."
  }
}

// Poll for completion
GET https://api.replicate.com/v1/predictions/{id}
```

**Pricing**: ~$0.05-0.10 per image
**Best for**: Artistic, stylized imagery

---

### 4. Grok Imagine (xAI)
**Recommended for**: Fast iterations, creative concepts

```javascript
// API Endpoint
POST https://api.x.ai/v1/images/generate

// Headers
Authorization: Bearer {XAI_API_KEY}

// Request Body
{
  "prompt": "...",
  "model": "grok-imagine-v1",
  "size": "1024x1024"
}
```

**Pricing**: TBD (currently in beta)
**Best for**: Quick concept art, rapid iteration

---

## Video Generators

### 1. Sora 2 (OpenAI)
**Max Duration**: 20 seconds
**Quality**: Highest

```javascript
// API Endpoint (when available)
POST https://api.openai.com/v1/videos/generate

// Headers
Authorization: Bearer {OPENAI_API_KEY}

// Request Body
{
  "model": "sora-2",
  "prompt": "Camera slowly pans across a rainy cityscape at night",
  "duration": 10,
  "resolution": "1080p",
  "fps": 24
}

// Response (async)
{
  "id": "video-id",
  "status": "processing"
}
```

---

### 2. Runway Gen-3 Alpha
**Max Duration**: 10 seconds
**Best for**: Image-to-video

```javascript
// API Endpoint
POST https://api.runwayml.com/v1/image_to_video

// Headers
Authorization: Bearer {RUNWAY_API_KEY}

// Request Body
{
  "promptImage": "https://... or base64",
  "promptText": "The camera slowly pushes in as rain begins to fall",
  "seed": 12345,
  "duration": 5, // 5 or 10 seconds
  "ratio": "16:9"
}

// Response
{
  "id": "task-id",
  "status": "PENDING"
}

// Poll status
GET https://api.runwayml.com/v1/tasks/{id}
```

**Pricing**: ~$0.50 per 5 seconds

---

### 3. Kling 1.6 (Kuaishou)
**Max Duration**: 10 seconds
**Best for**: Fast generation

```javascript
// API Endpoint
POST https://api.klingai.com/v1/videos/generate

// Headers
Authorization: Bearer {KLING_API_KEY}

// Request Body
{
  "prompt": "...",
  "image_url": "optional source image",
  "duration": 5,
  "mode": "standard" // or "pro"
}
```

**Pricing**: ~$0.20 per video

---

### 4. Veo 2 (Google)
**Max Duration**: 60 seconds
**Best for**: Long-form content

```javascript
// Via Vertex AI
POST https://us-central1-aiplatform.googleapis.com/v1/projects/{project}/locations/us-central1/publishers/google/models/veo-2:generate

// Headers
Authorization: Bearer {GOOGLE_ACCESS_TOKEN}

// Request Body
{
  "instances": [{
    "prompt": "...",
    "duration": 30
  }],
  "parameters": {
    "resolution": "1080p"
  }
}
```

---

### 5. Minimax
**Max Duration**: 6 seconds
**Best for**: Quick clips

```javascript
POST https://api.minimax.chat/v1/video/generate

// Headers
Authorization: Bearer {MINIMAX_API_KEY}

// Request Body
{
  "prompt": "...",
  "model": "video-01",
  "image_url": "optional"
}
```

---

### 6. Luma Ray 2
**Max Duration**: 9 seconds
**Best for**: Cinematic motion

```javascript
POST https://api.lumalabs.ai/v1/generations

// Headers
Authorization: Bearer {LUMA_API_KEY}

// Request Body
{
  "prompt": "...",
  "keyframes": {
    "frame0": { "image_url": "..." }
  },
  "model": "ray2",
  "duration": 5
}
```

---

## LLM Integration (Claude)

### Script Generation

```javascript
POST https://api.anthropic.com/v1/messages

// Headers
x-api-key: {ANTHROPIC_API_KEY}
anthropic-version: 2023-06-01
Content-Type: application/json

// Request Body
{
  "model": "claude-sonnet-4-20250514",
  "max_tokens": 4096,
  "system": "You are an expert screenwriter...",
  "messages": [
    {
      "role": "user",
      "content": "Write a script for Episode 1 of my series..."
    }
  ]
}
```

### Scene Breakdown

```javascript
// System prompt for scene breakdown
const systemPrompt = `You are a professional film director and cinematographer.
Analyze the provided script excerpt and break it down into individual shots.

For each shot, provide:
1. Shot type (wide, medium, close-up, etc.)
2. Camera movement (static, pan, dolly, etc.)
3. Duration estimate in seconds
4. Visual description for AI generation
5. Any dialogue or action

Return as JSON array:
[
  {
    "shot_type": "wide",
    "camera_movement": "static",
    "duration": 5,
    "visual_prompt": "Establishing shot of city skyline at dusk...",
    "dialogue": null,
    "action": "Camera holds on city view"
  },
  ...
]`;
```

---

## Character Consistency

### 9-Angle Reference System

Generate character from 9 angles for consistency:

```javascript
const angles = [
  'front',
  'front-left (3/4 view)',
  'left (profile)',
  'back-left',
  'back',
  'back-right',
  'right (profile)',
  'front-right (3/4 view)',
  'above (bird\'s eye)'
];

// Base prompt structure
const generateCharacterPrompt = (character, angle) => {
  return `${character.physical_description}, ${angle} view, 
character reference sheet, neutral pose, studio lighting, 
white background, consistent style --seed ${character.seed}`;
};
```

### Maintaining Consistency Across Shots

```javascript
// Include character references in shot prompts
const buildShotPrompt = (shot, characters) => {
  const characterRefs = characters.map(c => 
    `[${c.name}: ${c.physical_description}]`
  ).join(' ');
  
  return `${shot.visual_prompt}
Characters in scene: ${characterRefs}
Style: ${project.film_style}, ${project.video_style}
Lighting: ${shot.lighting_notes || 'cinematic'}`;
};
```

---

## Best Practices

### 1. Prompt Engineering
- Be specific about camera angles and movements
- Include lighting and mood descriptors
- Reference style consistently across prompts
- Use negative prompts to avoid common issues

### 2. Cost Optimization
- Generate thumbnails first (lower resolution)
- Use fast generators for iteration
- Reserve high-quality generators for final shots
- Implement credit limits per user

### 3. Error Handling
- Implement retry logic with exponential backoff
- Store failed attempts for debugging
- Refund credits on generation failure
- Provide user feedback on queue status

### 4. Quality Control
- Allow users to rate generations
- Track which prompts produce best results
- Build prompt templates from successful generations
