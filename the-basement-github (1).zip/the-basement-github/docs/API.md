# The Basement - API Endpoints

## Overview

The Basement uses Supabase as the backend, which provides:
- RESTful API via PostgREST
- Realtime subscriptions
- Storage API
- Edge Functions (for custom logic)

## Authentication

All API calls require authentication via Supabase Auth.

```javascript
import { createClient } from '@supabase/supabase-js'

const supabase = createClient(SUPABASE_URL, SUPABASE_ANON_KEY)

// Sign up
const { data, error } = await supabase.auth.signUp({
  email: 'user@example.com',
  password: 'password123'
})

// Sign in
const { data, error } = await supabase.auth.signInWithPassword({
  email: 'user@example.com',
  password: 'password123'
})

// Get current user
const { data: { user } } = await supabase.auth.getUser()
```

## REST Endpoints

Base URL: `https://your-project.supabase.co/rest/v1`

### Projects

#### List Projects
```
GET /projects?user_id=eq.{user_id}&order=updated_at.desc
```

#### Get Project
```
GET /projects?id=eq.{id}&select=*,episodes(*),characters(*)
```

#### Create Project
```
POST /projects
Body: { title, project_type, ... }
```

#### Update Project
```
PATCH /projects?id=eq.{id}
Body: { title, phase, ... }
```

#### Delete Project
```
DELETE /projects?id=eq.{id}
```

### Episodes

#### List Episodes
```
GET /episodes?project_id=eq.{project_id}&order=season_number,episode_number
```

#### Get Episode with Scenes
```
GET /episodes?id=eq.{id}&select=*,scenes(*)
```

#### Update Episode
```
PATCH /episodes?id=eq.{id}
Body: { title, synopsis, script_content, ... }
```

### Scenes

#### List Scenes
```
GET /scenes?project_id=eq.{project_id}&order=sort_order
# OR for specific episode
GET /scenes?episode_id=eq.{episode_id}&order=sort_order
```

#### Get Scene with Shots
```
GET /scenes?id=eq.{id}&select=*,shots(*)
```

#### Create Scene
```
POST /scenes
Body: { project_id, episode_id, scene_number, title, ... }
```

#### Reorder Scenes
```
POST /rpc/reorder_scenes
Body: { scene_ids: ['uuid1', 'uuid2', ...] }
```

### Shots

#### List Shots
```
GET /shots?scene_id=eq.{scene_id}&order=sort_order
```

#### Get Shot with Generations
```
GET /shots?id=eq.{id}&select=*,generated_images(*),generated_videos(*)
```

#### Create Shot
```
POST /shots
Body: { scene_id, project_id, shot_number, shot_type, ... }
```

#### Batch Create Shots (from scene breakdown)
```
POST /shots
Body: [{ shot1 }, { shot2 }, ...]
```

### Characters

#### List Characters
```
GET /characters?project_id=eq.{project_id}&order=name
```

#### Get Character with Images
```
GET /characters?id=eq.{id}&select=*,character_images(*)
```

#### Create Character
```
POST /characters
Body: { project_id, name, role, physical_description, ... }
```

### Elements

#### List Elements
```
GET /elements?project_id=eq.{project_id}&order=category,name
```

#### Filter by Category
```
GET /elements?project_id=eq.{project_id}&category=eq.prop
```

#### Search Elements
```
GET /elements?project_id=eq.{project_id}&name=ilike.*search*
```

### Generated Images

#### List for Shot
```
GET /generated_images?shot_id=eq.{shot_id}&order=created_at.desc
```

#### List for Project
```
GET /generated_images?project_id=eq.{project_id}&status=eq.completed&order=created_at.desc&limit=50
```

#### Get Favorites
```
GET /generated_images?project_id=eq.{project_id}&is_favorite=eq.true
```

### Generated Videos

#### List for Shot
```
GET /generated_videos?shot_id=eq.{shot_id}&order=created_at.desc
```

#### List Pending
```
GET /generated_videos?project_id=eq.{project_id}&status=in.(pending,processing)
```

### Generation Queue

#### Get User Queue
```
GET /generation_queue?user_id=eq.{user_id}&status=in.(pending,processing)&order=created_at
```

#### Queue Status Counts
```
GET /generation_queue?user_id=eq.{user_id}&select=status&status=in.(pending,processing,completed,failed)
```

### Collaboration

#### List Collaborators
```
GET /project_collaborators?project_id=eq.{project_id}&select=*,profiles(*)
```

#### Add Collaborator
```
POST /project_collaborators
Body: { project_id, user_id, role, invited_by }
```

#### Remove Collaborator
```
DELETE /project_collaborators?project_id=eq.{project_id}&user_id=eq.{user_id}
```

### Comments

#### List Comments for Project
```
GET /comments?project_id=eq.{project_id}&order=created_at.desc&select=*,profiles(full_name,avatar_url)
```

#### List Comments for Scene
```
GET /comments?scene_id=eq.{scene_id}&order=created_at
```

#### Create Comment
```
POST /comments
Body: { project_id, user_id, scene_id, content }
```

#### Resolve Comment
```
PATCH /comments?id=eq.{id}
Body: { is_resolved: true, resolved_by: user_id, resolved_at: now() }
```

### Share Links

#### Create Share Link
```
POST /share_links
Body: { project_id, created_by, permission, expires_at, max_uses }
```

#### Validate Link (RPC)
```
POST /rpc/validate_share_link
Body: { link_token: "abc123", password_attempt: "optional" }
```

#### Deactivate Link
```
PATCH /share_links?id=eq.{id}
Body: { is_active: false }
```

## RPC Functions

### Get Next Queue Item
```
POST /rpc/get_next_queue_item
Returns: Queue item or null
```

### Complete Queue Item
```
POST /rpc/complete_queue_item
Body: { queue_id: "uuid", success: true, error_msg: null }
```

### Get Project Stats
```
POST /rpc/get_project_stats
Body: { project_uuid: "uuid" }
Returns: { total_episodes, total_scenes, total_shots, ... }
```

### Deduct Credits
```
POST /rpc/deduct_generation_credits
Body: { user_uuid: "uuid", credits: 5 }
Returns: boolean (true if successful)
```

### Create Version Snapshot
```
POST /rpc/create_version_snapshot
Body: { project_uuid, user_uuid, version_num: "1.0", change_description: "Initial" }
Returns: version_id
```

### Duplicate Project
```
POST /rpc/duplicate_project
Body: { source_project_id: "uuid", new_title: "Copy of Project" }
Returns: new_project_id
```

## Realtime Subscriptions

### Subscribe to Generation Updates
```javascript
const subscription = supabase
  .channel('generation-updates')
  .on(
    'postgres_changes',
    {
      event: 'UPDATE',
      schema: 'public',
      table: 'generated_images',
      filter: `project_id=eq.${projectId}`
    },
    (payload) => {
      console.log('Image updated:', payload.new)
    }
  )
  .subscribe()
```

### Subscribe to Comments
```javascript
const subscription = supabase
  .channel('comments')
  .on(
    'postgres_changes',
    {
      event: 'INSERT',
      schema: 'public',
      table: 'comments',
      filter: `project_id=eq.${projectId}`
    },
    handleNewComment
  )
  .subscribe()
```

## Storage API

### Upload Image
```javascript
const { data, error } = await supabase.storage
  .from('project-assets')
  .upload(`${projectId}/images/${filename}`, file)
```

### Get Public URL
```javascript
const { data } = supabase.storage
  .from('project-assets')
  .getPublicUrl(`${projectId}/images/${filename}`)
```

### Upload Style Reference
```javascript
const { data, error } = await supabase.storage
  .from('style-references')
  .upload(`${projectId}/visual.jpg`, file)
```

## N8N Webhook Endpoints

### Generate Script
```
POST https://n8n.your-domain.com/webhook/generate-script
Headers: Authorization: Bearer {n8n_api_key}
Body: {
  project_id: "uuid",
  episode_id: "uuid",
  prompt: "Additional instructions..."
}
```

### Breakdown Scene
```
POST https://n8n.your-domain.com/webhook/breakdown-scene
Body: {
  project_id: "uuid",
  scene_id: "uuid",
  script_content: "Scene script..."
}
```

### Queue Image Generation
```javascript
// Insert into generated_images first
const { data: image } = await supabase
  .from('generated_images')
  .insert({ project_id, shot_id, prompt, generator, status: 'pending' })
  .select()
  .single()

// Then queue it
await supabase
  .from('generation_queue')
  .insert({
    user_id,
    project_id,
    generation_type: 'image',
    result_table: 'generated_images',
    result_id: image.id
  })
```

## Error Handling

All Supabase errors follow this structure:
```javascript
{
  message: "Error description",
  code: "PGRST116", // PostgreSQL error code
  details: "Additional details",
  hint: "Suggestion for fixing"
}
```

Common error codes:
- `PGRST116` - No rows returned (not found)
- `23505` - Unique constraint violation
- `23503` - Foreign key violation
- `42501` - Permission denied (RLS)

## Rate Limiting

- Supabase has built-in rate limiting
- Generation APIs have custom limits via N8N
- Recommended: Implement client-side debouncing for frequent operations
