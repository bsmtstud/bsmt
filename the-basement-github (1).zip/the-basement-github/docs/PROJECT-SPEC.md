# The Basement - Project Specification

## Product Overview

**The Basement** is an AI-powered video production platform that guides creators from initial concept through to final cut. It combines traditional production workflows with modern AI generation capabilities.

## Core User Flow

```
Landing Page → Sign Up → Dashboard → New Project Wizard → Episode Setup → Storyboard → Export
```

## Pages & Views

### 1. Landing Page (`/`)
- Hero section with animated gradient
- Feature highlights
- CTA to sign up / sign in

### 2. Dashboard / Home (`/home`)
- Welcome message with user name
- Statistics cards (total projects, scenes, shots, AI generations)
- "Continue Where You Left Off" - recent project with quick resume
- Quick Actions grid

### 3. Projects Page (`/projects`)
- Project grid/list view with thumbnails
- Search bar
- Filter by phase (All, Development, Pre-production, Production, Post-production, Complete)
- Quick actions per project (Open, Duplicate, Archive, Delete)
- "New Project" button

### 4. New Project Wizard (`/projects/new`)
3-step wizard:

**Step 1 - Details**:
- Project Type (Short Film, Feature Film, Series)
- Title
- For Series: Seasons, Episodes/Season, Episode Length
- For Film: Runtime
- Overview stats

**Step 2 - Technical**:
- Film Style (Cinematic, Documentary, Animated, Experimental)
- Video Style (Photorealistic, Cinematic Color, Noir, Vintage, Neon Noir, Pastel)
- AI Image Generator selection
- AI Video Generator selection

**Step 3 - Creative**:
- Creative Directive / Project Logline
- Theme
- Genre & Subgenres
- Tones
- Reference Studios
- Reference Films/Shows
- Style Reference Images (4 upload slots)
- Project Summary

### 5. Episode Setup (`/projects/:id/episodes/:episodeId`)
Main production workspace with tabs:

**Details Tab**:
- Episode metadata (title, synopsis)
- Target duration

**Script Tab**:
- Full script editor
- AI script generation
- Version history

**Scenes & Cast Tab**:
- Scene list with drag-drop reorder
- Character management
- Elements library

**Storyboard Tab**:
- Visual shot board
- Quick shot editing
- Navigate to full storyboard view

### 6. Storyboard View (`/projects/:id/storyboard`)
Full storyboard editing:
- Scene panels with shots
- Shot cards with:
  - Thumbnail
  - Shot type, camera movement
  - Duration
  - Dialogue/action
  - AI generation controls
- Drag-drop reordering
- Batch generation

### 7. Gen Space (`/gen-space`)
Standalone AI generation playground:
- Text-to-image generation
- Image-to-video generation
- Element browser (use existing characters/elements)
- Generation history
- Save to Elements or directly to shots

### 8. Elements Library (`/elements`)
Centralized asset management:
- Characters with 9-angle reference system
- Props, Locations, Vehicles, Creatures, Effects
- Search and filter
- Bulk import/export
- "Use in Gen Space" quick action

### 9. Promo Studio (`/promo-studio`)
Marketing asset creation:
- Project selector
- Template categories (Posters, Social, Trailers, Behind-the-scenes)
- AI-assisted generation

### 10. Templates (`/templates`)
Workflow templates:
- Pre-built project structures
- Scene/shot templates
- Community templates
- Save custom templates

### 11. Settings (`/settings`)
User preferences:
- Account settings
- Default AI preferences
- UI preferences
- Notification settings
- Subscription management

## Data Models

### Project
```typescript
interface Project {
  id: string;
  userId: string;
  title: string;
  projectType: 'short' | 'film' | 'series';
  phase: 'development' | 'pre-production' | 'production' | 'post-production' | 'complete';
  
  // Creative
  logline?: string;
  theme?: string;
  genre?: string;
  subgenres?: string[];
  tones?: string[];
  
  // Style
  filmStyle?: 'cinematic' | 'documentary' | 'animated' | 'experimental';
  videoStyle?: string;
  
  // Structure
  seasons?: number;
  episodesPerSeason?: number;
  episodeLength?: number;
  runtime?: number;
  
  // AI Preferences
  primaryImageGenerator?: string;
  primaryVideoGenerator?: string;
  
  // References
  referenceStudios?: string;
  referenceFilms?: string;
  styleRefVisual?: string;
  styleRefCamera?: string;
  styleRefTone?: string;
  styleRefLighting?: string;
  
  // Metadata
  thumbnailUrl?: string;
  createdAt: Date;
  updatedAt: Date;
}
```

### Episode
```typescript
interface Episode {
  id: string;
  projectId: string;
  seasonNumber: number;
  episodeNumber: number;
  title?: string;
  synopsis?: string;
  scriptContent?: string;
  targetDuration?: number;
  status: 'draft' | 'in-progress' | 'review' | 'complete';
}
```

### Scene
```typescript
interface Scene {
  id: string;
  projectId: string;
  episodeId?: string;
  sceneNumber: number;
  title?: string;
  description?: string;
  location?: string;
  timeOfDay?: string;
  mood?: string;
  scriptContent?: string;
  estimatedDuration?: number;
  sortOrder: number;
}
```

### Shot
```typescript
interface Shot {
  id: string;
  sceneId: string;
  projectId: string;
  shotNumber: number;
  shotType: 'wide' | 'medium' | 'close-up' | 'extreme-close-up' | 'over-shoulder' | 'pov' | 'aerial' | 'tracking';
  cameraMovement: 'static' | 'pan' | 'tilt' | 'dolly' | 'crane' | 'handheld' | 'steadicam' | 'drone';
  description?: string;
  visualPrompt?: string;
  duration: number;
  dialogue?: string;
  actionDescription?: string;
  selectedImageId?: string;
  selectedVideoId?: string;
  sortOrder: number;
}
```

### Character
```typescript
interface Character {
  id: string;
  projectId: string;
  name: string;
  role?: string;
  age?: string;
  gender?: string;
  physicalDescription?: string;
  personality?: string;
  backstory?: string;
  motivations?: string;
  referencePrompt?: string;
  primaryImageUrl?: string;
}
```

### Element
```typescript
interface Element {
  id: string;
  projectId: string;
  name: string;
  category: 'prop' | 'location' | 'vehicle' | 'creature' | 'effect' | 'other';
  description?: string;
  referencePrompt?: string;
  primaryImageUrl?: string;
  tags?: string[];
}
```

## AI Integration Points

### 1. Script Generation
- Input: Project context, characters, episode details, user prompt
- Output: Formatted screenplay text
- API: Claude (Anthropic)

### 2. Scene Breakdown
- Input: Script text
- Output: Array of shot objects with suggested types, durations, prompts
- API: Claude (Anthropic)

### 3. Image Generation
- Input: Visual prompt, style settings, character/element references
- Output: Generated image URL
- APIs: Flux Pro, Nano Banana Pro, Midjourney, Grok Imagine

### 4. Video Generation
- Input: Source image, motion prompt, duration
- Output: Generated video URL
- APIs: Sora 2, Runway Gen-3, Kling 1.6, Veo 2, Minimax, Luma Ray 2

### 5. Character Reference Generation
- Input: Character description, angle (9-angle system)
- Output: Consistent character images from multiple angles
- Special handling for consistency across angles

## UI Components

### Reusable Components
- `Button` - Primary, secondary, ghost, danger variants
- `Input` - Text, number, textarea
- `Select` - Dropdown selection
- `Modal` - Dialog overlay
- `Card` - Content container
- `Tabs` - Tab navigation
- `ProgressSteps` - Wizard step indicator
- `Badge` - Status/tag badges
- `Tooltip` - Hover information
- `DropdownMenu` - Action menus

### Feature Components
- `ProjectCard` - Project thumbnail with actions
- `ScenePanel` - Scene container for storyboard
- `ShotCard` - Individual shot display/edit
- `CharacterCard` - Character display with images
- `ElementCard` - Element display
- `GenerationPanel` - AI generation controls
- `PromptEditor` - Rich prompt editing modal
- `TimelineView` - Horizontal shot timeline

## State Management

### Global State (Context/Zustand)
- Current user
- Current project
- UI preferences (sidebar collapsed, theme)
- Generation queue status

### Local State
- Form inputs
- Modal open/close
- Selection states
- Drag-drop state

## Real-time Features

### Supabase Realtime
- Generation status updates
- Collaboration cursor positions
- Comment notifications
- Project changes (for collaborators)

## Export Formats

### Storyboard Export
- PDF with shot thumbnails
- Image sequence (ZIP)

### Shot List Export
- CSV with all shot details
- PDF formatted table

### Script Export
- Plain text (.txt)
- Final Draft (.fdx)
- PDF formatted

### Project Export
- Full JSON backup
- Selective data export

## Collaboration Features

### Share Links
- View-only access
- Comment-only access
- Edit access
- Password protection
- Expiration dates

### Comments
- Thread on any element (episode, scene, shot)
- @mentions
- Resolution tracking
- Email notifications

### Version History
- Auto-save versions
- Manual version snapshots
- Restore previous versions
- Diff view

## Subscription Tiers (Future)

### Free
- 3 projects
- 100 generation credits/month
- Basic export

### Pro ($19/mo)
- Unlimited projects
- 1000 generation credits/month
- All export formats
- Priority generation queue

### Studio ($49/mo)
- Everything in Pro
- 5000 generation credits/month
- Team collaboration (5 seats)
- API access
- Custom templates

## Performance Considerations

### Image Optimization
- Thumbnails generated on upload
- Lazy loading for galleries
- WebP format where supported

### Data Loading
- Pagination for lists
- Infinite scroll for timelines
- Optimistic updates

### Caching
- Browser cache for static assets
- Supabase cache for repeated queries
- Service worker for offline support

## Security

### Authentication
- Email/password
- OAuth (Google, GitHub)
- Magic links

### Authorization
- Row Level Security in Supabase
- Project-based access control
- Share link validation

### Data Protection
- All API keys server-side only
- Signed URLs for private assets
- Rate limiting on generation APIs
