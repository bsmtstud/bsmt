# The Basement - Builder Handoff Package

## Overview
**The Basement** is an AI-powered video production platform that guides creators from concept to final cut. This package contains everything needed to build the production application.

## Package Contents

```
BOLT-HANDOFF/
├── README.md                    # This file
├── App.jsx                      # Complete React UI (21,493 lines)
├── PROJECT-SPEC.md              # Detailed feature specification
├── DATABASE/
│   ├── supabase-schema.sql      # Complete Supabase schema
│   ├── supabase-rls.sql         # Row Level Security policies
│   ├── supabase-functions.sql   # Database functions & triggers
│   └── supabase-seed.sql        # Sample data for testing
├── API/
│   ├── api-endpoints.md         # REST API specification
│   └── api-types.ts             # TypeScript types
├── N8N/
│   ├── n8n-workflows.json       # N8N workflow definitions
│   └── n8n-setup.md             # N8N configuration guide
├── AI-INTEGRATIONS/
│   ├── image-generators.md      # Image AI setup (Flux, Midjourney, etc.)
│   ├── video-generators.md      # Video AI setup (Sora, Runway, etc.)
│   └── llm-integration.md       # Claude/LLM integration guide
└── ENV-TEMPLATE.env             # Environment variables template
```

## Tech Stack

### Frontend
- **React 18** with hooks
- **Tailwind CSS** (utility classes used inline)
- **Lucide Icons** (currently inline SVGs)

### Backend
- **Supabase** (PostgreSQL + Auth + Storage + Realtime)
- **N8N** (Workflow automation for AI generation queues)

### AI Services
- **Image Generation**: Flux Pro, Nano Banana Pro, Midjourney v6, Grok Imagine
- **Video Generation**: Sora 2, Runway Gen-3, Kling 1.6, Veo 2, Minimax, Luma Ray 2
- **LLM**: Claude (script generation, scene breakdown, shot suggestions)

## Quick Start for Bolt

1. **Create new Bolt project** with React + Vite template
2. **Copy App.jsx** as the main component
3. **Set up Supabase**:
   - Create new Supabase project
   - Run `supabase-schema.sql`
   - Run `supabase-rls.sql`
   - Run `supabase-functions.sql`
4. **Configure environment** using `ENV-TEMPLATE.env`
5. **Set up N8N** workflows for AI generation queues

## Key Features to Implement

### Phase 1 - Core (MVP)
- [ ] User authentication (Supabase Auth)
- [ ] Project CRUD operations
- [ ] Episode/Scene/Shot management
- [ ] Basic script editor
- [ ] Storyboard view

### Phase 2 - AI Integration
- [ ] Image generation queue (N8N)
- [ ] Video generation queue (N8N)
- [ ] Script generation (Claude API)
- [ ] Scene breakdown AI

### Phase 3 - Collaboration
- [ ] Real-time collaboration (Supabase Realtime)
- [ ] Comments system
- [ ] Version history
- [ ] Share links

### Phase 4 - Export & Polish
- [ ] Export to various formats
- [ ] Promo Studio
- [ ] Templates system
- [ ] Gen Space (standalone generation)

## Database Relationships

```
users
  └── projects (1:many)
        ├── episodes (1:many) [for series]
        │     └── scenes (1:many)
        │           └── shots (1:many)
        │                 ├── generated_images (1:many)
        │                 └── generated_videos (1:many)
        ├── characters (1:many)
        │     └── character_images (1:many)
        ├── elements (1:many)
        └── project_collaborators (many:many with users)
```

## Important Notes

1. **The App.jsx is a complete UI prototype** - All views are functional but use mock data
2. **AI integrations are mocked** - Need real API connections via N8N
3. **File uploads are mocked** - Need Supabase Storage integration
4. **Auth is not implemented** - Need Supabase Auth setup

## Contact
Questions about this handoff? Check the PROJECT-SPEC.md for detailed feature documentation.
