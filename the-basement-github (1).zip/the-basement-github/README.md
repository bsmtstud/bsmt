# The Basement 🎬

AI-powered video production platform. From concept to final cut.

![The Basement](https://via.placeholder.com/1200x600/0a0a0f/8b5cf6?text=The+Basement)

## Overview

The Basement is an AI-powered video production platform that guides creators from initial concept through to final cut. It combines traditional production workflows with modern AI generation capabilities.

## Features

- 🎬 **Project Management** - Organize films, series, and shorts
- 📝 **Script Generation** - AI-assisted screenplay writing
- 🎨 **Storyboard Creation** - Visual shot planning with AI image generation
- 🎭 **Character Management** - 9-angle reference system for consistency
- 🎥 **Video Generation** - AI-powered video from images
- 👥 **Collaboration** - Share, comment, and version control
- 📤 **Export** - PDF storyboards, CSV shot lists, Final Draft scripts

## Tech Stack

- **Frontend**: React 18 + Vite + Tailwind CSS
- **Backend**: Supabase (PostgreSQL + Auth + Storage + Realtime)
- **Automation**: N8N for AI generation queues
- **AI Services**:
  - Images: Flux Pro, Nano Banana Pro, Midjourney, Grok Imagine
  - Videos: Sora 2, Runway Gen-3, Kling 1.6, Veo 2, Minimax, Luma Ray 2
  - LLM: Claude (Anthropic)

## Quick Start

### Prerequisites

- Node.js 18+
- Supabase account
- API keys for AI services (see `.env.example`)

### Installation

```bash
# Clone the repo
git clone https://github.com/yourusername/the-basement.git
cd the-basement

# Install dependencies
npm install

# Copy environment file
cp .env.example .env

# Fill in your API keys in .env

# Start development server
npm run dev
```

### Database Setup

1. Create a new Supabase project
2. Run the SQL migrations in order:

```bash
# In Supabase SQL Editor, run these files:
supabase/migrations/001_schema.sql
supabase/migrations/002_rls.sql
supabase/migrations/003_functions.sql
supabase/migrations/004_seed.sql  # Optional: sample data
```

3. Copy your Supabase URL and anon key to `.env`

## Project Structure

```
the-basement/
├── src/
│   ├── App.jsx          # Main application (all components)
│   ├── main.jsx         # Entry point
│   ├── index.css        # Global styles + Tailwind
│   └── types.ts         # TypeScript definitions
├── supabase/
│   └── migrations/      # SQL files for database
├── n8n/
│   ├── workflows.json   # N8N workflow definitions
│   └── README.md        # N8N setup guide
├── docs/
│   ├── PROJECT-SPEC.md  # Feature specification
│   ├── API.md           # API documentation
│   └── AI-INTEGRATIONS.md
├── package.json
├── vite.config.js
├── tailwind.config.js
└── .env.example
```

## Documentation

- [Project Specification](./docs/PROJECT-SPEC.md) - Detailed feature docs
- [API Documentation](./docs/API.md) - REST endpoints
- [AI Integrations](./docs/AI-INTEGRATIONS.md) - AI service setup
- [N8N Setup](./n8n/README.md) - Workflow automation

## Roadmap

### Phase 1 - Core MVP
- [x] UI/UX complete
- [ ] Supabase Auth integration
- [ ] Database CRUD operations
- [ ] File upload to Storage

### Phase 2 - AI Integration
- [ ] N8N workflow setup
- [ ] Image generation queue
- [ ] Video generation queue
- [ ] Script generation (Claude)

### Phase 3 - Collaboration
- [ ] Real-time collaboration
- [ ] Comments system
- [ ] Version history

### Phase 4 - Export & Polish
- [ ] PDF export
- [ ] Final Draft export
- [ ] Payment/subscription

## Contributing

Contributions are welcome! Please read our contributing guidelines first.

## License

MIT License - see [LICENSE](./LICENSE) for details.

---

Built with ❤️ by The Basement Team
